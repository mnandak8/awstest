from main.corelibs.utils.config_util import ConfigUtil
import pytest


@pytest.fixture(scope='function')
def setup():
    return ConfigUtil('application/src/test/config/etl.conf')
    
def test_load_config(setup):
    cfg = setup.config()
    assert len(cfg) == 2


def test_config(setup):
    cfg = setup.config()
    assert cfg != None and len(cfg) == 2

    tb1 = cfg['tb1']
    assert len(tb1) == 2

    tb1_transform_cfg = tb1['update']
    assert tb1_transform_cfg == [['drg definition', 'string', 'drg', 'string'], 
                                 ['provider id', 'long', 'provider.id', 'long'], 
                                 ['provider name', 'string', 'provider.name', 'string'], 
                                 ['provider city', 'string', 'provider.city', 'string'], 
                                 ['provider state', 'string', 'provider.state', 'string'], 
                                 ['provider zip code', 'long', 'provider.zip', 'long'], 
                                 ['hospital referral region description', 'string', 'rr', 'string'], 
                                 ['ACC', 'string', 'charges.covered', 'double'], 
                                 ['ATP', 'string', 'charges.total_pay', 'double'], 
                                 ['AMP', 'string', 'charges.medicare_pay', 'double']]


    tb1_remove_cfg = tb1["remove"]
    assert tb1_remove_cfg == ['column1', 'column2', 'column3', 'column5']

    tb2 = cfg['tb2']
    assert len(tb2) == 1
    tb2_revove_cfg = tb2['remove']
    assert tb2_revove_cfg == ['provider id']

    
