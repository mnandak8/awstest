import unittest
from unittest.mock import MagicMock, patch
from main.corelibs.utils.s3_util import S3Util

class TestS3Util(unittest.TestCase):

    @patch('boto3.client')
    def test_bucket_empty(self, mock_boto_client):
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {}
        mock_boto_client.return_value = mock_s3
        s3Util = S3Util()
        self.assertIsNone(s3Util.getLatest('bucket_test', 'prefix_test'))

    @patch('boto3.client')
    def test_bucket_single_file(self, mock_boto_client):
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {
            'Contents': [{
            "Key": "prefix_test/file1.txt",
            "LastModified": "2025-01-23T12:00:00.000Z",
            "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
            "Size": 1234,
            "StorageClass": "STANDARD"
        }]
        }
        mock_boto_client.return_value = mock_s3
        s3Util = S3Util()
        latest = s3Util.getLatest('bucket_test', 'prefix_test')
        self.assertEqual(latest, 'prefix_test/file1.txt')

    @patch('boto3.client')
    def test_bucket_multiple_files(self, mock_boto_client):
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {
            'Contents': [
            {
                "Key": "prefix_test/file1.txt",
                "LastModified": "2025-01-23T12:00:00.000Z",
                "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
                "Size": 1234,
                "StorageClass": "STANDARD"
            },
            {
                "Key": "prefix_test/file2.txt",
                "LastModified": "2025-01-24T12:00:00.000Z",
                "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
                "Size": 5678,
                "StorageClass": "STANDARD"
            },
            {
                "Key": "prefix_test/file3.txt",
                "LastModified": "2025-01-25T12:00:00.000Z",
                "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
                "Size": 9101,
                "StorageClass": "STANDARD"
            },
            {
                "Key": "prefix_test/file4.txt",
                "LastModified": "2025-01-26T12:00:00.000Z",
                "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
                "Size": 1121,
                "StorageClass": "STANDARD"
            },
            {
                "Key": "prefix_test/file5.txt",
                "LastModified": "2025-01-27T12:00:00.000Z",
                "ETag": "\"d41d8cd98f00b204e9800998ecf8427e\"",
                "Size": 3141,
                "StorageClass": "STANDARD"
            }
            ]
        }
        mock_boto_client.return_value = mock_s3
        s3Util = S3Util()
        latest = s3Util.getLatest('bucket_test', 'prefix_test')
        self.assertEqual(latest, 'prefix_test/file5.txt')
