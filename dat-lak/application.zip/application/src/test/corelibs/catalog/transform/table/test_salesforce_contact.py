import unittest
from pyspark.sql import SparkSession, Column
from main.corelibs.catalog.transform.table.salesforce_contact import SalesforceContact

class TestSalesforceContact(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("test") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def test_columns(self):
        salesforceContact = SalesforceContact()
        
        self.assertIsInstance(salesforceContact.name, Column)
        self.assertEqual(salesforceContact.name._jc, 'name')
        
        self.assertIsInstance(salesforceContact.firstName, Column)
        self.assertEqual(salesforceContact.firstName._jc, 'firstname')
        
        self.assertIsInstance(salesforceContact.middleName, Column)
        self.assertEqual(salesforceContact.middleName._jc, 'middlename')
        
        self.assertIsInstance(salesforceContact.lastName, Column)
        self.assertEqual(salesforceContact.lastName._jc, 'lastname')
        
        self.assertIsInstance(salesforceContact.salutation, Column)
        self.assertEqual(salesforceContact.salutation._jc, 'salutation')
        
        self.assertIsInstance(salesforceContact.phone, Column)
        self.assertEqual(salesforceContact.phone._jc, 'phone')
        
        self.assertIsInstance(salesforceContact.email, Column)
        self.assertEqual(salesforceContact.email._jc, 'email')
        
        self.assertIsInstance(salesforceContact.locationAddressStreetC, Column)
        self.assertEqual(salesforceContact.locationAddressStreetC._jc, 'location_address_street__c')
        
        self.assertIsInstance(salesforceContact.locationAddressStreet2C, Column)
        self.assertEqual(salesforceContact.locationAddressStreet2C._jc, 'location_address_street_2__c')
        
        self.assertIsInstance(salesforceContact.locationAddressCityC, Column)
        self.assertEqual(salesforceContact.locationAddressCityC._jc, 'location_address_city__c')
        
        self.assertIsInstance(salesforceContact.locationAddressCountryC, Column)
        self.assertEqual(salesforceContact.locationAddressCountryC._jc, 'location_address_country__c')
        
        self.assertIsInstance(salesforceContact.locationAddressZipPostalCodeC, Column)
        self.assertEqual(salesforceContact.locationAddressZipPostalCodeC._jc, 'location_address_zip_postal_code__c')
        
        self.assertIsInstance(salesforceContact.mailingAddressStreetC, Column)
        self.assertEqual(salesforceContact.mailingAddressStreetC._jc, 'mailing_address_street__c')
        
        self.assertIsInstance(salesforceContact.mailingAddressStreet2C, Column)
        self.assertEqual(salesforceContact.mailingAddressStreet2C._jc, 'mailing_address_street_2__c')
        
        self.assertIsInstance(salesforceContact.mailingAddressCityC, Column)
        self.assertEqual(salesforceContact.mailingAddressCityC._jc, 'mailing_address_city__c')
        
        self.assertIsInstance(salesforceContact.mailingAddressStateC, Column)
        self.assertEqual(salesforceContact.mailingAddressStateC._jc, 'mailing_address_state__c')
        
        self.assertIsInstance(salesforceContact.mailingAdressCountryC, Column)
        self.assertEqual(salesforceContact.mailingAdressCountryC._jc, 'mailing_address_country__c')
        
        self.assertIsInstance(salesforceContact.mailingAddressZipPostalCodeC, Column)
        self.assertEqual(salesforceContact.mailingAddressZipPostalCodeC._jc, 'mailing_address_zip_postal_code__c')
        
        self.assertIsInstance(salesforceContact.accountId, Column)
        self.assertEqual(salesforceContact.accountId._jc, 'accountid')
        
