import unittest
from pyspark.sql import SparkSession, Column
from main.corelibs.catalog.transform.table.salesforce_account import SalesforceAccount

class TestSalesforceAccount(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("test") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def test_columns(self):
        salesforceAccount = SalesforceAccount()
        self.assertIsInstance(salesforceAccount.id, Column)
        self.assertEqual(salesforceAccount.id._jc, 'id')
        
        self.assertIsInstance(salesforceAccount.name, Column)
        self.assertEqual(salesforceAccount.name._jc, 'name')
        
        self.assertIsInstance(salesforceAccount.firstNameC, Column)
        self.assertEqual(salesforceAccount.firstNameC._jc, 'first_name__c')
        
        self.assertIsInstance(salesforceAccount.middleNameC, Column)
        self.assertEqual(salesforceAccount.middleNameC._jc, 'middle_name__c')
        
        self.assertIsInstance(salesforceAccount.lastNameC, Column)
        self.assertEqual(salesforceAccount.lastNameC._jc, 'last_name__c')
        
        self.assertIsInstance(salesforceAccount.phone, Column)
        self.assertEqual(salesforceAccount.phone._jc, 'phone')
        
        self.assertIsInstance(salesforceAccount.emailC, Column)
        self.assertEqual(salesforceAccount.emailC._jc, 'email__c')
        
        self.assertIsInstance(salesforceAccount.activeC, Column)
        self.assertEqual(salesforceAccount.activeC._jc, 'active__c')
        
        self.assertIsInstance(salesforceAccount.type, Column)
        self.assertEqual(salesforceAccount.type._jc, 'type')
        
        self.assertIsInstance(salesforceAccount.bankingDivisionC, Column)
        self.assertEqual(salesforceAccount.bankingDivisionC._jc, 'banking_division__c')
        
        self.assertIsInstance(salesforceAccount.cifPrimaryC, Column)
        self.assertEqual(salesforceAccount.cifPrimaryC._jc, 'cif_primary__c')
        
        self.assertIsInstance(salesforceAccount.ccanPrimaryC, Column)
        self.assertEqual(salesforceAccount.ccanPrimaryC._jc, 'ccan_primary__c')
        
        self.assertIsInstance(salesforceAccount.recordTypeId, Column)
        self.assertEqual(salesforceAccount.recordTypeId._jc, 'recordtypeid')
        
        self.assertIsInstance(salesforceAccount.masterPartyIDC, Column)
        self.assertEqual(salesforceAccount.masterPartyIDC._jc, 'master_party_id__c')
