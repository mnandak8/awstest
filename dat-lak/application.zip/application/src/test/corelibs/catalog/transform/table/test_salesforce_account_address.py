import unittest
from pyspark.sql import SparkSession, Column
from main.corelibs.catalog.transform.table.salesforce_account_address import SalesforceAccountAddress

class TestSalesforceAccountAddress(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("test") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def test_columns(self):
        salesforceAccountAddress = SalesforceAccountAddress()
        self.assertIsInstance(salesforceAccountAddress.id, Column)
        self.assertEqual(salesforceAccountAddress.id._jc, 'id')
        
        self.assertIsInstance(salesforceAccountAddress.addressTypeC, Column)
        self.assertEqual(salesforceAccountAddress.addressTypeC._jc, 'address_type__c')
        
        self.assertIsInstance(salesforceAccountAddress.street1C, Column)
        self.assertEqual(salesforceAccountAddress.street1C._jc, 'street_1__c')
        
        self.assertIsInstance(salesforceAccountAddress.street2C, Column)
        self.assertEqual(salesforceAccountAddress.street2C._jc, 'street_2__c')
        
        self.assertIsInstance(salesforceAccountAddress.street3C, Column)
        self.assertEqual(salesforceAccountAddress.street3C._jc, 'street_3__c')
        
        self.assertIsInstance(salesforceAccountAddress.cityC, Column)
        self.assertEqual(salesforceAccountAddress.cityC._jc, 'city__c')
        
        self.assertIsInstance(salesforceAccountAddress.stateC, Column)
        self.assertEqual(salesforceAccountAddress.stateC._jc, 'state__c')
        
        self.assertIsInstance(salesforceAccountAddress.zipPostalCodeC, Column)
        self.assertEqual(salesforceAccountAddress.zipPostalCodeC._jc, 'zip_postal_code__c')
        
        self.assertIsInstance(salesforceAccountAddress.regionC, Column)
        self.assertEqual(salesforceAccountAddress.regionC._jc, 'region__c')
        
        self.assertIsInstance(salesforceAccountAddress.countryC, Column)
        self.assertEqual(salesforceAccountAddress.countryC._jc, 'country__c')
        
        self.assertIsInstance(salesforceAccountAddress.relationshipC, Column)
        self.assertEqual(salesforceAccountAddress.relationshipC._jc, 'relationship__c')
