import unittest
from pyspark.sql import SparkSession, Column
from main.corelibs.catalog.transform.table.salesforce_account_contact_relation import SalesforceAccountContactRelation

class TestSalesforceAccountContactRelation(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("test") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def test_columns(self):
        salesforceAccountContactRelation = SalesforceAccountContactRelation()
        self.assertIsInstance(salesforceAccountContactRelation.isPrimaryContactC, Column)
        self.assertEqual(salesforceAccountContactRelation.isPrimaryContactC._jc, 'is_primary_contact__c')
        
        self.assertIsInstance(salesforceAccountContactRelation.isActive, Column)
        self.assertEqual(salesforceAccountContactRelation.isActive._jc, 'isactive')
        
        self.assertIsInstance(salesforceAccountContactRelation.roleC, Column)
        self.assertEqual(salesforceAccountContactRelation.roleC._jc, 'role__c')
        
        self.assertIsInstance(salesforceAccountContactRelation.accountId, Column)
        self.assertEqual(salesforceAccountContactRelation.accountId._jc, 'accountid')
        