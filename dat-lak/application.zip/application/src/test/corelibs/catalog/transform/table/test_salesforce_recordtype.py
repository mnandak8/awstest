import unittest
from pyspark.sql import SparkSession, Column
from main.corelibs.catalog.transform.table.salesforce_recordtype import SalesforceRecordType

class TestSalesforceRecordType(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder \
            .appName("test") \
            .master("local[*]") \
            .getOrCreate()

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def test_columns(self):
        salesforceRecordType = SalesforceRecordType()
        self.assertIsInstance(salesforceRecordType.id, Column)
        self.assertEqual(salesforceRecordType.id._jc, 'id')
        
        self.assertIsInstance(salesforceRecordType.name, Column)
        self.assertEqual(salesforceRecordType.name._jc, 'name')
        
        self.assertIsInstance(salesforceRecordType.isActive, Column)
        self.assertEqual(salesforceRecordType.isActive._jc, 'isactive')