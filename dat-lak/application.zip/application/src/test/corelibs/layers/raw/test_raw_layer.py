import json
import os
from pathlib import Path
import json
import os
from pathlib import Path
import unittest
from pyspark.sql import SparkSession, DataFrame
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from main.corelibs.source import Source
from main.corelibs.sink import Sink
from main.corelibs.layers.raw.raw_layer import RawLayer
from main.corelibs.data.source.s3_src import S3Source
from main.corelibs.data.sink.s3_snk import S3Sink
from unittest.mock import MagicMock, Mock, ANY
from datetime import datetime
import pyarrow.parquet as pq
from pyspark.testing.utils import assertDataFrameEqual
from test.testutils.util_file import UtilFile
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

class TestRawLayer(unittest.TestCase):
    def setUp(self):
        self.source = MagicMock()
        self.sink = MagicMock()
        self.logger = MagicMock()
        self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()
        self.raw_layer = RawLayer(self.source, self.sink, self.logger)

    
    def test_submit(self):
        options = {"multiline": "true"}
        spark = SparkSession.builder.master('local').getOrCreate()
        logger = Mock()
        job_name = "raw_testtable"
        source_folder_path = 'application/src/test/resources/raw_layer_data/'
        source_file_path = f'{source_folder_path}landing_data.json'
        expect_data_path = f'{source_folder_path}expected_raw_layer_data.json'
        output_path = 'application/src/test/resources/raw_layer_data/output/'
        source = S3Source(source_file_path,job_name, logger,'json', options=options)
        sink = S3Sink(output_path, job_name, logger)
        raw_layer = RawLayer(source, sink, logger)
        raw_layer.submit(spark)
        now_str = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        output_parquet_path = f'{output_path}/year={now_str[0]}/month={now_str[1]}/day={now_str[2]}'
        parquet_filename = UtilFile.get_file_name(output_parquet_path)
        file_path = os.path.join(output_parquet_path, parquet_filename)
        
        expected_data = UtilFile.get_expect_data(expect_data_path, spark)
        output_data = spark.read.parquet(file_path)
        assert parquet_filename is not None
        assert UtilFile.is_parquet(file_path)
        assert output_data.count() == expected_data.count()
        assert 'album' in output_data.columns
        assert 'US_peak_chart_post' in output_data.columns 
        assert 'release_year' in output_data.columns 
        assert 'raw_utc' in output_data.columns
        output_data = output_data.drop('raw_utc')
        assertDataFrameEqual(output_data, expected_data)
        
        os.remove(file_path)
    
    def test_submit_empty_dataframe(self):
        schema = StructType([
            StructField("id", IntegerType(), True),
            StructField("value", StringType(), True)
        ])
        self.source.read.return_value = self.spark.createDataFrame([], schema)
        self.source.get_job_name.return_value = "test_job"
        self.raw_layer.submit(self.spark)
        self.sink.write.assert_not_called()
        
