import json
import os
from pathlib import Path
import json
import os
from pathlib import Path
from pyspark.sql import SparkSession, DataFrame
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from main.corelibs.source import Source
from main.corelibs.sink import Sink

from main.corelibs.layers.curate.party import Party

from main.corelibs.data.source.curate_party_src import CuratePartySource
from main.corelibs.data.sink.s3_snk import S3Sink
from unittest.mock import Mock, ANY
from datetime import datetime
import pyarrow.parquet as pq
from pyspark.testing.utils import assertDataFrameEqual
from test.testutils.util_file import UtilFile


def test_submit():

    options = {"delimiter": ",", "header": "true", "inferSchema": "true"}
    spark = SparkSession.builder.master('local').getOrCreate()
    logger = Mock()
    job_name = "curate_testtable"
    source_folder_path = 'application/src/test/resources/curated_layer_data/'
    source_file_path = f'{source_folder_path}landing_data.csv'
    
    account_address_path = f'{source_folder_path}salesforce_account_address_c.csv'
    account_contact_relation_path = f'{source_folder_path}salesforce_account_contact_relation.csv'
    account_path = f'{source_folder_path}salesforce_account.csv'
    contact_path = f'{source_folder_path}salesforce_contact.csv'
    recordtype_path = f'{source_folder_path}salesforce_recordtype.csv'
    expect_data_path = f'{source_folder_path}curate_party.csv'

    output_path = 'application/src/test/resources/curated_layer_data/output'

    spark.read.csv(account_address_path, header=True, inferSchema=True).createOrReplaceTempView("salesforce_account_address_c")
    spark.read.csv(account_contact_relation_path, header=True, inferSchema=True).createOrReplaceTempView("salesforce_account_contact_relation")
    spark.read.csv(account_path, header=True, inferSchema=True).createOrReplaceTempView("salesforce_account")
    spark.read.csv(contact_path, header=True, inferSchema=True).createOrReplaceTempView("salesforce_contact")
    spark.read.csv(recordtype_path, header=True, inferSchema=True).createOrReplaceTempView("salesforce_recordtype")
    
    srcTables = {
        'addressTable': 'salesforce_account_address_c',
        'accountContactTable': 'salesforce_account_contact_relation',
        'accountTable': 'salesforce_account',
        'contactTable': 'salesforce_contact',
        'recordTypeTable': 'salesforce_recordtype'
    }
    # test the application functions
    source = CuratePartySource("default", srcTables, job_name, logger, 'csv', options=options)
    sink = S3Sink(output_path, job_name, logger)
    
    raw_layer = Party(source, sink, logger)
    raw_layer.submit(spark)
    
    now_str = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
    output_parquet_path = f'{output_path}/year={now_str[0]}/month={now_str[1]}/day={now_str[2]}'
    parquet_filename = UtilFile.get_file_name(output_parquet_path)
    file_path = os.path.join(output_parquet_path, parquet_filename)
    
    expected_data = spark.read.csv(expect_data_path, header=True, inferSchema=True)
    output_data = spark.read.parquet(file_path)
    
    # test the output data
    assert parquet_filename is not None
    assert UtilFile.is_parquet(file_path)
    assert output_data.count() == expected_data.count()

    assert 'Postal_Address_Id' in output_data.columns #account_address
    assert 'Contact_Active_Ind' in output_data.columns #account_contact
    assert 'Source_System_Unique_Key' in output_data.columns #account
    assert 'Contact_Nm' in output_data.columns #contact
    assert 'Party_Role_Type_Id' in output_data.columns #recordtype

    expected_data = expected_data.drop('Partition_0')
    expected_data = expected_data.drop('Year')
    expected_data = expected_data.drop('Month')
    expected_data = expected_data.drop('Day')
    output_data = UtilFile.normalize_column_names(output_data)
    expected_data = UtilFile.normalize_column_names(expected_data)
    assertDataFrameEqual(output_data, expected_data)
    
    if os.path.exists(file_path):
        os.remove(file_path)

    pass