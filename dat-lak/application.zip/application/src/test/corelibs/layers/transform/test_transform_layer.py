import json
import os
from pathlib import Path
from pyspark.sql import SparkSession, DataFrame
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from main.corelibs.source import Source
from main.corelibs.sink import Sink
from main.corelibs.layers.transform.transform_layer import TransformLayer
from main.corelibs.data.source.s3_src import S3Source
from main.corelibs.data.sink.s3_snk import S3Sink
from unittest.mock import Mock, ANY
from datetime import datetime
import pyarrow.parquet as pq
from pyspark.testing.utils import assertDataFrameEqual
from test.testutils.util_file import UtilFile

def test_submit():
    options = {"multiline": "true"}
    spark = SparkSession.builder.master('local').getOrCreate()
    logger = Mock()
    job_name = "transform_testtable"
    source_folder_path = 'application/src/test/resources/transform_layer_test_data/'
    source_file_path = f'{source_folder_path}raw_layer_data.json'
    expect_data_path = f'{source_folder_path}expected_transform_layer_data.json'
    output_path = 'application/src/test/resources/transform_layer_test_data/output/'
    source = S3Source(source_file_path,job_name, logger,'json', options=options)
    sink = S3Sink(output_path, job_name, logger)
    raw_layer = TransformLayer(source, sink, logger)
    raw_layer.submit(spark)
    now_str = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
    output_parquet_path = f'{output_path}/year={now_str[0]}/month={now_str[1]}/day={now_str[2]}'
    parquet_filename = UtilFile.get_file_name(output_parquet_path)
    file_path = os.path.join(output_parquet_path, parquet_filename)
    
    expected_data = UtilFile.get_expect_data(expect_data_path, spark)
    output_data = spark.read.parquet(file_path)
    assert parquet_filename is not None
    assert UtilFile.is_parquet(file_path)
    assert output_data.count() == expected_data.count()
    assert 'album' in output_data.columns
    assert 'US_peak_chart_post' in output_data.columns 
    assert 'release_year' in output_data.columns
    assertDataFrameEqual(output_data, expected_data)
    
    os.remove(file_path)
    pass