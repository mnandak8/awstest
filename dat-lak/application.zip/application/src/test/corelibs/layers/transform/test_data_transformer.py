import sys
import pytest
from unittest import mock
from pyspark.sql.types import StringType, StructField, StructType
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from unittest.mock import patch

@pytest.fixture(scope='session')
def create_context():
    sc = SparkContext()
    sc.setLogLevel('ERROR')
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session
    return spark, glue_context

@pytest.fixture
def data_gen():
    pass
'''
@pytest.mark.usefixtures('spark_create')
def test_process(glueContext: GlueContext):
    # TODO: Mock GlueContext
    #mock the module
    mocked_awsglue = mock.MagicMock()
    #mock the import
    sys.modules['awsglue'] = mocked_awsglue
    mocked_awsglue.getResolvedOptions.return_value = {'arg0', 'arg1', 'arg2', 'arg3'}

    dt = DataTransformer()
    dt.process(glueContext)
   ''' 