#from src.main.core.transform import DataTransformer


'''def test_map_fields():
    tran = DataTransformer(None, None, None)
    ddf = tran.map_fields(None, None)
    pass'''