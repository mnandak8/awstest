import os
import json
import os
import unittest
from pyspark.sql import SparkSession
from main.corelibs.data.source.s3_src import S3Source
from main.corelibs.data.sink.s3_snk import S3Sink
from unittest.mock import MagicMock
from pyspark.testing.utils import assertDataFrameEqual
from test.testutils.util_file import UtilFile

class TestS3Sink(unittest.TestCase):
    def setUp(self):
        self.logger = MagicMock()
        self.job_name = "job_test"
        self.source_folder_path = 'application/src/test/resources/s3_sink_data/'
        self.source = MagicMock()
        self.spark = SparkSession.builder.master("local").appName("test").getOrCreate()
        self.output_path = 'application/src/test/resources/s3_sink_data/output'
        self.sink = S3Sink(self.output_path, self.job_name, self.logger)
    
    def test_write(self):
        options = {"multiline": "true"}
        source_file_path = f'{self.source_folder_path}test_data.json'
        expect_data_path = f'{self.source_folder_path}expected_data.json'        
        
        source = S3Source(source_file_path,self.job_name, self.logger,'json', options=options)
        df_source = source.read(self.spark)
        self.sink.write(df_source)
        output_parquet_path = f'{self.output_path}/year=2025/month=01/day=24'
        parquet_filename = UtilFile.get_file_name(output_parquet_path)
        file_path = os.path.join(output_parquet_path, parquet_filename)
        
        expected_data = UtilFile.get_expect_data(expect_data_path, self.spark)
        output_data = self.spark.read.parquet(file_path)
        assert parquet_filename is not None
        assert UtilFile.is_parquet(file_path)
        assert output_data.count() == expected_data.count()
        assert 'album' in output_data.columns
        assert 'US_peak_chart_post' in output_data.columns 
        assert 'release_year' in output_data.columns
        assertDataFrameEqual(output_data, expected_data)
        
        os.remove(file_path)
         
    def test_jobname_property(self):
        self.assertEqual(self.sink.getjobname(), self.job_name)
        
