# test_curate_loan_source.py
import unittest
from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from main.corelibs.data.source.curate_loan_src import CurateLoanSource

class TestCurateLoanSource(unittest.TestCase):
    def setUp(self):
        self.srcDbName = "test_db"
        self.srcTables = {"table1": "table1_name", "table2": "table2_name"}
        self.job_name = "test_job"
        self.logger = MagicMock()
        self.curate_loan_source = CurateLoanSource(self.srcDbName, self.srcTables, self.job_name, self.logger)

    def test_init(self):
        self.assertEqual(self.curate_loan_source.srcDbName, self.srcDbName)
        self.assertEqual(self.curate_loan_source.data_source, self.srcTables)
        self.assertEqual(self.curate_loan_source.job_name, self.job_name)
        self.assertEqual(self.curate_loan_source.log, self.logger)

    def test_read(self):
        spark = MagicMock(spec=SparkSession)
        spark.catalog.setCurrentDatabase = MagicMock()
        spark.table = MagicMock(side_effect=lambda table_name: f"DataFrame for {table_name}")
        dfs = self.curate_loan_source.read(spark)
        spark.catalog.setCurrentDatabase.assert_called_once_with(self.srcDbName)
        self.assertEqual(dfs, {k: f"DataFrame for {v}" for k, v in self.srcTables.items()})

    def test_jobname_property(self):
        self.assertEqual(self.curate_loan_source.getjobname(), self.job_name)