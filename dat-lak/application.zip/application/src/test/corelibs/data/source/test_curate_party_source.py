# test_curate_party_source.py
import unittest
from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from main.corelibs.data.source.curate_party_src import CuratePartySource
class TestCuratePartySource(unittest.TestCase):
    def setUp(self):
        self.srcDbName = "test_db"
        self.srcTables = {"accountTable": "account_table", "addressTable": "address_table", "recordTypeTable": "record_type_table", "contactTable": "contact_table", "accountContactTable": "account_contact_table"}
        self.job_name = "test_job"
        self.logger = MagicMock()
        self.curate_party_source = CuratePartySource(self.srcDbName, self.srcTables, self.job_name, self.logger)

    def test_init(self):
        self.assertEqual(self.curate_party_source.srcDbName, self.srcDbName)
        self.assertEqual(self.curate_party_source.data_source, self.srcTables)
        self.assertEqual(self.curate_party_source.job_name, self.job_name)
        self.assertEqual(self.curate_party_source.log, self.logger)

    def test_read(self):
        spark = MagicMock(spec=SparkSession)
        spark.catalog.setCurrentDatabase = MagicMock()
        spark.table = MagicMock(side_effect=lambda table_name: f"DataFrame for {table_name}")
        dfs = self.curate_party_source.read(spark)
        spark.catalog.setCurrentDatabase.assert_called_once_with(self.srcDbName)
        self.assertIn('accountDF', dfs)
        self.assertIn('accountAddressDF', dfs)
        self.assertIn('recordTypeDF', dfs)
        self.assertIn('contactDF', dfs)
        self.assertIn('accountContactDF', dfs)
        
    def test_jobname_property(self):
        self.assertEqual(self.curate_party_source.getjobname(), self.job_name)