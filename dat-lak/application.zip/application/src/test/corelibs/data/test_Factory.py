import os
import json
import os
import unittest
from pyspark.sql import SparkSession
from unittest.mock import MagicMock, patch
from test.testutils.util_file import UtilFile
from main.corelibs.data.factory import Factory
from awsglue.context import GlueContext
from main.corelibs.utils.s3_util import S3Util
from corelibs.layers.raw.raw_layer import RawLayer
from corelibs.layers.transform.transform_layer import TransformLayer
from corelibs.layers.curate.party import Party
from corelibs.layers.curate.loan import Loan
from corelibs.layers.curate.loan_transaction import loanTransaction
from corelibs.layers.curate.loan_payment_schedule import loanPaymentSchedule
from corelibs.layers.curate.loan_billing_summary import loanBillingSummary
from corelibs.layers.consumption.party import Party as ConsumptionParty
from corelibs.layers.consumption.loan import Loan as ConsumptionLoan
class TestFactory(unittest.TestCase):
    def setUp(self):
        self.factory = Factory()

    def test_config(self):
        test_config = self.factory.config()
        self.assertIsNotNone(test_config)
        self.assertEqual(len(test_config), 2)
        tb1 = test_config['tb1']
        self.assertEqual(len(tb1), 2)
        tb1_transform_cfg = tb1['update']
        self.assertEqual(tb1_transform_cfg, [['drg definition', 'string', 'drg', 'string'], 
                                 ['provider id', 'long', 'provider.id', 'long'], 
                                 ['provider name', 'string', 'provider.name', 'string'], 
                                 ['provider city', 'string', 'provider.city', 'string'], 
                                 ['provider state', 'string', 'provider.state', 'string'], 
                                 ['provider zip code', 'long', 'provider.zip', 'long'], 
                                 ['hospital referral region description', 'string', 'rr', 'string'], 
                                 ['ACC', 'string', 'charges.covered', 'double'], 
                                 ['ATP', 'string', 'charges.total_pay', 'double'], 
                                 ['AMP', 'string', 'charges.medicare_pay', 'double']]
        )
        
        tb1_remove_cfg = tb1["remove"]
        self.assertEqual(tb1_remove_cfg, ['column1', 'column2', 'column3', 'column5'])

        tb2 = test_config['tb2']
        self.assertEqual(len(tb2),1)
        tb2_revove_cfg = tb2['remove']
        self.assertEqual(tb2_revove_cfg, ['provider id'])
        
    @patch('awsglue.context.GlueContext', autospec=True)
    def test_spark(self, mock_GlueContext):
        mock_GlueContext = MagicMock()
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        test_spark = self.factory.spark()
        self.assertIsNotNone(test_spark)
        test_spark.conf.set.assert_called_once_with("spark.sql.parquet.enableVectorizedReader", "false")
        
    @patch('awsglue.context.GlueContext', autospec=True)
    def test_logger(self, mock_GlueContext):
        mock_GlueContext = MagicMock()
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        test_logger = self.factory.logger()
        self.assertIsNotNone(test_logger)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_raw(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': 'test_date2process',
            'datasource': 'test_datasource',
            'groupname': 'test_groupname',
            'objectname': 'test_objectname',
            'layer': 'raw',
            'datasink': 'test_datasink'
        }
        
        self.factory.config = MagicMock(
            return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        )
        test_raw_layer = self.factory.raw(args)
        self.assertIsNotNone(test_raw_layer)
        self.assertIsInstance(test_raw_layer, RawLayer)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('boto3.client')
    def test_raw_none(self, mock_GlueContext, mock_boto_client):
        mock_GlueContext = MagicMock()
        mock_s3 = MagicMock()
        mock_s3.list_objects_v2.return_value = {}
        mock_boto_client.return_value = mock_s3
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': 'test_date2process',
            'datasource': 'test_datasource',
            'groupname': 'test_groupname',
            'objectname': 'test_objectname',
            'layer': 'raw',
            'datasink': 'test_datasink'
        }
        
        self.factory.config = MagicMock(
            return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        )
        test_raw_layer = self.factory.raw(args)
        self.assertIsNone(test_raw_layer)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_transform(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'test_groupname',
            'objectname': 'test_objectname',
            'layer': 'transform',
            'datasink': 'test_datasink'
        }
        
        self.factory.config = MagicMock(
            return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        },
                        {
                            "name": "account_address_c",
                            "raw": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account_address_c/test_groupname_to_landing_accountAddress/%s/",
                                "sink_path": "test_groupname/account_address_c/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account_address_c/latest/",
                                "sink_path": "test_groupname/account_address_c/latest/"
                            }
                        }
                    ] 
                }
            }
        )
        test_transform_layer = self.factory.transform(args)
        self.assertIsNotNone(test_transform_layer)
        self.assertIsInstance(test_transform_layer, TransformLayer)
        
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_party(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'party',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNotNone(test_curate_layer)
        self.assertIsInstance(test_curate_layer, Party)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_loanDetail(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanDetail',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNotNone(test_curate_layer)
        self.assertIsInstance(test_curate_layer, Loan)
        
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_loanTransaction(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanTransaction',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNotNone(test_curate_layer)
        self.assertIsInstance(test_curate_layer, loanTransaction)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_loanPaymentSchedule(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanPaymentSchedule',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNotNone(test_curate_layer)
        self.assertIsInstance(test_curate_layer, loanPaymentSchedule)


    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_loanBillingSummary(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanBillingSummary',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNotNone(test_curate_layer)
        self.assertIsInstance(test_curate_layer, loanBillingSummary)
        
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_curate_None(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'None',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        test_curate_layer = self.factory.curate(args)
        self.assertIsNone(test_curate_layer)
        
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_consumption_ConsumptionParty(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'CoBank-Party-Information',
            'objectname': 'test_objectname',
            'layer': 'consumption',
            'datasink': 'test_datasink',
            'env': 'test'
        }
        test_consumption_layer = self.factory.consumption(args)
        self.assertIsNotNone(test_consumption_layer)
        self.assertIsInstance(test_consumption_layer, ConsumptionParty)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_consumption_ConsumptionLoan(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'CoBank-Loan-Detail',
            'objectname': 'test_objectname',
            'layer': 'consumption',
            'datasink': 'test_datasink',
            'env': 'test'
        }
        test_consumption_layer = self.factory.consumption(args)
        self.assertIsNotNone(test_consumption_layer)
        self.assertIsInstance(test_consumption_layer, ConsumptionLoan)
        
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('corelibs.utils.s3_util.S3Util.getLatest')
    def test_consumption_None(self, mock_GlueContext, mock_s3_util_getLatest):
        mock_GlueContext = MagicMock()
        mock_s3_util_getLatest.return_value = "application/src/test/resources/raw_layer_data/landing_data.json"
        self.factory.glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'None',
            'objectname': 'test_objectname',
            'layer': 'consumption',
            'datasink': 'test_datasink',
            'env': 'test'
        }
        test_consumption_layer = self.factory.consumption(args)
        self.assertIsNone(test_consumption_layer)