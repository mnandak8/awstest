import unittest
from corelibs.data.factory import Factory
from main.driver import main
#from main.driver import Factory
from unittest.mock import MagicMock, Mock, patch
from pyspark.sql import SparkSession
from corelibs.layers.raw.raw_layer import RawLayer
from corelibs.layers.transform.transform_layer import TransformLayer
from main.corelibs.data.source.s3_src import S3Source
from main.corelibs.data.sink.s3_snk import S3Sink
class TestDriver(unittest.TestCase):
    
    @patch.object(Factory, 'raw')
    @patch.object(Factory, 'spark')
    @patch.object(RawLayer, 'submit')
    @patch('awsglue.utils.getResolvedOptions', autospec=True)
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('sys.argv', ['script_name', '--JOB_NAME', 'test_job', '--datasource', 'test_source', '--datasink', 'test_sink', '--layer', 'raw', '--date2process', '2025/01/28', '--groupname', 'test_groupname', '--objectname', 'test_objectname', '--env', 'test'])
    def test_main_raw(self,mock_GlueContext,mock_getResolvedOptions,mock_spark, mock_submit, mock_raw):
        logger = MagicMock()
        mock_getResolvedOptions = MagicMock()
        args = {
            'JOB_NAME': 'test_job',
            'date2process': 'test_date2process',
            'datasource': 'test_datasource',
            'groupname': 'test_groupname',
            'objectname': 'test_objectname',
            'layer': 'raw',
            'datasink': 'test_datasink'
        }
        mock_getResolvedOptions.return_value = args
        mock_getResolvedOptions.return_value = args
        mock_GlueContext = MagicMock()
        mock_glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        mock_config = MagicMock()
        mock_config.return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        main()
        mock_GlueContext.assert_called_once()        
        mock_raw.assert_called()
        mock_submit.assert_called_once()
        
        
    
    @patch.object(Factory, 'transform')
    @patch.object(Factory, 'spark')
    @patch.object(TransformLayer, 'submit')
    @patch('awsglue.utils.getResolvedOptions', autospec=True)
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('sys.argv', ['script_name', '--JOB_NAME', 'test_job', '--datasource', 'test_source', '--datasink', 'test_sink', '--layer', 'transform', '--date2process', '2025/01/28', '--groupname', 'test_groupname', '--objectname', 'test_objectname', '--env', 'test'])
    def test_main_transform(self,mock_GlueContext,mock_getResolvedOptions,mock_spark, mock_submit, mock_transform):
        logger = MagicMock()
        mock_getResolvedOptions = MagicMock()
        args = {
            'JOB_NAME': 'test_job',
            'date2process': 'test_date2process',
            'datasource': 'test_datasource',
            'groupname': 'test_groupname',
            'objectname': 'test_objectname',
            'layer': 'raw',
            'datasink': 'test_datasink'
        }
        mock_getResolvedOptions.return_value = args
        mock_getResolvedOptions.return_value = args
        mock_GlueContext = MagicMock()
        mock_glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        mock_config = MagicMock()
        mock_config.return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        main()
        mock_GlueContext.assert_called_once()        
        mock_transform.assert_called()
        mock_submit.assert_called_once()
        
        
    @patch.object(Factory, 'curate')
    @patch.object(Factory, 'spark')
    @patch.object(TransformLayer, 'submit')
    @patch('awsglue.utils.getResolvedOptions', autospec=True)
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('sys.argv', ['script_name', '--JOB_NAME', 'test_job', '--datasource', 'test_source', '--datasink', 'test_sink', '--layer', 'curate', '--date2process', '2025/01/28', '--groupname', 'test_groupname', '--objectname', 'test_objectname', '--env', 'test'])
    def test_main_curate(self,mock_GlueContext,mock_getResolvedOptions,mock_spark, mock_submit, mock_curate):
        logger = MagicMock()
        mock_getResolvedOptions = MagicMock()
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanPaymentSchedule',
            'objectname': 'test_objectname',
            'layer': 'curate',
            'datasink': 'test_datasink'
        }
        mock_getResolvedOptions.return_value = args
        mock_getResolvedOptions.return_value = args
        mock_GlueContext = MagicMock()
        mock_glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        mock_config = MagicMock()
        mock_config.return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        main()
        mock_GlueContext.assert_called_once()        
        mock_curate.assert_called()
        mock_submit.assert_called_once()
        
        
    @patch.object(Factory, 'consumption')
    @patch.object(Factory, 'spark')
    @patch.object(TransformLayer, 'submit')
    @patch('awsglue.utils.getResolvedOptions', autospec=True)
    @patch('awsglue.context.GlueContext', autospec=True)
    @patch('sys.argv', ['script_name', '--JOB_NAME', 'test_job', '--datasource', 'test_source', '--datasink', 'test_sink', '--layer', 'consumption', '--date2process', '2025/01/28', '--groupname', 'test_groupname', '--objectname', 'test_objectname', '--env', 'test'])
    def test_main_consumption(self,mock_GlueContext,mock_getResolvedOptions,mock_spark, mock_submit, mock_consumption):
        logger = MagicMock()
        mock_getResolvedOptions = MagicMock()
        args = {
            'date2process': '2025/01/28',
            'datasource': 'test_datasource',
            'groupname': 'loanPaymentSchedule',
            'objectname': 'test_objectname',
            'layer': 'consumption',
            'datasink': 'test_datasink'
        }
        mock_getResolvedOptions.return_value = args
        mock_getResolvedOptions.return_value = args
        mock_GlueContext = MagicMock()
        mock_glueContext = MagicMock(return_value=mock_GlueContext(SparkSession.builder.master("local").appName("test").getOrCreate()))
        mock_config = MagicMock()
        mock_config.return_value={
                "test_groupname": {
                    "objects" :[
                        {
                            "name": "test_objectname",
                            "raw": {
                                "update_columns": [],
                                "remove_columns": [],
                                "source_path": "test_groupname/test_objectname/test_groupname_to_landing_account/%s/",
                                "sink_path": "test_groupname/test_objectname/latest/"
                            },
                            "transform": {
                                "updates": [],
                                "removes": [],
                                "source_path": "test_groupname/account/latest/",
                                "sink_path": "test_groupname/account/latest/"
                            }
                        }
                    ] 
                }
            }
        main()
        mock_GlueContext.assert_called_once()        
        mock_consumption.assert_called()
        mock_submit.assert_called_once()