import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


#from pyspark import SparkContext
#from awsglue.context import GlueContext
#from moto.server import ThreadedMotoServer
# from moto import mock_s3, mock_secretsmanager
#from src.main.corelibs.utils.config_util import ConfigUtil
#import boto3
#import pytest


'''@pytest.fixture(scope = "session")
def moto_server():
    """
    start moto server
    """
    server = ThreadedMotoServer()
    server.start()
    yield server
    server.stop()
'''

'''@pytest.fixture(scope = "session")
def s3_client(moto_server):
    """
    create mock S3 infrastructure
    """
    with mock_s3():

        s3_client = boto3.client("s3", endpoint_url = "http://localhost:5000")

        bucket_config = "sd-pytest-bucket"
        file_path_list_config = ["input", "config", "config.yaml"]
        config_key = "config/config.yaml"
        file_path_config = FileLoader.load_data(file_path_list_config)
        

        file_path_list_schema = [   
                                    ["input", "schema", "Professor.yaml"],
                                    ["input", "schema", "Student.yaml"],
                                    ["input", "schema", "Course.yaml"],
                                    ["input", "schema", "Dummy.yaml"]
                                ]
        schema_keys = ["schema/postgres/Professor.yaml", "schema/postgres/Student.yaml", 
                        "schema/postgres/Course.yaml", "schema/postgres/Dummy.yaml"]
        
        file_path_schema1 = FileLoader.load_data(file_path_list_schema[0])
        file_path_schema2 = FileLoader.load_data(file_path_list_schema[1])
        file_path_schema3 = FileLoader.load_data(file_path_list_schema[2])
        file_path_schema4 = FileLoader.load_data(file_path_list_schema[3])

        s3_client.create_bucket(Bucket = bucket_config)
        s3_client.upload_file(file_path_config, bucket_config, config_key)

        s3_client.upload_file(file_path_schema1, bucket_config, schema_keys[0])
        s3_client.upload_file(file_path_schema2, bucket_config, schema_keys[1])
        s3_client.upload_file(file_path_schema3, bucket_config, schema_keys[2])
        s3_client.upload_file(file_path_schema4, bucket_config, schema_keys[3])

        yield s3_client
'''
'''
@pytest.fixture(scope = "session")
def spark_create(moto_server):
    spark_context = SparkContext()
    glue_context = GlueContext(spark_context)
    spark_session = glue_context.spark_session

    hadoop_conf = spark_session._jsc.hadoopConfiguration()
    hadoop_conf.set("fs.s3.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    hadoop_conf.set("fs.s3a.access.key", "mock")
    hadoop_conf.set("fs.s3a.secret.key", "mock")
    hadoop_conf.set("fs.s3a.endpoint", "http://localhost:5000")

    yield spark_context, glue_context, spark_session,
    
    if spark_context is not None:
        spark_context.stop()

'''
