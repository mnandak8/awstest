import json
import os
import pyarrow.parquet as pq
from pyspark.sql import DataFrame

class UtilFile:
    @staticmethod
    def get_file_name(folder_path):
        for file_name in os.listdir(folder_path):
            name, extension = os.path.splitext(file_name)
            if os.path.isfile(os.path.join(folder_path, file_name)) and extension == '.parquet':
                return file_name
        return None

    @staticmethod
    def is_parquet(file_path):
        try:
            pq.read_table(file_path)
            return True
        except Exception as e:
            return False
    
    @staticmethod    
    def get_expect_data(json_file_path, spark):
        with open(json_file_path, 'r') as json_file:
            expected_data = json.load(json_file)
        expected_df = spark.createDataFrame(expected_data)
        return expected_df
    
    @staticmethod
    def normalize_column_names(df: DataFrame) -> DataFrame:
        for field in df.schema.fields:
            df = df.withColumnRenamed(field.name, field.name.lower())
        return df