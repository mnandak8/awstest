"""import os
from src import src_dir

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
class FileLoader:

    @staticmethod
    def load_data(path_list):
        test_folder_root = src_dir.ROOT_DIR

        for elements in path_list:
            test_folder_root = os.path.join(test_folder_root, elements)
        return test_folder_root
    
    @staticmethod
    def load_data_s3(path_list):
        folder_root = 's3://'
        for element in path_list:
            folder_root = folder_root + element + '/'
        return folder_root
    
    """