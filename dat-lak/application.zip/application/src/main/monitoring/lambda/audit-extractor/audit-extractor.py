import boto3
import logging
from datetime import datetime
from boto3.dynamodb.conditions import Key

# Initialize the DynamoDB and CloudWatch Logs clients
dynamodb = boto3.resource('dynamodb')
cloudwatch_logs = boto3.client('logs')

# Define the DynamoDB table and CloudWatch log group
TABLE_NAME = 'data-lake-pipeline-audit-balance-control-table'
LOG_GROUP_NAME = '/aws/lakehouse-audit-extract'
LOG_STREAM_NAME = 'ABC-extract'

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    start_time = datetime.now()
    logger.info(f'Audit_extractor Starting execution for merge job at {start_time}')    
    table = dynamodb.Table(TABLE_NAME)
    
    # Get unique JobNames
    response = table.scan(ProjectionExpression="JobName")

    job_names = set(item['JobName'] for item in response['Items'])
    logger.info(f'Audit_extractor All jobs names in audit table: {job_names}')
    log_events = []
    
    for job_name in job_names:
        # Query the latest entry for each JobName
        response = table.query(
            KeyConditionExpression=Key('JobName').eq(job_name),
            ScanIndexForward=False,
            Limit=1
        )
        if response['Items']:
            latest_item = response['Items'][0]
            
            # Trim or skip RunStatusDesc field
            if 'RunStatusDesc' in latest_item:
                latest_item['RunStatusDesc'] = latest_item['RunStatusDesc'][:20] + "..."
            
            log_event = {
                'timestamp': int(datetime.now().timestamp() * 1000),
                'message': str(latest_item)
            }
            log_events.append(log_event)
    
    timestamp = start_time.strftime("%Y%m%d%H%M%S")
    log_stream_name = f"{LOG_STREAM_NAME}_{timestamp}"
    logger.info(f'Audit_extractor writing to log_stream_name - {log_stream_name}')
    # Create a log stream if it doesn't exist
    try:
        cloudwatch_logs.create_log_stream(logGroupName=LOG_GROUP_NAME, logStreamName=log_stream_name)
    except cloudwatch_logs.exceptions.ResourceAlreadyExistsException:
        pass
    
    # Put log events to CloudWatch Logs
    if log_events:
        cloudwatch_logs.put_log_events(
            logGroupName=LOG_GROUP_NAME,
            logStreamName=log_stream_name,
            logEvents=log_events
        )
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() / 60
    logger.info(f'Audit_extractor Job completed in {duration:.2f} minutes')

    
    return {
        'statusCode': 200,
        'body': 'Logs successfully written to CloudWatch'
    }