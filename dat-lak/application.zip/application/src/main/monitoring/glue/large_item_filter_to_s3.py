import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

sc = SparkContext()
glueContext = GlueContext(sc)
job = Job(glueContext)

args = getResolvedOptions(sys.argv, ['env'])
# Read data from AWS Data Catalog
dyf = glueContext.create_dynamic_frame.from_catalog(
    database="curate_db",
    table_name="curate_party",
    transformation_ctx="dyf"
)

# Function to check if item size is greater than 400KB
def is_large_item(record):
    record_size = sum([len(str(value)) for value in record.values()])
    return record_size > 409600

# Filter records based on item size
large_items_dyf = dyf.filter(is_large_item)

try:
      
    # Write large items to S3 in CSV format
    glueContext.write_dynamic_frame.from_options(
        frame=large_items_dyf,
        connection_type="s3",
        format="csv",
        format_options = {"withHeader": False},
        connection_options={
            "path": f"s3://{args['env']}-acb-dl-dat-lak-raw-lease-leasewave-asset/large_items/"
    
        }
    )
    print("Data successfully written to S3")
except Exception as e:
    print(f"Error writing to S3: {str(e)}")
    
job.commit()
