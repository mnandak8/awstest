import os
import argparse
from pyspark.sql import SparkSession
import boto3
import logging
import json
from datetime import datetime, timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed


class IcebergTableMaintenance:
    """
    Class to encapsulate the functionality for maintaining Iceberg tables in AWS Glue Catalog.
    """

    def __init__(self):
        """
        Initializes logging, SparkSession, and retrieves parameters from AWS Parameter Store.
        """
        self.logger = self._initialize_logging()
        self.spark = self._initialize_spark_session()
        self.ssm_client = boto3.client('ssm', region_name='us-west-2')

        # Retrieve necessary parameters from AWS Parameter Store
        self.expire_snapshots_older_than_date = self._get_parameter(
            '/dat-lak/iceberg-maintenance/expire_snapshots_older_than_date',
            default_value=(datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
        )
        sort_order_mapping_json = self._get_parameter(
            '/dat-lak/iceberg-maintenance/table_sort_order_mapping',
            default_value='{}'
        )
        concurrency_settings_json = self._get_parameter(
            '/dat-lak/iceberg-maintenance/concurrency_settings',
            default_value='{}'
        )

        # Parse the JSON mappings for sort order and concurrency settings
        self.sort_order_mapping = json.loads(sort_order_mapping_json)
        concurrency_settings = json.loads(concurrency_settings_json)

        self.default_concurrency = concurrency_settings.get("default", 5)
        self.max_concurrency = concurrency_settings.get("max", 10)

    def _initialize_logging(self):
        """
        Sets up logging.

        Returns:
            logger (Logger): Configured logger instance.
        """
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger(__name__)

    def _initialize_spark_session(self):
        """
        Sets up the Spark session.

        Returns:
            spark (SparkSession): Configured Spark session.
        """
        s3_bucket = os.getenv("S3_BUCKET_NAME")
        return SparkSession.builder \
                .config("spark.jars", "/usr/share/aws/iceberg/lib/iceberg-spark3-runtime.jar") \
                .config("spark.sql.catalog.glue_catalog","org.apache.iceberg.spark.SparkCatalog") \
                .config("spark.sql.catalog.glue_catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog") \
                .config("spark.sql.catalog.glue_catalog.warehouse", "s3://{s3_bucket}/warehouse-prefix") \
                .config("spark.sql.catalog.glue_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO") \
                .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
                .enableHiveSupport()\
                .getOrCreate()

    def _get_parameter(self, name, with_decryption=True, default_value=None):
        """
        Retrieve a single parameter from AWS Parameter Store.

        Args:
            name (str): The name of the parameter.
            with_decryption (bool): Whether to decrypt the parameter if it's encrypted.
            default_value: The default value to return if the parameter is not found.

        Returns:
            The value of the parameter, or the default value if not found.
        """
        try:
            response = self.ssm_client.get_parameter(Name=name, WithDecryption=with_decryption)
            return response['Parameter']['Value']
        except self.ssm_client.exceptions.ParameterNotFound:
            return default_value

    @staticmethod
    def log_table_image(spark, database, table, description):
        """
        Logs the current state of a table in the AWS Glue Catalog.

        Args:
            spark (SparkSession): The Spark session.
            database (str): The database name.
            table (str): The table name.
            description (str): A description of the table state being logged.
        """
        logger = logging.getLogger(__name__)
        logger.info(f"{description} for {database}.{table}")
        df = spark.sql(f"SELECT * FROM glue_catalog.{database}.{table}")
        df.show()

    @staticmethod
    def process_table(database, table, expire_snapshots_older_than_date, sort_order_mapping):
        """
        Perform maintenance tasks on  Iceberg tables.

        Args:
            database (str): The database name.
            table (str): The table name.
            expire_snapshots_older_than_date (str): Date string to expire snapshots older than this date.
            sort_order_mapping (dict): Dictionary mapping of sort orders for tables.
        """
        logger = logging.getLogger(__name__)
        glue_client = boto3.client('glue', region_name='us-west-2')
        spark = SparkSession.builder.getOrCreate()

        logger.info(f"Starting processing for {database}.{table}")
        try:
            response = glue_client.get_table(DatabaseName=database, Name=table)
            table_metadata = response['Table']

            if table_metadata['Parameters'].get('table_type') == 'ICEBERG':
                logger.info(f"Processing Iceberg table: {database}.{table}")

                # Log the state of the table before optimization
                IcebergTableMaintenance.log_table_image(spark, database, table, "Before optimization")

                # Determine the sort order columns based on the mapping
                sort_order_columns = sort_order_mapping.get(database, {}).get(table, None)
                if sort_order_columns is None:
                    # If no specific columns are mapped, use the first column as a fallback
                    sort_order_columns = [
                        spark.sql(f"SELECT * FROM glue_catalog.{database}.{table}").schema.fields[0].name]

                # Join multiple sort columns with commas for the SQL query
                sort_order_columns_str = ", ".join(sort_order_columns)

                # SQL commands to perform Iceberg table maintenance
                snapshotsql = f"""
                    CALL glue_catalog.system.expire_snapshots(
                        table => 'glue_catalog.{database}.{table}',
                        older_than => DATE '{expire_snapshots_older_than_date}'
                    )
                """
                rewrite_data_sql = f"""
                    CALL glue_catalog.system.rewrite_data_files(
                        table => 'glue_catalog.{database}.{table}',
                        options => map('min-input-files', '2')
                    )
                """
                rewrite_data_zorder_sql = f"""
                    CALL glue_catalog.system.rewrite_data_files(
                        table => 'glue_catalog.{database}.{table}',
                        strategy => 'sort',
                        sort_order => '{sort_order_columns_str}'
                    )
                """
                

                # Execute the SQL commands
                spark.sql(snapshotsql)
                spark.sql(rewrite_data_sql)
                spark.sql(rewrite_data_zorder_sql)


                # Log the state of the table after optimization
                IcebergTableMaintenance.log_table_image(spark, database, table, "After optimization")

                logger.info(f"Finished processing Iceberg table: {database}.{table}")
        except Exception as e:
            logger.error(f"Error processing table {database}.{table}: {e}")

    def run(self):
        """
        Main method to parse command-line arguments, determine databases and tables to process,
        filter out non-Iceberg tables, and process tables in parallel .
        """
        parser = argparse.ArgumentParser(description='Process Iceberg tables in AWS Glue Catalog.')
        parser.add_argument('--databases', nargs='*', help='List of databases to process')
        parser.add_argument('--tables', nargs='*', help='List of tables to process in the form database.table')

        args = parser.parse_args()

        # Determine databases and tables to process
        database_collect = self.spark.sql("SHOW DATABASES").collect()
        all_databases = [row.namespace for row in database_collect]

        databases_to_process = args.databases if args.databases else all_databases
        tables_to_process = {}

        if args.tables:
            for table in args.tables:
                database, table_name = table.split('.')
                if database not in tables_to_process:
                    tables_to_process[database] = []
                tables_to_process[database].append(table_name)

        # Filter to only include Iceberg tables
        for database in databases_to_process:
            if database not in tables_to_process:
                table_collect = self.spark.sql(f"SHOW TABLES IN {database}").collect()
                tables_to_process[database] = [row.tableName for row in table_collect]

            iceberg_tables = []
            for table in tables_to_process[database]:
                try:
                    response = boto3.client('glue', region_name='us-west-2').get_table(DatabaseName=database,
                                                                                       Name=table)
                    table_metadata = response['Table']
                    if table_metadata['Parameters'].get('table_type') == 'ICEBERG':
                        iceberg_tables.append(table)
                except Exception as e:
                    self.logger.error(f"Error checking table type for {database}.{table}: {e}")
            tables_to_process[database] = iceberg_tables

        # Calculate total number of tables
        total_tables = sum(len(tables) for tables in tables_to_process.values())

        # Process tables in parallel
        for database in databases_to_process:
            if not tables_to_process[database]:
                self.logger.info(f"No Iceberg tables to process in database: {database}")
                continue

            max_workers = min(self.default_concurrency, total_tables, self.max_concurrency)
            self.logger.info(
                f"Starting parallel processing for database: {database} with max workers: {max_workers}")

            # Use a ProcessPoolExecutor to parallelize the processing of tables
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                future_to_table = {
                    executor.submit(self.process_table, database, table, self.expire_snapshots_older_than_date,
                                    self.sort_order_mapping): (database, table)
                    for table in tables_to_process[database]
                }

                # Iterate over completed futures and log their results
                for future in as_completed(future_to_table):
                    database, table = future_to_table[future]
                    try:
                        future.result()
                        self.logger.info(
                            f"Successfully processed table {database}.{table}")
                    except Exception as e:
                        self.logger.error(f"Table {database}.{table} generated an exception: {e}")

        self.logger.info("Maintenance task completed successfully.")


if __name__ == "__main__":
    maintenance = IcebergTableMaintenance()
    maintenance.run()
