import sys
from awsglue.utils import getResolvedOptions
from corelibs.data.factory import Factory

def main():
    args = getResolvedOptions(sys.argv, ['JOB_NAME', 'datasource', 'datasink', 'layer', 'date2process', 'groupname', 'objectname','env'])
    factory = Factory()
    match args.get('layer'):
        case 'raw':
            job = factory.raw(args)
        case 'transform':
            job = factory.transform(args)
        case 'curate':
            job = factory.curate(args)
        case 'consumption':
            job = factory.consumption(args)
        case _:
            raise Exception(f'Invalid layer name: {args.get("layer")}. Valid layer names are: raw, transorm, curate and consumption')
    if job is not None:
        job.submit(factory.spark())
    else:
        raise Exception(f'Data is not available for layer: {args.get("layer")}, groupname: {args.get("groupname")}, objectname: {args.get("objectname")} , date2process: {args.get("date2process")} and env: {args.get("env")}')    
           
        

if __name__ == '__main__':
    main()