
from pyspark.sql.column import Column

class ColumnExt(Column):
    def __init__(self, name) -> None:
        super().__init__()
        self.name = name
        pass

    def alias(self, colm: ColumnExt):
        return super().alias(self.name)
