from pyspark.sql.column import Column

class SalesforceAccountAddress:
    id: Column = Column('id')
    addressTypeC: Column = Column('address_type__c')
    street1C: Column = Column('street_1__c')
    street2C: Column = Column('street_2__c')
    street3C: Column = Column('street_3__c')
    cityC: Column = Column('city__c')
    stateC: Column = Column('state__c')
    zipPostalCodeC: Column = Column('zip_postal_code__c')
    regionC: Column = Column('region__c')
    countryC: Column = Column('country__c')
    relationshipC: Column = Column('relationship__c')