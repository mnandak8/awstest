from pyspark.sql.column import Column

class SalesforceRecordType:
    id: Column = Column('id')
    name: Column = Column('name')
    isActive: Column = Column('isactive')