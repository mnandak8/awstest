from pyspark.sql.column import Column

class SalesforceAccount:
    id: Column = Column('id')
    name: Column = Column('name')
    firstNameC: Column = Column('first_name__c')
    middleNameC: Column = Column('middle_name__c')
    lastNameC: Column = Column('last_name__c')
    phone: Column = Column('phone')
    emailC: Column = Column('email__c')
    activeC: Column = Column('active__c')
    type: Column = Column('type')
    bankingDivisionC: Column = Column('banking_division__c')
    cifPrimaryC: Column = Column('cif_primary__c')
    ccanPrimaryC: Column = Column('ccan_primary__c')
    recordTypeId: Column = Column('recordtypeid')
    masterPartyIDC: Column = Column('master_party_id__c')

    