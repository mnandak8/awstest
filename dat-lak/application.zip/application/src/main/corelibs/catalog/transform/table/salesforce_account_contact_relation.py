from pyspark.sql.column import Column

class SalesforceAccountContactRelation:
    isPrimaryContactC: Column = Column('is_primary_contact__c')
    isActive: Column = Column('isactive')
    roleC: Column = Column('role__c')
    accountId: Column = Column('accountid')
    