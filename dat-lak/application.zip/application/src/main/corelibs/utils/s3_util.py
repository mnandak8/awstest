import boto3
from collections import OrderedDict

class S3Util:
    def __init__(self) -> None:
        pass

    @staticmethod
    def getLatest(bucket_name, prefix):
        s3 = boto3.client('s3')
        modified_at = lambda x: x['LastModified']
        s3_object = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        if 'Contents' in s3_object:
            last_update = max(s3_object['Contents'], key=modified_at)
            return last_update['Key']
        return None
