import json

class ConfigUtil:
    def __init__(self, cfg_file = './etl.conf'):
        self.cfg_file = cfg_file
        pass

    def config(self):
        try:
            with open(self.cfg_file) as f:
                return json.load(f)
        except Exception as ex:
            raise Exception(f"Fail to load ETL configuration file: {ex}")

    