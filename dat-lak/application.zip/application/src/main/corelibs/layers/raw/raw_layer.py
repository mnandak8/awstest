from datetime import datetime
from datetime import timezone
from logging import getLogger
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from pyspark.context import SparkContext
from awsglue.context import GlueContext

class RawLayer(EtlJob):
    def __init__(self, source: Source, sink: Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        # self.log = getLogger(__name__)
        self.log = logger
        pass

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2raw'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
    
        now_str = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        df = self.source.read(spark)
        df.printSchema()
        if(df.isEmpty()):
            self.log.warn(f'{job_name} ERROR : The dataframe is empty. Please validate the source path!')
            return
        ext_df = df.withColumn("raw_utc", lit(f'{datetime.now(timezone.utc)}'))\
            .withColumn("year", lit(now_str[0]))\
            .withColumn("month",lit(now_str[1]))\
            .withColumn("day", lit(now_str[2]))
        self.sink.write(ext_df)

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')
