import logging
from awsglue.context import GlueContext
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    lit, struct, array_distinct, col,
    collect_list, array, filter)
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.layers.consumption import parties, parties_ccans, parties_200


class Party(EtlJob):
    def __init__(self, source: Source, sink: Sink, env, logger : any) -> None:
        self.source = source
        self.sink = sink
        # self.log = logging.getLogger(__name__)
        self.log = logger
        self.env = env
        pass\
        
    def __isLegalAddress(self, address) -> bool:
        return address['AddressType'] == "Legal Address"

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2consumption-Party'
        self.log.info(f"{job_name} Starting execution for merge job at {start_time}")
        parties_removed = ['0015G00002GjbxiQAB']
        if self.env.lower() == 'prod':
            # print(f"Prod: Environment is: {self.env}")
            self.log.info(f"{job_name} Triggering for filtered parties")
            df = self.source.read(spark)["partyDF"].filter(col("primary_cif").isin(parties) | col("primary_ccan").isin(parties_ccans)).cache()
        else:
            # print(f"Non-Prod: Environment is: {self.env}")
            # PBI 322696 - ALL CIF's - VallemS - 12/03/2024
            self.log.info(f"{job_name} Triggering for all parties")
            df = self.source.read(spark)["partyDF"].cache()
            df_total = self.source.read(spark)["partyDF"].cache()
            df = df_total.filter(~df_total["source_system_unique_key"].isin(parties_removed)) 
        finalDF = df.groupBy(
                    df.source_system_unique_key.alias("pk"), 
                    df.source_system_unique_key.alias("sk"), 
                    df.master_party_id.alias("mpid"),
                    df.party_nm.alias("PartyName"),
                    df.party_first_nm.alias("PartyFirstName"), 
                    df.party_middle_nm.alias("PartyMiddleName"), 
                    df.party_last_nm.alias("PartyLastName"), 
                    df.phone_num.alias("PartyPrimaryPhone"), 
                    df.email_address.alias("PartyPrimaryEmail"), 
                    df.party_status_type_desc.alias("PartyActiveFlag"), 
                    df.party_type_id.alias("PartyType"), 
                    df.banking_division.alias("BankingDivision"),
                    df.party_role.alias("PartyRole"), 
                    lit(start_time).alias("load_date")
                ).agg(
                    array_distinct(collect_list(struct(
                        array(df.primary_cif).alias("CIF"),
                        array(df.primary_ccan).alias("CCAN")
                        ))).alias("PartyRelationship"),
                    filter(
                        array_distinct(collect_list(struct(
                            df.address_type_desc.alias("AddressType"),
                            df.address_line_1_txt.alias("Street1"),
                            df.address_line_2_txt.alias("Street2"),
                            df.address_line_3_txt.alias("Street3"),
                            df.city_nm.alias("City"),
                            df.state_nm.alias("State"),
                            df.postalcd_area_cd.alias("PostalCode"),
                            df.party_address_region.alias("Region")
                        ))), self.__isLegalAddress).alias("PartyAddress"),
                    array_distinct(collect_list(struct(
                        df.party_contact_id.alias("ContactGUID"),
                        df.contact_nm.alias("ContactFullName"),
                        df.contact_first_nm.alias("ContactFirstName"),
                        df.contact_middle_nm.alias("ContactMiddleName"),
                        df.contact_last_nm.alias("ContactLastName"),
                        df.contact_salutation.alias("ContactSalutation"),
                        df.contact_phone.alias("ContactPrimaryPhone"),
                        df.contact_email_address.alias("ContactPrimaryEmail"),
                        df.contact_primary_ind.alias("ContactPrimaryFlag"),
                        df.contact_active_ind.alias("ContactActiveFlag"),
                        df.contact_designation.alias("ContactRole"),
                        struct(
                            df.contact_location_street1.alias("Street1"),
                            df.contact_location_street2.alias("Street2"),
                            df.contact_location_city.alias("City"),
                            df.contact_location_state.alias("State"),
                            df.contact_location_country.alias("Country"),
                            df.contact_location_postalcd.alias("PostalCode")
                        ).alias("ContactLocationAddress"),
                        struct(
                            df.contact_mailing_street1.alias("Street1"),
                            df.contact_mailing_street2.alias("Street2"),
                            df.contact_mailing_city.alias("City"),
                            df.contact_mailing_state.alias("State"),
                            df.contact_mailing_country.alias("Country"),
                            df.contact_mailing_postalcd.alias("PostalCode")
                        ).alias("ContactMailingAddress")
                    ))).alias("PartyContact")
                )
        self.sink.write(finalDF.repartition(100), GlueContext(spark))
        df.unpersist()
        # pass

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')