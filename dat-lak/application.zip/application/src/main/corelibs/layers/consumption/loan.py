import logging
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    lit,concat,max,trim,coalesce,first,col)
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
# from corelibs.layers.consumption import parties, parties_200
from datetime import datetime

class Loan(EtlJob):
    def __init__(self, source: Source, sink: Sink, env, logger : any) -> None:
        self.source = source
        self.sink = sink
        # self.log = logging.getLogger(__name__)
        self.log = logger
        self.env = env
        pass
                
    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2consumption-Loan'
        self.log.info(f"{job_name} Starting execution for merge job at {start_time}")
        dfs = self.source.read(spark)
        # if self.env.lower() == 'prod':
        #     self.log.info(f"{job_name} Triggering for filtered parties")
        #     # print(f"Prod: Environment is: {self.env}")
        #     loanDF = dfs["loanDetailDF"].filter(col("cif_num").isin(parties))
        #     loanTransactionDF = dfs["loanTransactionDF"].filter(col("cif_num").isin(parties)).filter(col("master_party_id").isNotNull())
        #     loanPaymentScheduleDF = dfs["loanPaymentScheduleDF"].filter(col("cif_num").isin(parties))
        # else:
            # print(f"Non-Prod: Environment is: {self.env}")
            # PBI 322696 - ALL CIF's - VallemS - 12/03/2024
        self.log.info(f"{job_name} Triggering for all parties")
        loanDF = dfs["loanDetailDF"]
        loanTransactionDF = dfs["loanTransactionDF"].filter(col("master_party_id").isNotNull())
        loanPaymentScheduleDF = dfs["loanPaymentScheduleDF"]

        self.log.info(f"{job_name} Processing loanBillingSummary records..")

        loanBillingSummaryDF = dfs["loanBillingSummaryDF"]
        creditArrangementSummary = loanDF.groupBy(
                concat(lit("LoanCreditArrangement#"),loanDF.cif_num).alias("pk"), 
                concat(lit("CreditArrangementSummary#"),loanDF.cif_num).alias("sk"))\
            .agg(
                concat(lit("PartyGuid: {"), first(loanDF.source_system_unique_key,True), lit("}")).alias("PartyReference"),
                first(loanDF.master_party_id, True).alias("mpid"),
                max(loanDF.customer_outstanding_bal).alias("CreditArrangementTotalOutstandingBalance"),
                max(loanDF.customer_tot_comm_amt).alias("CreditArrangementTotalCommitment"),
                max(loanDF.customer_tot_available_bal).alias("CreditArrangementTotalAvailableBalance"),
                max(loanDF.as_of_dt).alias("LoadDateTime")
            )
        self.sink.write(creditArrangementSummary, GlueContext(spark))

        self.log.info(f"{job_name} Processing creditArrangement records..")
        creditArrangement = loanDF.groupBy(
            concat(lit("LoanCreditArrangement#"),coalesce(loanDF.cif_num, lit('null'))).alias("pk"), 
            concat(lit("CreditArrangement#"),coalesce(loanDF.facility_num, lit('null'))).alias("sk"))\
            .agg(
                concat(lit("PartyGuid: {"),first(loanDF.source_system_unique_key,True),lit("}")).alias("PartyReference"), 
                first(loanDF.master_party_id, True).alias("mpid"),
                max(coalesce(loanDF.facility_num, lit('null'))).alias("CreditArrangementFacilityNumber"),
                max(loanDF.facility_outstanding_bal).alias("CreditArrangementOutstandingBalance"),
                max(loanDF.facility_comm_amt).alias("CreditArrangementCommitment"),
                max(loanDF.facility_available_bal).alias("CreditArrangementAvailableBalance"),
                max(loanDF.facility_active_ind).alias("CreditArrangementActiveFlag"),
                max(trim(loanDF.agreement_num)).alias("CreditArrangementAgreementNumber"),
                max(loanDF.as_of_dt).alias("LoadDateTime")
            )
        self.sink.write(creditArrangement, GlueContext(spark))

        self.log.info(f"{job_name} Processing loanTransactionSummary records..")
        loanTransactionSummary = loanDF.groupBy(
            concat(lit("LoanTransaction#"), coalesce(loanDF.obligation_num, lit('null'))).alias("pk"), 
            concat(lit("LoanTransactionSummary#"),coalesce(loanDF.obligation_num, lit('null'))).alias("sk"))\
            .agg(
                concat(lit("PartyGuid: {"),first(loanDF.source_system_unique_key,True),lit("}")).alias("PartyReference"),
                first(loanDF.master_party_id, True).alias("mpid"),
                max(coalesce(loanDF.facility_num, lit('null'))).alias("CreditArrangementFacilityNumber"), 
                max(trim(loanDF.agreement_num)).alias("CreditArrangementAgreementNumber"),
                lit(0).alias("LoanTransactionMonthlyBeginningBalance"),
                lit(0).alias("LoanTransactionMonthlyEndingBalance"),
                lit(0).alias("LoanTransactionMonthlyAccruedInterest"),
                max(loanDF.as_of_dt).alias("LoadDateTime")
            )
        self.sink.write(loanTransactionSummary, GlueContext(spark))

        self.log.info(f"{job_name} Processing loanAccountSummary records..")
        loanAccountSummary = loanDF.groupBy(
            concat(lit("LoanCreditArrangement#"),loanDF.cif_num).alias("pk"), 
            concat(lit("LoanAccountSummary#"),coalesce(loanDF.obligation_num, lit('null'))).alias("sk"))\
            .agg(
                first(loanDF.master_party_id, True).alias("mpid"),
                concat(lit("PartyGuid: {"),first(loanDF.source_system_unique_key,True),lit("}")).alias("PartyReference"), 
                max(coalesce(loanDF.obligation_num, lit('null'))).alias("LoanAccountNumber"),
                max(coalesce(loanDF.facility_num, lit('null'))).alias("CreditArrangementFacilityNumber"),
                max(loanDF.account_nm).alias("LoanAccountName"),
                max(loanDF.loan_active_ind).alias("LoanActiveFlag"),
                max(loanDF.loan_next_pmt_amt).alias("LoanNextPaymentAmount"),
                max(loanDF.loan_next_due_dt).alias("LoanNextDueDate"),
                max(loanDF.loan_maturity_dt).alias("LoanMaturityDate"),
                max(loanDF.loan_eff_dt).alias("LoanEffectiveDate"),
                max(loanDF.loan_bal).alias("LoanBalance"),
                max(loanDF.loan_interest_rt).alias("LoanInterestRate"),
                max(loanDF.rt_maturity_dt).alias("LoanInterestRateMaturityDate"),
                max(loanDF.loan_rt_set_dt).alias("LoanInterestRateSetDate"),
                max(loanDF.as_of_dt).alias("LoadDateTime")
            )
        self.sink.write(loanAccountSummary, GlueContext(spark))

        self.log.info(f"{job_name} Processing principalPayment records..")
        principalPayment = loanPaymentScheduleDF.filter(loanPaymentScheduleDF.obligation_num.isNotNull())\
            .groupBy(
                concat(lit("LoanTransaction#"), loanPaymentScheduleDF.obligation_num).alias("pk") , 
                concat(lit("PrincipalPayment#"),loanPaymentScheduleDF.obligation_num, lit("#"), coalesce(loanPaymentScheduleDF.sched_due_dt, lit('null'))).alias("sk"),
                loanPaymentScheduleDF.sched_due_dt.alias("PaymentDueDate"))\
            .agg(
                concat(lit("PartyGuid: {"),first(loanPaymentScheduleDF.party_guid,True),lit("}")).alias("PartyReference"),
                first(loanPaymentScheduleDF.master_party_id, True).alias("mpid"),
                max(loanPaymentScheduleDF.tot_prin_amt).alias("TotalPrincipalAmount"),
                max(loanPaymentScheduleDF.scheduled_prin_amt).alias("PrincipalAmount"),
                max(loanPaymentScheduleDF.last_modified_dttm).alias("LoadDateTime")
            )
        self.sink.write(principalPayment, GlueContext(spark))

        self.log.info(f"{job_name} Processing billingSummary records..")
        billingSummary = loanBillingSummaryDF.filter(loanBillingSummaryDF.cif_num.isNotNull())\
            .groupBy(
                concat(lit("LoanCreditArrangement#"), loanBillingSummaryDF.cif_num).alias("pk") , 
                concat(lit("Invoice#"), loanBillingSummaryDF.interim_statement_dt).alias("sk"),
                loanBillingSummaryDF.interim_statement_dt.alias("InterimStatementDate"))\
            .agg(
                concat(lit("PartyGuid: {"),first(loanBillingSummaryDF.party_guid,True),lit("}")).alias("PartyReference"),
                first(loanBillingSummaryDF.master_party_id,True).alias("mpid"),
                max(loanBillingSummaryDF.pmt_due_dt).alias("PaymentDueDate"),
                max(loanBillingSummaryDF.currency_cd).alias("CurrencyCode"),
                max(loanBillingSummaryDF.total_prin_amt).alias("TotalPrincipal"),
                max(loanBillingSummaryDF.total_int_amt).alias("TotalInterest"),
                max(loanBillingSummaryDF.total_fees_amt).alias("TotalFees"),
                max(loanBillingSummaryDF.total_other_amt).alias("TotalOther"),
                max(loanBillingSummaryDF.grand_total_due_amt).alias("GrandTotalDue"),
                max(loanBillingSummaryDF.last_modified_dttm).alias("LoadDateTime")
            )
        self.sink.write(billingSummary, GlueContext(spark))

        self.log.info(f"{job_name} Processing loanTransactionDetails records..")
        if 'number_of_days' in loanTransactionDF.columns:
            loanTransactionDetails = loanTransactionDF.filter(loanTransactionDF.obligation_num.isNotNull()).groupBy(
                    concat(lit("LoanTransaction#"), loanTransactionDF.obligation_num).alias("pk") , 
                    concat(lit("LoanTransactionDetails#"), loanTransactionDF.obligation_num, lit("#"), 
                    loanTransactionDF.loan_tran_eff_dt, lit("#"),coalesce(loanTransactionDF.tran_ref_num, lit('null'))).alias("sk"))\
                .agg(
                    concat(lit("PartyGuid: {"),first(loanTransactionDF.party_guid,True),lit("}")).alias("PartyReference"),
                    first(loanTransactionDF.master_party_id,True).alias("mpid"),
                    max(loanTransactionDF.loan_tran_eff_dt).alias("LoanTransactionEffectiveDate"),
                    max(loanTransactionDF.loan_tran_post_dt).alias("LoanTransactionPostDate"),
                    max(loanTransactionDF.loan_tran_desc).alias("LoanTransactionDescription"),
                    max(loanTransactionDF.loan_tran_amt).alias("LoanTransactionAmount"),
                    max(loanTransactionDF.loan_tran_new_prin_bal).alias("LoanTransactionNewPrincipalBalance"),
                    max(loanTransactionDF.loan_tran_accrued_interest_amt).alias("LoanTransactionAccruedInterest"),
                    max(loanTransactionDF.loan_tran_int_current_accruing_rt).alias("LoanTransactionInterestRate"),
                    max(loanTransactionDF.tran_ref_num).alias("TransactionReferenceNumber"),
                    max(loanTransactionDF.tran_type_cd).alias("LoanTransactionHistoryTransactionCode"),
                    max(loanTransactionDF.last_modified_dttm).alias("LoadDateTime"),
                    max(loanTransactionDF.number_of_days).alias("LoanTransactionInterestNumberOfDays"),
                    max(loanTransactionDF.beginning_date).alias("LoanTransactionInterestBeginningDate"),
                    max(loanTransactionDF.ending_date).alias("LoanTransactionInterestEndingDate"),
                    max(loanTransactionDF.avg_daily_interest_accrual_amount).alias("LoanTransactionInterestAccrualAmount")
                )
        else:
            loanTransactionDetails = loanTransactionDF.filter(loanTransactionDF.obligation_num.isNotNull()).groupBy(
                concat(lit("LoanTransaction#"), loanTransactionDF.obligation_num).alias("pk") , 
                concat(lit("LoanTransactionDetails#"), loanTransactionDF.obligation_num, lit("#"), 
                loanTransactionDF.loan_tran_eff_dt, lit("#"),coalesce(loanTransactionDF.tran_ref_num, lit('null'))).alias("sk"))\
            .agg(
                concat(lit("PartyGuid: {"),first(loanTransactionDF.party_guid,True),lit("}")).alias("PartyReference"),
                first(loanTransactionDF.master_party_id,True).alias("mpid"),
                max(loanTransactionDF.loan_tran_eff_dt).alias("LoanTransactionEffectiveDate"),
                max(loanTransactionDF.loan_tran_post_dt).alias("LoanTransactionPostDate"),
                max(loanTransactionDF.loan_tran_desc).alias("LoanTransactionDescription"),
                max(loanTransactionDF.loan_tran_amt).alias("LoanTransactionAmount"),
                max(loanTransactionDF.loan_tran_new_prin_bal).alias("LoanTransactionNewPrincipalBalance"),
                max(loanTransactionDF.loan_tran_accrued_interest_amt).alias("LoanTransactionAccruedInterest"),
                max(loanTransactionDF.loan_tran_int_current_accruing_rt).alias("LoanTransactionInterestRate"),
                max(loanTransactionDF.tran_ref_num).alias("TransactionReferenceNumber"),
                max(loanTransactionDF.tran_type_cd).alias("LoanTransactionHistoryTransactionCode"),
                max(loanTransactionDF.last_modified_dttm).alias("LoadDateTime")
            )
            
        self.sink.write(loanTransactionDetails, GlueContext(spark))
        # pass  
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')

    
