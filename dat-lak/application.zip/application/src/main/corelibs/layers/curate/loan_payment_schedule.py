from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit,broadcast,translate,date_format,unix_timestamp
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.catalog.curate.table.loan_table import LoanTable


class loanPaymentSchedule(EtlJob):
    def __init__(self, source: Source, sink:Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        self.log = logger
        # self.log = logging.getLogger(__name__)
        pass

    def __trnsformDate(self, dtClumn):
        return translate(date_format(unix_timestamp(dtClumn, 'mm/dd/yyyy').cast('timestamp'), 'yyyy/mm/dd'),'/','')

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2curate-LoanPaymentSchedule'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
        
        now_arr = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        dfs = self.source.read(spark)
        zHhpsDF = dfs['zHhpsDF']
        jCamsDF = dfs['jCamsDF']
        sLlcBiLoanDF =  dfs['sLlcBiLoanDF'].select('commitment_number__c','llc_bi__account__c', 'cif__c').distinct()
        sAccountDF = dfs['sAccountDF'].select('id', 'master_party_id__c', 'accountnumber').distinct()
        totalPrinAmtDF = zHhpsDF.where(zHhpsDF.z_mou82.like('TOTAL%')).select(zHhpsDF.z_fobl.alias('zfobl'), zHhpsDF.z_ffa1.alias('zffa1'))
        sflc = sLlcBiLoanDF\
            .join(broadcast(sAccountDF), sLlcBiLoanDF.llc_bi__account__c == sAccountDF.id, 'inner')\
            .join(broadcast(jCamsDF), sLlcBiLoanDF.commitment_number__c == jCamsDF.j_baci, 'inner')\
            .select(sLlcBiLoanDF.cif__c,sLlcBiLoanDF.llc_bi__account__c,sAccountDF.master_party_id__c, sAccountDF.accountnumber ).distinct()

        loanPaymentScheduleDF = zHhpsDF\
            .join(broadcast(sflc), zHhpsDF.z_cif == sflc.cif__c, 'left')\
            .join(broadcast(sAccountDF), sLlcBiLoanDF.llc_bi__account__c == sAccountDF.id, 'left')\
            .join(broadcast(totalPrinAmtDF), zHhpsDF.z_fobl == totalPrinAmtDF.zfobl, 'left')\
            .select(
                zHhpsDF.z_cif.alias(LoanTable.CifNum),
                zHhpsDF.z_fobl.alias(LoanTable.ObligationNum),
                sflc.llc_bi__account__c.alias(LoanTable.PartyGuid),
                sflc.master_party_id__c.alias(LoanTable.MasterPartyId),
                self.__trnsformDate(zHhpsDF.z_we10).alias(LoanTable.EffectiveDt),
                zHhpsDF.zjobnbr.alias(LoanTable.JobNum),
                self.__trnsformDate(zHhpsDF.z_mou82).alias(LoanTable.SchedDueDt),
                zHhpsDF.z_ffa1.alias(LoanTable.ScheduledPrinAmt),
                zHhpsDF.zdattim.alias(LoanTable.LastModifiedDttm),
                zHhpsDF.update_ident.alias(LoanTable.UpdateIdentifier),
                totalPrinAmtDF.zffa1.alias(LoanTable.TotPrinAmt)
            )\
            .where(~zHhpsDF.z_mou82.like('TOTAL%')).distinct()\
            .withColumn('year', lit(now_arr[0]))\
            .withColumn('month', lit(now_arr[1]))\
            .withColumn('day', lit(now_arr[2]))
        self.sink.write(loanPaymentScheduleDF)
        self.sink.write(loanPaymentScheduleDF.transform(super(loanPaymentSchedule, self).trimStrColumns))
        # pass

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')