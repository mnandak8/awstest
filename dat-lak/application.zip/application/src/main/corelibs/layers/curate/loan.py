from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import lit, broadcast, min, max, sum, col, current_timestamp
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.catalog.curate.table.loan_table import LoanTable


class Loan(EtlJob):
    def __init__(self, source: Source, sink:Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        self.log = logger
        # self.log = logging.getLogger(__name__)
        pass

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2curate-Loan'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
    
        now_arr = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        dfs = self.source.read(spark)
        jCumsDF = dfs['jCumsDF']
        jCamsDF = dfs['jCamsDF']
        jCamiDF = dfs['jCamiDF']
        jClmsDF = dfs['jClmsDF']
        jClmiDF = dfs['jClmiDF']
        jClasDF = dfs['jClasDF'].filter(dfs['jClasDF'].j_cczc.isin('100', '600'))
        jClliDF = dfs['jClliDF']
        jClsbDF = dfs['jClsbDF']
        sLlcBiLoanDF =  dfs['sLlcBiLoanDF'].select('commitment_number__c', 'llc_bi__account__c')
        sAccountDF = dfs['sAccountDF'].select('id', 'master_party_id__c')
        cbDF = jCamsDF.groupBy(jCamsDF.j_babi).agg(
            sum(jCamsDF.j_bbu_).alias(LoanTable.CustomerOurstadingBal),
            sum(jCamsDF.j_bbs_).alias(LoanTable.CustomerTotCommAmt),
            sum(jCamsDF.j_bbv_).alias(LoanTable.CustomerTotAvailableBal)
        )

        loanNextDueDateDF = jClliDF.filter(jClliDF.j_cxic.isin('100', '600'))\
            .groupBy(jClliDF.j_mori).agg(max(jClliDF.j_mou8).alias(LoanTable.LoanNextDueDt))
        
        LoanNextPmtAmtDF = jClliDF.select(
            jClliDF.j_mori,
            (sum(jClliDF.j_mox_).over(Window.partitionBy(jClliDF.j_mori))
            + sum(jClliDF.j_moy_).over(Window.partitionBy(jClliDF.j_mori))
            + sum(jClliDF.j_moz_).over(Window.partitionBy(jClliDF.j_mori))).alias(LoanTable.LoanNextPmtAmt)).distinct()

        secondaryBillingSegmentDF = jClsbDF.filter(jClsbDF.j_cxec.isin('100','600'))\
                                    .withColumn('minJFmln', min(jClsbDF.j_fmln).over(Window.partitionBy(jClsbDF.j_mnei)))\
                                    .filter(jClsbDF.j_fmln == col('minJFmln'))\
                                    .select(jClsbDF.j_mnei, jClsbDF.j_mnic.alias(LoanTable.LoanSecondaryBillingSegmentFrequencyCd))
        loanDF = jCumsDF\
            .join(broadcast(jCamsDF), jCumsDF.j_mrui == jCamsDF.j_babi, 'left')\
            .join(broadcast(jCamiDF), (jCamsDF.j_baci == jCamiDF.j_baci) & (jCamsDF.j_baai == jCamiDF.j_baai), 'left')\
            .join(broadcast(jClmsDF), (jCamsDF.j_baci == jClmsDF.j_mbxi) & (jCamsDF.j_baai == jClmsDF.j_mbsi), 'left')\
            .join(broadcast(jClmiDF), (jClmsDF.j_mbti == jClmiDF.j_mbti) & (jClmsDF.j_mbsi == jClmiDF.j_mbsi), 'left')\
            .join(broadcast(jClasDF), (jClmsDF.j_mbti == jClasDF.j_ccwi) & (jClmsDF.j_mbsi == jClasDF.j_ccvi) & (jClasDF.j_cddc == 'INTLN') & (jClasDF.j_cdcc == '1'), 'left')\
            .join(broadcast(loanNextDueDateDF), jClmsDF.j_mbti == loanNextDueDateDF.j_mori, 'left')\
            .join(broadcast(LoanNextPmtAmtDF), jClmsDF.j_mbti == LoanNextPmtAmtDF.j_mori, 'left')\
            .join(broadcast(cbDF), jCumsDF.j_mrui == cbDF.j_babi, 'left')\
            .join(broadcast(sLlcBiLoanDF), jCamsDF.j_baci == sLlcBiLoanDF.commitment_number__c, 'left')\
            .join(broadcast(sAccountDF), sLlcBiLoanDF.llc_bi__account__c == sAccountDF.id, 'left')\
            .join(broadcast(secondaryBillingSegmentDF), jClmsDF.j_mbti == secondaryBillingSegmentDF.j_mnei, 'left')\
            .select(
                jCumsDF.j_mrui.alias(LoanTable.CifNum),
                jCamsDF.j_bagt.alias(LoanTable.AgreementNum),
                jCamsDF.j_baci.alias(LoanTable.FacilityNum),
                jCamsDF.j_bbs_.alias(LoanTable.FacilityCommAmt),
                jCamsDF.j_bao8.alias(LoanTable.FacilityMaturityDt),
                jCamsDF.j_bbu_.alias(LoanTable.FacilityOutstadingBal),
                jCamsDF.j_bbv_.alias(LoanTable.FacilityAvailableBal),
                jCamiDF.j_bcac.alias(LoanTable.FacilityActiveInd),
                jClmsDF.j_mee_.alias(LoanTable.LoanBal),
                jClmsDF.j_mci8.alias(LoanTable.LoanEffDt),
                jClmsDF.j_mcj8.alias(LoanTable.LoanMaturityDt),
                jClmsDF.j_dhd8.alias(LoanTable.LoanRtSetDt),
                jClmsDF.j_mbti.alias(LoanTable.ObligationNum),
                jClmsDF.j_mck8.alias(LoanTable.RtMaturityDt),
                jClmsDF.j_awac.alias(LoanTable.LoanActiveInd),
                jClmsDF.raw_utc.alias(LoanTable.AsOfDt),
                sAccountDF.master_party_id__c.alias(LoanTable.MasterPartyId),
                current_timestamp().alias(LoanTable.LoanDttm),
                jClmiDF.j_duec.alias(LoanTable.AccountNm),
                jClasDF.j_cdzr.alias(LoanTable.LoanInterestRt),
                cbDF.Customer_Outstanding_Bal,
                cbDF.Customer_Tot_Comm_Amt,
                cbDF.Customer_Tot_Available_Bal,
                loanNextDueDateDF.Loan_Next_Due_Dt,
                LoanNextPmtAmtDF.Loan_Next_Pmt_Amt,
                sLlcBiLoanDF.llc_bi__account__c.alias(LoanTable.SourceSystemUniqueKey),
                secondaryBillingSegmentDF.Loan_Secondary_Billing_Segment_Frequency_Cd
            ).distinct()\
            .withColumn('year', lit(now_arr[0]))\
            .withColumn('month', lit(now_arr[1]))\
            .withColumn('day', lit(now_arr[2]))
        self.sink.write(loanDF.transform(super(Loan, self).trimStrColumns))
        # pass

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')