from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, broadcast, col
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.catalog.curate.table.party_table import PartyTable


class Party(EtlJob):
    def __init__(self, source: Source, sink:Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        self.log = logger
        # self.log = logging.getLogger(__name__)
        pass

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2curate-Party'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
    
        now_arr = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        dfs = self.source.read(spark)
        accountDF = dfs['accountDF']
        accountAddressDF = dfs['accountAddressDF']
        recordTypeDF = dfs['recordTypeDF'].filter(col('isactive') == True)
        contactDF = dfs['contactDF']
        accountContactDF = dfs['accountContactDF']

        self.log.info(f'Preparing curate data for party with number of accounts: {accountDF.count()}')
        partyDF = accountDF\
            .join(broadcast(recordTypeDF), accountDF.recordtypeid == recordTypeDF.id, 'left')\
            .join(broadcast(accountAddressDF), accountDF.id == accountAddressDF.relationship__c, 'left')\
            .join(broadcast(accountContactDF),
                  (accountDF.id == accountContactDF.accountid)\
                  & (accountContactDF.isdeleted == False),
                   'left')\
            .join(broadcast(contactDF), accountContactDF.contactid == contactDF.id, 'left')\
            .select(
                accountDF.id.alias(PartyTable.sourceSystemUniqueKey),
                accountDF.name.alias(PartyTable.partyNm),
                accountDF.first_name__c.alias(PartyTable.partyFirstNm),
                accountDF.middle_name__c.alias(PartyTable.partyMiddleNm),
                accountDF.last_name__c.alias(PartyTable.partyLastNm),
                accountDF.phone.alias(PartyTable.phoneNum),
                accountDF.email__c.alias(PartyTable.emailAddress),
                accountDF.active__c.alias(PartyTable.partyStatusTypeDesc),
                accountDF.type.alias(PartyTable.partyTypeId),
                accountDF.banking_division__c.alias(PartyTable.bankingDivision),
                accountDF.cif_primary__c.alias(PartyTable.primaryCIF),
                accountDF.ccan_primary__c.alias(PartyTable.primaryCCAN),
                accountDF.master_party_id__c.alias(PartyTable.masterPartyID),
                accountAddressDF.id.alias(PartyTable.postalAddressId),
                accountAddressDF.address_type__c.alias(PartyTable.addressTypeDesc),
                accountAddressDF.street_1__c.alias(PartyTable.addressLine1Txt),
                accountAddressDF.street_2__c.alias(PartyTable.addressLine2Txt),
                accountAddressDF.street_3__c.alias(PartyTable.addressLine3Txt),
                accountAddressDF.city__c.alias(PartyTable.cityNm),
                accountAddressDF.state__c.alias(PartyTable.stateNm),
                accountAddressDF.zip_postal_code__c.alias(PartyTable.postalCdAreaCd),
                accountAddressDF.region__c.alias(PartyTable.partyAddressRegion),
                recordTypeDF.id.alias(PartyTable.partyRoleTypeId),
                recordTypeDF.name.alias(PartyTable.partyRole),
                contactDF.name.alias(PartyTable.contactNm),
                contactDF.id.alias(PartyTable.contactId),
                contactDF.firstname.alias(PartyTable.contactFirstNm),
                contactDF.middlename.alias(PartyTable.contactMiddleNm),
                contactDF.lastname.alias(PartyTable.contactLastNm),
                contactDF.salutation.alias(PartyTable.contactSalutation),
                contactDF.phone.alias(PartyTable.contactPhone),
                contactDF.email.alias(PartyTable.contactEmailAddress),
                contactDF.location_address_street__c.alias(PartyTable.contactLocationStreet1),
                contactDF.location_address_street_2__c.alias(PartyTable.contactLocationStreet2),
                contactDF.location_address_city__c.alias(PartyTable.contactLocationCity),
                contactDF.location_address_state__c.alias(PartyTable.contactLocationState),
                contactDF.location_address_country__c.alias(PartyTable.contactLocationCountry),
                contactDF.location_address_zip_postal_code__c.alias(PartyTable.contactLocationPostalCd),
                contactDF.mailing_address_street__c.alias(PartyTable.contactMailingStreet1),
                contactDF.mailing_address_street_2__c.alias(PartyTable.contactMailingStreet2),
                contactDF.mailing_address_city__c.alias(PartyTable.contactMailingCity),
                contactDF.mailing_address_state__c.alias(PartyTable.contactMailingState),
                contactDF.mailing_address_country__c.alias(PartyTable.contactMailingCountry),
                contactDF.mailing_address_zip_postal_code__c.alias(PartyTable.contactMailingPostalCd),
                accountContactDF.isactive.alias(PartyTable.contactActiveInd),
                accountContactDF.is_primary_contact__c.alias(PartyTable.contactPrimaryInd),
                accountContactDF.role__c.alias(PartyTable.contactDesignation)
                )\
                .distinct()\
                .withColumn('year', lit(now_arr[0]))\
                .withColumn('month', lit(now_arr[1]))\
                .withColumn('day', lit(now_arr[2]))
        self.sink.write(partyDF.transform(super(Party, self).trimStrColumns))
        # pass

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')