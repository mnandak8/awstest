from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit,broadcast
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.catalog.curate.table.loan_table import LoanTable


class loanBillingSummary(EtlJob):
    def __init__(self, source: Source, sink:Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        self.log = logger
        # self.log = logging.getLogger(__name__)
        pass

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2curate-LoanBillingSummary'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
    
        now_arr = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        dfs = self.source.read(spark)
        zHhbsDF = dfs['zHhbsDF']
        jCamsDF = dfs['jCamsDF']
        sLlcBiLoanDF =  dfs['sLlcBiLoanDF'].select('cif__c', 'commitment_number__c', 'llc_bi__account__c').distinct()
        sAccountDF = dfs['sAccountDF'].select('id', 'master_party_id__c').distinct()
        sflc = sLlcBiLoanDF\
            .join(broadcast(sAccountDF), sLlcBiLoanDF.llc_bi__account__c == sAccountDF.id, 'inner')\
            .join(broadcast(jCamsDF), sLlcBiLoanDF.commitment_number__c == jCamsDF.j_baci, 'inner')\
            .select(sLlcBiLoanDF.cif__c,sLlcBiLoanDF.llc_bi__account__c,sAccountDF.master_party_id__c ).distinct()

        loanBillingSummaryDF = zHhbsDF\
            .join(broadcast(sflc), zHhbsDF.j_mbui == sflc.cif__c, 'left')\
            .select(
                zHhbsDF.j_mbui.alias(LoanTable.CifNum),
                zHhbsDF.j_axv8.alias(LoanTable.InterimStatementDt),
                sflc.llc_bi__account__c.alias(LoanTable.PartyGuid),
                sflc.master_party_id__c.alias(LoanTable.MasterPartyId),
                zHhbsDF.j_mbsi.alias(LoanTable.LoanPortfolioId),
                zHhbsDF.dsdyw8.alias(LoanTable.PmtDueDt),
                zHhbsDF.zjobnbr.alias(LoanTable.JobNum),
                zHhbsDF.j_javc.alias(LoanTable.CurrencyCd),
                zHhbsDF.zbsora.alias(LoanTable.TotalPrinAmt),
                zHhbsDF.zbsosa.alias(LoanTable.TotalIntAmt),
                zHhbsDF.zbsota.alias(LoanTable.TotalFeesAmt),
                zHhbsDF.zbsoua.alias(LoanTable.TotalOtherAmt),
                zHhbsDF.zbsnya.alias(LoanTable.GrandTotalDueAmt),
                zHhbsDF.zdattim.alias(LoanTable.LastModifiedDttm)
            ).distinct()\
            .withColumn('year', lit(now_arr[0]))\
            .withColumn('month', lit(now_arr[1]))\
            .withColumn('day', lit(now_arr[2]))
        self.sink.write(loanBillingSummaryDF.transform(super(loanBillingSummary, self).trimStrColumns))
        # pass
            
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')