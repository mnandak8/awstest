from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit,broadcast
from pyspark.sql.types import IntegerType,DecimalType
from corelibs.etl_job import EtlJob
from corelibs.source import Source
from corelibs.sink import Sink
from corelibs.catalog.curate.table.loan_table import LoanTable


class loanTransaction(EtlJob):
    def __init__(self, source: Source, sink:Sink, logger:any) -> None:
        self.source = source
        self.sink = sink
        self.log = logger
        # self.log = logging.getLogger(__name__)
        pass

    def submit(self, spark: SparkSession) -> None:
        start_time = datetime.now()
        job_name = f'{self.source.getjobname()}_2curate-LoanTransaction'
        self.log.info(f'{job_name} Starting execution for merge job at {start_time}')
    
        now_arr = datetime.now().strftime('%Y/%m/%d/%H/%M/%S').split("/")
        dfs = self.source.read(spark)
        zHhtrDF = dfs['zHhtrDF']
        jCamsDF = dfs['jCamsDF']
        sLlcBiLoanDF =  dfs['sLlcBiLoanDF'].select('cif__c','commitment_number__c', 'llc_bi__account__c').distinct()
        sAccountDF = dfs['sAccountDF'].select('id', 'master_party_id__c').distinct()
        sflc = sLlcBiLoanDF\
            .join(broadcast(sAccountDF), sLlcBiLoanDF.llc_bi__account__c == sAccountDF.id, 'inner')\
            .join(broadcast(jCamsDF), sLlcBiLoanDF.commitment_number__c == jCamsDF.j_baci, 'inner')\
            .select(sLlcBiLoanDF.cif__c,sLlcBiLoanDF.llc_bi__account__c,sAccountDF.master_party_id__c ).distinct()
        
        if 'j_perdys' in zHhtrDF.columns:
            loanTransactionDF = zHhtrDF\
                .join(broadcast(sflc), zHhtrDF.j_mbui == sflc.cif__c, 'left')\
                .filter(zHhtrDF.j_mbui.isNotNull())\
                .select(
                    zHhtrDF.j_mbui.alias(LoanTable.CifNum),
                    zHhtrDF.j_mbti.alias(LoanTable.ObligationNum),
                    zHhtrDF.j_mpw8.alias(LoanTable.LoanTranEffDt),
                    zHhtrDF.j_jgsn.cast(IntegerType()).alias(LoanTable.TranRefNum),
                    zHhtrDF.j_mpyc.alias(LoanTable.TranTypeCd),
                    sflc.llc_bi__account__c.alias(LoanTable.PartyGuid),
                    sflc.master_party_id__c.alias(LoanTable.MasterPartyId),
                    zHhtrDF.j_mbsi.alias(LoanTable.LoanPortfolioId),
                    zHhtrDF.coagv8.alias(LoanTable.ProcessDt),
                    zHhtrDF.zjobnbr.alias(LoanTable.JobNum),
                    zHhtrDF.j_mpx8.alias(LoanTable.LoanTranPostDt),
                    zHhtrDF.j_nlrt.alias(LoanTable.LoanTranDesc),
                    zHhtrDF.j_tranval.cast(DecimalType(18,2)).alias(LoanTable.LoanTranAmt),
                    zHhtrDF.z_ffa1.cast(DecimalType(18,2)).alias(LoanTable.LoanTranNewPrinBal),
                    zHhtrDF.z_cdzr.cast(DecimalType(18,2)).alias(LoanTable.LoanTranIntCurrentAccruingRt),
                    zHhtrDF.z_ffa2.cast(DecimalType(18,2)).alias(LoanTable.LoanTranAccruedInterestAmt),
                    zHhtrDF.z_wrfl.alias(LoanTable.CoLinkWireableInd),
                    zHhtrDF.zdattim.alias(LoanTable.LastModifiedDttm),
                    zHhtrDF.j_perdys.cast(DecimalType(18,2)).alias(LoanTable.NumberOfDays),
                    zHhtrDF.j_acrfr8.alias(LoanTable.BeginningDate),
                    zHhtrDF.z_acrto8.alias(LoanTable.EndingDate),
                    zHhtrDF.j_dlyacr.cast(DecimalType(26,10)).alias(LoanTable.AvgDailyInterestAccrualAmount)
                ).distinct()\
                .withColumn('year', lit(now_arr[0]))\
                .withColumn('month', lit(now_arr[1]))\
                .withColumn('day', lit(now_arr[2]))
        else:
            loanTransactionDF = zHhtrDF\
                .join(broadcast(sflc), zHhtrDF.j_mbui == sflc.cif__c, 'left')\
                .filter(zHhtrDF.j_mbui.isNotNull())\
                .select(
                    zHhtrDF.j_mbui.alias(LoanTable.CifNum),
                    zHhtrDF.j_mbti.alias(LoanTable.ObligationNum),
                    zHhtrDF.j_mpw8.alias(LoanTable.LoanTranEffDt),
                    zHhtrDF.j_jgsn.cast(IntegerType()).alias(LoanTable.TranRefNum),
                    zHhtrDF.j_mpyc.alias(LoanTable.TranTypeCd),
                    sflc.llc_bi__account__c.alias(LoanTable.PartyGuid),
                    sflc.master_party_id__c.alias(LoanTable.MasterPartyId),
                    zHhtrDF.j_mbsi.alias(LoanTable.LoanPortfolioId),
                    zHhtrDF.coagv8.alias(LoanTable.ProcessDt),
                    zHhtrDF.zjobnbr.alias(LoanTable.JobNum),
                    zHhtrDF.j_mpx8.alias(LoanTable.LoanTranPostDt),
                    zHhtrDF.j_nlrt.alias(LoanTable.LoanTranDesc),
                    zHhtrDF.j_tranval.cast(DecimalType(18,2)).alias(LoanTable.LoanTranAmt),
                    zHhtrDF.z_ffa1.cast(DecimalType(18,2)).alias(LoanTable.LoanTranNewPrinBal),
                    zHhtrDF.z_cdzr.cast(DecimalType(18,2)).alias(LoanTable.LoanTranIntCurrentAccruingRt),
                    zHhtrDF.z_ffa2.cast(DecimalType(18,2)).alias(LoanTable.LoanTranAccruedInterestAmt),
                    zHhtrDF.z_wrfl.alias(LoanTable.CoLinkWireableInd),
                    zHhtrDF.zdattim.alias(LoanTable.LastModifiedDttm)
                ).distinct()\
                .withColumn('year', lit(now_arr[0]))\
                .withColumn('month', lit(now_arr[1]))\
                .withColumn('day', lit(now_arr[2]))
            
        self.sink.write(loanTransactionDF.transform(super(loanTransaction, self).trimStrColumns))
        # pass

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        self.log.info(f'{job_name} Job completed in {duration:.2f} minutes')