from pyspark.sql import SparkSession, DataFrame
class Source:
    def __init__(self) -> None:
        pass

    def read(self, spark: SparkSession)->DataFrame:
        pass

    def getjobname(self):
        pass