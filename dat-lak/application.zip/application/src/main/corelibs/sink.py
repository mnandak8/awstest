from pyspark.sql import SparkSession, DataFrame


class Sink:
    def __init__(self) -> None:
        pass

    def write(df: DataFrame) -> None:
        pass

    def getjobname(self):
        pass