from awsglue.job import Job
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import trim, col

class EtlJob(Job):
    def submit(self, spark: SparkSession):
        pass

    # Method to trim string columns
    def trimStrColumns(self, df: DataFrame) -> DataFrame:
        return df.select(*[trim(col(c[0])).alias(c[0]) if c[1] == 'string' else col(c[0]) for c in df.dtypes])
