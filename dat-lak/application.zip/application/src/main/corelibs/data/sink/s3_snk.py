from corelibs.sink import Sink
from pyspark.sql import DataFrame


class S3Sink(Sink):
    def __init__(self, sink_path, job_name, logger : any) -> None:
        self.sink_path = sink_path
        self.job_name = job_name
        # self.log = logging.getLogger(__name__)
        self.log = logger
        pass

    def write(self, df: DataFrame) -> None:
        if(not df.isEmpty()):
            total_records = df.count()
            self.log.info(f'{self.job_name} About to write {total_records} records to s3 sink path {self.sink_path}')
            df.write.partitionBy("year", "month", "day").parquet(path=self.sink_path, mode='overwrite')
            self.log.info(f'{self.job_name} Completed writing total {total_records} records to {self.sink_path}')

        else:
            self.log.info(f'{self.job_name} ERROR : There is no data to write to s3 sink path {self.sink_path}, skipping..........')
        pass

    def getjobname(self):
        return self.job_name