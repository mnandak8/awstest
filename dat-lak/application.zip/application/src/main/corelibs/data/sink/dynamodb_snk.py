from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from corelibs.sink import Sink
from pyspark.sql import DataFrame

class DynamoDBSink(Sink):
    def __init__(self, tableName: str, writeRole: str, region: str, job_name, logger : any) -> None:
        # self.log = logging.getLogger(__name__)
        self.log = logger
        self.tableName = tableName
        self.writeRole = writeRole
        self.region = region
        self.job_name = job_name
        pass

    def write(self, df: DataFrame, glue: GlueContext) -> None:
        if(not df.isEmpty()):
            total_records = df.count()
            self.log.info(f'{self.job_name} About to write {total_records} records to DynamoDB {self.tableName} table ')

            dynamic_df = DynamicFrame.fromDF(df, glue, "final_dynamic_df")

            glue.write_dynamic_frame.from_options(
                frame = dynamic_df,
                connection_type = "dynamodb",
                connection_options = {
                    "dynamodb.region": self.region,
                    "dynamodb.throughput.write.percent": 1.0,
                    "dynamodb.output.retry": 100,
                    "dynamodb.output.tableName": self.tableName,
                    "dynamodb.sts.roleArn": self.writeRole
                }
            )
            self.log.info(f'{self.job_name} Completed writing total {total_records} records to {self.tableName}')
        else:
            self.log.info(f'{self.job_name} ERROR : There is no data to write to table {self.tableName}, skipping')
        pass

    def getjobname(self):
        return self.job_name