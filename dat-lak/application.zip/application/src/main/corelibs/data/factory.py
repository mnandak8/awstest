from pyspark.context import SparkContext
from awsglue.context import GlueContext
from corelibs.utils.config_util import ConfigUtil
from corelibs.utils.s3_util import S3Util
from corelibs.layers.raw.raw_layer import RawLayer
from corelibs.layers.transform.transform_layer import TransformLayer
from corelibs.data.source.s3_src import S3Source
from corelibs.data.sink.s3_snk import S3Sink
from corelibs.data.sink.dynamodb_snk import DynamoDBSink
from corelibs.layers.curate.party import Party
from corelibs.layers.consumption.party import Party as ConsumptionParty
from corelibs.layers.consumption.loan import Loan as ConsumptionLoan
from corelibs.data.source.curate_loan_src import CurateLoanSource
from corelibs.layers.curate.party import Party
from corelibs.layers.curate.loan import Loan
from corelibs.layers.curate.loan_transaction import loanTransaction
from corelibs.layers.curate.loan_payment_schedule import loanPaymentSchedule
from corelibs.layers.curate.loan_billing_summary import loanBillingSummary

class Factory:
    def __init__(self) -> None:
        # self.log = getLogger(__name__)
        # self.log = self.logger()
        pass

    def config(self):
        cfg_util = ConfigUtil()
        return cfg_util.config()
    
    def spark(self):
        glue_ctx = self.glueContext()
        spark =  glue_ctx.spark_session
        spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")
        return spark

    def glueContext(self):
        return GlueContext(SparkContext.getOrCreate())
    
    def logger(self):
        return self.glueContext().get_logger()
    
    def raw(self, args):
        self.log = self.logger()
        date_path = f"{args.get('date2process')}"
        data_source = args.get('datasource')
        grp_name = args.get('groupname')
        job_name = f"{grp_name}_{args.get('objectname')}"
        conf = self.config()
        objects = conf[grp_name]['objects']
        obj_cfg = list(obj for obj in objects if obj['name'] == args.get('objectname'))[0]
        
        latest = S3Util.getLatest(bucket_name=data_source[5:].rstrip('/'), 
            prefix=obj_cfg[args.get('layer')]['source_path']%date_path)
        if latest is None:
            self.log.error(f'{job_name} ERROR : No data found for {date_path}')
            return None
        latest_path = f"{data_source}{latest[:latest.rfind('/')+1]}"
        self.log.debug(f'{job_name} Datasource: {latest_path}')
        sink_path = f"{args.get('datasink')}{obj_cfg[args.get('layer')]['sink_path']}"
        self.log.debug(f'{job_name} Datasink: {sink_path}')
        
        source = S3Source(latest_path, job_name, self.log)
        sink = S3Sink(sink_path, job_name, self.log)
        raw_layer = RawLayer(source, sink, self.log)
        return raw_layer

    def transform(self, args):
        self.log = self.logger()
        d2p = args.get('date2process').split("/")
        grp_name = args.get('groupname')
        job_name = f"{grp_name}_{args.get('objectname')}"
        conf = self.config()
        objects = conf[grp_name]['objects']
        obj_cfg = list(obj for obj in objects if obj['name'] == args.get('objectname'))[0]

        source_path = f"{args.get('datasource')}{obj_cfg[args.get('layer')]['source_path']}year={d2p[0]}/month={d2p[1]}/day={d2p[2]}"
        self.log.debug(f'{job_name} Datasource: {source_path}')
        sink_path = f"{args.get('datasink')}{obj_cfg[args.get('layer')]['sink_path']}"
        self.log.debug(f'{job_name} Datasink: {sink_path}')

        source = S3Source(source_path, job_name, self.log)
        sink = S3Sink(sink_path, job_name, self.log)
        transform_layer = TransformLayer(source, sink, self.log)
        return transform_layer

    def curate(self, args):
        self.log = self.logger()
        db = "transform_db"
        commons = {
            "jCamsDF": "acbs_j_cams",
            "sLlcBiLoanDF": "salesforce_llc_bi_loan_c",
            "sAccountDF": "salesforce_account"
        }
        job_name = f"{args.get('layer')}_{args.get('groupname')}"
        sink = S3Sink(f"{args.get('datasink')}{args.get('layer')}/{args.get('groupname')}/latest/", job_name, self.log)
        match args.get('groupname'):
            case "party":
                source = CurateLoanSource(db, {
                    "accountDF": "salesforce_account",
                    "accountAddressDF": "salesforce_account_address_c",
                    "recordTypeDF": "salesforce_recordtype",
                    "contactDF": "salesforce_contact",
                    "accountContactDF": "salesforce_account_contact_relation"
                }, job_name, self.log)
                curateJob = Party(source, sink, self.log )
            case "loanDetail":
                source = CurateLoanSource(db, {
                    "jCumsDF": "acbs_j_cums",
                    "jCamiDF": "acbs_j_cami",
                    "jClmsDF": "acbs_j_clms",
                    "jClmiDF": "acbs_j_clmi",
                    "jClasDF": "acbs_j_clas",
                    "jClliDF": "acbs_j_clli",
                    "jClsbDF": "acbs_j_clsb",
                }|commons, job_name, self.log)
                curateJob = Loan(source, sink, self.log)
            case "loanTransaction":
                source = CurateLoanSource(db, {"zHhtrDF": "acbs_z_hhtr"}|commons, job_name, self.log)
                curateJob = loanTransaction(source, sink, self.log)
            case "loanPaymentSchedule":
                source = CurateLoanSource(db, {"zHhpsDF": "acbs_z_hhps"}|commons, job_name, self.log)
                curateJob = loanPaymentSchedule(source, sink, self.log)
            case "loanBillingSummary":
                source = CurateLoanSource(db, {"zHhbsDF": "acbs_z_hhbs"}|commons, job_name, self.log)
                curateJob = loanBillingSummary(source, sink, self.log)
            case _:
                curateJob = None
        return curateJob

    def consumption(self, args):
        self.log = self.logger()
        sourceDB = "curate_db"
        arnRole = args.get('datasink')
        env = args.get('env')
        job_name = f"{args.get('layer')}_{args.get('groupname')}"
        region = 'us-west-2'
        sink = DynamoDBSink(args.get('groupname'), arnRole, region, job_name, self.log)
        match args.get('groupname'):
            case 'CoBank-Party-Information':
                source = CurateLoanSource(sourceDB, {"partyDF": "curate_party"}, job_name, self.log, env)
                return ConsumptionParty(source, sink,env, self.log)
            case 'CoBank-Loan-Detail':
                source = CurateLoanSource(sourceDB, {
                    "loanDetailDF": "curate_loandetail",
                    "loanTransactionDF": "curate_loantransaction",
                    "loanPaymentScheduleDF": "curate_loanpaymentschedule",
                    "loanBillingSummaryDF": "curate_loanbillingsummary"
                }, job_name, self.log, env)
                return ConsumptionLoan(source, sink,env, self.log)
            case _:
                return None
    