from pyspark.sql import SparkSession, DataFrame
from corelibs.source import Source

class CuratePartySource(Source):
    def __init__(self, srcDbName: str, srcTables: dict[str,str], job_name, logger :any, format='parquet', options = None) -> None:
        self.srcDbName = srcDbName
        self.data_source = srcTables
        self.format = format
        self.options = options
        # self.log = logging.getLogger(__name__)
        self.job_name = job_name
        self.log = logger
        pass

    def read(self, spark: SparkSession)->dict[str, DataFrame]:
        
        spark.catalog.setCurrentDatabase(self.srcDbName)
        self.log.info(f'{self.job_name} About to read data from transfrom db source tables - {self.data_source}')
        dfs = {
            'accountDF': self.__getAccount(spark),
            'accountAddressDF': self.__getAccountAddress(spark),
            'recordTypeDF': self.__getRecordType(spark),
            'contactDF': self.__getContact(spark),
            'accountContactDF': self.__getAccountContactRelation(spark)
        }
        self.log.info(f'{self.job_name} Finished reading data from transform db source tables - {self.data_source}')
        return dfs
    

    def __getAccount(self, spark: SparkSession)->DataFrame:
        return spark.table(self.data_source['accountTable'])
    
    def __getAccountAddress(self, spark: SparkSession)->DataFrame:
        return spark.table(self.data_source['addressTable'])
    
    def __getRecordType(self, spark: SparkSession)->DataFrame:
        return spark.table(self.data_source['recordTypeTable'])
    
    def __getContact(self, spark: SparkSession)->DataFrame:
        return spark.table(self.data_source['contactTable'])
    
    def __getAccountContactRelation(self, spark: SparkSession)->DataFrame:      
        return spark.table(self.data_source['accountContactTable'])
    
    def getjobname(self):
        return self.job_name