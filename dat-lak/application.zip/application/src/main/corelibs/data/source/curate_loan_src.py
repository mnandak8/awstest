from pyspark.sql import SparkSession, DataFrame
from corelibs.source import Source

class CurateLoanSource(Source):
    def __init__(self, srcDbName: str, srcTables: dict[str,str], job_name, logger :any, format='parquet', options = None) -> None:
        self.srcDbName = srcDbName
        self.data_source = srcTables
        self.format = format
        self.options = options
        # self.log = logging.getLogger(__name__)
        self.job_name = job_name
        self.log = logger
        pass

    def read(self, spark: SparkSession)->dict[str, DataFrame]:
        spark.catalog.setCurrentDatabase(self.srcDbName)
        self.log.info(f'{self.job_name} About to read data from transfrom db source path {self.data_source}')
        dfs = {k: spark.table(v) for k, v in self.data_source.items()}
        self.log.info(f'{self.job_name} Finished reading data from transform db source path {self.data_source} ........')
        return dfs
    
    def getjobname(self):
        return self.job_name