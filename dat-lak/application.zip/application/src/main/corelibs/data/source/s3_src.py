from pyspark.sql import SparkSession, DataFrame
from corelibs.source import Source

class S3Source(Source):
    def __init__(self, data_source, job_name, logger: any, format='parquet', options = dict()) -> None:
        self.data_source = data_source
        self.job_name = job_name
        self.format = format
        self.options = options
        self.log = logger
        pass

    def read(self, spark: SparkSession)->DataFrame:
        self.log.info(f'{self.job_name} About to read data from source {self.data_source}')
        self.options['recursiveFileLookup'] = 'true'
        df = spark.read.load(path=self.data_source, format=self.format, **self.options)
        self.log.info(f'{self.job_name} Finished reading data from source {self.data_source}')
        return df
    
    def getjobname(self):
        return self.job_name