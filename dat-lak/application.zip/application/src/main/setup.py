from setuptools import setup, find_packages

setup(
    name='corelibs',
    version='0.1',
    packages=["corelibs",
              "corelibs.data",
              "corelibs.data.sink",
              "corelibs.data.source", 
              "corelibs.layers",
              "corelibs.layers.consumption",
              "corelibs.layers.curate",
              "corelibs.layers.raw",
              "corelibs.layers.transform",
              "corelibs.utils",
              "corelibs.catalog",
              "corelibs.catalog.transform",
              "corelibs.catalog.transform.table",
              "corelibs.catalog.curate",
              "corelibs.catalog.curate.table"],
    include_dirs=True,
    include_package_data=True
)