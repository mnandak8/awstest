variable "s3-bucket" {
  type = string
  nullable = false
}
variable "s3-bucket-tags" {
  type = map(string)
}
variable "s3-object-path" {
  type = string
}

variable "create-s3-object" {
  type = bool
  default = false
}

variable "target_log_bucket" {
  type = string
}
