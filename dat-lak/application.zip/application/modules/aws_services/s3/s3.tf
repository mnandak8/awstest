resource "aws_s3_bucket" "s3-bucket" {
  #checkov:skip=CKV_AWS_144:Cross-region replication is not necessary
  #checkov:skip=CKV_AWS_145:Encrypted is not necessary
  #checkov:skip=CKV_AWS_19:Encrypted at rest  is not necessary
  #checkov:skip=CKV_AWS_18: bucket login already enabled
  bucket = var.s3-bucket
  tags = var.s3-bucket-tags
}

resource "aws_s3_object" "s3-object" {
  count = var.create-s3-object ? 1 : 0
  bucket = aws_s3_bucket.s3-bucket.id
  key = var.s3-object-path  
}

resource "aws_s3_bucket_versioning" "s3-bucket-versioning" {
  bucket = aws_s3_bucket.s3-bucket.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_logging" "s3-bucket" {
  bucket = aws_s3_bucket.s3-bucket.id
  target_bucket = var.target_log_bucket
  target_prefix = "log/"
}

resource "aws_s3_bucket_public_access_block" "s3-bucket" {
  bucket = aws_s3_bucket.s3-bucket.id
  block_public_acls   = true
  block_public_policy = true
  restrict_public_buckets = true
  ignore_public_acls=true
}
