variable "account_num" {
  type = string
}
variable "aws_region" {
  type = string
  default = "us-west-2"
}
variable "job-name" {
  type = string
}
variable "cloudwatch_key-alias" {
  type = string
}
variable "cloudwatch-log-group-name" {
  type = string
}
variable "coudwatch-tags" {
  type = map(string)
}
variable "glue-security-configuration-name" {
  type = string
}
