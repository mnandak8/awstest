output "cloudwatch-log-group-arn" {
  value = aws_cloudwatch_log_group.cloudwatch-log-group.arn
}
output "cloudwatch-log-group-name" {
  value = aws_cloudwatch_log_group.cloudwatch-log-group.name
}