resource "aws_kms_key" "cloudwatch-kms-key" {
  description = "KMS key CloudWatch Logs"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_num}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}
resource "aws_kms_alias" "cloudwatch-kms-key-alias"{
  name          = var.cloudwatch_key-alias 
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}

resource "aws_cloudwatch_log_group" "cloudwatch-log-group" {
  name              = var.cloudwatch-log-group-name 
  retention_in_days = 365
  kms_key_id = aws_kms_key.cloudwatch-kms-key.arn
  tags = merge(var.coudwatch-tags, {Splunk = true})
}
data "aws_cloudwatch_log_group" "security-log-group-rds-load" {
  name = "${var.cloudwatch-log-group-name }-${var.glue-security-configuration-name}"
}

# Null resource to update log group configuration (enabling Splunk monitoring.)
resource "null_resource" "update_log_group_config" {
  triggers = {
    log_group_name = data.aws_cloudwatch_log_group.security-log-group-rds-load.name
  }

  provisioner "local-exec" {
    command = <<EOT
      aws logs tag-log-group \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --tags "Splunk=${true}"

      aws logs put-retention-policy \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --retention-in-days 365

      aws logs associate-kms-key \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --kms-key-id "${aws_kms_key.cloudwatch-kms-key.arn}"
    EOT
  }
}
