variable "s3-arn" {
  type = string
}
variable "lakeformation-role-arn" {
  type = string
}
variable "lakeformation-db-name" {
  type = string
}
variable "lakeformation-admin-arns" {
  type = list(string)
}
variable "data-operator-role-arn" {
  type = string
  
}

variable "lakeformation-table-name" {
  type = string
}