# Register s3 using lakeformation role
resource "aws_lakeformation_resource" "lakeformation-resource" {
  arn = var.s3-arn
  role_arn = var.lakeformation-role-arn
}

# create lakeformation admin
resource "aws_lakeformation_data_lake_settings" "lakeformation-admin" {
  admins = var.lakeformation-admin-arns
}

# grant database/table fine grained access to an IAM user/role
resource "aws_lakeformation_permissions" "lakeformation-permissions" {
  principal = var.data-operator-role-arn
  permissions = ["ALL"]
  permissions_with_grant_option = [ALL]
  table {
    database_name = var.lakeformation-db-name
    name=var.lakeformation-table-name
  }
}

# grant data location access to IAM user/role to give alter database access (optional)
resource "aws_lakeformation_permissions" "lakeformation-s3-bucket-location-permission" {
  principal = var.data-operator-role-arn
  permissions = ["DATA_LOCATION_ACCESS"]
  data_location {
    arn = aws_lakeformation_resource.s3_bucket.arn
  }
}