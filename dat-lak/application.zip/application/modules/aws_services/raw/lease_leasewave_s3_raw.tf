# data "aws_caller_identity" "current" {}
# data "aws_region" "current" {}

# locals {
#     account_id                  = data.aws_caller_identity.current.account_id
#     region_name                 = data.aws_region.current.name
#   }

module "lease_leasewave_raw_bucket" {
  source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241212.66"
  lake_type                 = "dl"
  encryption_type           = "sse-kms"
  resource_suffix           = "raw-lease-leasewave-asset"
  environment               = var.environment
  terra_factory_aws_id      = var.terra_factory_aws_id
  expiration_days           = 2555
  ia_transition_days        = 365
  governance_account_id     = var.governance_account_id
  log_bucket_name           = "cobank-dl-${local.account_id}-${local.region_name}-logs-${var.environment}"
}
