locals {
  leasewave_glue_role              = "cobank-${var.environment}-leasewave-glue-role"
  leasewave_ing_s3_bucket          =  "${var.environment}-acb-dl-dat-ing-leasewave-asset"
}

resource "aws_iam_role" "create_role_leasewave_glue" {
  name = local.leasewave_glue_role
  tags = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}



resource "aws_iam_policy" "secret_read_policy_for_leasewave_glue" {
  name        = "cobank-${var.environment}-leasewave-glue-jobs"
  description = "Policy to give necessary permissions for Glue jobs"
  tags        = var.tags
  policy = jsonencode(
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Sid": "AllowReadOnAll",
          "Effect": "Allow",
          "Action": [
              "secretsmanager:GetResourcePolicy",
              "secretsmanager:GetSecretValue",
              "secretsmanager:DescribeSecret",
              "secretsmanager:ListSecretVersionIds",
              "secretsmanager:ListSecrets"
          ],
            "Resource": [
                  "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
            ],
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:PutLogEvents",
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:AssociateKmsKey"
            ],
            "Resource": [
                "arn:aws:logs:*:*:log-group:/aws-glue/*"
            ]
        }
      ]
    }
  )
}

resource "aws_iam_policy" "ing_s3_access_policy_for_leasewave_glue" {
  name        = "cobank-${var.environment}-leasewave-glue-s3-ing"
  description = "Policy to allow Glue job to read from S3 bucket in ing account"
  policy      = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect   = "Allow",
        Action   = ["s3:GetObject", "s3:ListBucket", "kms:Decrypt"],
        Resource = [
          "arn:aws:s3:::${local.leasewave_ing_s3_bucket}",
          "arn:aws:s3:::${local.leasewave_ing_s3_bucket}/*",
          "arn:aws:kms:us-west-2:${var.ing_account_id}:key/*"
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "secretsmanager_read_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = aws_iam_policy.secret_read_policy_for_leasewave_glue.arn
 }

 resource "aws_iam_role_policy_attachment" "ing_s3_read_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = aws_iam_policy.ing_s3_access_policy_for_leasewave_glue.arn
 }


# TODO: Reevaluate these permissions
resource "aws_iam_role_policy_attachment" "kms_full_policy_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "rds_full_policy_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess"
}

resource "aws_iam_role_policy_attachment" "s3_full_policy_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}

resource "aws_iam_role_policy_attachment" "glue_service_role_policy_attach_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}