variable "environment" {type        = string}



variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "buckets_transition" { type = string }
variable "buckets_expiration" { type = string }
variable "storage_class" { type = string }
variable "bucket_key_enabled" { type = string }
variable "ing_account_id" { type = string }
variable "bucket_encryption" {
  type = map(string)
  default = {
    algorithm : "aws:kms"
    kms_id : ""
  }
}

variable "terra_factory_aws_id" {
  type        = string
  description = "Name of the aws account."
}

variable "governance_account_id" {
  type        = string
  description = "governance account id"
}