data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
    lake_raw_s3_bucket_leasewave       = "cobank-dat-lak-${local.region_name}-leasewave-raw-${var.environment}"
    account_id                  = data.aws_caller_identity.current.account_id
    region_name                 = data.aws_region.current.name
    ing_log_bucket               ="cobank-dl-${local.account_id}-us-west-2-logs-${var.environment}"
    ing_account_id              = var.ing_account_id
  }


resource "aws_s3_bucket" "datalake_buckets_leasing" {
  #checkov:skip=CKV_AWS_21: Versioning is selectively enabled based on the input parameter. Checkov is unable to recognize it
  #checkov:skip=CKV_AWS_144: Cross region replication will incur cost. Current implementation does not CRR
  #checkov:skip=CKV_AWS_18: Access log bucket is accessed here
  #checkov:skip=CKV2_AWS_62: Notifications will be enabled later based on the requirements. It is not needed now.
  bucket = local.lake_raw_s3_bucket_leasewave
  tags = var.tags
}

resource "aws_s3_bucket_public_access_block" "datalake_buckets_block_leasing" {

  bucket = aws_s3_bucket.datalake_buckets_leasing.id

  block_public_acls       = true
  block_public_policy     = true
  restrict_public_buckets = true
  ignore_public_acls      = true
}

resource "aws_s3_bucket_versioning" "datalake_buckets_versioning_leasing" {
  bucket = aws_s3_bucket.datalake_buckets_leasing.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "datalake_buckets_encryption_leasing" {
  bucket = aws_s3_bucket.datalake_buckets_leasing.id
  rule {
    bucket_key_enabled = var.bucket_key_enabled
    apply_server_side_encryption_by_default {
      sse_algorithm     = var.bucket_encryption["algorithm"]
    }
    }
}


resource "aws_s3_bucket_logging" "datalake_buckets_logging_leasing" {
  bucket        = aws_s3_bucket.datalake_buckets_leasing.id
  target_bucket = local.ing_log_bucket
   target_prefix ="Leaswave/"
  
}

resource "aws_s3_bucket_lifecycle_configuration" "datalake_buckets_lifecycle_leasing" {
  bucket = aws_s3_bucket.datalake_buckets_leasing.id
  rule {
    abort_incomplete_multipart_upload {
      days_after_initiation = 7
      }
    id = "Leasing-Rule-id-1"
    transition {
      days          = var.buckets_transition
      storage_class = var.storage_class
    }
    expiration {
      days = var.buckets_expiration
    }
    status = "Enabled"
  }
}

########### s3 bucket for the LEasewave RAW DMS

resource "aws_s3_bucket_policy" "allow_access_from_another_account_dms" {
  bucket = local.lake_raw_s3_bucket_leasewave
  policy = <<POLICY
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AllowAppINgestionDMSTasktowriteintothisbucket",
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.amazonaws.com"
            },
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::cobank-dat-lak-${local.region_name}-leasewave-raw-${var.environment}/*",
                "arn:aws:s3:::cobank-dat-lak-${local.region_name}-leasewave-raw-${var.environment}"
            ]
        },
        {
            "Sid": "AllowIngestionDMSrole",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${local.ing_account_id}:role/cobank-${var.environment}-lw-dms-role"
            },
            "Action": "s3:*",
            "Resource": [
                "arn:aws:s3:::cobank-dat-lak-${local.region_name}-leasewave-raw-${var.environment}/*",
                "arn:aws:s3:::cobank-dat-lak-${local.region_name}-leasewave-raw-${var.environment}"
            ]
        }
    ]
}
POLICY
}

resource "aws_s3_object" "airflow_bucket_dags" {
  bucket = aws_s3_bucket.datalake_buckets_leasing.id
  key    = "leasewave/"
}

