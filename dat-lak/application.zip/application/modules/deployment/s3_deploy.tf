resource "terraform_data" "lake-etl-data" {
  triggers_replace = [
    var.github_run_id
  ]
  provisioner "local-exec" {
    command = <<-EOT
    echo "Starting to download artifact..."
    gh run download ${var.github_run_id} -n ${var.artifact-file} -D "src/main/dist/"
    echo "Done downloading!!!" 
    aws s3 cp src/main/dist/${var.artifact-file} ${var.etl-s3-path}
    aws s3 cp src/main/config/etl.conf ${var.etl-s3-path}
    aws s3 cp src/main/driver.py ${var.etl-s3-path}
    aws s3 cp --recursive airflow/dags/ "${var.dag-s3-path}/dags/"
    aws s3 cp airflow/requirements.txt "${var.dag-s3-path}/"
    aws s3 cp airflow/plugins/plugins.zip "${var.dag-s3-path}/plugins/plugins.zip"
  EOT
  }
  
}