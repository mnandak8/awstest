variable "etl-s3-path" {
  type = string
}
variable "artifact-file" {
  type = string
}
variable "dag-s3-path" {
  type = string
}
variable "github_run_id" {
  type = number
}