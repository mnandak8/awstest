data "aws_caller_identity" "current-identity" {}
data "aws_region" "current-region" {}
data "aws_iam_policy_document" "glue-role" {
    version =  "2012-10-17"
    statement {
        sid = "STSassumeRole"
        actions = ["sts:AssumeRole"]
        principals {
            type = "Service"
            identifiers = ["glue.amazonaws.com"]
        }
    }
}

/*
data "aws_iam_policy_document" "glue-iam-role-policy" {
    version = "2012-10-17"
    statement {
        effect = "Allow"
        actions = [
            "s3:GetObject",
            "s3:PutObject",
            "s3:ListBucket"
        ]
        resources = [
            "arn:aws:s3:::${var.glue-crawler-s3-target}/*",
            "arn:aws:s3:::${var.glue-crawler-s3-target}"
        ]
    }
}
*/