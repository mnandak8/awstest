resource "aws_glue_job" "glue-job" {
  name = var.glue-job-name
  role_arn =var.glue-job-role 
  description = "glue job to perform etl targeting data lake"
  max_retries = var.glue-job-max-retries
  timeout = var.glue-job-timeout
  
  command {
    script_location = var.etl-script-location
    python_version = local.python-version
  }
  execution_property {
    max_concurrent_runs = local.glue-max-concurrent-runs
  }
  glue_version = local.glue-version

  default_arguments = {
    "--enable-continous-log-filter"     = var.enable-continous-log-filter
    "--continuous-log-logGroup"         = module.log-group.cloudwatch-log-group-name
    "--continuous-log-logGroup"         = module.log-group.cloudwatch-log-group-name
    "--extra-py-files"                  = var.extra-py-files
    "--extra-files"                     = var.extra-files
    "--enable-glue-datacatalog"         = var.enable-glue-datacatalog
    "--enable-metrics"                  = var.enable-metrics
    "--enable-spark-ui"                 = var.enable-spark-ui
    "--spark-event-logs-path"           = var.spark-logs-path
    "--datasource"                     = var.glue-data-source-bucket
    "--datasink"                       = var.glue-data-sink-bucket
    "--layer"                          = var.etl-layer-name
    "--date2process"                   = var.date-to-process
    "--objectname"                     = var.object-to-process
    "--groupname"                      = var.groupname-to-process
    "--env"                            = var.environment
    "--enable-auto-scaling"            = true
  }
  # worker_type       = "G.1X"
  # number_of_workers = "10"
  # Svallem 12-06-2024 , increased for ALL customers
  worker_type = var.glue-job-name == "populateconsumption-loan-airflow" ? "G.4X" : "G.1X" 
  number_of_workers = var.glue-job-name == "populateconsumption-loan-airflow" ? 20 : 10

  tags = var.glue-job-tags
  security_configuration = var.glue-security-configuration-name
}

module "log-group" {
  source = "../aws_services/cloudwatch"
  account_num = data.aws_caller_identity.current-identity.account_id
  aws_region  = data.aws_region.current-region.name
  job-name    = var.glue-job-name
  cloudwatch_key-alias = "alias/key-${var.glue-job-name}"
  cloudwatch-log-group-name = "/aws-glue/datalake/jobs/${var.glue-job-name}/log_group/"
  coudwatch-tags = var.glue-job-tags
  glue-security-configuration-name = var.glue-security-configuration-name
}

resource "aws_glue_catalog_database" "glue-catalog-db" {
  count = var.create-glue-datacatalog ? 1 : 0
  name = var.glue-catalog-db-name
  description = "glue database"
}

resource "aws_glue_crawler" "glue-crawler" {
  count = var.create-crawler ? 1 : 0
  database_name = var.glue-catalog-db-name
  name = var.glue-crawler-name
  table_prefix = var.table-prefix
  role = var.glue-job-role
  tags = var.glue-job-tags
  s3_target {
    path = "${var.glue-crawler-s3-bucket}${var.glue-crawler-s3-bucket-key}"
    exclusions = var.crawler-exclusions
  }
  configuration = jsonencode(
    {
      CrawlerOutput = {
        Partitions = {AddOrUpdateBehavior = "InheritFromTable"}
      },
      Grouping = {TableLevelConfiguration = 3}
      Version = 1
    }
  )
  security_configuration = var.glue-security-configuration-name
}
