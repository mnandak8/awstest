variable "environment" {
  type = string
  description = "specify the environment to deploy the resources"
}


# Glue Job
variable "glue-job-name" {
  type = string
  nullable = false
}
variable "glue-job-role" {
  type = string
  nullable = false
  
}
variable "glue-job-max-retries" {
  type = number
  nullable = false
}
variable "glue-job-timeout" {
  type = number
  nullable = false
}
variable "glue-job-tags" {
  type = map(string)
}
variable "etl-script-location" {
  type = string
  nullable = false
}
variable "extra-py-files" {
  type = string
  nullable = false
}
variable "extra-files" {
  type = string
  nullable = false
}
variable "glue-data-source-bucket" {
  type = string
  nullable = false
}
variable "glue-data-sink-bucket" {
  type = string
  nullable = false
}
variable "etl-layer-name" {
  type = string
  nullable = false
  description = "data layer name that the etl job for"
}
variable "date-to-process" {
  type = string
  default = "2024/03/30"
  description = "specifys the date to be ingested or processed"
}
variable "object-to-process" {
  type = string
  nullable = false
  description = "specify the object name to process"
}
variable "groupname-to-process" {
  type = string
  nullable = false
  description = "group name should be salesforce or acbs"
}
variable "enable-continous-log-filter" {
  type = bool
} 
variable "enable-glue-datacatalog" {
  type = bool
}
variable "enable-metrics" {
  type = bool
}
variable "enable-spark-ui" {
  type = bool
}
variable "spark-logs-path" {
  type = string
}


# Glue catalog
variable "glue-catalog-db-name" {
  type = string
}
variable "create-glue-datacatalog" {
  type = bool
}


# Glue Crawler
variable "glue-crawler-name" {
  type = string
  nullable = false
}
variable "glue-crawler-s3-bucket" {
  type = string
  nullable = false
}
variable "glue-crawler-s3-bucket-key" {
  type = string
  nullable = false
}
variable "crawler-exclusions" {
  type = list(string)
}
variable "create-crawler" {
  type = bool
}
variable "table-prefix" {
  type = string
}

variable "glue-security-configuration-name" {
  type = string
}