variable "role_name" {
  type        = string
  description = "(Required) Name of the Role"
}

variable "assume_role_policy" {
  type = string
}

variable "tags" {
  type = map(string)
}