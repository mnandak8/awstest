output "role_arn" {
  description = "The ARN of the execution role"
  value       = aws_iam_role.role.arn
}

output "role_name" {
  description = "The name of the execution role"
  value       = aws_iam_role.role.name
}

output "id" {
  value = aws_iam_role.role.id
}