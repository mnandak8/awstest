variable "account_id" {type = string}
resource "aws_iam_role" "role" {
  name = var.role_name  
  assume_role_policy = var.assume_role_policy
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "AmazonSSMFullAcces_read_attach" {
  role       = aws_iam_role.role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMFullAccess"
 }


resource "aws_iam_role_policy_attachment" "AmazonS3FullAccess_read_attach" {
  role       = aws_iam_role.role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
 }

# TODO: Reevaluate these permissions
resource "aws_iam_role_policy_attachment" "kms_full_policy_attach" {
  role       =  aws_iam_role.role.name
  policy_arn = "arn:aws:iam::${var.account_id}:policy/KMSFullAccess"
}
