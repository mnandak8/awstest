variable "tags" {
  type = map(string)
}

variable "role_execution_lambda" {
  type = string
  description = "ARN Role that assumes lambda function"
}

variable "lambda_name" {
  type = string
}

variable "layers_lambda"{
    type = list(string)
    default = [ ]
}

variable "retention_logs_in_days" {
  type = number
}

variable "api_gateway_name" {
  type = string
}

variable "endpoints"{
    type = list(object({
                index = string
                resource = string
                methods  = list(string)
                parent_resource = string
                level = number
                request_parameters = string
            }))
}

variable "stage" {
  type = string
  default = "dev"
}

variable "role_api_gateway" {
  type = string
}

variable "authorizer_name" {
  type = string
  default = null
}

variable "lambda_authorizer_name" {
  type = string
  default = ""
}

variable "dynamoDB_table_name" {
  type    = string
  default = "data-lake-pipeline-audit-balance-control-table"
}

variable "image_uri" {
  type    = string
  description = "Image ECR"
}

variable "lambda_description" {
  type        = string
  description = "(Required) Description of the Lambda Function"
}

variable "account_id" {
  type = string
}

variable "aws_region" {
  type = string
}