module "lambda" {
  source           = "../lambda"
  lambda_name      = var.lambda_name
  lambda_description = "Audit Balance API"  
  role             = var.role_execution_lambda
  image_uri        = var.image_uri
  account_id       = var.account_id
  aws_region       = var.aws_region
  tags = var.tags
}
resource "aws_kms_key" "APIGateway_key" {
  description = "KMS key API Gateway"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
  tags = var.tags
}

resource "aws_kms_alias" "APIGateway_key" {
  name          = "alias/key-${var.api_gateway_name}"
  target_key_id = aws_kms_key.APIGateway_key.key_id
}

resource "aws_cloudwatch_log_group" "api_gw" {
  name              = "/aws/api_gw/${aws_api_gateway_rest_api.private_rest_api.name}"
  retention_in_days = var.retention_logs_in_days
  kms_key_id = aws_kms_key.APIGateway_key.arn
  depends_on = [ aws_kms_key.APIGateway_key ]
  tags = {Splunk = true}
}

resource "aws_api_gateway_rest_api" "private_rest_api" {
  name          = var.api_gateway_name
  endpoint_configuration {
    types = ["PRIVATE"]
  }
  lifecycle {
   create_before_destroy = true
 }
  tags = var.tags
}

module "root"{
  source           = "../api_gateway_paths"
  for_each =  { for endpoint in var.endpoints : endpoint.index => endpoint if endpoint.level == 0 }
  invoke_arn = module.lambda.invoke_arn
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  path_part = each.value.resource
  authorizer_id = ""
  parent_id = aws_api_gateway_rest_api.private_rest_api.root_resource_id
  http_methods = each.value.methods
  request_parameters = each.value.request_parameters
}

module "path_level1"{
  source           = "../api_gateway_paths"
  for_each =  { for endpoint in var.endpoints : endpoint.index => endpoint if endpoint.level == 1 }
  invoke_arn = module.lambda.invoke_arn
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  path_part = each.value.resource
  authorizer_id = ""
  parent_id = module.root[each.value.parent_resource].id
  http_methods = each.value.methods
  request_parameters = each.value.request_parameters
  depends_on = [ module.root ]
}

module "path_level2"{
  source           = "../api_gateway_paths"
  for_each =  { for endpoint in var.endpoints : endpoint.index => endpoint if endpoint.level == 2 }
  invoke_arn = module.lambda.invoke_arn
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  path_part = each.value.resource
  authorizer_id = ""
  parent_id = module.path_level1[each.value.parent_resource].id
  request_parameters = each.value.request_parameters
  http_methods = each.value.methods
  depends_on = [ module.path_level1 ]
}

resource "aws_api_gateway_rest_api_policy" "resource_policy" {
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  policy      = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action = "execute-api:Invoke",
      Effect = "Allow",
      Resource =  "${aws_api_gateway_rest_api.private_rest_api.execution_arn}/*/*/*"
      Principal = "*"
    }]
  })
}

resource "aws_api_gateway_deployment" "api_gateway_deployment_deployment" {
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  triggers = {
    redeployment = sha1(var.image_uri)
  }
  depends_on = [ 
    aws_api_gateway_account.api_gateway_account,
    module.root,
    module.path_level1,
    module.path_level2
  ]
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_account" "api_gateway_account" {
  cloudwatch_role_arn = module.role_api_gateway_assume.role_arn
}

data "aws_iam_policy_document" "assume_role" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["apigateway.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

module "role_api_gateway_assume" {
    source = "../role"
    account_id = var.account_id
    role_name = var.role_api_gateway
    assume_role_policy = data.aws_iam_policy_document.assume_role.json
    tags = var.tags
}

resource "aws_iam_role_policy_attachment" "cloudwatch" {
  role   = module.role_api_gateway_assume.id
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs"
}

resource "aws_api_gateway_stage" "my_stage" {
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  stage_name  = var.stage
  xray_tracing_enabled = true
  cache_cluster_enabled = true
  cache_cluster_size = "0.5"
  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gw.arn
    format = jsonencode({
      requestId               = "$context.requestId"
      sourceIp                = "$context.identity.sourceIp"
      requestTime             = "$context.requestTime"
      protocol                = "$context.protocol"
      httpMethod              = "$context.httpMethod"
      resourcePath            = "$context.resourcePath"
      routeKey                = "$context.routeKey"
      status                  = "$context.status"
      responseLength          = "$context.responseLength"
      integrationErrorMessage = "$context.integrationErrorMessage"
      errorMessage            = "$context.error.messageString"
      }
    )
  }
  deployment_id = aws_api_gateway_deployment.api_gateway_deployment_deployment.id
  client_certificate_id = aws_api_gateway_client_certificate.api_client_certificate.id
  tags = var.tags
  depends_on = [  aws_api_gateway_client_certificate.api_client_certificate ]
}

resource "aws_api_gateway_method_settings" "all" {
  rest_api_id = aws_api_gateway_rest_api.private_rest_api.id
  stage_name  = aws_api_gateway_stage.my_stage.stage_name
  method_path = "*/*"

  settings {
    metrics_enabled  = true
    logging_level    = "ERROR"
    caching_enabled  = true
    cache_data_encrypted = true
    data_trace_enabled   = false
  }
}

resource "aws_lambda_permission" "apigw_lambda" {
  statement_id  = "AllowExecutionFromAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = module.lambda.lambda_name
  principal     = "apigateway.amazonaws.com"
  source_arn = "${aws_api_gateway_rest_api.private_rest_api.execution_arn}/*"
}

resource "aws_api_gateway_client_certificate" "api_client_certificate" {
  description = "${var.api_gateway_name} client certificate"
  tags = var.tags
}
