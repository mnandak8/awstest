output "api_gateway_name" {
  value = aws_api_gateway_rest_api.private_rest_api.name
}

output "api_gateway_arn" {
  value = aws_api_gateway_rest_api.private_rest_api.arn
}

output "api_gateway_id" {
  value = aws_api_gateway_rest_api.private_rest_api.id
}

output "lambda_name" {
  value = module.lambda.lambda_name
}

output "lambda_arn" {
  value = module.lambda.lambda_arn
}

output "lambda_invoke_arn" {
  value = module.lambda.invoke_arn
}

output "dql_arn" {
  value = module.lambda.dql_arn
}

output "kms_arn" {
  value = aws_kms_key.APIGateway_key.arn
}