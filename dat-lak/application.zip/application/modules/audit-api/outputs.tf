output "arn" {
  description = "The ARN of the Lambda function"
  value       = module.audit-private-api.lambda_arn
}

output "name" {
  description = "The name of the Lambda function"
  value       = module.audit-private-api.lambda_name
}

output "invoke_arn" {
  value = module.audit-private-api.lambda_invoke_arn
}