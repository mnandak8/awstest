variable "alias" {
  description = "The Alias of the key as viewed in AWS console"
  type        = string
}

variable "description" {
  description = "The description of the key as viewed in AWS console"
  type        = string
}

variable "account_id" {
  type = string
}

variable "aws_region" {
  type = string
}

variable "tags" {
  type = map(string)
}