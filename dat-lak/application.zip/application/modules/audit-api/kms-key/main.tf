resource "aws_kms_key" "kms" {
  description = var.description
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      }  
    ]
  }
  EOF
  tags = var.tags
}

resource "aws_kms_alias" "DynamoDB_key" {
  name          = "alias/key-${var.alias}"
  target_key_id = aws_kms_key.kms.key_id
}