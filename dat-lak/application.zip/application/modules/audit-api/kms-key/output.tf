output "kms_arn" {
    description = "The ARN of the kms key"
    value       = aws_kms_key.kms.arn
}