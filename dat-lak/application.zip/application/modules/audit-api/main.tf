module "kms_dynamoDB" {
  source = "./kms-key"
  description = "KMS key DynamoDB table"
  alias       = "alias/key-${var.dynamoDB_table_name}"
  account_id = var.account_id
  aws_region = var.aws_region
  tags = var.tags
}

resource "aws_dynamodb_table" "audit_balance_control_table" {
  name           = var.dynamoDB_table_name
  billing_mode   = "PROVISIONED"
  read_capacity  = 5
  write_capacity = 5
  hash_key       = "JobName"
  range_key      = "JobRunId"


  attribute {
    name = "JobName"
    type = "S"
  }


  attribute {
    name = "JobRunId"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption{
    enabled = true
    kms_key_arn = module.kms_dynamoDB.kms_arn
  }

  depends_on = [ module.kms_dynamoDB ]
}

resource "aws_appautoscaling_target" "audit_balance_control_table" {
  resource_id        = "table/${aws_dynamodb_table.audit_balance_control_table.name}"
  scalable_dimension = "dynamodb:table:ReadCapacityUnits"
  service_namespace  = "dynamodb"
  min_capacity       = 1
  max_capacity       = 15
}

resource "aws_appautoscaling_policy" "audit_balance_control_table" {
  name               = "rcu-auto-scaling"
  service_namespace  = aws_appautoscaling_target.audit_balance_control_table.service_namespace
  scalable_dimension = aws_appautoscaling_target.audit_balance_control_table.scalable_dimension
  resource_id        = aws_appautoscaling_target.audit_balance_control_table.resource_id
  policy_type        = "TargetTrackingScaling"
  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "DynamoDBReadCapacityUtilization"
    }

    target_value = 70.0
  }
}

resource "aws_kms_key" "cloudwatch_key" {
  description = "KMS key CloudWatch Logs"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}
resource "aws_kms_alias" "cloudwatch_key" {
  name          = "alias/key-${var.lambda_name}"
  target_key_id = aws_kms_key.cloudwatch_key.key_id
}

resource "aws_cloudwatch_log_group" "cloudwatch-lambda" {
  name              = "/aws/lambda/${var.lambda_name}"
  retention_in_days = 365
  kms_key_id = aws_kms_key.cloudwatch_key.arn
  depends_on = [ aws_kms_key.cloudwatch_key ]
  tags = {Splunk = true}
}
resource "aws_iam_role_policy" "lambda_policy" {
  name        = "Lambda-Policy"
  role = module.role_lambda_execution.id
  policy = jsonencode({
  Version: "2012-10-17",
  Statement: [
    {
      Effect : "Allow",
      Action : [
        "dynamodb:Scan",
        "dynamodb:Query",
        "dynamodb:ListTables",
        "dynamodb:CreateTable",
        "dynamodb:PutItem",
        "dynamodb:UpdateItem",
        "dynamodb:DescribeTable",
        "dynamodb:GetItem",
        "dynamodb:GetRecords",
        "application-autoscaling:RegisterScalableTarget",
        "application-autoscaling:PutScalingPolicy"
      ],
      Resource : [
        aws_dynamodb_table.audit_balance_control_table.arn,
        "${aws_dynamodb_table.audit_balance_control_table.arn}/index/*"
      ]
    },
    {
      Effect : "Allow",
      Action : [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams",
        "logs:PutLogEvents",
        "logs:GetLogEvents",
        "logs:FilterLogEvents"
      ],
      Resource : [
        "${aws_cloudwatch_log_group.cloudwatch-lambda.arn}:*",
        "arn:aws:logs:${var.aws_region}:${var.account_id}:log-group:/aws/lakehouse-audit-extract:*"        
      ]
    },
    {
      Action: [
        "kms:Decrypt"
      ],
      Effect: "Allow",
      Resource: [
        aws_kms_key.cloudwatch_key.arn,
        module.kms_dynamoDB.kms_arn
      ]
    },
    {
      Effect: "Allow",
      Action: [
        "sqs:*"
      ],
      Resource: [
        module.audit-private-api.dql_arn
      ]
    }
  ]
})
}

module "role_lambda_execution" {
    source = "./role"
    role_name = "cobank-${var.environment}-lambda-role"
    account_id = var.account_id
    assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Sid    = ""
      Principal = {
        Service = "lambda.amazonaws.com"
      }
      }
    ]
  })
    tags = var.tags
}



module "audit-private-api" {
  source = "./private-api"
  api_gateway_name = var.api_gateway_name
  role_execution_lambda = module.role_lambda_execution.role_arn
  lambda_name = var.lambda_name
  retention_logs_in_days = var.retention_logs_in_days
  tags = var.tags
  stage = var.environment
  role_api_gateway = "cobank-${var.environment}-api-gateway-role"
  endpoints = var.audit_api_endpoints
  authorizer_name = var.authorizer_name
  lambda_description = var.lambda_description
  image_uri   = var.image_uri
  account_id = var.account_id
  aws_region = var.aws_region
 }
