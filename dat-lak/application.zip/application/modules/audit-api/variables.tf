variable "api_gateway_name"{
    type = string
}
variable "lambda_name"{
    type = string
}
variable "retention_logs_in_days"{
    type = string
}
variable "tags" {
  type = map(string)
}
variable "environment"{
    type = string
}
variable "authorizer_name"{
    type = string
}

variable "image_uri"{
    type = string
}

variable "audit_api_endpoints"{
    type = list(object({
                index = string
                resource = string
                methods  = list(string)
                parent_resource = string
                level = number
                request_parameters = string
            }))
}

variable "lambda_description" {
    type = string
}

variable "dynamoDB_table_name" {
    type = string
}

variable "account_id" {
  type = string
}

variable "aws_region" {
  type = string
}