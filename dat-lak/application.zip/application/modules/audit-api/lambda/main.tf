module "kms_dql_key" {
  source = "../kms-key"
  description = "KMS key DQL"
  alias       = "alias/key-lambda_dead_letter_queue"
  account_id = var.account_id
  aws_region = var.aws_region
  tags = var.tags
}
resource "aws_sqs_queue" "dead_letter_queue" {
  name                      = "lambda_dead_letter_queue"
  delay_seconds             = 90
  max_message_size          = 2048
  message_retention_seconds = 86400
  receive_wait_time_seconds = 10
  kms_master_key_id                 = module.kms_dql_key.kms_arn
  kms_data_key_reuse_period_seconds = 300
}

resource "aws_lambda_function" "lambda-api" {
  #checkov:skip=CKV_AWS_117:Lambda function does not need access to anything else in a VPC
  #checkov:skip=CKV_AWS_272: Code signing is not supported for functions created with container images.
  function_name    = var.lambda_name
  description      = var.lambda_description
  package_type     = "Image"
  role             = var.role
  image_uri        = var.image_uri
  publish          = "true"
  tags             = var.tags
  logging_config {
    log_format            = "JSON"
    system_log_level      = "INFO"
    application_log_level = "INFO"
  }

  image_config{
    command = [ var.lambda_handler ]
  }

  reserved_concurrent_executions = 100
  tracing_config {
    mode = "Active"
  }

  dead_letter_config {
    target_arn = aws_sqs_queue.dead_letter_queue.arn
  }
}

data "aws_ecr_image" "lambda-api-image" {
  repository_name = "dat-lakehouse"
  image_tag = "latest"
}

resource "aws_lambda_function_event_invoke_config" "lambda-api-invoke-config" {
  function_name                = aws_lambda_function.lambda-api.function_name
  qualifier                    = "$LATEST"
  maximum_event_age_in_seconds = 60
  maximum_retry_attempts       = 1

}
