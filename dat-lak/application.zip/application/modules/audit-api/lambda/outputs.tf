output "lambda_arn" {
    description = "The ARN of the Lambda function"
    value       = aws_lambda_function.lambda-api.arn
}

output "lambda_name" {
    description = "The name of the Lambda function"
    value       = aws_lambda_function.lambda-api.function_name
}

output "lambda_version" {
    description = "The version of the Lambda function"
    value       = aws_lambda_function.lambda-api.version
}

output "invoke_arn" {
    value = aws_lambda_function.lambda-api.invoke_arn
}

output "dql_arn" {
  value = aws_sqs_queue.dead_letter_queue.arn
}
