variable "lambda_name" {
  type        = string
  description = "(Required) Name of the Lambda Function"
}

variable "lambda_description" {
  type        = string
  description = "(Required) Description of the Lambda Function"
}

variable "lambda_handler" {
  type        = string
  description = "(Required) Handler of the Lambda Function"
  default     = "main.handler"
}

variable "lambda_runtime" {
  type        = string
  description = "(Required) Runtime of the Lambda Function"
  default     = "python3.12"
}

variable "lambda_timeout" {
  type        = number
  description = "Max time for which lambda has to run"
  default     = 3
}

variable "lambda_memory" {
  type        = number
  description = "Memory allocated to lambda"
  default     = 128
}

variable "lambda_ephemeral_storage" {
  type        = number
  description = "ephemeral_storage allocated to lambda"
  default     = 512
}

variable "role" {
  type        = string
  description = "role that assume the lambda"
}

variable "tags" {
  type = map(string)
}

variable "layers_lambda"{
    type = list(string)
    default = []
}

variable "image_uri" {
  type    = string
}

variable "account_id" {
  type = string
}

variable "aws_region" {
  type = string
}