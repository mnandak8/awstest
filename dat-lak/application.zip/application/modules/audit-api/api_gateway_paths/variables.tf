variable "rest_api_id"{
    type = string
}

variable "parent_id"{
    type = string
}

variable "path_part"{
    type = string
}

variable "authorizer_id" {
    type = string
}

variable "invoke_arn" {
    type = string
}

variable "http_methods" {
  type = list(string)
}

variable "request_parameters" {
  type = string
}