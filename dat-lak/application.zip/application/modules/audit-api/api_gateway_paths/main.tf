resource "aws_api_gateway_resource" "resources"{
    rest_api_id = var.rest_api_id
    parent_id   = var.parent_id
    path_part   = var.path_part
}

resource "aws_api_gateway_method" "methods" {
    #checkov:skip=CKV_AWS_59:API gateway is private
    for_each = toset(var.http_methods)
    rest_api_id   = var.rest_api_id
    resource_id   = aws_api_gateway_resource.resources.id
    http_method   = each.value
    authorization = var.authorizer_id == "" ? "NONE":"CUSTOM"
    authorizer_id = var.authorizer_id == "" ? "": var.authorizer_id
    request_parameters = var.request_parameters != "" ? tomap({ "method.request.path.${var.request_parameters}" = true }) :{}
     request_validator_id = aws_api_gateway_request_validator.request_validator.id
    depends_on = [ aws_api_gateway_resource.resources, aws_api_gateway_request_validator.request_validator ]
}

resource "aws_api_gateway_integration" "integrations" {
    for_each = toset(var.http_methods)
    rest_api_id             = var.rest_api_id
    resource_id             = aws_api_gateway_resource.resources.id
    http_method             = aws_api_gateway_method.methods[each.value].http_method
    integration_http_method = "POST"
    content_handling        = "CONVERT_TO_TEXT"
    passthrough_behavior    = "NEVER"
    type                    = "AWS_PROXY"
    uri                     = var.invoke_arn
    request_parameters = var.request_parameters != "" ? tomap({ "integration.request.path.${var.request_parameters}" = "method.request.path.${var.request_parameters}" }) :{}
    depends_on = [ aws_api_gateway_method.methods ]
}

resource "aws_api_gateway_method_response" "responses" {
    for_each = toset(var.http_methods)
    rest_api_id = var.rest_api_id
    resource_id = aws_api_gateway_resource.resources.id
    http_method = aws_api_gateway_method.methods[each.value].http_method
    status_code = "200"
    depends_on = [ aws_api_gateway_integration.integrations ]
}

resource "aws_api_gateway_request_validator" "request_validator" {
  name                     = "request_validator_${aws_api_gateway_resource.resources.id}"
  rest_api_id              = var.rest_api_id
  validate_request_body    = true
  validate_request_parameters = true
}
