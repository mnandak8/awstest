output "id" {
  value = aws_api_gateway_resource.resources.id
}