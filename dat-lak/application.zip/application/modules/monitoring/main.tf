
## Audit monitoring lambda creation
## To be moved to create using eks in later sprints

data "archive_file" "audit-extractor-script" {
  type        = "zip"
  source_dir  = "${path.module}/../../src/main/monitoring/lambda/audit-extractor"
  output_path = "${path.module}/audit-extractor.zip"
}

data "aws_iam_role" "lambda-role" {
  name = "cobank-${var.environment}-lambda-role"
}

resource "aws_lambda_function" "cobank-audit-extractor" {
  filename         = "${path.module}/audit-extractor.zip"
  function_name    = "audit-extractor"
  handler          = "audit-extractor.lambda_handler"
  runtime          = "python3.12"
  role             = data.aws_iam_role.lambda-role.arn
  source_code_hash = data.archive_file.audit-extractor-script.output_base64sha256
  timeout = 180
}

resource "aws_kms_key" "cloudwatch_key" {
  description = "KMS key CloudWatch Logs"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}

resource "aws_kms_alias" "cloudwatch_key" {
  name          = "alias/key-lakehouse-audit-extract"
  target_key_id = aws_kms_key.cloudwatch_key.key_id
}

resource "aws_cloudwatch_log_group" "lakehouse-audit-extract" {
  name              = "/aws/lakehouse-audit-extract"
  retention_in_days = 365
  kms_key_id = aws_kms_key.cloudwatch_key.arn
  depends_on = [ aws_kms_key.cloudwatch_key ]
  tags = {Splunk = true}
}

# Upload Glue script file to tooling
resource "aws_s3_object" "glue-script" {
  bucket = "cobank-dl-${var.account_id}-us-west-2-tooling-${var.environment}"
  key    = "monitoring/glue-scripts/large_item_filter_to_s3.py"
  source = "${path.module}/../../src/main/monitoring/glue/large_item_filter_to_s3.py"
  etag   = filemd5("${path.module}/../../src/main/monitoring/glue/large_item_filter_to_s3.py")
}
data "aws_iam_role" "glue-role" {
  name = "cobank-${var.environment}-glue-role"
}

resource "aws_glue_job" "large_item_filter_to_s3" {
  name        = "large_item_filter_to_s3"
  role_arn    = data.aws_iam_role.glue-role.arn
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.glue-script.bucket}/${aws_s3_object.glue-script.key}"
    python_version  = "3"
  }
   default_arguments = {
     "--job-language" = "python"
     "--env"          = var.environment
   }

  glue_version      = "4.0"
  worker_type       = "G.1X"
  number_of_workers = "10"
}
