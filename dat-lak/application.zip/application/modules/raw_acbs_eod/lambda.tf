resource "aws_cloudwatch_log_group" "raw_acbs_eod_lambda_decrypt_files" {
  name = "/aws/lambda/${local.raw_acbs_eod_lambda_decrypt_files}"
  kms_key_id = aws_kms_key.kms_key_acbs_eod.arn
  tags = var.splunk_tags
}

resource "aws_lambda_function" "raw_acbs_eod_lambda_decrypt_files" {
  function_name                  = local.raw_acbs_eod_lambda_decrypt_files
  description                    = "Decrypts ACBS files"
  role                           =  local.lambda_role_arn
  tags                           =  var.splunk_tags
  image_uri                      = local.ecr_image_uri
  package_type                   = "Image"
  publish                        = "true"
  timeout                        = 600
  reserved_concurrent_executions = 150
  memory_size                    = 10240
  ephemeral_storage            {  size = 10240 }
  kms_key_arn                    = aws_kms_key.kms_key_acbs_eod.arn
  image_config                     {command = [ "Lambda_acbs_eod_decrypt_move_to_raw.lambda_handler"]}
  tracing_config                   {mode = "Active"}
  environment {
    variables = {
      log_group_name = aws_cloudwatch_log_group.raw_acbs_eod_lambda_decrypt_files.name
    }
  }
    depends_on = [
      aws_cloudwatch_log_group.raw_acbs_eod_lambda_decrypt_files
    ]
  source_code_hash = trimprefix(data.aws_ecr_image.lambda-acbs-eod-decrypt-move-to-raw-image.id, "sha256:")
}
########## get the latest Image 
data "aws_ecr_image" "lambda-acbs-eod-decrypt-move-to-raw-image" {
  repository_name = "lambda-acbs-eod-decrypt-move-to-raw-image"
  image_tag = "latest"
}
