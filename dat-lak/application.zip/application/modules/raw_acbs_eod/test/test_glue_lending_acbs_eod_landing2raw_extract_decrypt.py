import pytest
import json
import unittest
import botocore
import boto3
import sys
import os
import pandas as pd
from datetime import datetime
import difflib
from unittest.mock import MagicMock, patch
from botocore.exceptions import ClientError
from botocore.config import Config
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.types import StructType, StructField, StringType

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from test.testdata import input_business_date




with patch('awsglue.context.GlueContext', MagicMock()), \
     patch('sys.argv', ['script_name','--ACBS_TABLE', 'test_ACBS_TABLE', '--ENV', 'test']):
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_get_business_date_ssm
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_cleanup_partition_folder
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_get_gpg_keys
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_invoke_lambdato_decrypt
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import archive_files
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_move_to_s3
     from src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt import def_check_preprocess    
     

class TestsfdcEODRaw(unittest.TestCase):
    @patch('boto3.client')
    def test_def_get_business_date_ssm(self,mock_boto_client):
        mock_ssm = MagicMock()
        mock_boto_client.return_value = mock_ssm
        mock_ssm.get_parameter.return_value= {'Parameter': {'Value': input_business_date}}
        bus_date_date,bus_date_str = def_get_business_date_ssm('test_param')
        assert bus_date_str == input_business_date

    @patch('boto3.client')  # Mock boto3 client
    def test_def_cleanup_partition_folder(self,mock_boto_client):
    # Create a mock S3 client
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

    # Define test parameters
        bus_date_date = datetime(2025, 2, 25)
        raw_bucket_name = "test-bucket"
        raw_file_key = "test-folder/"
        acbs_table = "acbs_data"

    # Expected S3 path
        expected_prefix = f"{raw_file_key}{acbs_table}/year=2025/month=2/day=25/"

    # Mock response for list_objects_v2 with two files
        mock_s3.list_objects_v2.return_value = {
            'Contents': [
                {'Key': f"{expected_prefix}file1.txt"},
                {'Key': f"{expected_prefix}file2.txt"}
            ]
        }

    # Call the function
        result = def_cleanup_partition_folder(bus_date_date, raw_bucket_name, raw_file_key, acbs_table)

    # Assertions
        mock_s3.list_objects_v2.assert_called_once_with(Bucket=raw_bucket_name, Prefix=expected_prefix)
        assert mock_s3.delete_object.call_count == 2  # Two files should be deleted
        assert result == 2  # Function should return the count of deleted objects

    @patch('boto3.client')
    def test_def_cleanup_partition_folder_no_files(self,mock_boto_client):
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

    # Define test parameters
        bus_date_date = datetime(2025, 2, 25)
        raw_bucket_name = "test-bucket"
        raw_file_key = "test-folder/"
        acbs_table = "acbs_data"

    # Mock empty response (no files)
        mock_s3.list_objects_v2.return_value = {}

    # Call the function
        result = def_cleanup_partition_folder(bus_date_date, raw_bucket_name, raw_file_key, acbs_table)

    # Assertions
        mock_s3.list_objects_v2.assert_called_once()
        mock_s3.delete_object.assert_not_called()  # No deletion should occur
        assert result == 0  # Should return 0 since no files exist

    @patch('boto3.client')
    def test_def_cleanup_partition_folder_delete_error(self,mock_boto_client):

        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3

    # Define test parameters
        bus_date_date = datetime(2025, 2, 25)
        raw_bucket_name = "test-bucket"
        raw_file_key = "test-folder/"
        acbs_table = "acbs_data"

    # Expected S3 path
        expected_prefix = f"{raw_file_key}{acbs_table}/year=2025/month=2/day=25/"

    # Mock response with one file
        mock_s3.list_objects_v2.return_value = {
            'Contents': [{'Key': f"{expected_prefix}file1.txt"}]
        }

    # Simulate an exception when trying to delete an object
        mock_s3.delete_object.side_effect = Exception("S3 delete error")

    # Call the function
        with pytest.raises(Exception, match="S3 delete error"):
            def_cleanup_partition_folder(bus_date_date, raw_bucket_name, raw_file_key, acbs_table)

    # Assertions
        mock_s3.delete_object.assert_called_once()

    @patch('boto3.client')  # Mock boto3 client
    def test_def_get_gpg_keys_success(self,mock_boto_client):
        """Test successful retrieval of GPG keys from AWS Secrets Manager."""
    # Create a mock Secrets Manager client
        mock_secretsmanager = MagicMock()
        mock_boto_client.return_value = mock_secretsmanager

    # Define test secrets
        gpg_secret_private_key = "test-private-key-secret"
        gpg_secret_pass_phrase_key = "test-passphrase-secret"

    # Mock responses for get_secret_value
        mock_secretsmanager.get_secret_value.side_effect = [
            {'SecretString': 'mocked_private_key'},
            {'SecretString': 'mocked_passphrase'}
        ]

    # Call the function
        result = def_get_gpg_keys(gpg_secret_private_key, gpg_secret_pass_phrase_key)

    # Assertions
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_private_key)
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_pass_phrase_key)
        assert result == ('mocked_private_key', 'mocked_passphrase')  # Expected result

    @patch('boto3.client')
    def test_def_get_gpg_keys_private_key_failure(self,mock_boto_client):
        """Test failure when fetching the private key from AWS Secrets Manager."""
        mock_secretsmanager = MagicMock()
        mock_boto_client.return_value = mock_secretsmanager

    # Define test secrets
        gpg_secret_private_key = "test-private-key-secret"
        gpg_secret_pass_phrase_key = "test-passphrase-secret"

    # Mock response: private key retrieval fails
        mock_secretsmanager.get_secret_value.side_effect = [
            ClientError({"Error": {"Code": "AccessDeniedException"}}, "GetSecretValue"),
            {'SecretString': 'mocked_passphrase'}
        ]

    # Call the function
        result = def_get_gpg_keys(gpg_secret_private_key, gpg_secret_pass_phrase_key)

    # Assertions
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_private_key)
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_pass_phrase_key)
        assert result == (None, 'mocked_passphrase')
    
    @patch('boto3.client')
    def test_def_get_gpg_keys_both_fail(self,mock_boto_client):
        """Test failure when both GPG key and passphrase retrievals fail."""
        mock_secretsmanager = MagicMock()
        mock_boto_client.return_value = mock_secretsmanager

    # Define test secrets
        gpg_secret_private_key = "test-private-key-secret"
        gpg_secret_pass_phrase_key = "test-passphrase-secret"

    # Mock response: both retrievals fail
        mock_secretsmanager.get_secret_value.side_effect = [
            ClientError({"Error": {"Code": "AccessDeniedException"}}, "GetSecretValue"),
            ClientError({"Error": {"Code": "AccessDeniedException"}}, "GetSecretValue")
        ]

    # Call the function
        result = def_get_gpg_keys(gpg_secret_private_key, gpg_secret_pass_phrase_key)

    # Assertions
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_private_key)
        mock_secretsmanager.get_secret_value.assert_any_call(SecretId=gpg_secret_pass_phrase_key)
        assert result == (None, None) 

    @patch('boto3.client')  # Mock boto3 Lambda client
    def test_def_invoke_lambdato_decrypt_success(self,mock_boto_client):
        """Test successful invocation of Lambda function."""
    # Create a mock Lambda client
        mock_lambda_client = MagicMock()
        mock_boto_client.return_value = mock_lambda_client

        lambda_payload = {"test": "data"}
        lambda_function_name = "test-lambda-function"

    # Mock response for successful Lambda invocation
        mock_response = {
            "Payload": MagicMock(read=MagicMock(return_value=json.dumps({"errorType": "success"}).encode('utf-8')))
        }
        mock_lambda_client.invoke.return_value = mock_response

    # Call the function
        def_invoke_lambdato_decrypt(lambda_payload, lambda_function_name)

    # Assertions
        mock_lambda_client.invoke.assert_called_once_with(
            FunctionName=lambda_function_name,
            InvocationType='RequestResponse',
            Payload=str(lambda_payload)
        )

    
    @patch('boto3.client')
    def test_def_invoke_lambdato_decrypt_failure(self,mock_boto_client):
        """Test failure scenario where Lambda returns an error."""
        mock_lambda_client = MagicMock()
        mock_boto_client.return_value = mock_lambda_client

        lambda_payload = {"test": "data"}
        lambda_function_name = "test-lambda-function"

    # Mock response for Lambda failure
        mock_response = {
            "Payload": MagicMock(read=MagicMock(return_value=json.dumps({"errorType": "failure", "message": "Decryption failed"}).encode('utf-8')))
        }
        mock_lambda_client.invoke.return_value = mock_response

    # Patch sys.exit to prevent pytest from exiting
        with patch("sys.exit") as mock_exit:
            def_invoke_lambdato_decrypt(lambda_payload, lambda_function_name)

        # Assertions
            mock_lambda_client.invoke.assert_called_once_with(
                FunctionName=lambda_function_name,
                InvocationType='RequestResponse',
                Payload=str(lambda_payload)
            )
            mock_exit.assert_called_once_with(20)  # Ensure sys.exit(20) is called
    

    @patch("boto3.client")  # Mock boto3 S3 client
    def test_archive_files(self,mock_boto_client):
        """Test that archive_files correctly copies and deletes an S3 object."""
    # Create a mock S3 client
        mock_s3_client = MagicMock()
        mock_boto_client.return_value = mock_s3_client

    # Test parameters
        source_bucket = "source-bucket"
        source_key = "path/to/source-file.txt"
        destination_bucket = "destination-bucket"
        destination_key = "path/to/destination-file.txt"

    # Call the function
        archive_files(source_bucket, source_key, destination_bucket, destination_key)

    # Assertions: Verify copy operation
        mock_s3_client.copy_object.assert_called_once_with(
        Bucket=destination_bucket,
        CopySource={'Bucket': source_bucket, 'Key': source_key},
        Key=destination_key
        )

    # Assertions: Verify delete operation
        mock_s3_client.delete_object.assert_called_once_with(
            Bucket=source_bucket,
            Key=source_key
        )
    
    
    @patch("boto3.client")  # Mock S3 client
    def test_def_check_preprocess_success(self,mock_boto_client):
         
        mock_s3_client = MagicMock()
        mock_s3_client.list_objects_v2.return_value = {
            "KeyCount": 2,
            "Contents": [
                {"Key": "test-folder/file1.txt"},
                {"Key": "test-folder/file2.txt"}
            ]
        }
        mock_boto_client.return_value = mock_s3_client

        ing_bucket_name = "test-bucket"
        ing_file_key = "test-folder/"
        result = def_check_preprocess(ing_bucket_name, ing_file_key)
        assert result == ["test-folder/file1.txt", "test-folder/file2.txt"]
        mock_s3_client.list_objects_v2.assert_called_once_with(Bucket=ing_bucket_name, Prefix=ing_file_key)
    
    

    @patch("boto3.client")
    def test_def_check_preprocess_no_files(self,mock_boto_client):
        """Test def_check_preprocess when no files are present (should exit with code 11)."""
    
        mock_s3_client = MagicMock()
        mock_s3_client.list_objects_v2.return_value = {"KeyCount": 0}  # Simulate empty folder
        mock_boto_client.return_value = mock_s3_client

        ing_bucket_name = "test-bucket"
        ing_file_key = "test-folder/"
    
        with pytest.raises(SystemExit) as exc_info:
            def_check_preprocess(ing_bucket_name, ing_file_key)
    
        assert exc_info.value.code == 11


    @patch("boto3.client")
    def test_def_check_preprocess_s3_error(self,mock_boto_client):
        """Test def_check_preprocess when S3 throws an error (should exit with code 10)."""

        mock_s3_client = MagicMock()
        mock_s3_client.list_objects_v2.side_effect = botocore.exceptions.ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Access Denied"}},
            "ListObjectsV2"
        )
        mock_boto_client.return_value = mock_s3_client

        ing_bucket_name = "test-bucket"
        ing_file_key = "test-folder/"
    
        with pytest.raises(SystemExit) as exc_info:
            def_check_preprocess(ing_bucket_name, ing_file_key)
    
        assert exc_info.value.code == 10
    """
    @patch('boto3.client')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.spark')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.glueContext')
    def test_def_move_to_s3(self, mock_glueContext, mock_spark, mock_boto3_client):
        mock_s3_client = MagicMock()
        mock_boto3_client.return_value = mock_s3_client

        mock_spark.read.option.return_value.option.return_value.csv.return_value = MagicMock()
        mock_glueContext.write_dynamic_frame.from_options = MagicMock()

        bus_date_date = MagicMock()
        bus_date_date.year = 2025
        bus_date_date.month = 2
        bus_date_date.day = 26
        
        def_move_to_s3(bus_date_date, 'test-bucket', 'test-key', 'test-table')

        mock_spark.read.option.return_value.option.return_value.csv.assert_called_once()
        mock_glueContext.write_dynamic_frame.from_options.assert_called_once()
        mock_s3_client.create_bucket.assert_not_called() 
    """
    @patch('boto3.client')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.spark')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.glueContext')
    #@patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.logger')
    def test_def_move_to_s3_write_exception(self, mock_glueContext, mock_spark, mock_boto3_client):
        mock_s3_client = MagicMock()
        mock_boto3_client.return_value = mock_s3_client
        mock_df = MagicMock()
        mock_spark.read.option.return_value.option.return_value.csv.return_value = mock_df
        error = "Test write error"
        #mock_glueContext.write_dynamic_frame.from_options.side_effect = Exception(error)
        bus_date_date = MagicMock()
        bus_date_date.year = 2025
        bus_date_date.month = 2
        bus_date_date.day = 26

        def_move_to_s3(bus_date_date, 'test-bucket', 'test-key', 'test-table')
        #mock_logger.error.assert_any_call(f"Error writing the Dynamic Frame to Raw -->  {error}")
    
    @patch('boto3.client')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.spark')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.glueContext')
    @patch('src.Glue_acbs_eod_decrypt_move_to_raw.lending_acbs_eod_landing2raw_extract_decrypt.logger')    
    def test_def_move_to_s3_no_data(self, mock_logger, mock_glueContext, mock_spark, mock_boto3_client):
        mock_s3_client = MagicMock()
        mock_boto3_client.return_value = mock_s3_client

        mock_df = MagicMock()
        mock_df.head.return_value = []
        mock_spark.read.option.return_value.option.return_value.csv.return_value = mock_df
        mock_glueContext.write_dynamic_frame.from_options = MagicMock()

        bus_date_date = MagicMock()
        bus_date_date.year = 2025
        bus_date_date.month = 2
        bus_date_date.day = 26
        def_move_to_s3(bus_date_date, 'test-bucket', 'test-key', 'test-table')
        mock_df.write.mode.return_value.parquet.assert_called_once_with(f"s3://test-bucket/test-keytest-table/")
    
    
if __name__ == '__main__': 
    unittest.main()
    

    