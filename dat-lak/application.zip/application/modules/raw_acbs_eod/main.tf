variable "environment" {type = string}
variable "lending-acb_table_names" {type    = list(string)}
variable "splunk_tags"{  type= map(string) }
variable "etl-script-s3-bucket" {type = string}
variable "tags" {type = map(string)}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}


locals {
  account_id                      = data.aws_caller_identity.current.account_id
  region_name                     = data.aws_region.current.name
  glue_role_arn                   = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
  lambda_role_arn                 = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-lambda-role"
  acbs_raw_s3_bucket              = "${var.environment}-acb-dl-dat-lak-raw-lending-acbs-asset"
  raw_acbs_eod_glue_ing2raw       =  "lending_acbs_eod_landing2raw_extract_decrypt"
  raw_acbs_eod_lambda_decrypt_files= "acb-dat-lak-lambda-decrypt-acbs-files"
  ecr_image_uri                   ="${local.account_id}.dkr.ecr.us-west-2.amazonaws.com/lambda-acbs-eod-decrypt-move-to-raw-image:latest"
  acbs_gpg_public_key             = "${var.environment}/acbs/eod_files/secret_gpg_public_key"
  acbs_gpg_pass_pharse            = "${var.environment}/acbs/eod_files/secret_gpg_pass_pharse"
  acbs_gpg_private_key            = "${var.environment}/acbs/eod_files/secret_gpg_private_key"
  

}


resource "aws_ssm_parameter" "acbd_eod_business_date" {
  name  = "/acbs-eod/business-date"
  type  = "String"
  value = "19000101"
  lifecycle {
      ignore_changes = [value]
  }
  tags        = var.tags
}






resource "aws_s3_object" "acbs_eod_raw_dags_1" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_1.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_1.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_1.py")
}


resource "aws_s3_object" "acbs_eod_raw_dags_2" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_2.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_2.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_2.py")
}

resource "aws_s3_object" "acbs_eod_raw_dags_3" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_3.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_3.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_3.py")
}

resource "aws_s3_object" "acbs_eod_raw_dags_4" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_4.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_4.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_4.py")
}


resource "aws_s3_object" "acbs_eod_raw_dags_5" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_5.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_5.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_set_5.py")
}

resource "aws_s3_object" "acbs_eod_raw_dags_s3keysensor_load" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_s3_sensor_and_load.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_s3_sensor_and_load.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_s3_sensor_and_load.py")
}


resource "aws_s3_object" "acbs_eod_raw_dags_large_files" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/acbs_eod/airflow_acbs_eod_decrypt_ingestion_2_raw_load_Large_files.py"
  source = "${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_Large_files.py"
  source_hash = filemd5("${path.module}/airflow/airflow_acbs_eod_decrypt_ingestion_2_raw_load_Large_files.py")
}





