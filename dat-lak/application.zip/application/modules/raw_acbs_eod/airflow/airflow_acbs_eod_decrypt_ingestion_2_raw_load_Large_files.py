from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'email_on_failure': False
}
start_date = datetime(2025, 1, 1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ing2raw_set_gb',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_large_files',
    default_args=default_args,
    tags=['ACBS'],
    schedule=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)

J_SYCE = GlueJobOperator(task_id = 'J_SYCE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYCE"},dag=dag)
J_SYCE_crawler = GlueCrawlerOperator(task_id="J_SYCE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYCE" } , poll_interval=30, dag = dag)

J_CAHS = GlueJobOperator(task_id = 'J_CAHS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAHS"},dag=dag)
J_CAHS_crawler = GlueCrawlerOperator(task_id="J_CAHS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAHS" } , poll_interval=30, dag = dag)

COCMAY = GlueJobOperator(task_id = 'COCMAY',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAY"},dag=dag)
COCMAY_crawler = GlueCrawlerOperator(task_id="COCMAY_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAY" } , poll_interval=30, dag = dag)

ZFPINA = GlueJobOperator(task_id = 'ZFPINA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFPINA"},dag=dag)
ZFPINA_crawler = GlueCrawlerOperator(task_id="ZFPINA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFPINA" } , poll_interval=30, dag = dag)

ZFPACK = GlueJobOperator(task_id = 'ZFPACK',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFPACK"},dag=dag)
ZFPACK_crawler = GlueCrawlerOperator(task_id="ZFPACK_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFPACK" } , poll_interval=30, dag = dag)

COCMBA = GlueJobOperator(task_id = 'COCMBA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMBA"},dag=dag)
COCMBA_crawler = GlueCrawlerOperator(task_id="COCMBA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMBA" } , poll_interval=30, dag = dag)


ACBS_EOD_Raw_Start_Task >> [J_SYCE,J_CAHS,COCMAY,ZFPINA,ZFPACK,COCMBA]
J_SYCE >> J_SYCE_crawler
J_CAHS >> J_CAHS_crawler  
COCMAY >> COCMAY_crawler  
ZFPINA >> ZFPINA_crawler  
ZFPACK >> ZFPACK_crawler  
COCMBA >> COCMBA_crawler  
[J_SYCE_crawler ,J_CAHS_crawler ,COCMAY_crawler ,ZFPINA_crawler ,ZFPACK_crawler ,COCMBA_crawler ]


