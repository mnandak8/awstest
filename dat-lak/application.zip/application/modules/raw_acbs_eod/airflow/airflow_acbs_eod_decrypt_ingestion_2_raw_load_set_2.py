from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'email_on_failure': False
}
start_date = datetime(2025, 1, 1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ing2raw_set2',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_2',
    default_args=default_args,
    tags=['ACBS'],
    schedule=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_StartTask_set2 = DummyOperator(task_id='ACBS_EOD_Raw_StartTask_set2',dag=dag)
ACBS_EOD_Raw_EndTask_set2 = DummyOperator(task_id='ACBS_EOD_Raw_EndTask_set2',dag=dag)

J_CLAS = GlueJobOperator(task_id = 'J_CLAS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAS"},dag=dag)
J_CLAS_crawler = GlueCrawlerOperator(task_id="J_CLAS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAS"  } , poll_interval=30, dag = dag)

ZFBPEXT = GlueJobOperator(task_id = 'ZFBPEXT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPEXT"},dag=dag)
ZFBPEXT_crawler = GlueCrawlerOperator(task_id="ZFBPEXT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFBPEXT"  } , poll_interval=30, dag = dag)

J_CAFE = GlueJobOperator(task_id = 'J_CAFE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFE"},dag=dag)   
J_CAFE_crawler = GlueCrawlerOperator(task_id="J_CAFE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFE"  } , poll_interval=30, dag = dag)

J_CAFI = GlueJobOperator(task_id = 'J_CAFI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFI"},dag=dag)   
J_CAFI_crawler = GlueCrawlerOperator(task_id="J_CAFI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFI"  } , poll_interval=30, dag = dag)

J_CLLA = GlueJobOperator(task_id = 'J_CLLA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLA"},dag=dag)   
J_CLLA_crawler = GlueCrawlerOperator(task_id="J_CLLA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLLA"  } , poll_interval=30, dag = dag)

J_CLIS = GlueJobOperator(task_id = 'J_CLIS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIS"},dag=dag)   
J_CLIS_crawler = GlueCrawlerOperator(task_id="J_CLIS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLIS"  } , poll_interval=30, dag = dag)

DMEXAF = GlueJobOperator(task_id = 'DMEXAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DMEXAF"},dag=dag)   
DMEXAF_crawler = GlueCrawlerOperator(task_id="DMEXAF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DMEXAF"  } , poll_interval=30, dag = dag)

J_CLRS = GlueJobOperator(task_id = 'J_CLRS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRS"},dag=dag)   
J_CLRS_crawler = GlueCrawlerOperator(task_id="J_CLRS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLRS"  } , poll_interval=30, dag = dag)

ZQRMEX = GlueJobOperator(task_id = 'ZQRMEX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZQRMEX"},dag=dag)   
ZQRMEX_crawler = GlueCrawlerOperator(task_id="ZQRMEX_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZQRMEX"  } , poll_interval=30, dag = dag)

J_CLPB = GlueJobOperator(task_id = 'J_CLPB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPB"},dag=dag)   
J_CLPB_crawler = GlueCrawlerOperator(task_id="J_CLPB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPB"  } , poll_interval=30, dag = dag)

J_CLPS = GlueJobOperator(task_id = 'J_CLPS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPS"},dag=dag)
J_CLPS_crawler = GlueCrawlerOperator(task_id="J_CLPS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPS"  } , poll_interval=30, dag = dag)

ZWFBLH = GlueJobOperator(task_id = 'ZWFBLH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFBLH"},dag=dag)
ZWFBLH_crawler = GlueCrawlerOperator(task_id="ZWFBLH_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFBLH"  } , poll_interval=30, dag = dag)

COCMAG = GlueJobOperator(task_id = 'COCMAG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAG"},dag=dag)
COCMAG_crawler = GlueCrawlerOperator(task_id="COCMAG_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAG"  } , poll_interval=30, dag = dag)

J_CLMS = GlueJobOperator(task_id = 'J_CLMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMS"},dag=dag)
J_CLMS_crawler = GlueCrawlerOperator(task_id="J_CLMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLMS"  } , poll_interval=30, dag = dag)

J_CAFB = GlueJobOperator(task_id = 'J_CAFB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFB"},dag=dag)
J_CAFB_crawler = GlueCrawlerOperator(task_id="J_CAFB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFB"  } , poll_interval=30, dag = dag)

Z_LBRHST = GlueJobOperator(task_id = 'Z_LBRHST',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_LBRHST"},dag=dag)
Z_LBRHST_crawler = GlueCrawlerOperator(task_id="Z_LBRHST_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_LBRHST"  } , poll_interval=30, dag = dag)

DSLWTR = GlueJobOperator(task_id = 'DSLWTR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTR"},dag=dag)
DSLWTR_crawler = GlueCrawlerOperator(task_id="DSLWTR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTR"  } , poll_interval=30, dag = dag)

J_CALM = GlueJobOperator(task_id = 'J_CALM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CALM"},dag=dag)
J_CALM_crawler = GlueCrawlerOperator(task_id="J_CALM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CALM"  } , poll_interval=30, dag = dag)

J_CAFF = GlueJobOperator(task_id = 'J_CAFF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFF"},dag=dag)
J_CAFF_crawler = GlueCrawlerOperator(task_id="J_CAFF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFF"  } , poll_interval=30, dag = dag)

DSLWTB = GlueJobOperator(task_id = 'DSLWTB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTB"},dag=dag)
DSLWTB_crawler = GlueCrawlerOperator(task_id="DSLWTB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTB"  } , poll_interval=30, dag = dag)

J_CLMI = GlueJobOperator(task_id = 'J_CLMI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMI"},dag=dag)
J_CLMI_crawler = GlueCrawlerOperator(task_id="J_CLMI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLMI"  } , poll_interval=30, dag = dag)

J_CLTP = GlueJobOperator(task_id = 'J_CLTP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTP"},dag=dag)
J_CLTP_crawler = GlueCrawlerOperator(task_id="J_CLTP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLTP"  } , poll_interval=30, dag = dag)

ZWFCUD = GlueJobOperator(task_id = 'ZWFCUD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFCUD"},dag=dag)
ZWFCUD_crawler = GlueCrawlerOperator(task_id="ZWFCUD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFCUD"  } , poll_interval=30, dag = dag)

Z_GLDT = GlueJobOperator(task_id = 'Z_GLDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_GLDT"},dag=dag)
Z_GLDT_crawler = GlueCrawlerOperator(task_id="Z_GLDT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_GLDT"  } , poll_interval=30, dag = dag)

J_CAMS = GlueJobOperator(task_id = 'J_CAMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMS"},dag=dag)
J_CAMS_crawler = GlueCrawlerOperator(task_id="J_CAMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAMS"  } , poll_interval=30, dag = dag)

J_CLDTW = GlueJobOperator(task_id = 'J_CLDTW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDTW"},dag=dag)
J_CLDTW_crawler = GlueCrawlerOperator(task_id="J_CLDTW_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLDTW"  } , poll_interval=30, dag = dag)

J_CUPI = GlueJobOperator(task_id = 'J_CUPI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUPI"},dag=dag)
J_CUPI_crawler = GlueCrawlerOperator(task_id="J_CUPI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUPI"  } , poll_interval=30, dag = dag)

J_CLAP = GlueJobOperator(task_id = 'J_CLAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAP"},dag=dag)
J_CLAP_crawler = GlueCrawlerOperator(task_id="J_CLAP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAP"  } , poll_interval=30, dag = dag)

DSGNEB = GlueJobOperator(task_id = 'DSGNEB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSGNEB"},dag=dag)
DSGNEB_crawler = GlueCrawlerOperator(task_id="DSGNEB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSGNEB"  } , poll_interval=30, dag = dag)

Z_ACCLSM = GlueJobOperator(task_id = 'Z_ACCLSM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACCLSM"},dag=dag)
Z_ACCLSM_crawler = GlueCrawlerOperator(task_id="Z_ACCLSM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ACCLSM"  } , poll_interval=30, dag = dag)




ACBS_EOD_Raw_StartTask_set2 >> [J_CLAS,ZFBPEXT,J_CAFE,J_CAFI,J_CLLA,J_CLIS,DMEXAF,J_CLRS,ZQRMEX,J_CLPB,J_CLPS,ZWFBLH,COCMAG,J_CLMS,J_CAFB,Z_LBRHST,DSLWTR,J_CALM,J_CAFF,DSLWTB,J_CLMI,J_CLTP,ZWFCUD,Z_GLDT,J_CAMS,J_CLDTW,J_CUPI,J_CLAP,DSGNEB,Z_ACCLSM]
J_CLAS >> J_CLAS_crawler
ZFBPEXT >> ZFBPEXT_crawler  
J_CAFE >> J_CAFE_crawler    
J_CAFI >> J_CAFI_crawler    
J_CLLA >> J_CLLA_crawler    
J_CLIS >> J_CLIS_crawler    
DMEXAF >> DMEXAF_crawler    
J_CLRS >> J_CLRS_crawler    
ZQRMEX >> ZQRMEX_crawler    
J_CLPB >> J_CLPB_crawler    
J_CLPS >> J_CLPS_crawler    
ZWFBLH >> ZWFBLH_crawler    
COCMAG >> COCMAG_crawler    
J_CLMS >> J_CLMS_crawler    
J_CAFB >> J_CAFB_crawler    
Z_LBRHST >> Z_LBRHST_crawler
DSLWTR >> DSLWTR_crawler    
J_CALM >> J_CALM_crawler    
J_CAFF >> J_CAFF_crawler    
DSLWTB >> DSLWTB_crawler    
J_CLMI >> J_CLMI_crawler    
J_CLTP >> J_CLTP_crawler    
ZWFCUD >> ZWFCUD_crawler    
Z_GLDT >> Z_GLDT_crawler    
J_CAMS >> J_CAMS_crawler    
J_CLDTW >> J_CLDTW_crawler  
J_CUPI >> J_CUPI_crawler    
J_CLAP >> J_CLAP_crawler    
DSGNEB >> DSGNEB_crawler    
Z_ACCLSM >> Z_ACCLSM_crawler
[J_CLAS_crawler ,ZFBPEXT_crawler ,J_CAFE_crawler ,J_CAFI_crawler ,J_CLLA_crawler ,J_CLIS_crawler ,DMEXAF_crawler ,J_CLRS_crawler ,ZQRMEX_crawler ,J_CLPB_crawler ,J_CLPS_crawler ,ZWFBLH_crawler ,COCMAG_crawler ,J_CLMS_crawler ,J_CAFB_crawler ,Z_LBRHST_crawler ,DSLWTR_crawler ,J_CALM_crawler ,J_CAFF_crawler ,DSLWTB_crawler ,J_CLMI_crawler ,J_CLTP_crawler ,ZWFCUD_crawler ,Z_GLDT_crawler ,J_CAMS_crawler ,J_CLDTW_crawler ,J_CUPI_crawler ,J_CLAP_crawler ,DSGNEB_crawler ,Z_ACCLSM_crawler ] >> ACBS_EOD_Raw_EndTask_set2


