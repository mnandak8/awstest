# Upload Glue script file to tooling
resource "aws_s3_object" "raw-acbs-eod-glue-script" {
  bucket = "${var.etl-script-s3-bucket}"
  key    = "deploy/lending_acbs_eod_landing2raw_extract_decrypt.py"
  source = "${path.module}/src/Glue_acbs_eod_decrypt_move_to_raw/lending_acbs_eod_landing2raw_extract_decrypt.py"
  etag   = filemd5("${path.module}/src/Glue_acbs_eod_decrypt_move_to_raw/lending_acbs_eod_landing2raw_extract_decrypt.py")
   
}
 

resource "aws_glue_job" "raw-acbs-eod-lending-acbs-eod-landing2raw-extract-decrypt" {
  name        = local.raw_acbs_eod_glue_ing2raw
  role_arn    = local.glue_role_arn
  tags=var.splunk_tags
  execution_property {
    max_concurrent_runs = 150
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.raw-acbs-eod-glue-script.bucket}/${aws_s3_object.raw-acbs-eod-glue-script.key}"
    python_version  = "3"
  }

  glue_version      = "5.0"
  worker_type       = "G.2X"
  number_of_workers = "5"

}
