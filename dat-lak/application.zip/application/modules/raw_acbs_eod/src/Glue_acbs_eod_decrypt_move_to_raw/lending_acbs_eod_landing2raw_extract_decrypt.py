import sys
import boto3
import botocore.exceptions
import pandas as pd
import logging
import json
import tempfile
import os
from datetime import datetime
from botocore.config import Config
from botocore.exceptions import ClientError

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, regexp_replace, year, month, dayofmonth, to_date, lit

from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ['ENV','ACBS_TABLE'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

env = args['ENV']
acbs_table = args['ACBS_TABLE']

job.commit()



logger = logging.getLogger()
logger.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


ing_bucket_name=f"{env}-acb-dat-ing-acbs-landing"
ing_file_key="SVCAWSSFTP/"
raw_bucket_name=f"{env}-acb-dl-dat-lak-raw-lending-acbs-asset"
raw_file_key="acbs_eod/"

  
gpg_secret_private_key=f"{env}/acbs/eod_files/secret_gpg_private_key"
gpg_secret_pass_phrase_key=f"{env}/acbs/eod_files/secret_gpg_pass_pharse"
lambda_function_name="acb-dat-lak-lambda-decrypt-acbs-files"
ssm_parameter_bus_date_name="/acbs-eod/business-date"

#################################################
def def_invoke_lambdato_decrypt(lambda_payload, lambda_function_name):
    logger.info('def_invoke_lambdato_decrypt')
    #lambda_client = boto3.client('lambda') 
    lambda_client = boto3.client('lambda',region_name='us-west-2',config=Config(read_timeout=900))
    response = lambda_client.invoke(FunctionName=lambda_function_name,InvocationType='RequestResponse', Payload=str(lambda_payload))
    
    response_payload = json.loads(response['Payload'].read().decode('utf-8'))
    if response_payload['errorType'] == 'success':
        logger.info(f"Lambda processing successful --> {response_payload}")
    else:
        print(f"Lambda processing Failed --> {response_payload}")
        sys.exit(20)

#####################################################################


###################################
def def_check_preprocess(ing_bucket_name,ing_file_key):
    logger.info('def_check_preprocess')
    try:
        s3_client=boto3.client('s3')
        result_files = s3_client.list_objects_v2(Bucket=ing_bucket_name, Prefix=ing_file_key)
    except botocore.exceptions.ClientError as error:
        logger.error(f"Reading the ING S3 Bucket  --> Failed with Error {error}")
        sys.exit(10)
    fileCount = result_files['KeyCount']
    if fileCount == 0:
        logger.error(f"No Files from ACBS the folder is Empty")
        sys.exit(11)
    acbs_file_name_list=[]
    acbs_file_name_list = [
        obj['Key'] for obj in result_files.get('Contents', [])
        if obj['Key'].count('/') == ing_file_key.count('/')  
    ]

    return(acbs_file_name_list)
    
###################################


########################################

def def_get_gpg_keys(gpg_secret_private_key,gpg_secret_pass_phrase_key): 
    logger.info("def_get_gpg_keys")
    session = boto3.Session()
    secretsmanager_client=boto3.client('secretsmanager',region_name= "us-west-2")
    gpg_private_key = None  # Initialize to None
    gpg_pass_phrase_key = None  # Initialize to None
    try:
        get_secret_value_response_key = secretsmanager_client.get_secret_value(SecretId=gpg_secret_private_key)
    except ClientError as err:
        logger.critical('Error reading the Secrets gpg key')
    else:
        gpg_private_key = get_secret_value_response_key['SecretString']
        
    try:
        get_secret_value_response_pp = secretsmanager_client.get_secret_value(SecretId=gpg_secret_pass_phrase_key)
    except ClientError as err:
        logger.critical('Error reading the Secrets key gpg pp ')
    else:
        gpg_pass_phrase_key=get_secret_value_response_pp['SecretString']
    
    return(gpg_private_key,gpg_pass_phrase_key)
    
def def_get_business_date_ssm(ssm_parameter_bus_date_name):
    logger.info('def_get_business_date_ssm')
    ssm_client = boto3.client('ssm')
    try:
        response = ssm_client.get_parameter(Name=ssm_parameter_bus_date_name)
    except botocore.exceptions.ClientError as error:
        print(f"Failed in Fetching value from  SSM {error}")
        result = {'errorType': 'error',  'errorMessage': 'Failed in Fetching value from  SSM'}
        raise 

    bus_date_str = response['Parameter']['Value'] 
    try:
        bus_date_date = datetime.strptime(bus_date_str, '%Y%m%d')
        print(f"Date from the SYDC file is valid date")
    except ValueError:
        print(f"Date from the SYDC file has an Invalid date")
        result = {'errorType': 'error',  'errorMessage': 'Date from the SYDC file has an Invalid date'}
        raise ValueError(f"Invalid date format: {bus_date_str}. Expected format is YYYYMMDD.")  

    return(bus_date_date,bus_date_str)
#################################################################
def def_move_to_s3(bus_date_date,raw_bucket_name,raw_file_key,acbs_table):
    logger.info('def_move_to_s3')
    s3_client=boto3.client('s3')
    
    year_value = bus_date_date.year
    month_value = bus_date_date.month
    day_value = bus_date_date.day
                  
    temp_raw_file=f"s3://{raw_bucket_name}/{raw_file_key}temp/{acbs_table}.DAT"
    try:
        df_raw_data = spark.read.option("header", "true").option("delimiter", "|").csv(temp_raw_file)
    except Exception as error:
        logger.info("print error reading the spark.read Temp file -->  {error}")

    if df_raw_data.head(1):
        df_cleaned = df_raw_data.select([regexp_replace(col(c), r'[\x00-\x1F\x7F\x20]', '').alias(c) for c in df_raw_data.columns])
        
        df_cleaned = df_cleaned.withColumn("year", lit(year_value)).withColumn("month", lit(month_value)).withColumn("day", lit(day_value))
    
        dynamic_frame = DynamicFrame.fromDF(df_cleaned, glueContext, "dynamic_frame")
    
        raw_output_path=f"s3://{raw_bucket_name}/{raw_file_key}{acbs_table}/"
        try:
            glueContext.write_dynamic_frame.from_options(dynamic_frame,connection_type="s3",connection_options={"path": raw_output_path, "partitionKeys": ["year", "month", "day"]},format="parquet")
        except Exception as error:
            logger.error(f"Error writing the Dynamic Frame to Raw -->  {error}")
    else:
        logger.info("No Data in the file ")
        raw_output_path=f"s3://{raw_bucket_name}/{raw_file_key}{acbs_table}/"
        df_raw_data.write.mode("overwrite").parquet(raw_output_path)
########################################################################
def def_cleanup_partition_folder(bus_date_date,raw_bucket_name,raw_file_key,acbs_table):
    s3_client=boto3.client('s3')
    year_value = bus_date_date.year
    month_value = bus_date_date.month
    day_value = bus_date_date.day
    path = f"{raw_file_key}{acbs_table}/year={year_value}/month={month_value}/day={day_value}/"
    response = s3_client.list_objects_v2(Bucket=raw_bucket_name, Prefix=path)
    x=0
    if 'Contents' in response:
        object_keys = [obj['Key'] for obj in response['Contents']]
        for key in object_keys:
            print(f"Deleting: {key}")
            s3_client.delete_object(Bucket=raw_bucket_name, Key=key)
            x=x+1
    return(x)
#################################################################
def archive_files(source_bucket, source_key, destination_bucket, destination_key):
    s3 = boto3.client('s3')
    s3.copy_object(
        Bucket=destination_bucket,
        CopySource={'Bucket': source_bucket, 'Key': source_key},
        Key=destination_key
    )
    # Delete the original file
    s3.delete_object(Bucket=source_bucket, Key=source_key)
    print(f"Moved file from s3://{source_bucket}/{source_key} to s3://{destination_bucket}/{destination_key}")

##################################################################
if __name__ == '__main__':
    logger.info(f"running the job for the table --> {acbs_table}")
    
    acbs_file_name_list=def_check_preprocess(ing_bucket_name,ing_file_key)
    
    if "SYDC" in acbs_table:
        logger.info("checking the Trigger file ")
        if any("SYDC" in item for item in acbs_file_name_list):
            logger.info("Trigger file Exist in Landing Bucket")
        else:
            logger.error(f"No SYDC Trigger File ")
            sys.exit(100)
    
    if any( acbs_table in item for item in acbs_file_name_list):
        logger.info(f"{acbs_table} exist in the Landing Bucket")
        gpg_private_key,gpg_pass_phrase_key=def_get_gpg_keys(gpg_secret_private_key,gpg_secret_pass_phrase_key)
        lambda_payload = {
            'gpg_private_key': gpg_private_key,
            'gpg_pass_phrase_key': gpg_pass_phrase_key,
            'acbs_table': acbs_table,
            'ing_bucket_name':ing_bucket_name,
            'ing_file_key':ing_file_key,
            'raw_bucket_name':raw_bucket_name,
            'raw_file_key':raw_file_key,
            'ssm_parameter_bus_date_name':ssm_parameter_bus_date_name
                }
        lambda_payload_json = json.dumps(lambda_payload, indent=4)
        #call the lambda
        def_invoke_lambdato_decrypt(lambda_payload_json,lambda_function_name)
        
        #get the business_date from SSM
        bus_date_date,bus_date_str=def_get_business_date_ssm(ssm_parameter_bus_date_name)
        
        def_cleanup_partition_folder(bus_date_date,raw_bucket_name,raw_file_key,acbs_table)
        #read the Temp file replace with tabs with nulls and write to S3 as parquet with patitions.
        def_move_to_s3(bus_date_date,raw_bucket_name,raw_file_key,acbs_table)
        #archive files
        source_bucket=ing_bucket_name
        destination_bucket=ing_bucket_name
        source_key=f"{ing_file_key}{acbs_table}.DAT.asc"
        destination_key=f"{ing_file_key}archive/{bus_date_str}/{acbs_table}.DAT.asc"
        archive_files(source_bucket, source_key, destination_bucket, destination_key)
    else:
        logger.info(f"{acbs_table} not present in the landing Bucket exiting the job")     

    logger.info("Glue job finished successfully.") 
