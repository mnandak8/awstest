import os
import boto3
import json
import gnupg
import io
from botocore.exceptions import ClientError
from datetime import datetime
from io import StringIO
import pandas as pd
import subprocess
import tempfile
from io import BytesIO
s3_client=boto3.client('s3')
ssm_client = boto3.client('ssm')

def def_read_encrypted_file(ing_bucket_name,ing_file_key,acbs_table,s3_client):
    print('def_read_encrypted_file')
    ing_file=f"{ing_file_key}{acbs_table}.DAT.asc"
    #ing_file=f"{ing_file_key}{acbs_table}.DAT"
    try:
        sys_data = s3_client.get_object(Bucket=ing_bucket_name, Key=ing_file)
    except Exception as error:
        result = {'errorType': 'error',  'errorMessage': 'Failed in REading data from Ing Bucket'}
        raise 
    sys_file_content = sys_data['Body'].read()
   
    return sys_file_content
                       
def def_decrypt_file(sys_file_content,gpg_private_key,gpg_pass_phrase_key):
    print('def_decrypt_file')
    
    try:
        gpg = gnupg.GPG(gnupghome='/tmp', verbose=True)
        print('gpg = gnupg.GPG Successfully' )
    except Exception as e:
        print('gpg = gnupg.GPG failed' , e)

    try:
        import_result = gpg.import_keys(gpg_private_key)
    except Exception as e:
        print('Found errors while Importing file, e')
        raise 
    
    decrypted_data = gpg.decrypt(sys_file_content , passphrase=gpg_pass_phrase_key)
    if not decrypted_data.ok:
        print('Found errors while encrypting the file')
        raise 
 
    print('decryption complete') 
    return(decrypted_data)
##############################
def def_get_business_date_ssm(ssm_parameter_bus_date_name,ssm_client):
    print('def_get_business_date_ssm')
    try:
        response = ssm_client.get_parameter(Name=ssm_parameter_bus_date_name)
    except botocore.exceptions.ClientError as error:
        print(f"Failed in Fetching value from  SSM {error}")
        result = {'errorType': 'error',  'errorMessage': 'Failed in Fetching value from  SSM'}
        raise 

    bus_date_str = response['Parameter']['Value'] 
    try:
        bus_date_date = datetime.strptime(bus_date_str, '%Y%m%d')
        print(f"Date from the SYDC file is valid date")
    except ValueError:
        print(f"Date from the SYDC file has an Invalid date")
        result = {'errorType': 'error',  'errorMessage': 'Date from the SYDC file has an Invalid date'}
        raise ValueError(f"Invalid date format: {bus_date_str}. Expected format is YYYYMMDD.")  

    return(bus_date_date)
#########################################################
def def_fetch_Business_date_update_ssm(ssm_parameter_bus_date_name,sys_file_content_decrypted_e,ssm_client):
    print('def_fetch_Business_date_update_ssm')
    sys_file_content_decrypted_u=sys_file_content_decrypted_e.data.decode('utf-8')
    
    sys_file_content_decrypted = StringIO(sys_file_content_decrypted_u)
    sys_df = pd.read_csv(sys_file_content_decrypted, delimiter='|')
    
    bus_date_df = sys_df[(sys_df['J$RDQI'] == 'GEN') & (sys_df['J$DWKC'] == 'XX')]['J$MWY8']


    bus_date_str = ' '.join(bus_date_df.astype(str))
    try:
        bus_date_date = datetime.strptime(bus_date_str, '%Y%m%d')
        print(f"Date from the SYDC file is valid date --> {bus_date_str} ")
    except ValueError:
        print(f"Date from the SYDC file has an Invalid date")
        result = {'errorType': 'error',  'errorMessage': 'Date from the SYDC file has an Invalid date'}
        raise ValueError(f"Invalid date format: {bus_date_str}. Expected format is YYYYMMDD.")
      

    try:
        ssm_client.put_parameter(Name=ssm_parameter_bus_date_name,Value=bus_date_str,Type="String",Overwrite=True)
    except botocore.exceptions.ClientError as error:
        print(f"Failed in updating SSM {error}")   
        result = {'errorType': 'error',  'errorMessage': 'Failed in updating SSM'}
        raise 
    return(bus_date_date)


def def_move_data_2_raw(sys_file_content_decrypted,raw_bucket_name,raw_file_key,bus_date_date,acbs_table,s3_client):
    print('def_move_data_2_raw')
    #raw_file_key_out=f"{raw_file_key}{acbs_table}/{bus_date_date.year}/{bus_date_date.month}/{bus_date_date.day}/{acbs_table}.DAT"
    raw_file_key_out=f"{raw_file_key}temp/{acbs_table}.DAT"
    decrypted_bytes = bytes(sys_file_content_decrypted.data)
  
    try:
        s3_client.put_object(Body=decrypted_bytes, Bucket=raw_bucket_name, Key=raw_file_key_out)
        print(f"Moving files to Raw Succeeded --> {raw_file_key_out}")
    except Exception as error:
        print(f"Moving files to Raw --> {raw_file_key_out} with error {error}") 
        result = {'errorType': 'error',  'errorMessage': 'Failed in Eriting to RAW S3'}
        raise 
    
def lambda_handler(event, context):
    
    gpg_private_key = event.get('gpg_private_key') 
    gpg_pass_phrase_key = event.get('gpg_pass_phrase_key') 
    acbs_table = event.get('acbs_table') 
    ing_bucket_name= event.get('ing_bucket_name')
    ing_file_key= event.get('ing_file_key')
    raw_bucket_name= event.get('raw_bucket_name')
    raw_file_key= event.get('raw_file_key')
    ssm_parameter_bus_date_name=event.get('ssm_parameter_bus_date_name')
    """
    ############### 
    print("def_get_gpg_keys")
    gpg_secret_private_key=f"acbs/eod_files/gpg_private_key_p"
    gpg_secret_pass_phrase_key=f"acbs/eod_files/gpg_pass_pharse_p"
    session = boto3.Session()
    secretsmanager_client=boto3.client('secretsmanager',region_name= "us-west-2")
    
    try:
        get_secret_value_response_key = secretsmanager_client.get_secret_value(SecretId=gpg_secret_private_key)
    except ClientError as err:
        logger.critical('Error reading the Secrets gpg key')
    else:
        gpg_private_key = get_secret_value_response_key['SecretString']
        
    try:
        get_secret_value_response_pp = secretsmanager_client.get_secret_value(SecretId=gpg_secret_pass_phrase_key)
    except ClientError as err:
        logger.critical('Error reading the Secrets key gpg pp ')
    else:
        gpg_pass_phrase_key=get_secret_value_response_pp['SecretString']
    
    gpg_private_key = gpg_private_key
    gpg_pass_phrase_key = gpg_pass_phrase_key
    
    ##############
    """
    print(f"Decrypting the file --> {acbs_table}")
    #Read the Encrypted file from ING Bucket
    sys_file_content=def_read_encrypted_file(ing_bucket_name,ing_file_key,acbs_table,s3_client)
    #Decrypt
    sys_file_content_decrypted=def_decrypt_file(sys_file_content,gpg_private_key,gpg_pass_phrase_key)
    
    #REad the SYDC file, get the Business date and Update SSM.
    if "SYDC" in acbs_table:
        bus_date_date=def_fetch_Business_date_update_ssm(ssm_parameter_bus_date_name,sys_file_content_decrypted,ssm_client)
    else:
        #Get Business Date from SSM.
        bus_date_date=def_get_business_date_ssm(ssm_parameter_bus_date_name,ssm_client)

    #Move the decrypted file to RAW. 
    def_move_data_2_raw(sys_file_content_decrypted,raw_bucket_name,raw_file_key,bus_date_date,acbs_table,s3_client)
    print('The sucessfully moved to the temp Folder in RAW')
    result = {'errorType': 'success',  'errorMessage': 'Lambda Processing complete'}
    return result
