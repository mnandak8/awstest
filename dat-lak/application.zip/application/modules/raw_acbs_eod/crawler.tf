


resource "aws_glue_crawler" "lease_eod_glue_crawler" {
  for_each    = toset(var.lending-acb_table_names)
  database_name = "lending_acbs_raw_dataasset_db"
  name = "lending_acbs_raw_dataasset_db_${each.key}" 
  role = local.glue_role_arn
  #tags = var.lease-eod-glue-job-tags
  s3_target {
    path = "s3://${local.acbs_raw_s3_bucket}/acbs_eod/${each.key}"
  }
  recrawl_policy {
    recrawl_behavior = "CRAWL_NEW_FOLDERS_ONLY"
  }
  schema_change_policy {
    delete_behavior = "LOG"
    update_behavior = "LOG"
  }
}
