################################
resource "aws_secretsmanager_secret" "acbs_gpg_public_key" {
  name        = local.acbs_gpg_public_key
  description = "PGP Private Key for the ACBS decryption"
  tags        = var.tags
  kms_key_id   =aws_kms_key.kms_key_acbs_eod.arn
}
resource "aws_secretsmanager_secret_policy" "secret_read_policy_acbs_gpg_public_key" {
  secret_arn = aws_secretsmanager_secret.acbs_gpg_public_key.arn
  policy     = <<EOF
{
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Principal" : {
      "Service" : "glue.amazonaws.com"
    },
    "Action" : "secretsmanager:*",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  }, {
    "Effect" : "Allow",
    "Principal" : {
      "AWS" : "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
    },
    "Action" : "secretsmanager:GetSecretValue",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  } ]
}
EOF
}
#################################
################################
resource "aws_secretsmanager_secret" "acbs_gpg_pass_pharse" {
  name        = local.acbs_gpg_pass_pharse
  description = "PGP Pass Pharse for the ACBS decryption"
  tags        = var.tags
  kms_key_id   =aws_kms_key.kms_key_acbs_eod.arn
}
resource "aws_secretsmanager_secret_policy" "secret_read_policy_acbs_gpg_pass_pharse" {
  secret_arn = aws_secretsmanager_secret.acbs_gpg_pass_pharse.arn
  policy     = <<EOF
{
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Principal" : {
      "Service" : "glue.amazonaws.com"
    },
    "Action" : "secretsmanager:*",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  }, {
    "Effect" : "Allow",
    "Principal" : {
      "AWS" : "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
    },
    "Action" : "secretsmanager:GetSecretValue",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  } ]
}
EOF
}
#################################
################################
resource "aws_secretsmanager_secret" "acbs_gpg_private_key" {
  name        = local.acbs_gpg_private_key
  description = "PGP Private Key for the ACBS decryption"
  tags        = var.tags
  kms_key_id   =aws_kms_key.kms_key_acbs_eod.arn
}
resource "aws_secretsmanager_secret_policy" "secret_read_policy_acbs_gpg_private_key" {
  secret_arn = aws_secretsmanager_secret.acbs_gpg_private_key.arn
  policy     = <<EOF
{
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Principal" : {
      "Service" : "glue.amazonaws.com"
    },
    "Action" : "secretsmanager:*",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  }, {
    "Effect" : "Allow",
    "Principal" : {
      "AWS" : "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
    },
    "Action" : "secretsmanager:GetSecretValue",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  } ]
}
EOF
}
#################################
