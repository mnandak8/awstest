resource "aws_kms_key" "kms_key_acbs_eod" {
  description             = "kms key for ACBS EOD"
  enable_key_rotation     = true
  tags        = var.tags
  deletion_window_in_days = 7
  key_usage               = "ENCRYPT_DECRYPT"
  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Id" : "key-consolepolicy-3",
      "Statement" : [
        {
          "Sid" : "EnableIAMUserPermissions",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:root"
          },
          "Action" : "kms:*",
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "events.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt",
            "kms:GenerateDataKey",
            "kms:Decrypt"
          ],
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "lambda.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt",
            "kms:GenerateDataKey",
            "kms:Decrypt"
          ],
          "Resource" : "*"
        },
        {
          "Sid" : "AllowAccessForKeyAdministrators",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
          },
          "Action" : [
            "kms:Create*",
            "kms:Describe*",
            "kms:Enable*",
            "kms:List*",
            "kms:Put*",
            "kms:Update*",
            "kms:Revoke*",
            "kms:Disable*",
            "kms:Get*",
            "kms:Delete*",
            "kms:TagResource",
            "kms:UntagResource",
            "kms:ScheduleKeyDeletion",
            "kms:CancelKeyDeletion"
          ],
          "Resource" : "*"
        },
        {
          "Sid" : "AllowAccessForKeyAdministrators_lambda",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-lambda-role"
          },
          "Action" : [
            "kms:Create*",
            "kms:Describe*",
            "kms:Enable*",
            "kms:List*",
            "kms:Put*",
            "kms:Update*",
            "kms:Revoke*",
            "kms:Disable*",
            "kms:Get*",
            "kms:Delete*",
            "kms:TagResource",
            "kms:UntagResource",
            "kms:ScheduleKeyDeletion",
            "kms:CancelKeyDeletion"
          ],
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "logs.us-west-2.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt*",
            "kms:Decrypt*",
            "kms:ReEncrypt*",
            "kms:GenerateDataKey*",
            "kms:Describe*"
          ],
          "Resource" : "*",
          "Condition" : {
            "ArnLike" : {
              "kms:EncryptionContext:aws:logs:arn" : "arn:aws:logs:us-west-2:${local.account_id}:log-group*"
            }
          }
        }
      ]
    }
  )
}


resource "aws_kms_alias" "kms_key_acbs_eod_add_kms_key_alis" {
  name          = "alias/cust-kms-key-acbs-eod-raw"
  target_key_id = aws_kms_key.kms_key_acbs_eod.key_id
}
