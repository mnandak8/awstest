
locals {
  leasewave_glue_role              = "cobank-${var.environment}-leasewave-glue-role"
  leasewave_raw_s3_bucket          = "${var.environment}-acb-dl-dat-lak-raw-lease-leasewave-asset"
}

resource "aws_glue_crawler" "lease_eod_glue_crawler" {
  for_each    = toset(var.lease_eod_table_names)
  database_name = var.lease-eod-glue-catalog-db-name
  name = "raw-db-crawler-lease-eod-dbo-${each.key}" #var.glue-crawler-name
  table_prefix           = var.lease-eod-table-prefix 
  role = local.leasewave_glue_role
  tags = var.lease-eod-glue-job-tags
  s3_target {
    path = "s3://${local.leasewave_raw_s3_bucket}/${var.lease-eod-glue-crawler-s3-bucket-key}/${each.key}"
    sample_size         = 3
    exclusions = var.lease-eod-crawler-exclusions
  }

  schema_change_policy {
    delete_behavior = "LOG"
    update_behavior = "LOG"
  }

  recrawl_policy {
    recrawl_behavior = "CRAWL_NEW_FOLDERS_ONLY"
  }
  configuration = jsonencode(
    {
      Version = 1.0,
      CrawlerOutput = {
        Partitions = {AddOrUpdateBehavior = "InheritFromTable"}
      },
      Grouping = {TableLevelConfiguration = 4}
      
    }
  )
  security_configuration = var.lease-eod-glue-security-configuration-name
}