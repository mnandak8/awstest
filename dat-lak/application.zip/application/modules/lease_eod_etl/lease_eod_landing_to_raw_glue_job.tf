# Upload Glue script file to tooling
resource "aws_s3_object" "lease-eod-glue-script" {
  bucket = "${var.etl-script-s3-bucket}"
  key    = "deploy/lease_eod_landingtoraw_extract.py"
  source = "${path.module}/lease_eod_landingtoraw_extract.py"
  etag   = filemd5("${path.module}/lease_eod_landingtoraw_extract.py")
}

/*
resource "aws_kms_alias" "KMS_cloudwatch_acbs" {
  name          = "alias/key-cloudwatch-group_acbs"
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}
*/

/* this is just example of how to derive role arn
  role_arn   = "arn:aws:iam::${local.account_id}:role/${local.lw_dms_role}" 
*/

data "aws_iam_role" "leasewave-glue-role" {
  name = "cobank-${var.environment}-leasewave-glue-role"
}

resource "aws_glue_job" "lease_landing_to_raw_extract" {
  name        = "lease_eod_landingtoraw_extract"
  role_arn    = data.aws_iam_role.leasewave-glue-role.arn
  execution_property {
    max_concurrent_runs = 30
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.lease-eod-glue-script.bucket}/${aws_s3_object.lease-eod-glue-script.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : ""
    "--objectname": ""
    "--datasource": "s3://${var.environment}-acb-dat-ing-leasewave-asset/"
    "--enable-glue-datacatalog": "true"
    "--groupname": "lease_eod"
    "--enable-continous-log-filter": "true"
    "--enable-metrics": "false"
    "--extra-py-files": "s3://${var.etl-script-s3-bucket}/deploy/corelibs-0.1-py3-none-any.whl"
    "--layer": "raw"
    "--date2process": "2025-01-01"
    "--configfile": "etl.conf"
    "--enable-auto-scaling" = true
    "--enable-job-insights" = true
    "--env": "${var.environment}"
    "--datasink": "s3://${var.environment}-acb-dl-dat-lak-raw-lease-leasewave-asset/"
    "--extra-files": "s3://${var.etl-script-s3-bucket}/deploy/etl.conf"
  }

  glue_version      = "4.0"
  worker_type       = "G.2X"
  number_of_workers = "10"

}