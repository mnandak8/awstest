import sys
from datetime import datetime
from datetime import timezone
from pyspark.sql.functions import lit
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from awsglue.context import GlueContext
#from awsglue.transforms import *
from pyspark.context import SparkContext
import logging

from corelibs.utils.config_util import ConfigUtil
from corelibs.utils.s3_util import S3Util
from corelibs.data.source.s3_src import S3Source
from corelibs.data.sink.s3_snk import S3Sink

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

def main():
    args = getResolvedOptions(sys.argv, ['JOB_NAME', 'datasource', 'datasink', 'layer', 'date2process', 'groupname', 'objectname','configfile','env'])

    date_path = f"{args.get('date2process')}"
    data_source = args.get('datasource')
    grp_name = args.get('groupname')
    job_name = f"{grp_name}_{args.get('objectname')}"

    def config():
        cfg_util = ConfigUtil()
        return cfg_util.config()
    conf = config()
    objects = conf[grp_name]['objects']
    obj_cfg = list(obj for obj in objects if obj['name'] == args.get('objectname'))[0]

    latest = S3Util.getLatest(bucket_name=data_source[5:].rstrip('/'), prefix=obj_cfg[args.get('layer')]['source_path']%date_path)
    if latest is None:
        self.log.error(f'{job_name} ERROR : No data found for {date_path}')
        return None
    latest_path = f"{data_source}{latest[:latest.rfind('/')+1]}"
    logger.info(f'For job_name: {job_name} Datasource: {latest_path}')
    
    source = S3Source(latest_path, job_name, logger)
    source_df = source.read(spark)
    
    if(source_df.isEmpty()):
        self.log.warn(f'{job_name} ERROR : The dataframe is empty. Please validate the source path!')
        return
    parti_dt = date_path.split("/")
    source_ext_df = source_df.withColumn("raw_utc", lit(f'{datetime.now(timezone.utc)}'))\
        .withColumn("year", lit(parti_dt[0]))\
        .withColumn("month",lit(parti_dt[1]))\
        .withColumn("day",lit(parti_dt[2]))
    
    source_ext_df.printSchema()
    
    sink_path = f"{args.get('datasink')}{obj_cfg[args.get('layer')]['sink_path']}"
    #sink = S3Sink(sink_path, job_name, logger)
    
    if(not source_ext_df.isEmpty()):
        source_ext_df.write\
        .partitionBy("year", "month", "day") \
        .mode("overwrite") \
        .parquet(path=sink_path)
        #sink.write(source_ext_df)
        logger.info(f'{job_name} Finished writing data to s3 sink path {sink_path}')
    else:
        logger.info(f'{job_name} ERROR : There is no data to write to s3 sink path {sink_path}, skipping..........')
    pass

if __name__ == '__main__':
    main()