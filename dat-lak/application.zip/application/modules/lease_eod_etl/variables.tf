
# lw Glue Crawler
variable "environment" {
  type = string
  description = "specify the environment to deploy the resources"
}

variable "lease-eod-glue-crawler-s3-bucket-key" {
  type = string
  nullable = false
}
variable "lease-eod-crawler-exclusions" {
  type = list(string)
}

variable "lease-eod-table-prefix" {
  type = string
}

variable "lease_eod_table_names" {
  type    = list(string)
}

variable "lease-eod-glue-catalog-db-name" {
  type = string
}

variable "lease-eod-glue-job-tags" {
  type = map(string)
}

variable "lease-eod-glue-security-configuration-name" {
  type = string
}

variable  "etl-script-s3-bucket" {
  type = string
}