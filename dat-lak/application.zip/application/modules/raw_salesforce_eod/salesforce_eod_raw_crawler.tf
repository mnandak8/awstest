
resource "aws_glue_crawler" "salesforce_eod_glue_crawler" {
  for_each    = toset(var.party_salesforce_table_names)
  tags        =var.splunk_tags
  database_name = "party_salesforce_raw_dataasset_db" 
  name = "party_salesforce_raw_dataasset_db_${each.key}" 
  role = local.glue_role_arn
  s3_target {
    path = "s3://${local.salesforce_raw_s3_bucket}/salesforce_eod/${each.key}"
  }
  recrawl_policy {
    recrawl_behavior = "CRAWL_NEW_FOLDERS_ONLY"
  }
  schema_change_policy {
    delete_behavior = "LOG"
    update_behavior = "LOG"
  }
}


