# Upload Glue script file to tooling
resource "aws_s3_object" "saleforce-raw-eod-glue-script" {
  bucket = "${var.etl-script-s3-bucket}"
  key    = "deploy/glue_party_salesforce_eod_landing2raw_extract.py"
  source = "${path.module}/src/glue_party_salesforce_eod_landing2raw_extract.py"
  etag   = filemd5("${path.module}/src/glue_party_salesforce_eod_landing2raw_extract.py")
   
}


resource "aws_glue_job" "saleforce_landing_to_raw" {
  name        = "party_salesforce_eod_landing2raw"
  role_arn    = local.glue_role_arn
  execution_property {
    max_concurrent_runs = 30
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.saleforce-raw-eod-glue-script.bucket}/${aws_s3_object.saleforce-raw-eod-glue-script.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--extra-py-files": "s3://${var.etl-script-s3-bucket}/deploy/corelibs-0.1-py3-none-any.whl"
    "--extra-files": "s3://${var.etl-script-s3-bucket}/deploy/etl.conf"
  }

  glue_version      = "5.0"
  worker_type       = "G.1X"
  number_of_workers = "10"

}

# Upload Glue script file to tooling
resource "aws_s3_object" "saleforce-raw-eod-glue-script-load-hist" {
  bucket = "${var.etl-script-s3-bucket}"
  key    = "deploy/glue_party_salesforce_eod_landing2raw_load_hist.py"
  source = "${path.module}/src/glue_party_salesforce_eod_landing2raw_load_hist.py"
  etag   = filemd5("${path.module}/src/glue_party_salesforce_eod_landing2raw_load_hist.py")
   
}

##########hist###############

resource "aws_glue_job" "saleforce_landing_to_raw_load_hist" {
  name        = "party_salesforce_eod_landing2raw_load_hist"
  role_arn    = local.glue_role_arn
  execution_property {
    max_concurrent_runs = 30
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.saleforce-raw-eod-glue-script.bucket}/${aws_s3_object.saleforce-raw-eod-glue-script-load-hist.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--acct_id": "${var.ing_account_id}"
    "--env": "${var.environment}"
  }

  glue_version      = "5.0"
  worker_type       = "G.1X"
  number_of_workers = "5"

}
