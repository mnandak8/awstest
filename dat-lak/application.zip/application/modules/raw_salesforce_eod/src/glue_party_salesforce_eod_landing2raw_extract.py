import sys
import boto3
import botocore.exceptions
import pandas as pd
import logging
import json
import tempfile
import os
from datetime import datetime
from datetime import timezone
from pyspark.sql.functions import lit
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from awsglue.context import GlueContext
from awsglue.transforms import *
from pyspark.context import SparkContext
from botocore.exceptions import ClientError
from pyspark.sql.functions import col, regexp_replace, year, month, dayofmonth, to_date, lit

from awsglue.dynamicframe import DynamicFrame

from corelibs.utils.config_util import ConfigUtil
from corelibs.utils.s3_util import S3Util
from corelibs.data.source.s3_src import S3Source
from corelibs.data.sink.s3_snk import S3Sink

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")


args = getResolvedOptions(sys.argv, ['date2process','objectname','env'])
env = args['env']
objectname= args['objectname']
business_date = args['date2process']

grp_name = "party_salesforce_eod"
job_name = "party_salesforce_eod_landing2raw"
ing_bucket_name=f"{env}-acb-dat-ing-sfdc-asset"
ing_bucket_key=f"salesforce/EOD/{objectname}_sfdc_to_ing_EOD/"
raw_bucket_name= f"{env}-acb-dl-dat-lak-raw-party-salesforce-asset"
raw_bucket_key="salesforce_eod"


def def_cleanup_partition_folder(year_value,month_value,day_value,raw_bucket_name,raw_bucket_key,objectname):
    print('def_cleanup_partition_folder')
    x=0
    s3_client=boto3.client('s3')
    path = f"{raw_bucket_key}/{objectname}/year={year_value}/month={month_value}/day={day_value}/"
    response = s3_client.list_objects_v2(Bucket=raw_bucket_name, Prefix=path)
    if 'Contents' in response:
        object_keys = [obj['Key'] for obj in response['Contents']]
        for key in object_keys:
            print(f"Deleting: {key}")
            x=x+1
            try:
                s3_client.delete_object(Bucket=raw_bucket_name, Key=key)
            except Exception as error:
                print(f"Error While Emptying the Patitions {error}")
                sys.exit(30)
    return(x)
    
def def_copy_ing_2_raw(year_value,month_value,day_value,latest_path,raw_bucket_name,raw_bucket_key,objectname):
    print("def_copy_ing_2_raw")
    try:
        df_data = spark.read.parquet(latest_path)
    except Exception as error:
        print(f"error In fetching the Data from Landing {error}")
        sys.exit(40)
    print(f"record count --> {df_data.count()}")
    
    df_data_part = df_data.withColumn("year", lit(year_value)).withColumn("month", lit(month_value)).withColumn("day", lit(day_value))
    
    dynamic_frame = DynamicFrame.fromDF(df_data_part, glueContext, "dynamic_frame")
    raw_output_path=f"s3://{raw_bucket_name}/{raw_bucket_key}/{objectname}"
    try:
        glueContext.write_dynamic_frame.from_options(dynamic_frame,connection_type="s3",connection_options={"path": raw_output_path, "partitionKeys": ["year", "month", "day"]},format="parquet")
    except Exception as error:
        print(f"Error While Wrirting into RAW {error}")
        sys.exit(20)
    
def def_process_business_date(business_date):
    bus_date_date = datetime.strptime(business_date, '%Y%m%d')
    year_value = bus_date_date.year
    month_value = bus_date_date.month
    day_value = bus_date_date.day
    return(year_value,month_value,day_value)
    
if __name__ == '__main__':
    print(f"Prcessing for the Object --> {objectname}")
    
    latest_path = S3Util.getLatest(bucket_name=ing_bucket_name, prefix=ing_bucket_key)
    if latest_path is None:
        print(f"Cant get the Latest Path for {ing_bucket_name}/{ing_bucket_key}")
        sys.exit(10)
    latest_path=f"s3://{ing_bucket_name}/{latest_path}"
    latest_path = latest_path.rsplit('/', 1)[0] + "/"
    print(f'For job_name: {job_name} Datasource: {latest_path}')
    
    year_value,month_value,day_value=def_process_business_date(business_date)
    
    def_cleanup_partition_folder(year_value,month_value,day_value,raw_bucket_name,raw_bucket_key,objectname)
    
    def_copy_ing_2_raw(year_value,month_value,day_value,latest_path,raw_bucket_name,raw_bucket_key,objectname)
    
    
    
