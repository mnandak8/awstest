
import sys
import re
from datetime import datetime,timedelta
import boto3
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import botocore.exceptions
from pyspark.sql.functions import col, regexp_replace, year, month, dayofmonth, to_date, lit
from awsglue.dynamicframe import DynamicFrame

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)
job.commit()


args = getResolvedOptions(sys.argv, ['acct_id','env'])
env = args['env']
acct_id= args['acct_id']
sfdc_object=""
date=""

sfdc_mapping = {
    'recordtype': 'RecordType',
    'contact': 'Contact',
    'llc_bi_loan_c': 'LLC_BI__Loan__c',
    'account': 'Account',
    'account_address_c': 'Account_Address__c',
    'account_contact_relation': 'AccountContactRelation'
}

sfdc_folder_mapping = {
    'recordtype': 'recordtype',
    'contact': 'contact',
    'llc_bi_loan_c': 'llcBiLoanC',
    'account': 'account',
    'account_address_c': 'accountAddress',
    'account_contact_relation': 'accountContactRelation'
}


#ing_bucket_name=f"cobank-dl-{acct_id}-us-west-2-landing-{env}"
#ing_bucket_key=f"salesforce/{sfdc_object}/salesforce_to_landing_{sfdc_object}/{date}/"
raw_bucket_name= f"{env}-acb-dl-dat-lak-raw-party-salesforce-asset"
raw_bucket_key="salesforce_eod"


def def_copy_ing_2_raw(year_value,month_value,day_value,latest_path,raw_bucket_name,raw_bucket_key,objectname):
    try:
        df_data = spark.read.parquet(latest_path)
    except Exception as error:
        print(f"error In fetching the Data from Landing {error}")
        sys.exit(40)
    
    df_data_part = df_data.withColumn("year", lit(year_value)).withColumn("month", lit(month_value)).withColumn("day", lit(day_value))
    
    dynamic_frame = DynamicFrame.fromDF(df_data_part, glueContext, "dynamic_frame")
    raw_output_path=f"s3://{raw_bucket_name}/{raw_bucket_key}/{objectname}"
    try:
        glueContext.write_dynamic_frame.from_options(dynamic_frame,connection_type="s3",connection_options={"path": raw_output_path, "partitionKeys": ["year", "month", "day"]},format="parquet")
    except Exception as error:
        sys.exit(20)

def def_cleanup_partition_folder(year_value,month_value,day_value,raw_bucket_name,raw_bucket_key,objectname):
    
    
    s3_client=boto3.client('s3')
    path = f"{raw_bucket_key}/{objectname}/year={year_value}/month={month_value}/day={day_value}/"
    response = s3_client.list_objects_v2(Bucket=raw_bucket_name, Prefix=path)
    if 'Contents' in response:
        object_keys = [obj['Key'] for obj in response['Contents']]
        for key in object_keys:
            
            try:
                s3_client.delete_object(Bucket=raw_bucket_name, Key=key)
            except Exception as error:
                print(f"Error While Emptying the Patitions {error}")
                sys.exit(30)
                
def get_latest_subfolder(acct_id,env,date_str,sfdc_object,s3,folder_sfdc_object):
    date=date_str
    ing_bucket_name=f"cobank-dl-{acct_id}-us-west-2-landing-{env}"
    ing_bucket_key=f"salesforce/{sfdc_object}/salesforce_to_landing_{folder_sfdc_object}/{date}/"
    subfolders = []
    latest_subfolder=""
    bucket_latest_subfolder=""
    response = s3.list_objects_v2(Bucket=ing_bucket_name, Prefix=ing_bucket_key, Delimiter='/')
    pattern = re.compile(r'.*-(\d{4}-\d{2}-\d{2}T(\d{2}):(\d{2}):(\d{2}))/$')
    for obj in response.get('CommonPrefixes', []):
        folder_name = obj['Prefix']
        match = pattern.match(folder_name)
        if match:
            full_timestamp = match.group(1)  # Full timestamp (YYYY-MM-DDTHH:MM:SS)
            hour = int(match.group(2))  # Extract hour (HH)
            
            if hour == 4:  # Check for 04:00:00 AM
                timestamp = datetime.strptime(full_timestamp, "%Y-%m-%dT%H:%M:%S")
                subfolders.append((folder_name, timestamp))

    if subfolders:
        latest_subfolder = max(subfolders, key=lambda x: x[1])[0]
        bucket_latest_subfolder=f"s3://{ing_bucket_name}/{latest_subfolder}/"
        
    return(subfolders,bucket_latest_subfolder)
    

if __name__ == '__main__':
    subfolders = []
    s3 = boto3.client('s3')
    sfdc_object=['contact', 'recordtype','llc_bi_loan_c','account','account_contact_relation','account_address_c']
    #sfdc_object=['recordtype']
    year = ['2025']
    month = ['1', '2']
    subfolders = []
    bucket_latest_subfolder=""
    for obj in sfdc_object:
        print(f"Now Processing for {obj}")
        for y in year:
            for m in month:
                if m == '1':
                    days = range(1, 32)  # 1 to 31
                elif m == '2':
                    days = range(1, 27)  # 1 to 26
                else:
                    days = []
                for d in days:
                    current_date = datetime(int(y), int(m), d)
                    previous_date = current_date - timedelta(days=1)  # Get previous day
                    date_str = current_date.strftime("%Y/%m/%d")
                    prev_date_str = previous_date.strftime("%Y/%m/%d")
                    prev_year = previous_date.year
                    prev_month = previous_date.month
                    prev_day = previous_date.day
                    sfdc_object=obj
                    objectname=""
                    folder_sfdc_object=""
                    objectname = sfdc_mapping.get(sfdc_object, 'Unknown')  
                    folder_sfdc_object=sfdc_folder_mapping.get(sfdc_object, 'Unknown')  
                    subfolders,bucket_latest_subfolder=get_latest_subfolder(acct_id,env,date_str,sfdc_object,s3,folder_sfdc_object)
                    if subfolders:
                        def_cleanup_partition_folder(prev_year,prev_month,prev_day,raw_bucket_name,raw_bucket_key,objectname)
                        def_copy_ing_2_raw(prev_year,prev_month,prev_day,bucket_latest_subfolder,raw_bucket_name,raw_bucket_key,objectname)

    
