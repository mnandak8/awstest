import pytest
import json
import unittest
import boto3
import sys
import os
import pandas as pd
import difflib
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from test.testdata import input_business_date
from test.testdata import out_business_date_year, out_business_date_month, out_business_date_day

#def_cleanup_partition_folder(year_value,month_value,day_value,raw_bucket_name,raw_bucket_key,objectname)

with patch('awsglue.context.GlueContext', MagicMock()), \
     patch('sys.argv', ['script_name', '--date2process', input_business_date, '--objectname', 'test_objectname', '--env', 'test']):
     from src.glue_party_salesforce_eod_landing2raw_extract import def_process_business_date
     from src.glue_party_salesforce_eod_landing2raw_extract import def_cleanup_partition_folder
     from src.glue_party_salesforce_eod_landing2raw_extract import def_copy_ing_2_raw

  
class TestsfdcEODRaw(unittest.TestCase):

    def test_input_business_date_case1(self):
        year,month,day=def_process_business_date(input_business_date)
        assert out_business_date_year == year
        assert out_business_date_month == month
        assert out_business_date_day == day


    @patch('boto3.client')
    def test_cleanup_partition_folder(self, mock_boto_client):
        number_files = 5
        year = '2025'
        month = '02'
        day = '01'
        mock_s3 = MagicMock()
        mock_boto_client.return_value = mock_s3
        
        mock_s3.list_objects_v2.return_value = {
            'Contents': [{'Key': f'{year}/{month}/{day}/test/file_{i}.txt'} for i in range(number_files)]
        }

        result = def_cleanup_partition_folder(year_value = year,month_value = month,day_value = day ,raw_bucket_name = 'test_bucket',raw_bucket_key ='test_key',objectname = 'test')
        self.assertEqual(result, number_files)

        mock_s3.list_objects_v2.assert_called_once_with(Bucket='test_bucket', Prefix=f'test_key/test/year={year}/month={month}/day={day}/')
        
        for i in range(number_files):
            mock_s3.delete_object.assert_any_call(Bucket='test_bucket', Key=f'{year}/{month}/{day}/test/file_{i}.txt')
        self.assertEqual(mock_s3.delete_object.call_count, number_files)
    
    @patch('src.glue_party_salesforce_eod_landing2raw_extract.glueContext')
    @patch('src.glue_party_salesforce_eod_landing2raw_extract.spark')
    def test_copy_ing_2_raw(self, mock_spark, mock_glue_context):
        mock_spark.read.parquet.return_value = MagicMock(count=MagicMock(return_value=100))
        mock_glue_context.write_dynamic_frame.from_options.return_value = MagicMock()
        def_copy_ing_2_raw(2025, 2, 19, 's3://path/to/latest', 'raw-bucket', 'raw-key', 'objectname')
        mock_spark.read.parquet.assert_called_once_with('s3://path/to/latest')
        self.assertEqual(mock_spark.read.parquet.return_value.count(), 100)
        mock_glue_context.write_dynamic_frame.from_options.assert_called_once()


    @patch('src.glue_party_salesforce_eod_landing2raw_extract.spark')
    def test_copy_ing_2_raw_fetch_exception(self, mock_spark):
        mock_spark.read.parquet.side_effect = Exception("Error in fetching the data from landing")
        with self.assertRaises(SystemExit) as cm:
            def_copy_ing_2_raw(2025, 2, 19, 's3://path/to/latest', 'raw-bucket', 'raw-key', 'objectname')
        
        self.assertEqual(cm.exception.code, 40)
    
    
    @patch('src.glue_party_salesforce_eod_landing2raw_extract.glueContext')
    @patch('src.glue_party_salesforce_eod_landing2raw_extract.spark')    
    def test_copy_ing_2_raw_write_exception(self, mock_spark, mock_glue_context):
        mock_spark.read.parquet.return_value = MagicMock(count=MagicMock(return_value=100))
        mock_glue_context.write_dynamic_frame.from_options.side_effect = Exception("Error while writing into RAW")
        with self.assertRaises(SystemExit) as cm:
            def_copy_ing_2_raw(2025, 2, 19, 's3://path/to/latest', 'raw-bucket', 'raw-key', 'objectname')
        
        self.assertEqual(cm.exception.code, 20)

    
           
if __name__ == '__main__': 
    unittest.main()
    

    