variable "environment" {type = string}
variable "party_salesforce_table_names" {type    = list(string)}
variable  "etl-script-s3-bucket" {type = string}
variable "splunk_tags"{  type= map(string) }
variable "tags" {type = map(string)}
variable  "ing_account_id" {type = string}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}


locals {
  account_id                        = data.aws_caller_identity.current.account_id
  region_name                       = data.aws_region.current.name
  glue_role_arn                     = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-glue-role"
  salesforce_raw_s3_bucket          = "${var.environment}-acb-dl-dat-lak-raw-party-salesforce-asset"
  salesforce_landing_s3_bucket      = "${var.environment}-acb-dat-ing-sfdc-asset"
  
}

resource "aws_s3_object" "sfdc_eod_raw_dags" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/sfdc_eod/airflow_SFDC_EOD_Ingestion_2_raw.py"
  source = "${path.module}/airflow/airflow_SFDC_EOD_Ingestion_2_raw.py"
  source_hash = filemd5("${path.module}/airflow/airflow_SFDC_EOD_Ingestion_2_raw.py")
}


resource "aws_s3_object" "sfdc_eod_raw_dags_rus" {
  bucket =  "cobank-dl-${local.account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/raw/sfdc_eod/airflow_SFDC_EOD_Ingestion_2_raw_rus.py"
  source = "${path.module}/airflow/airflow_SFDC_EOD_Ingestion_2_raw_rus.py"
  source_hash = filemd5("${path.module}/airflow/airflow_SFDC_EOD_Ingestion_2_raw_rus.py")
}
