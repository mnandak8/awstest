#KMS for Jobs
resource "aws_kms_key" "KMS_Glue" {
  description = "KMS key glue job"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}

resource "aws_kms_alias" "KMS_Glue" {
  name          = "alias/key-glue-job"
  target_key_id = aws_kms_key.KMS_Glue.key_id
}

resource "aws_glue_security_configuration" "security_configuration" {
    depends_on = [ aws_kms_alias.KMS_Glue ]
    name = var.name

    encryption_configuration {
        cloudwatch_encryption {
            cloudwatch_encryption_mode    = "SSE-KMS"
            kms_key_arn                   = aws_kms_key.KMS_Glue.arn
        }
        job_bookmarks_encryption {
            job_bookmarks_encryption_mode = "CSE-KMS"
            kms_key_arn                   = aws_kms_key.KMS_Glue.arn
        }
        s3_encryption {
            s3_encryption_mode            = "SSE-KMS"
            kms_key_arn                   = aws_kms_key.KMS_Glue.arn
            }
  }
}