output "name" {
  description = "The name of the glue security configuration"
  value       = aws_glue_security_configuration.security_configuration.name
}
