moved {
  from = module.audit-private-api.aws_kms_key.DynamoDB_key
  to   = module.audit-private-api.module.kms_dynamoDB.aws_kms_key.kms
}

moved {
  from = module.audit-private-api.aws_kms_alias.DynamoDB_key
  to   = module.audit-private-api.module.kms_dynamoDB.aws_kms_alias.DynamoDB_key
}


data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
  s3_bucket_prefixes = ["transform-lending-asset","raw-lending-acbs-asset","raw-party-salesforce-asset","transform-party-asset"]
  s3_log_bucket_prefix = "common-asset-logs"
}


# Create s3 bucket for glue etl code deployment
module "glue-etl-script" {
  source            = "./modules/aws_services/s3"
  s3-bucket         = var.etl-script-s3-bucket
  s3-object-path    = var.etl-script-s3-path
  create-s3-object  = var.create-etl-script-s3-path
  s3-bucket-tags    = var.etl-script-s3-bucket-tags
  target_log_bucket = var.default_settings.target_log_bucket
}

module "raws3buckets" { 
  source                = "./modules/aws_services/raw"
  ing_account_id        = var.ing_account_id
  tags                  = var.tags
  environment           = var.environment
  bucket_key_enabled    = var.bucket_key_enabled
  storage_class         = var.storage_class
  buckets_transition    = var.buckets_transition
  buckets_expiration    = var.buckets_expiration  
  terra_factory_aws_id  = var.terra_factory_aws_id
  governance_account_id = var.governance_account_id
}

module "glue_security"{
  source = "./modules/glue_security"
  name   = "glue_security_configuration-${var.environment}"
  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name
}

module "lending_asset"{
  depends_on = [ module.logging_bucket ]
  for_each = toset(local.s3_bucket_prefixes)
  source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241212.66"
  environment               = var.environment
  lake_type                 = "dl"
  encryption_type           = "sse-kms"
  expiration_days           = 2555
  ia_transition_days        = 365
  governance_account_id     = var.governance_account_id
  log_bucket_name           = "${var.environment}-acb-dat-lak-${local.s3_log_bucket_prefix}"
  access_service_user_names = ["glue"]
  terra_factory_aws_id      = var.terra_factory_aws_id
  resource_suffix           = each.value
  
}

module "logging_bucket" {
  source          = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241212.66"
  environment     = var.environment
  terra_factory_aws_id = var.terra_factory_aws_id
  resource_suffix = local.s3_log_bucket_prefix
  expiration_days = 7
  include_logging = false
}

#Jobs
module "all" {
    depends_on = [ module.glue-etl-script, module.glue_security ]
    for_each = var.jobs
    source = "./modules/etl"
    glue-job-name = coalesce(each.value.job_name, each.key)
    create-glue-datacatalog     = coalesce(each.value.create-glue-datacatalog, var.default_settings.create-glue-datacatalog)
    glue-catalog-db-name        = each.value.catalog_db_name
    create-crawler              = coalesce(each.value.create-glue-crawler, var.default_settings.create-glue-crawler)
    glue-crawler-name           = each.value.crawler_name
    table-prefix                = coalesce(each.value.glue-table-prefix, var.default_settings.glue-table-prefix)
    glue-crawler-s3-bucket      = each.value.sink_bucket
    glue-crawler-s3-bucket-key  = each.value.crawler-s3-bucket-key
    glue-data-source-bucket     = each.value.source_bucket
    glue-data-sink-bucket       = each.value.sink_bucket
    etl-layer-name              = each.value.layer
    object-to-process           = coalesce(each.value.objectname, var.default_settings.objectname)
    groupname-to-process        = each.value.groupname
    environment                 = var.default_settings.environment
    glue-job-tags               = var.default_settings.tags
    glue-job-role               = var.default_settings.job_role_arn
    glue-job-timeout            = var.default_settings.job_timeout
    glue-job-max-retries        = var.default_settings.max_retries
    enable-metrics              = var.default_settings.enable-metrics
    enable-spark-ui             = var.default_settings.enable-spark-ui
    spark-logs-path             = "${var.default_settings.spark-logs-path}${each.key}/"
    extra-files                 = "s3://${var.etl-script-s3-bucket}/deploy/etl.conf"  
    extra-py-files              = "s3://${var.etl-script-s3-bucket}/deploy/${var.default_settings.etl-artfact-file}"
    etl-script-location         = "s3://${var.etl-script-s3-bucket}/deploy/driver.py"
    crawler-exclusions          = var.default_settings.crawler_exclusions
    enable-glue-datacatalog     = var.default_settings.enable-glue-datacatalog
    enable-continous-log-filter = var.default_settings.enable-continous-log-filter
    glue-security-configuration-name = module.glue_security.name 
}

# lease eod etl
module "lease_eod_etl" {
  depends_on = [ module.glue_security ]
  source = "./modules/lease_eod_etl"  
  lease-eod-glue-job-tags                     = var.default_settings.tags
  lease-eod-crawler-exclusions                = var.default_settings.crawler_exclusions
  lease-eod-glue-crawler-s3-bucket-key        = var.lease-eod-glue-crawler-s3-bucket-key
  lease-eod-table-prefix                      = var.lease-eod-table-prefix
  lease_eod_table_names                       = var.lease_eod_table_names
  lease-eod-glue-catalog-db-name              = var.lease-eod-glue-catalog-db-name
  lease-eod-glue-security-configuration-name  = module.glue_security.name 
  environment                                 = var.environment
  etl-script-s3-bucket                        = var.etl-script-s3-bucket
}

# deploy etl
module "deployment" {
  source = "./modules/deployment" 
  etl-s3-path = "s3://${var.etl-script-s3-bucket}/deploy/"
  dag-s3-path = var.default_settings.airflow-bucket
  artifact-file = var.default_settings.etl-artfact-file
  github_run_id = var.github_run_id 
}

# Audit api/dynamodb
module "audit-private-api" {
  source = "./modules/audit-api"
  api_gateway_name = "cobank-${local.region_name}-${local.account_id}-audit-private-api-gateway-${var.environment}"
  lambda_name = "cobank-${local.region_name}-${local.account_id}-audit-private-lambda-${var.environment}"
  dynamoDB_table_name = "data-lake-pipeline-audit-balance-control-table"
  retention_logs_in_days = 365
  tags = var.tags
  environment = var.environment
  audit_api_endpoints = var.audit_api_endpoints
  authorizer_name = ""
  lambda_description = "Lambda function for Audit Balance API"
  image_uri   = "${local.account_id}.dkr.ecr.${local.region_name}.amazonaws.com/dat-lakehouse:latest"
  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name
 }

 # deploy etl
module "monitoring" {
  source = "./modules/monitoring" 
  environment = var.environment
  account_id = local.account_id
  aws_region = local.region_name
}

# lending acbs eod raw 
module "acbs_eod_raw" {
  source = "./modules/raw_acbs_eod"  
  environment                                 = var.environment
  lending-acb_table_names                     = var.lending-acb_table_names 
  etl-script-s3-bucket                        = var.etl-script-s3-bucket
  splunk_tags                                 = var.splunk_tags
  tags                                        = var.default_settings.tags
}

# Party salesforce eod raw 
module "raw_salesforce_eod" {
  source = "./modules/raw_salesforce_eod"  
  environment                                 = var.environment
  party_salesforce_table_names                = var.party_salesforce_table_names
  etl-script-s3-bucket                        = var.etl-script-s3-bucket
  ing_account_id                              =var.ing_account_id
  splunk_tags                                 = var.splunk_tags
  tags                                        = var.default_settings.tags
}
