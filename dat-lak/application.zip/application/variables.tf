# Jobs
variable "default_settings" {
  type = object({
    enable-glue-datacatalog     = bool
    enable-metrics              = bool
    enable-spark-ui             = bool
    enable-continous-log-filter = bool
    spark-logs-path             = string
    crawler_exclusions          = list(string)
    job_role_arn                = string
    tags                        = map(string)
    max_retries                 = number
    job_timeout                 = number 
    create-glue-datacatalog     = bool
    create-glue-crawler         = bool
    glue-table-prefix           = string
    environment                 = string
    etl-artfact-file            = string
    airflow-bucket              = string
    target_log_bucket           = string
    objectname                  = string
  })
}
variable "jobs" {
  type = map(object({
    job_name                    = optional(string)
    create-glue-datacatalog     = optional(bool)
    catalog_db_name             = optional(string)
    create-glue-crawler         = optional(bool)
    crawler_name                = optional(string)
    glue-table-prefix           = optional(string)
    crawler-s3-bucket-key       = string 
    source_bucket               = string
    sink_bucket                 = string
    layer                       = string
    objectname                  = optional(string)
    groupname                   = string
  }))
}

#Glue etl script
variable "etl-script-s3-bucket" {
  type = string
}
variable "etl-script-s3-bucket-tags" {
  type = map(string)
  description = "s3 bucket for etl code deployment"
  default = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Data Innovation" 
  }
}
variable "etl-script-s3-path" {
  type = string
}
variable "create-etl-script-s3-path" {
  type = bool
}

# Audit api
variable "resource_prefix" {
  type        = string
  description = "Prefix to be added for all resources"
}

variable "audit_api_endpoints"{
    type = list(object({
                index = string
                resource = string
                methods  = list(string)
                parent_resource = string
                level = number
                request_parameters = string
            }))
}
# TODO: Refactor the following variables
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "buckets_transition" { type = string }
variable "buckets_expiration" { type = string }
variable "storage_class" { type = string }
variable "bucket_key_enabled" { type = string }
variable "ing_account_id" { type = string }
variable "governance_account_id" {
  type        = string
  description = "governance account id"
}

# lw Glue Crawler

variable "lease-eod-glue-crawler-s3-bucket-key" {
  type = string
  nullable = false
}

variable "lease-eod-table-prefix" {
  type = string
}

variable "lease_eod_table_names" {
  type    = list(string)
}

variable "lease-eod-glue-catalog-db-name" {
  type = string
}
variable "lending-acb_table_names" {type    = list(string)}
variable "party_salesforce_table_names" {type    = list(string)}
variable "splunk_tags"{  type= map(string) }
