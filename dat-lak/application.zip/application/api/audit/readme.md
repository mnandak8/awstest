 # Create virtual environment
 cd .\src\
 python -m venv env
 
 # Active virtual environment
 .\env\Scripts\activate

 # Install dependencies
 pip install -r ..\requirements.txt

 # Start serve
 uvicorn main:app --reload