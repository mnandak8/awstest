import os
from pydantic_settings import BaseSettings
from dotenv import load_dotenv
load_dotenv()


class Settings(BaseSettings):
    app_name: str = os.getenv("NAME")
    app_version: str =  os.getenv("VERSION")
    open_api_version: str =  os.getenv("OPEN_API_VERSION")
    
    table_name: str = os.getenv("TABLE_NAME")
    aws_region: str = os.getenv("AWS_REGION")