from fastapi import APIRouter
import datetime as dt
from app.schemas.home_schemas.home import Home
from app.utils.settings import Settings



home_router = APIRouter(
    tags=["Home"]
)

@home_router.get(
    "/",
    tags=["Home"],
    response_model=Home
)
async def home():
    settings = Settings()
    current_datetime = dt.datetime.now()
    return Home(
            name = settings.app_name,
            version = settings.app_version,
            message = "Pipeline Audit API",
            datetime = str(current_datetime)
    )