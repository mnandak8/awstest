from fastapi import APIRouter
from app.schemas.log_schemas.log_insert import LogInsert
from app.schemas.log_schemas.log_update import LogUpdate
from app.schemas.response_schemas.response_audit import ResponseAudit
from app.services.audit import AuditService


audit_router = APIRouter(    
    tags=["Audit"],
)

@audit_router.post(
    "/audit",
    tags=["Audit"],
    response_model=ResponseAudit
)
async def insert_audit(log: LogInsert):
    return AuditService.insert_audit_log(log=log)

@audit_router.put(
    "/audit",
    tags=["Audit"],
    response_model=ResponseAudit
)
async def update_audit(log: LogUpdate):
    return AuditService.update_audit_log(log=log)