import boto3
import logging
from fastapi import HTTPException, status
from app.schemas.log_schemas.log_insert import LogInsert
from app.schemas.log_schemas.log_update import LogUpdate
from app.schemas.response_schemas.response_audit import ResponseAudit
from app.utils.settings import Settings
import uuid

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

settings = Settings()
class AuditService():
    @staticmethod
    def insert_audit_log(log: LogInsert):
        try:
            sanitized_job_name = log.jobName.replace('\r\n', '').replace('\n', '')
            logger.info(f"Received log input: {sanitized_job_name} for Table Name: {settings.table_name} and AWS Region: {settings.aws_region}")
            dynamodb: any = boto3.resource('dynamodb', region_name = settings.aws_region)
            table = dynamodb.Table(settings.table_name)
            jobRunId = str(uuid.uuid4())
            log.jobRunId = jobRunId
            result = table.put_item(Item=log.model_dump(by_alias=True, exclude_none=True, exclude_unset=True))
            if result.get('ResponseMetadata').get('HTTPStatusCode') == 200:
                response = ResponseAudit(statusCode=status.HTTP_200_OK, message=f"Log inserted successfully", jobRunId=jobRunId)
            else:
                raise Exception(f"Error inserting log: {result}")

        except Exception as exception:
            logger.error(f"Error inserting Audit log: {str(exception)}")
            get_customers_exception = HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exception),
            )
            raise get_customers_exception
        
        return response
    
    @staticmethod
    def update_audit_log(log: LogUpdate):
        try:
            dynamodb = boto3.resource('dynamodb', region_name = settings.aws_region)
            table = dynamodb.Table(settings.table_name)
            response = table.update_item(
                Key={'JobName': log.jobName, 'JobRunId':log.jobRunId},
                UpdateExpression='SET RunEndDateTime = :val1, RunStatus = :val2, RunStatusDesc = :val3, LastModifiedDataDate = :val4, TargetRecordCount = :val5, ObjectName = :val6, GroupName = :val7, Layer = :val8, Date2Process = :val9, ExecutionTime = :val10',
                ConditionExpression='attribute_exists(JobName) AND attribute_exists(JobRunId)',
                ExpressionAttributeValues={
                    ':val1': log.runEndDateTime,
                    ':val2': log.runStatus,
                    ':val3': log.runStatusDesc,
                    ':val4': log.lastModifiedDataDate,
                    ':val5': log.targetRecordCount,
                    ':val6': log.objectName,
                    ':val7': log.groupName,
                    ':val8': log.layer,
                    ':val9': log.date2Process,
                    ':val10': log.executionTime
                    }
            )
            responseAudit = ResponseAudit(statusCode=status.HTTP_200_OK, message=f"Log updated successfully", jobRunId=log.jobRunId)            
        except Exception as exception:
            get_customers_exception = HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exception),
            )
            raise get_customers_exception
        
        return responseAudit
