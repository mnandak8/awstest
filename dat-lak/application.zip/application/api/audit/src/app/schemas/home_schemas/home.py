from pydantic import BaseModel

class Home(BaseModel):
    name: str
    version: str
    message: str
    datetime: str   