from pydantic import BaseModel

class ResponseAudit(BaseModel):
    statusCode: int
    message: str
    jobRunId: str