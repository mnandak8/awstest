from pydantic import BaseModel, Field
class  LogUpdate(BaseModel):
   jobName: str= Field(None, serialization_alias="JobName", strict=True)
   jobRunId: str= Field(None, serialization_alias="JobRunId", strict=True)
   runEndDateTime: str= Field(None, serialization_alias="RunEndDateTime", strict=True)
   runStatus: str= Field(None, serialization_alias="RunStatus", strict=True)
   runStatusDesc: str= Field(None, serialization_alias="RunStatusDesc", strict=True)
   lastModifiedDataDate: str= Field(None, serialization_alias="LastModifiedDataDate", strict=True)
   targetRecordCount: str= Field(None, serialization_alias="TargetRecordCount", strict=True)
   executionTime: str= Field(None, serialization_alias="ExecutionTime", strict=True)
   objectName: str= Field(None, serialization_alias="ObjectName", strict=True)
   groupName: str= Field(None, serialization_alias="GroupName", strict=True)
   layer: str= Field(None, serialization_alias="Layer", strict=True)
   date2Process: str= Field(None, serialization_alias="Date2Process", strict=True)