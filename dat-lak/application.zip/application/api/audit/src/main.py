from fastapi import FastAPI
from mangum import Mangum
from app.utils.settings import Settings
from app.routers.home import home_router
from app.routers.audit import audit_router

settings = Settings()
app = FastAPI(title=settings.app_name, version=settings.app_version, swagger_ui_parameters={"defaultModelsExpandDepth": 1})
app.openapi_version = settings.open_api_version
handler = Mangum(app)
app.include_router(home_router)
app.include_router(audit_router)