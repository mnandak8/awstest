from typing import Any
from typing import Generator

import pytest
from fastapi import FastAPI

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
print("sys path", sys.path)


def start_application():
    app = FastAPI()   
    return app

@pytest.fixture(scope="function")
def app() -> Generator[FastAPI, Any, None]:
    _app = start_application()
    yield _app  
