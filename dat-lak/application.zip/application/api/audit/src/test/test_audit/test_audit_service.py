from uuid import UUID
import uuid
import boto3
from moto import mock_aws
import pytest
from app.schemas.log_schemas.log_insert import LogInsert
from app.schemas.log_schemas.log_update import LogUpdate
from datetime import datetime
from app.schemas.response_schemas.response_audit import ResponseAudit
from app.services.audit import AuditService
from app.utils.settings import Settings
settings = Settings()
jobRunId = ""

@mock_aws
class TestAuditService():

    @pytest.fixture
    def use_moto(self):
        @mock_aws
        def dynamodb_client():
            dynamodb = boto3.resource('dynamodb', region_name=settings.aws_region)
            dynamodb.create_table(
                TableName=settings.table_name,
                KeySchema=[
                    {'AttributeName': 'JobName', 'KeyType': 'HASH'},
                    {'AttributeName': 'JobRunId', 'KeyType': 'RANGE'},
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'JobName', 'AttributeType': 'S'},
                    {'AttributeName': 'JobRunId', 'AttributeType': 'S'},
                ],
                BillingMode='PROVISIONED',
                ProvisionedThroughput={
                    "ReadCapacityUnits": 10,
                    "WriteCapacityUnits": 10
                }
            )
            return dynamodb
        return dynamodb_client

    def test_insert_audit_log(self, use_moto):
        use_moto()
        runStartDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
        log_test = LogInsert(
            jobName="Test Job name",
            source="DynamoDB",
            target="S3 Bucket",
            runBy="Test API",
            runStartDateTime=runStartDateTime,
            runStatus="Start",
            runStatusDesc="Test Unit"
        )
        response_audit_test = AuditService.insert_audit_log(log=log_test)
        assert response_audit_test.statusCode == 200, f"status is not http code 200"
        assert response_audit_test.message == "Log inserted successfully", f"Log dio insert succesfully"
        
        
    def test_insert_audit_logs_type(self, use_moto):
        use_moto()
        runStartDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
        log_test = LogInsert(
            jobName="Test Job name",
            source="DynamoDB",
            target="S3 Bucket",
            runBy="Test API",
            runStartDateTime=runStartDateTime,
            runStatus="Start",
            runStatusDesc="Test Unit"
        )
        response_audit_test = AuditService.insert_audit_log(log=log_test)
        assert isinstance(response_audit_test, ResponseAudit), f"response_audit_test isn't a ResponseAudit instance"
        
    def test_insert_audit_log_jobRunId_is_uuid4(self, use_moto):
        use_moto()
        runStartDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
        log_test = LogInsert(
            jobName="Test Job name",
            source="DynamoDB",
            target="S3 Bucket",
            runBy="Test API",
            runStartDateTime=runStartDateTime,
            runStatus="Start",
            runStatusDesc="Test Unit"
        )
        response_audit_test = AuditService.insert_audit_log(log=log_test)
        uuid_obj = UUID(response_audit_test.jobRunId, version=4)
        assert str(uuid_obj) == response_audit_test.jobRunId, f"jobRunId is not UUID 4"
        
    
    def test_update_audit_log_jobRunId(self, use_moto):
        use_moto()
        runStartDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
        log_insert_test = LogInsert(
            jobName="Test Job name",
            source="DynamoDB",
            target="S3 Bucket",
            runBy="Test API",
            runStartDateTime=runStartDateTime,
            runStatus="Start",
            runStatusDesc="Test Unit"
        )
        response_audit_insert_test = AuditService.insert_audit_log(log=log_insert_test)
        runEndDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
        log_update_test = LogUpdate(
            jobName="Test Job name",
            jobRunId=log_insert_test.jobRunId,
            runEndDateTime= runEndDateTime,
            runStatus= "Succesfully",
            runStatusDesc = "Test Unit update",
            lastModifiedDataDate = runEndDateTime,
            targetRecordCount = "10"
        )
        response_audit_test = AuditService.update_audit_log(log=log_update_test)
        assert response_audit_test.statusCode == 200, f"status is not http code 200"
        assert response_audit_test.message == "Log updated successfully", f"Log dio insert succesfully"
        assert response_audit_test.jobRunId == response_audit_insert_test.jobRunId, f"jobRunId is not exist"
        
        
    def test_update_audit_log_jobName_is_not_exist(self, use_moto):
        try:            
            use_moto()
            runStartDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
            log_insert_test = LogInsert(
                jobName="Test Job name",
                source="DynamoDB",
                target="S3 Bucket",
                runBy="Test API",
                runStartDateTime=runStartDateTime,
                runStatus="Start",
                runStatusDesc="Test Unit"
            )
            response_audit_insert_test = AuditService.insert_audit_log(log=log_insert_test)
            runEndDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
            log_update_test = LogUpdate(
                jobRunId=log_insert_test.jobRunId,
                runEndDateTime= runEndDateTime,
                runStatus= "Succesfully",
                runStatusDesc = "Test Unit update",
                lastModifiedDataDate = runEndDateTime,
                targetRecordCount = "10"
            )
            response_audit_test = AuditService.update_audit_log(log=log_update_test)
        except Exception as exception:
            assert "ConditionalCheckFailedException" in str(exception), f"ConditionalCheckFailedException failed"
            
    def test_update_audit_log_jobRunId_is_not_exist(self, use_moto):
        try:            
            use_moto()
            runEndDateTime = str(datetime.now().strftime(":%Y-%m-%d %H:%M:%S%z"))
            log_update_test = LogUpdate(
                jobName="Test Job name",
                jobRunId=str(uuid.uuid4()),
                runEndDateTime= runEndDateTime,
                runStatus= "Succesfully",
                runStatusDesc = "Test Unit update",
                lastModifiedDataDate = runEndDateTime,
                targetRecordCount = "10"
            )
            response_audit_test = AuditService.update_audit_log(log=log_update_test)
        except Exception as exception:
            assert "ConditionalCheckFailedException" in str(exception), f"ConditionalCheckFailedException failed"
        