provider "aws" {
  region = "us-west-2"
  /*default_tags {
    tags = {
      "cobank:cost-allocation:cost-center"  = "8030"
      "cobank:operations:support-group"     = "Data Inovation"
    }
  }*/
}
