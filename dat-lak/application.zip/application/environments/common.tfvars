
audit_api_endpoints = [
    {
        "index": "1",
		"resource": "audit",
		"methods": ["PUT", "POST"],
        "parent_resource": "",
        "level": 0,
        "request_parameters": ""
	},
    {
        "index": "2",
		"resource": "docs",
		"methods": ["GET"],
        "parent_resource": "",
        "level": 0,
        "request_parameters": ""
	},
    {
        "index": "3",
		"resource": "openapi.json",
		"methods": ["GET"],
        "parent_resource": "",
        "level": 0,
        "request_parameters": ""
	}
    
]
splunk_tags= {
        "cobank:cost-allocation:cost-center" = "8103"
        "cobank:operations:support-group" = "Transformation Programs"
        Splunk = true
}
lease-eod-glue-crawler-s3-bucket-key = "eod/dbo"
lease-eod-table-prefix = "lease_eod_"
lease_eod_table_names  = ["LeaseFinances" ,"LeaseFinanceDetails" ,"Contracts" ,"Parties" ,"RemainingNetInvestments" ,"DealProductTypes" ,"Users" ,"ContractOriginations" ,"OriginationSourceTypes" ,"LeasePaymentSchedules" ,"Receivables" ,"ReceivableDetails" ,"RemitToes" ,"ReceivableCodes" ,"ReceivableTypes" ,"ReceivableInvoiceDetails" ,"ReceivableTaxes" ,"ReceivableTaxDetails" ,"ReceivableInvoices"
,"AccountsPayableDetails","AccountsPayablePayments","AccountsPayablePaymentVouchers","AccountsPayables",
"AcquiredPortfolios","Activities","ActivityEntityConfigs","ActivityForCollectionWorkLists","ActivityForCustomers","ActivityTypes","AgencyLegalPlacementAmounts",
"AgencyLegalPlacements","AnalysisTypeConfigs","AppraisalDetails","AppraisalRequests","AssetCategories","AssetClassADRConfigs","AssetClassCodes","AssetClassConfigs",
"AssetFeatures","AssetGLDetails","AssetGroupByOptions","AssetHistories","AssetIncomeSchedules","AssetLocations","AssetMeters","Assets","AssetSaleBlendedItems",
"AssetSaleDetails","AssetSales","AssetsValueStatusChangeDetails","AssetTypeAccountingComplianceDetails","AssetTypes","AssetUsages","AssetValueHistories",
"AssumptionAssets","Assumptions","BankAccountCategories","BankAccounts","BankBranches","BillToAssetGroupByOptions","BillToes","BillToInvoiceAddendumBodyDynamicContents",
"BillToInvoiceBodyDynamicContents","BillToInvoiceFormats","BillToInvoiceParameters","BlendedIncomeSchedules","BlendedItemAssets","BlendedItemCodes","BlendedItems",
"BookDepreciations",
"DiscountingAmortizationSchedules","GLJournalDetails","GLJournals","CustomerBillingPreferences","CustomerLateFeeSetups","DiscountingRepaymentSchedules","DisbursementRequestPayables","DiscountingCapitalizedInterests","ContractLateFeeReceivableTypes","Comments",
"DisbursementRequests","ContractBillingPreferences","ContractACHAssignments","CreditSummaryExposures","ContractReportStatusHistories","EmployeesAssignedToParties","Customers","CreditRiskGrades","CustomerACHAssignments","ContractThirdPartyRelationships","CollectionWorkListContractDetails",
"EmployeesAssignedToContracts","ContractContacts","ContractOriginationServicingDetails","CustomerThirdPartyRelationships","ContractBillings","ContractLateFees","CollateralTrackings","ContractCollectionDetails","CollectionWorkLists","ContractLateFeeDetails","DiscountingContracts",
"DiscountingFinances","DiscountingServicingDetails","Discountings","ContractBankAccountPaymentThresholds","DiscountingPaydowns","CommentSubTypes","CustomerDoingBusinessAs","Counties","CommentResponses","BusinessTypeNAICSCodes","GLTemplateDetails","CollectionCustomerStatusHistories","Funders",
"FunderLegalEntities","BusinessTypesSICsCodes","DiscountingPaydownSundries","DiscountingNonAccrualDetails","GLEntryItems","GLTemplates","FloatRateIndexDetails","DiscountingBlendedItems","DiscountingWriteDowns","GLAccounts","GLTransactionTypes",
"CollectionStatus","CommentTypeSubTypes","ContactTypesForEntityTypes","CashTypes","CommentTypes","CollectionQueues","EligibilityConfigs","BusinessTypes","CoverageTypeConfigs","CustomerBusinessConfigs","CustomerClasses",
"DealTypes","CancellationCodeConfigs","CeclTextConfigs","CourtFilings","ExceptionApprovalConfigs","FloatRateIndexes","Countries","BusinessUnits",
"LeaseIncomeSchedules","LoanIncomeSchedules","InvoiceExtractReceivableDetails","PayableGLJournals","Payables","InvoiceExtractCustomerDetails","Jobs","JobInstances",
"LeaseYields","PartyContactTypes","PartyAddresses","LeaseContractOptions","PartyContacts","PartyRoles","LeaseAssets","InterestRateDetails","LeaseInterestRates",
"LeaseCustomAmorts","MaturityMonitorActivityTypes","LeaseTaxAssessmentDetails","LeaseTaxAssessmentTaxBasisTypes","InsurancePolicyAssignments","LienCollaterals","LienFilings","LienResponses",
"LocationTaxAreaHistories","LoanPaymentSchedules","Locations","LeaseAmendments","PayableInvoiceAssets","LeaseBlendedItems","PayableInvoices","InsurancePolicyCoverageDetails",
"PayableInvoiceOtherCosts","MaturityMonitors","MaturityMonitorRenewalDetails","MasterAgreements","LeaseAssetVendorResidualGuarantees","LandRecordsContractDetails","MaturityMonitorLesseeNotifications",
"LandRecords","InsurancePolicies","LoanFundings","LeaseAssetPaymentSchedules","PartyBankAccounts","InstrumentTypeGLAccounts","InsuranceAgencies","MaturityMonitorFMVAssetDetails","LoanInterestRates",
"LoanFinances","ParentPartyRelationshipHistories","NonAccrualContracts","InsuranceCompanies","LeaseAmendmentImpairmentAssetDetails","NonAccruals","InstrumentTypes","PayableCodes",
"InvoiceFormats","LegalReliefBankruptcyChapters","LegalReliefs","InvoiceTypes","PayableTypes","LegalFormationTypeConfigs","LossGivenDefaultConfigs","LateFeeTemplateDetails","LateFeeTemplates",
"LegalEntityAddresses","MaturityActivityTypes","LegalEntities","LineOfBusinesses","InsurancePolicyAssignmentDetails"
,"ReceivableTaxImpositions","TaxDepAmortizationDetails","ReceiptApplicationReceivableDetails","ReceivableGLJournals","Sundries",
"ReceiptGLJournals","TreasuryPayableDetails","SettlementEngines","ReceivableInvoiceReceiptDetails","Workitems","TreasuryPayables",
"PaymentVoucherDetails","PaymentVoucherGLJournals","ReceiptApplications","Transactioninstances","Receipts","ReceiptAllocations",
"TaxExemptRules","PaymentVouchers","PaymentVoucherInfoes","ReceivableInvoicePastDueDetails","SundryDetails","PayoffAssets",
"TaxDepAmortizations","TaxDepEntities","Payoffs","ServicingDetails","PropertyTaxDetails","PayoffInvoices",
"PayOffOutStandingChargeDetails","PropertyTaxes","Vendors","VendorLegalEntities","PayoffSundries",
"PayoffAssetEstimatedPropertyTaxDetails","UnallocatedRefundDetails","UnallocatedRefunds","RemitToWireDetails","VehicleDetails",
"WorkItemConfigs","UsersInUserGroups","WriteDowns","Products","States","UserGroups","ReceiptPostingOrders","ReceiptTypes",
"ProgramIndicatorConfigs","SalesTaxExemptionCodeConfigs","TaxDepRates","TaxDepTemplateDetails","TaxDepTemplates",
"ReportingChannelConfigs","RoleFunctions","TaxAuthorityConfigs","TerminationReasonConfigs","ProductAndServiceTypeConfigs",
"ReceivableCategories","PropertyTaxReportCodeConfigs","PayOffTemplates","PayoffTerminationOptions","TaxTypes",
"RatingModelConfigs","TaxDepConventions","VendorAssetCategoryConfigs","TaxBasisTypes","ReceiptHierarchyTemplates",
"TransTypeConfigs"
]
lease-eod-glue-catalog-db-name = "lease_eod_leasewave_raw_dataasset_db"
lending-acb_table_names=["COADOB","COCMAA","COCMAF","COCMAG","COCMAI","COCMAJ","COCMAN","COCMAO","COCMAP","COCMAU","COCMAV","COCMAW","COCMAY","COCMAZ","COCMBA","COCMBD","DMEXAF","DSCAGH","DSCAGL","DSCAGP","DSCAIL","DSCAPI","DSCAPL","DSGNEB","DSLWLA","DSLWLB","DSLWLM","DSLWLR","DSLWNL","DSLWTB","DSLWTI","DSLWTR","DSLWTRR","DSLWUT","DSTRDM","DSTRMS","FNGNED","FNGNEL","J_CACG","J_CADT","J_CADTW","J_CAFB","J_CAFE","J_CAFF","J_CAFI","J_CAFT","J_CAGU","J_CAHS","J_CALM","J_CAMI","J_CAMS","J_CAPF","J_CATE","J_CLAC","J_CLAD","J_CLAP","J_CLAS","J_CLBC","J_CLDT","J_CLDTW","J_CLFD","J_CLFP","J_CLGU","J_CLIS","J_CLIX","J_CLLA","J_CLLI","J_CLMI","J_CLMS","J_CLMX","J_CLPB","J_CLPC","J_CLPF","J_CLPS","J_CLRM","J_CLRR","J_CLRS","J_CLSB","J_CLTE","J_CLTP","J_CTDE","J_CTID","J_CTIM","J_CTMS","J_CTPD","J_CTPG","J_CTUH","J_CTUN","J_CUAD","J_CUAF","J_CUAL","J_CUCR","J_CUDT","J_CUIN","J_CUIS","J_CULB","J_CUMS","J_CUPI","J_CUTE","J_GLAS","J_GLBS","J_GLCC","J_GLER","J_GLNO","J_SCMS","J_SYCD","J_SYCE","J_SYDC","J_SYDM","J_SYDMR","J_SYDR","J_SYFL","J_SYXL","J_SYXM","Z_ACCLSM","Z_ACSOLD","Z_ADCA","Z_ATCI","Z_ATCUST","Z_CAADDI","Z_CAMA","Z_CAP","Z_CAPEQ","Z_CAPINM","Z_CAPINT","Z_CAPPF","Z_CDERV","Z_CIB","Z_CLPPF","Z_CLPY","Z_CUEX","Z_CUMA","Z_CUSNAI","Z_FCLACT","Z_GLDT","Z_LBRHST","ZCMXAI","ZCMXRF","ZFBPCFE","ZFBPEXT","ZFMIFB","ZFPACK","ZFPINA","ZQRMEX","ZSEDTL","ZWFBLH","ZWFCUD","ZWFPLN","ZWFTYP"]

