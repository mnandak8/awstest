For each environment and another set of variables to move scripts to correct places and set glue variables. 
Areas that need to be updated are crawler-s3-bucket-key, glue-table-prefix, objectname, groupname. Usually raw and transform are added at the same time
curated and dynamo entries can be added later. 
jobs = {
    // Salesforce
    "landing2raw-salesforce-account-airflow" = {
        source_bucket               = "s3://cobank-dl-471112929721-us-west-2-landing-dev/" #source (landing in this case)
        sink_bucket                 = "s3://cobank-dl-654654598303-us-west-2-raw-dev/" #target (raw in this case)
        layer                       = "raw" #(sets which glue layer to use)
        catalog_db_name             = "raw_db" #(set crawler database catalog name)
        crawler_name                = "raw-db-crawler-airflow-account" #set crawler
        crawler-s3-bucket-key       = "salesforce/account/" #set s3 bucket 
        objectname                  = "account" #set table to run ETL glue job against
        groupname                   = "salesforce"  #set source database
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_" #create prefix for crawler to show which app data is from
    },
    "raw2transform-salesforce-account-airflow" = {
        source_bucket               = "s3://cobank-dl-654654598303-us-west-2-raw-dev/" #source (raw in this case)
        sink_bucket                 = "s3://cobank-dl-654654598303-us-west-2-transformed-dev/" #target (raw in this case)
        layer                       = "transform" #sets which glue layer to use
        catalog_db_name             = "transform_db" #sets crawler database catalog name
        crawler_name                = "transform-db-crawler-airflow-account" #set crawler
        crawler-s3-bucket-key       = "salesforce/account/" #set s3 bucket
        objectname                  = "account" #set table to run ETL glue job against
        groupname                   = "salesforce" #set source database
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_" #create prefix for crawler to show which app data is from
    },
  
