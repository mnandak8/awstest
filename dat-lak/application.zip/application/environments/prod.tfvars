default_settings = {
    enable-glue-datacatalog     = true
    enable-metrics              = false
    enable-spark-ui             = true
    enable-continous-log-filter = false
    spark-logs-path             = "s3://cobank-dl-767397798595-us-west-2-logs-prod/"
    crawler_exclusions          = ["history/**"]
    job_role_arn                = "arn:aws:iam::767397798595:role/cobank-prod-glue-role"
    tags                        = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation" 
    }
    max_retries                 = 0
    job_timeout                 = 2800
    environment                 = "prod"
    create-glue-datacatalog     = false
    create-glue-crawler         = false
    glue-table-prefix           = "na"
    objectname                  = "na"
    etl-artfact-file            = "corelibs-0.1-py3-none-any.whl"
    airflow-bucket              = "s3://cobank-dl-767397798595-us-west-2-airflow-prod"
    target_log_bucket           = "cobank-dl-767397798595-us-west-2-tooling-prod"
}

jobs = {
    // Salesforce
    "landing2raw-salesforce-account-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        create-glue-datacatalog     = true
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-account"
        crawler-s3-bucket-key       = "salesforce/account/"
        objectname                  = "account"
        groupname                   = "salesforce" 
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-account-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        create-glue-datacatalog     = true
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-account"
        crawler-s3-bucket-key       = "salesforce/account/"
        objectname                  = "account"
        groupname                   = "salesforce" 
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "landing2raw-salesforce-contact-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-contact"
        crawler-s3-bucket-key       = "salesforce/contact/"
        objectname                  = "contact"
        groupname                   = "salesforce" 
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-contact-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-contact"
        crawler-s3-bucket-key       = "salesforce/contact/"
        objectname                  = "contact"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "landing2raw-salesforce-account_address_c-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-account_address_c"
        crawler-s3-bucket-key       = "salesforce/account_address_c/"
        objectname                  = "account_address_c"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-account_address_c-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-account_address_c"
        crawler-s3-bucket-key       = "salesforce/account_address_c/"
        objectname                  = "account_address_c"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "landing2raw-salesforce-account_contact_relation-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-account_contact_relation"
        crawler-s3-bucket-key       = "salesforce/account_contact_relation/"
        objectname                  = "account_contact_relation"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-account_contact_relation-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-account_contact_relation"
        crawler-s3-bucket-key       = "salesforce/account_contact_relation/"
        objectname                  = "account_contact_relation"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "landing2raw-salesforce-llc_bi_loan_c-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-llc_bi_loan_c"
        crawler-s3-bucket-key       = "salesforce/llc_bi_loan_c/"
        objectname                  = "llc_bi_loan_c"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-llc_bi_loan_c-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-llc_bi_loan_c"
        crawler-s3-bucket-key       = "salesforce/llc_bi_loan_c/"
        objectname                  = "llc_bi_loan_c"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "landing2raw-salesforce-recordtype-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-recordtype"
        crawler-s3-bucket-key       = "salesforce/recordtype/"
        objectname                  = "recordtype"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },
    "raw2transform-salesforce-recordtype-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-recordtype"
        crawler-s3-bucket-key       = "salesforce/recordtype/"
        objectname                  = "recordtype"
        groupname                   = "salesforce"
        create-glue-crawler         = true
        glue-table-prefix           = "salesforce_"
    },

    // ACBS
    "landing2raw-acbs-j_cami-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_cami"
        crawler-s3-bucket-key       = "acbs/j_cami/"
        objectname                  = "j_cami"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_cami-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_cami"
        crawler-s3-bucket-key       = "acbs/j_cami/"
        objectname                  = "j_cami"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clte-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clte"
        crawler-s3-bucket-key       = "acbs/j_clte/"
        objectname                  = "j_clte"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clte-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clte"
        crawler-s3-bucket-key       = "acbs/j_clte/"
        objectname                  = "j_clte"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_cams-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_cams"
        crawler-s3-bucket-key       = "acbs/j_cams/"
        objectname                  = "j_cams"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_cams-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_cams"
        crawler-s3-bucket-key       = "acbs/j_cams/"
        objectname                  = "j_cams"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clas-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clas"
        crawler-s3-bucket-key       = "acbs/j_clas/"
        objectname                  = "j_clas"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clas-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clas"
        crawler-s3-bucket-key       = "acbs/j_clas/"
        objectname                  = "j_clas"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clhs-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clhs"
        crawler-s3-bucket-key       = "acbs/j_clhs/"
        objectname                  = "j_clhs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clhs-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clhs"
        crawler-s3-bucket-key       = "acbs/j_clhs/"
        objectname                  = "j_clhs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clli-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clli"
        crawler-s3-bucket-key       = "acbs/j_clli/"
        objectname                  = "j_clli"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clli-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clli"
        crawler-s3-bucket-key       = "acbs/j_clli/"
        objectname                  = "j_clli"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clmi-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clmi"
        crawler-s3-bucket-key       = "acbs/j_clmi/"
        objectname                  = "j_clmi"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clmi-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clmi"
        crawler-s3-bucket-key       = "acbs/j_clmi/"
        objectname                  = "j_clmi"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clms-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clms"
        crawler-s3-bucket-key       = "acbs/j_clms/"
        objectname                  = "j_clms"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clms-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clms"
        crawler-s3-bucket-key       = "acbs/j_clms/"
        objectname                  = "j_clms"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clpb-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clpb"
        crawler-s3-bucket-key       = "acbs/j_clpb/"
        objectname                  = "j_clpb"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clpb-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clpb"
        crawler-s3-bucket-key       = "acbs/j_clpb/"
        objectname                  = "j_clpb"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clrs-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clrs"
        crawler-s3-bucket-key       = "acbs/j_clrs/"
        objectname                  = "j_clrs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clrs-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clrs"
        crawler-s3-bucket-key       = "acbs/j_clrs/"
        objectname                  = "j_clrs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_clsb-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_clsb"
        crawler-s3-bucket-key       = "acbs/j_clsb/"
        objectname                  = "j_clsb"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_clsb-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_clsb"
        crawler-s3-bucket-key       = "acbs/j_clsb/"
        objectname                  = "j_clsb"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_cucr-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_cucr"
        crawler-s3-bucket-key       = "acbs/j_cucr/"
        objectname                  = "j_cucr"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_cucr-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_cucr"
        crawler-s3-bucket-key       = "acbs/j_cucr/"
        objectname                  = "j_cucr"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_cums-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_cums"
        crawler-s3-bucket-key       = "acbs/j_cums/"
        objectname                  = "j_cums"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_cums-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_cums"
        crawler-s3-bucket-key       = "acbs/j_cums/"
        objectname                  = "j_cums"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_sydc-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_sydc"
        crawler-s3-bucket-key       = "acbs/j_sydc/"
        objectname                  = "j_sydc"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_sydc-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_sydc"
        crawler-s3-bucket-key       = "acbs/j_sydc/"
        objectname                  = "j_sydc"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-j_cate-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-j_cate"
        crawler-s3-bucket-key       = "acbs/j_cate/"
        objectname                  = "j_cate"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-j_cate-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-j_cate"
        crawler-s3-bucket-key       = "acbs/j_cate/"
        objectname                  = "j_cate"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-z_hhtr-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-z_hhtr"
        crawler-s3-bucket-key       = "acbs/z_hhtr/"
        objectname                  = "z_hhtr"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-z_hhtr-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-z_hhtr"
        crawler-s3-bucket-key       = "acbs/z_hhtr/"
        objectname                  = "z_hhtr"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-z_hhbs-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-z_hhbs"
        crawler-s3-bucket-key       = "acbs/z_hhbs/"
        objectname                  = "z_hhbs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-z_hhbs-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-z_hhbs"
        crawler-s3-bucket-key       = "acbs/z_hhbs/"
        objectname                  = "z_hhbs"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "landing2raw-acbs-z_hhps-airflow" = {
        source_bucket               = "s3://cobank-dl-654654446028-us-west-2-landing-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-raw-prod/" 
        layer                       = "raw"
        catalog_db_name             = "raw_db"
        crawler_name                = "raw-db-crawler-airflow-z_hhps"
        crawler-s3-bucket-key       = "acbs/z_hhps/"
        objectname                  = "z_hhps"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    "raw2transform-acbs-z_hhps-airflow" = {
        source_bucket               = "s3://cobank-dl-767397798595-us-west-2-raw-prod/"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-transformed-prod/" 
        layer                       = "transform"
        catalog_db_name             = "transform_db"
        crawler_name                = "transform-db-crawler-airflow-z_hhps"
        crawler-s3-bucket-key       = "acbs/z_hhps/"
        objectname                  = "z_hhps"
        groupname                   = "acbs" 
        create-glue-crawler         = true
        glue-table-prefix           = "acbs_"
    },
    // Curate
    "transform2curate-party-airflow" = {
        source_bucket               = "NA"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/" 
        layer                       = "party"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-party"
        crawler-s3-bucket-key       = "curate/party/"
        objectname                  = "NA"
        groupname                   = "curate" 
        create-glue-datacatalog     = true
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },
     "transform2curate-party-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/"  
        layer                       = "curate"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-party"
        crawler-s3-bucket-key       = "curate/party/"
        groupname                   = "party" 
        create-glue-datacatalog     = true
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },
     "transform2curate-loanDetail-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/"  
        layer                       = "curate"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-loanDetail"
        crawler-s3-bucket-key       = "curate/loanDetail/"
        groupname                   = "loanDetail"
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },
    "transform2curate-loanTransaction-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/"  
        layer                       = "curate"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-loanTransaction"
        crawler-s3-bucket-key       = "curate/loanTransaction/"
        groupname                   = "loanTransaction"
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },
    "transform2curate-loanPaymentSchedule-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/"  
        layer                       = "curate"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-loanPaymentSchedule"
        crawler-s3-bucket-key       = "curate/loanPaymentSchedule/"
        groupname                   = "loanPaymentSchedule"
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },
    "transform2curate-loanBillingSummary-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "s3://cobank-dl-767397798595-us-west-2-curated-prod/"  
        layer                       = "curate"
        catalog_db_name             = "curate_db"
        crawler_name                = "curate-db-crawler-airflow-loanBillingSummary"
        crawler-s3-bucket-key       = "curate/loanBillingSummary/"
        groupname                   = "loanBillingSummary"
        create-glue-crawler         = true
        glue-table-prefix           = "curate_"
    },

    // Consumption
    "populateconsumption-party-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "arn:aws:iam::767397911309:role/cobank-crossacct-lake-dynamodbfullaccess"
        layer                       = "consumption"
        catalog_db_name             = "na"
        crawler_name                = "na"
        crawler-s3-bucket-key       = "na"
        groupname                   = "CoBank-Party-Information"
    },
    "populateconsumption-loan-airflow" = {
        source_bucket               = "na"
        sink_bucket                 = "arn:aws:iam::767397911309:role/cobank-crossacct-lake-dynamodbfullaccess"
        layer                       = "consumption"
        catalog_db_name             = "na"
        crawler_name                = "na"
        crawler-s3-bucket-key       = "na"
        groupname                   = "CoBank-Loan-Detail"
    }
}

#Glue etl script
etl-script-s3-bucket      = "cobank-dl-767397798595-us-west-2-glue-etl-script-prod"
create-etl-script-s3-path = true
etl-script-s3-path        = "deploy/libs"

# Audit api/dynamodb
resource_prefix = "cobank"
environment     = "prod"
tags            = { "Env" = "prod" }

# DMS 
buckets_transition="365"
buckets_expiration="2555"
storage_class="STANDARD_IA"
bucket_key_enabled="true"
ing_account_id="654654446028"

governance_account_id = "992382767970"
party_salesforce_table_names=["Account" ,"Contact" ,"LLC_BI__Loan__c" ,"AccountContactRelation" ,"Account_Address__c" ,"RecordType" ,"LLC_BI__Loan__History" ,"LLC_BI__Product_Package__c"]
