#Method to create new flow is change tfvars for all environments, copy dag.py file, and change obj_name and group_name. will comment in line as to each piece of code. 
from datetime import datetime, timedelta
from airflow import DAG
from airflow.models.baseoperator import chain
from cb_common.utils.common import archive, save_job_status
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator

date2process = datetime.now().strftime('%Y/%m/%d') #sets date2process variable to current date with latest time
obj_name = 'j_cami' #sets obj_name variable to name all airflow objects to the correct table for new dag
group_name = 'acbs' #sets group_name to change all objects to contain correct source group_name data 
raw_job_name = f'landing2raw-{group_name}-{obj_name}-airflow' #sets raw glue job name with group_name and obj_name variable
transform_job_name = f'raw2transform-{group_name}-{obj_name}-airflow' #set transform glue job name with group_name and obj_name variable
raw_crawler_name = f'raw-db-crawler-airflow-{obj_name}' #set crawler name to correct table name for raw
transform_crawler_name = f'transform-db-crawler-airflow-{obj_name}' Set crawler name to correct table name for transform
dag_id = f'landing2transform-{group_name}-{obj_name}-etl' #sets dag ID name to group and obj name for airflow clarity and to address airflow name from ingestion dag job

default_args = {
    'owner': 'SMW', #sets owner - we should come up with a standard for this
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    start_date =  datetime(2024, 3, 25),
    schedule_interval=None, #sets schedule to none as this job will be called by prior ingestion job. 
    catchup=False,
    default_view='graph',
    tags=[group_name], #sets tag for dag so it can be searched in airflow by tag of originating source system
    max_active_runs=1
)

darchive_data = BashOperator(
    task_id='archive_latest_to_history',
    bash_command=archive(raw_job_name),
    dag=dag #moves raw latest data to history
)

glue_job = GlueJobOperator(
    job_name=raw_job_name,
    task_id = f"ingest_{group_name}_{obj_name}_landing2raw", #sets task ID for airflow raw job with group_name and object name
    script_args={
       "--date2process": date2process # sets date to process based on date to process time set in variable. this can also be hard coded or date2process can be set to a particular date
    },
    verbose=False,
    dag=dag
    )

raw_layer_crawler = GlueCrawlerOperator (
        task_id = 'catalog_raw_layer_data',
        config = { 
            "Name": raw_crawler_name,
        },#runs crawler for raw
        dag=dag
    )

job_status = PythonOperator(
        task_id = 'save_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': raw_job_name},
        dag=dag
    )#runs audit job to move audit data to audit database


archive_transform_data = BashOperator(
    task_id='archive_transform_latest_to_history',
    bash_command=archive(transform_job_name),
    dag=dag #moves transform data to history
) #moves transform old latest data to history

glue_transform_job = GlueJobOperator(
    job_name=transform_job_name,
    task_id = f"{group_name}_{obj_name}_raw2transform", #sets shown task ID for raw 2 transform glue job task ID based on variable
    script_args={"--date2process": datetime.now().strftime('%Y/%m/%d')},#sets date to process glue job, normally current date most recent data
    verbose=False,
    dag=dag
    )

transform_layer_crawler = GlueCrawlerOperator (
        task_id = 'catalog_transform_layer_data',
        config = { "Name": transform_crawler_name },
        dag=dag
    )#runs transform crawler to make any updates

job_transform_status = PythonOperator(
        task_id = 'save_transform_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': transform_job_name},
        dag=dag#saves audit data to audit db
    )


# Define the DAG dependencies
chain(
    archive_data, 
    glue_job,  
    [raw_layer_crawler, job_status],
    archive_transform_data,
    glue_transform_job,
    [transform_layer_crawler, job_transform_status]
    )#sets up workflow and dependencies for airflow
