from datetime import datetime, timedelta
from airflow import DAG
from airflow.models.baseoperator import chain
from cb_common.utils.common import archive, save_job_status
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from cb_common.utils.common import SNSNotifier
 
sns_notifier = SNSNotifier(region_name='us-west-2')

date2process = datetime.now().strftime('%Y/%m/%d')
obj_name = 'j_clmi'
group_name = 'acbs'
raw_job_name = f'landing2raw-{group_name}-{obj_name}-airflow'
transform_job_name = f'raw2transform-{group_name}-{obj_name}-airflow'
raw_crawler_name = f'raw-db-crawler-airflow-{obj_name}'
transform_crawler_name = f'transform-db-crawler-airflow-{obj_name}'
dag_id = f'landing2transform-{group_name}-{obj_name}-etl'

default_args = {
    'owner': 'SMW',
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    start_date =  datetime(2024, 3, 25),
    schedule_interval= None,
    catchup=False,
    default_view='graph',
    tags=[group_name],
    max_active_runs=1,   
    on_failure_callback=[sns_notifier.failure_notification] 
)

archive_data = BashOperator(
    task_id='archive_latest_to_history',
    bash_command=archive(raw_job_name),
    dag=dag
)

glue_raw_job = GlueJobOperator(
    job_name=raw_job_name,
    task_id = f"ingest_{group_name}_{obj_name}_landing2raw",
    script_args={
       "--date2process": date2process
    },
    verbose=False,
    dag=dag
    )

raw_layer_crawler = GlueCrawlerOperator (
        task_id = 'catalog_raw_layer_data',
        config = { 
            "Name": raw_crawler_name,
        },
        poll_interval=30,
        dag=dag
    )

job_status = PythonOperator(
        task_id = 'save_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': raw_job_name},
        dag=dag
    )


archive_transform_data = BashOperator(
    task_id='archive_transform_latest_to_history',
    bash_command=archive(transform_job_name),
    dag=dag
)

glue_transform_job = GlueJobOperator(
    job_name=transform_job_name,
    task_id = f"{group_name}_{obj_name}_raw2transform",
    script_args={"--date2process": datetime.now().strftime('%Y/%m/%d')},
    verbose=False,
    dag=dag
    )

transform_layer_crawler = GlueCrawlerOperator (
        task_id = 'catalog_transform_layer_data',
        config = { "Name": transform_crawler_name },
        poll_interval=30,
        dag=dag
    )

job_transform_status = PythonOperator(
        task_id = 'save_transform_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': transform_job_name},
        dag=dag
    )


# Define the DAG dependencies
chain(
    archive_data, 
    glue_raw_job,  
    [raw_layer_crawler, job_status],
    archive_transform_data,
    glue_transform_job,
    [transform_layer_crawler, job_transform_status]
    )
