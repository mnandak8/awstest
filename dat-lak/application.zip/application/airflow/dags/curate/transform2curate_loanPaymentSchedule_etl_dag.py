from datetime import datetime, timedelta
from airflow import DAG
from cb_common.utils.common import archive, save_job_status
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from cb_common.utils.common import SNSNotifier
 
sns_notifier = SNSNotifier(region_name='us-west-2')

obj_name = 'loanPaymentSchedule'
loan_job_name = f'transform2curate-{obj_name}-airflow'
glue_crawler_name = f'curate-db-crawler-airflow-{obj_name}'
dag_id = f'transform2curate_{obj_name}_etl'
default_args = {
    'owner': 'SMW',
    'retries': 4,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    start_date =  datetime(2024, 3, 25),
    schedule_interval='5 5/4 * * *',
    catchup=False,
    default_view='graph',
    tags=['curate'],
    max_active_runs=1,   
    on_failure_callback=[sns_notifier.failure_notification] 
)

archive_data = BashOperator(
    task_id=f'archive_latest_{obj_name}_to_history',
    bash_command=archive(loan_job_name),
    dag=dag
)

glue_job = GlueJobOperator(
    job_name=loan_job_name,
    task_id = f"transform_to_curate_{obj_name}",
    verbose=False,
    dag=dag
    )

raw_layer_crawler = GlueCrawlerOperator (
        task_id = f'catalog_curate_layer_{obj_name}_data',
        config = { 
            "Name": glue_crawler_name,
        },
        poll_interval=30,
        dag=dag
    )

job_status = PythonOperator(
        task_id = f'save_{obj_name}_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': loan_job_name},
        dag=dag
    )

# Define the DAG dependencies
archive_data >> glue_job >> [raw_layer_crawler, job_status]
