from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from cb_common.utils.common import SNSNotifier

sns_notifier = SNSNotifier(region_name='us-west-2')

party_job_name = f'populateconsumption-loan-airflow'
dag_id = f'populateconsumption_loan_etl'
default_args = {
    'owner': 'SMW',
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    start_date =  datetime(2024, 3, 25),
    schedule_interval='5 6/4 * * *',
    catchup=False,
    default_view='graph',
    tags=['consumption'],
    max_active_runs=1,   
    on_failure_callback=[sns_notifier.failure_notification] 
)

loan_job = GlueJobOperator(
    job_name=party_job_name,
    task_id = f"populate_consumption_loan",
    verbose=False,
    dag=dag
    )


# Define the DAG dependencies
[loan_job]
