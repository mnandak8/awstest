import unittest
from unittest.mock import MagicMock, patch
import awswrangler as wr
from cb_common.utils.common import __read_athena_query as read, __get_job as get_job, log, archive, save_job_status, SNSNotifier
import pandas as pd
from datetime import datetime
from botocore.exceptions import ClientError

class TestCommon(unittest.TestCase):
    
    @patch('awswrangler.athena.read_sql_query')
    def test_read_athena_query(self, mock_read_sql_query):
        test_env = 'test_env'
        test_acc_num = '123456'
        mock_data = pd.DataFrame({"column1": [1, 2, 3], "column2": ["a", "b", "c"]})
        mock_read_sql_query.return_value = mock_data
        test_s3_output = f's3://cobank-dl-{test_acc_num}-us-west-2-logs-{test_env}/athena-query-results/'
        test_query = 'SELECT * FROM "raw_db"."salesforce_account"'
        test_db = 'raw_db'
        rows = read(env=test_env,acc_num=test_acc_num)
        mock_read_sql_query.assert_called()
        mock_read_sql_query.assert_called_with(
            test_query, 
            database=test_db,
            s3_output=test_s3_output, 
            ctas_approach=True
        )
        self.assertEqual(rows, 3)
        
    @patch('boto3.client')
    def test_get_job(self, mock_boto_client):
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client

        mock_glue_client.get_job.return_value = {
            'Job': {
                'Name': 'example_job',
                'Role': 'example_role',
                'CreatedOn': '2025-01-30T00:00:00.000Z',
                'LastModifiedOn': '2025-01-30T00:00:00.000Z',
                'ExecutionProperty': {
                    'MaxConcurrentRuns': 1
                },
                'Command': {
                    'Name': 'glueetl',
                    'ScriptLocation': 's3://example-bucket/scripts/example_script.py'
                },
                'DefaultArguments': {
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable'
                },
                'MaxRetries': 0
            }
        }
        
        job_info = get_job('example_job')        
        self.assertEqual(job_info, {
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable'
                })
        
        
    @patch('boto3.client')
    def test_get_job_error(self, mock_boto_client):
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client
        mock_glue_client.get_job.return_value = None        
        
        with self.assertLogs(level='ERROR') as log:
            job_info = get_job('example_job')
            self.assertIsNone(job_info)
            self.assertIn("Fail while processing job: 'NoneType' object is not subscriptable",log.output[0])

    @patch('boto3.client')
    def test_archive(self, mock_boto_client):
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client

        mock_glue_client.get_job.return_value = {
            'Job': {
                'Name': 'example_job',
                'Role': 'example_role',
                'CreatedOn': '2025-01-30T00:00:00.000Z',
                'LastModifiedOn': '2025-01-30T00:00:00.000Z',
                'ExecutionProperty': {
                    'MaxConcurrentRuns': 1
                },
                'Command': {
                    'Name': 'glueetl',
                    'ScriptLocation': 's3://example-bucket/scripts/example_script.py'
                },
                'DefaultArguments': {
                    '--objectname': None,
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable',
                    '--layer': 'test-layer',
                    '--groupname': 'test-groupname',
                    '--datasink': 'test-datasink'
                },
                'MaxRetries': 0
            }
        }
        test_result_archive = archive('example_job')
        self.assertEqual(test_result_archive, 'aws s3 cp --recursive test-datasinktest-layer/test-groupname/latest/ test-datasinktest-layer/test-groupname/history/ && aws s3 rm --recursive test-datasinktest-layer/test-groupname/latest/')
       
    @patch('boto3.client')
    def test_archive_objectname(self, mock_boto_client):
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client

        mock_glue_client.get_job.return_value = {
            'Job': {
                'Name': 'example_job',
                'Role': 'example_role',
                'CreatedOn': '2025-01-30T00:00:00.000Z',
                'LastModifiedOn': '2025-01-30T00:00:00.000Z',
                'ExecutionProperty': {
                    'MaxConcurrentRuns': 1
                },
                'Command': {
                    'Name': 'glueetl',
                    'ScriptLocation': 's3://example-bucket/scripts/example_script.py'
                },
                'DefaultArguments': {
                    '--objectname': 'objectname',
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable',
                    '--layer': 'test-layer',
                    '--groupname': 'test-groupname',
                    '--datasink': 'test-datasink'
                },
                'MaxRetries': 0
            }
        }
        test_result_archive = archive('example_job')
        self.assertEqual(test_result_archive, 'aws s3 cp --recursive test-datasinktest-groupname/objectname/latest/ test-datasinktest-groupname/objectname/history/ && aws s3 rm --recursive test-datasinktest-groupname/objectname/latest/')
     
    @patch('boto3.client')
    @patch('requests.post')
    @patch('awswrangler.athena.read_sql_query')
    def test_save_job_status(self,mock_read_sql_query,mock_post, mock_boto_client):
        mock_data = pd.DataFrame({"column1": [1, 2, 3], "column2": ["a", "b", "c"]})
        mock_read_sql_query.return_value = mock_data
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client
        date2process = datetime.today().strftime('%Y/%m/%d')
        mock_glue_client.get_job.return_value = {
            'Job': {
                'Name': 'example_job',
                'Role': 'example_role',
                'CreatedOn': '2025-01-30T00:00:00.000Z',
                'LastModifiedOn': '2025-01-30T00:00:00.000Z',
                'ExecutionProperty': {
                    'MaxConcurrentRuns': 1
                },
                'Command': {
                    'Name': 'glueetl',
                    'ScriptLocation': 's3://example-bucket/scripts/example_script.py'
                },
                'DefaultArguments': {
                    '--objectname': 'objectname',
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable',
                    '--layer': 'test-layer',
                    '--groupname': 'test-groupname',
                    '--datasink': 'test-datasink',
                    '--datasource': 'test-datasource',
                    '--date2process': date2process,
                    '--env': 'dev'
                },
                'MaxRetries': 0
            }
        }
        mock_glue_client.get_job_runs.return_value = {
            'JobRuns': [
                {
                    'Id': 'example-job-run-id',
                    'Attempt': 1,
                    'JobName': 'example-job-name',
                    'StartedOn': '2025-02-03T12:00:00Z',
                    'LastModifiedOn': '2025-02-03T12:30:00Z',
                    'CompletedOn': '2025-02-03T12:45:00Z',
                    'JobRunState': 'SUCCEEDED',
                    'Arguments': {
                        '--example-arg': 'value'
                    },
                    'ErrorMessage': '',
                    'PredecessorRuns': [],
                    'AllocatedCapacity': 2,
                    'ExecutionTime': 2700,
                    'Timeout': 2880,
                    'MaxCapacity': 10.0,
                    'WorkerType': 'Standard',
                    'NumberOfWorkers': 2,
                    'SecurityConfiguration': 'example-security-config',
                    'LogGroupName': '/aws-glue/jobs/example-job-name',
                    'NotificationProperty': {
                        'NotifyDelayAfter': 60
                    },
                    'GlueVersion': '2.0',
                    'DPUSeconds': 5400.0
                }
            ],
            'NextToken': 'example-next-token'
        }
        mock_post.return_value.status_code = 200
        test_save_job_status = save_job_status('example_job')
        self.assertIsNotNone(test_save_job_status)
        self.assertIn('200', test_save_job_status)
        self.assertIn('payload:', test_save_job_status)
        
        
    @patch('boto3.client')
    def test_save_job_status_date2process_is_none(self, mock_boto_client):
        mock_glue_client = MagicMock()
        mock_boto_client.return_value = mock_glue_client
        mock_glue_client.get_job.return_value = {
            'Job': {
                'Name': 'example_job',
                'Role': 'example_role',
                'CreatedOn': '2025-01-30T00:00:00.000Z',
                'LastModifiedOn': '2025-01-30T00:00:00.000Z',
                'ExecutionProperty': {
                    'MaxConcurrentRuns': 1
                },
                'Command': {
                    'Name': 'glueetl',
                    'ScriptLocation': 's3://example-bucket/scripts/example_script.py'
                },
                'DefaultArguments': {
                    '--objectname': 'objectname',
                    '--TempDir': 's3://example-bucket/temp/',
                    '--job-bookmark-option': 'job-bookmark-enable',
                    '--layer': 'test-layer',
                    '--groupname': 'test-groupname',
                    '--datasink': 'test-datasink',
                    '--env': 'dev'
                },
                'MaxRetries': 0
            }
        }
        test_save_job_status = save_job_status('example_job')
        self.assertIsNone(test_save_job_status)
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    def test_sns__init__(self,mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier()
        self.assertIsNotNone(test_sns_notifier)
        self.assertEqual(test_sns_notifier.sns_topic_arn, "arn:aws:sns:us-west-2:654654598303:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-dev")
        self.assertEqual(test_sns_notifier.environment, "dev")
        self.assertEqual(test_sns_notifier.acc_num, "654654598303")
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    def test_sns__init__with_sns_topic_arn(self,mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier(sns_topic_arn="arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        self.assertIsNotNone(test_sns_notifier)
        self.assertEqual(test_sns_notifier.sns_topic_arn, "arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        self.assertEqual(test_sns_notifier.environment, "dev")
        self.assertEqual(test_sns_notifier.acc_num, "654654598303")
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    @patch('logging.error')
    def test_sns_send_notification_error(self,mock_logging_error, mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_sns_client.publish.side_effect = ClientError(
            {"Error": {"Code": "500", "Message": "Internal Server Error"}},
            "Publish"
        )
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier(sns_topic_arn="arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        test_subject = "test_subject"
        test_message = "test_message"
        test_sns_notifier.send_notification(test_subject, test_message)
        mock_logging_error.assert_called_once_with("Failed to send Notification: An error occurred (500) when calling the Publish operation: Internal Server Error")
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    @patch('logging.info')
    def test_sns_send_notification_info(self,mock_logging_info, mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_sns_client.publish.return_value = {
            'MessageId': '12345abcde-6789-0abc-def1-234567890abc',
            'ResponseMetadata': {
                'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890',
                'HTTPStatusCode': 200,
                'HTTPHeaders': {
                    'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890',
                    'content-type': 'text/xml',
                    'content-length': '294',
                    'date': 'Tue, 04 Feb 2025 22:35:02 GMT'
                },
                'RetryAttempts': 0
            }
        }
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier(sns_topic_arn="arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        test_subject = "test_subject"
        test_message = "test_message"
        test_sns_notifier.send_notification(test_subject, test_message)
        mock_logging_info.assert_called_once_with("SNS notification sent: {'MessageId': '12345abcde-6789-0abc-def1-234567890abc', 'ResponseMetadata': {'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890', 'HTTPStatusCode': 200, 'HTTPHeaders': {'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890', 'content-type': 'text/xml', 'content-length': '294', 'date': 'Tue, 04 Feb 2025 22:35:02 GMT'}, 'RetryAttempts': 0}}")
        
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    @patch('logging.info')
    def test_sns_success_notification(self,mock_logging_info, mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_sns_client.publish.return_value = {
            'MessageId': '12345abcde-6789-0abc-def1-234567890abc',
            'ResponseMetadata': {
                'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890',
                'HTTPStatusCode': 200,
                'HTTPHeaders': {
                    'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890',
                    'content-type': 'text/xml',
                    'content-length': '294',
                    'date': 'Tue, 04 Feb 2025 22:35:02 GMT'
                },
                'RetryAttempts': 0
            }
        }
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier(sns_topic_arn="arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        mokc_task_intance = MagicMock()
        mokc_task_intance.task_id ="b8bbefe4-d27c-4596-9e01-35311a49b49c"
        mokc_task_intance.dag_id = "3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf"
        test_date = datetime.today().strftime('%Y/%m/%d')
        test_context = {
            "task_instance": mokc_task_intance,
            "execution_date": test_date
        }
        test_sns_notifier.success_notification(test_context)
        mock_logging_info.assert_called_once_with("SNS notification sent: {'MessageId': '12345abcde-6789-0abc-def1-234567890abc', 'ResponseMetadata': {'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890', 'HTTPStatusCode': 200, 'HTTPHeaders': {'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890', 'content-type': 'text/xml', 'content-length': '294', 'date': 'Tue, 04 Feb 2025 22:35:02 GMT'}, 'RetryAttempts': 0}}")
        mock_sns_client.publish.assert_called_once_with(TopicArn='arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing', Message=f'Task b8bbefe4-d27c-4596-9e01-35311a49b49c in DAG 3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf succeeded on {test_date} in dev', Subject='Task Succeeded: b8bbefe4-d27c-4596-9e01-35311a49b49c in DAG 3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf in dev')
        
    
        
    @patch('boto3.client')
    @patch('airflow.models.Variable.get')
    @patch('logging.info')
    def test_sns_failure_notification(self,mock_logging_info, mock_variable_get, mock_boto_client):
        mock_sns_client = MagicMock()
        mock_sns_client.publish.return_value = {
            'MessageId': '12345abcde-6789-0abc-def1-234567890abc',
            'ResponseMetadata': {
                'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890',
                'HTTPStatusCode': 200,
                'HTTPHeaders': {
                    'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890',
                    'content-type': 'text/xml',
                    'content-length': '294',
                    'date': 'Tue, 04 Feb 2025 22:35:02 GMT'
                },
                'RetryAttempts': 0
            }
        }
        mock_boto_client.return_value = mock_sns_client
        mock_variable_get.return_value = {"environment": "dev"}
        test_sns_notifier = SNSNotifier(sns_topic_arn="arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing")
        mokc_task_intance = MagicMock()
        mokc_task_intance.task_id ="b8bbefe4-d27c-4596-9e01-35311a49b49c"
        mokc_task_intance.dag_id = "3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf"
        mokc_task_intance.log_url = "https://test.url"
        test_date = datetime.today().strftime('%Y/%m/%d')
        test_context = {
            "task_instance": mokc_task_intance,
            "execution_date": test_date
        }
        test_sns_notifier.failure_notification(test_context)
        mock_logging_info.assert_called_once_with("SNS notification sent: {'MessageId': '12345abcde-6789-0abc-def1-234567890abc', 'ResponseMetadata': {'RequestId': 'abcdef12-3456-7890-abcd-ef1234567890', 'HTTPStatusCode': 200, 'HTTPHeaders': {'x-amzn-requestid': 'abcdef12-3456-7890-abcd-ef1234567890', 'content-type': 'text/xml', 'content-length': '294', 'date': 'Tue, 04 Feb 2025 22:35:02 GMT'}, 'RetryAttempts': 0}}")
        mock_sns_client.publish.assert_called_once_with(TopicArn='arn:aws:sns:us-west-2:1234567890:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-testing', Message=f'Task b8bbefe4-d27c-4596-9e01-35311a49b49c in DAG 3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf failed on {test_date} in dev with log url: https://test.url', Subject='Task Failed: b8bbefe4-d27c-4596-9e01-35311a49b49c in DAG 3c3f554b-70b4-41ac-8ec3-c8d0b06e99bf in dev')
        
    
        
        