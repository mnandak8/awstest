CONFIG = {
    "dev": {
        "acc_num": "654654598303",
        "audit_api": "https://oggebiubxi.execute-api.us-west-2.amazonaws.com/dev/audit",
        "acbs_eod_raw_schedule": None
    },
    "test": {
        "acc_num": "767398005888",
        "audit_api": "https://94n2al9wbf.execute-api.us-west-2.amazonaws.com/test/audit",
        "acbs_eod_raw_schedule": None
    },
    "preprod": {
        "acc_num": "654654411062",
        "audit_api": "https://u3ihiwxaak.execute-api.us-west-2.amazonaws.com/preprod/audit",
        "acbs_eod_raw_schedule": None
    },
    "prod": {
        "acc_num": "767397798595",
        "audit_api": "https://8yl7f468w1.execute-api.us-west-2.amazonaws.com/prod/audit",
        "acbs_eod_raw_schedule": "15 7 * * 2-6"
    }
}
