# Jobs
variable "default_settings" {
  type = object({
    enable-glue-datacatalog     = bool
    enable-metrics              = bool
    enable-spark-ui             = bool
    enable-continous-log-filter = bool
    spark-logs-path             = string
    job_role_arn                = string
    tags                        = map(string)
    max_retries                 = number
    job_timeout                 = number 
    environment                 = string
    airflow-bucket              = string
    target_log_bucket           = string
    objectname                  = string
    glue_security               = string
  })
}

variable "tooling_bucket_name" {
  type = string
}

variable "curate_validation_jobs" {
  type = map(object({
    job_name                    = optional(string)
    validation-case             = string
    groupname                   = optional(string)
  }))
}


variable "acbs_validation_jobs" {
  type = map(object({
    job_name                    = optional(string)
    validation-case             = string
    datasource                  = optional(string)
    groupname                   = optional(string)
  }))
}


variable "etl-script-s3-bucket-tags" {
  type = map(string)
  description = "s3 bucket for etl code deployment"
  default = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Data Innovation" 
  }
}


# TODO: Refactor the following variables
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
  default = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Data Innovation" 
  }
}

variable "job-role" {
  description = "The IAM role to be assumed by the Glue job"
  type        = string
}
variable "data-source-bucket" { 
  description = "The S3 bucket where the data source is stored"
  type        = string
}
variable dag_bucket {
  description = "The S3 bucket where the DAG is stored"
  type        = string
}
variable "dag_key" {
  description = "The key of the DAG file"
  type        = string
}
variable "rds_host" {
  description = "The RDS host"
  type        = string
}
variable "secret_arn" {
  description = "The secret ARN"
  type        = string
}
variable "subnet_id" {
  description = "The subnet ID"
  type        = string
}
/*
variable "egress_cidr_blocks" {
  description = "The egress cider blocks"
  type        = list(string)
}
variable "ingress_cidr_blocks" {
  description = "The ingress cider blocks"
  type        = list(string)
}
*/
variable "validation_script_bucket" {
  description = "The S3 bucket where the validation script is stored"
  type        = string
}
