from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.empty import EmptyOperator
from airflow.providers.amazon.aws.operators.appflow import AppflowRunOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from datetime import datetime,timedelta
from validation.validation_common.notifier import SNSNotifier , save_job_status
from airflow.operators.python import PythonOperator


sns_notifier = SNSNotifier(region_name='us-west-2')
dag_id = "sf2rds_data_validator_dag"
date2process = datetime.now().strftime('%Y/%m/%d')
obj_names = ['account', 'contact','recordtype','accountAddress','accountContactRelation','llcBiLoanC']
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=2),
    'catchup': False,
}
start_date = datetime.today()

with DAG(
    dag_id, 
    default_args=default_args,
    default_view='graph',
    start_date=start_date,
    schedule = '@daily',
    is_paused_upon_creation=True,
    max_active_runs=1,
    tags=["validator"],
    on_failure_callback=[sns_notifier.failure_notification],
    on_success_callback=[sns_notifier.success_notification]
) as dag:
    @task_group
    def ingest_data(objs):
        tasks = []
        for obj in objs:
            tasks.append(
                AppflowRunOperator(
                    task_id=f'{obj}_get_snapshot_task',
                    flow_name=f'salesforce_to_landing_{obj}',
                    aws_conn_id='ing_appflow',
                    wait_for_completion=True))
        
        EmptyOperator(task_id='Start_ingesting_data_tasks') >> tasks >> EmptyOperator(task_id='ingesting_data_tasks_done')

        
    glue_validation_job = GlueJobOperator(
        job_name="sf2rds_data_validation_job",
        task_id ="sf2rds_data_validation_task",
        script_args={
            "--cDate": date2process
        },
        verbose=False)
    
    job_status = PythonOperator(
        task_id = 'save_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': "sf2rds_data_validation_job"},
        dag=dag
    )
        
    ingest_data(obj_names)  >> glue_validation_job >> job_status
