CONFIG = {
    "dev": {
        "acc_num": "654654598303",
        "audit_api": "https://oggebiubxi.execute-api.us-west-2.amazonaws.com/dev/audit"
    },
    "test": {
        "acc_num": "767398005888",
        "audit_api": "https://94n2al9wbf.execute-api.us-west-2.amazonaws.com/test/audit"
    },
    "preprod": {
        "acc_num": "654654411062",
        "audit_api": "https://u3ihiwxaak.execute-api.us-west-2.amazonaws.com/preprod/audit"
    },
    "prod": {
        "acc_num": "767397798595",
        "audit_api": "http://localhost:5000/audit"
    },
    "ing": {
        "dev": {"acc_num": "471112929721"
        },
        "test": {
            "acc_num": "533267072724"
        }
    }
}