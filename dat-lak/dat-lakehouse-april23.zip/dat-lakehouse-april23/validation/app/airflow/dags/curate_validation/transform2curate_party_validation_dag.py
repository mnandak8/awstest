from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import  GlueJobOperator
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from validation.validation_common.notifier import SNSNotifier , save_job_status
from airflow.operators.python import PythonOperator

sns_notifier = SNSNotifier(region_name='us-west-2')

group_name = 'party'
job_name = 'transform2curate-validation'  #f'transform2curate-{group_name}-test-airflow'
dag_id = f'transform2curate_{group_name}_validation'

default_args = {
    'owner': 'DJ',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    description='Glue test DAG scheduled to run 13:30 and 21:30 UTC',
    schedule_interval='30 13,21 * * *',  # Run at 13:30 and 21:30 UTC
    catchup=False,
    tags=['validation'],
    start_date=start_date,
    default_view='graph',
    max_active_runs=1, 
    on_failure_callback=[sns_notifier.failure_notification] 
)

script_arguments = {
    "--groupname": group_name
}

glue_job_operator = GlueJobOperator(
    job_name=job_name,
    task_id = f"transform_to_curate_test_{group_name}",
    dag=dag,
    script_args=script_arguments
)

job_status = PythonOperator(
        task_id = 'save_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': job_name},
        dag=dag
    )

# Define tasks/operators
start_task = DummyOperator(task_id='start', dag=dag)
end_task = DummyOperator(task_id='end', dag=dag)

start_task >> glue_job_operator >> job_status >> end_task
