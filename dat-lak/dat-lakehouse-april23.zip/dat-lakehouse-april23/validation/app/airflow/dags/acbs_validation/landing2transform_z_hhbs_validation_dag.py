from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import  GlueJobOperator
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from validation.validation_common.notifier import SNSNotifier , save_job_status
from airflow.operators.python import PythonOperator

sns_notifier = SNSNotifier(region_name='us-west-2')

obj_name = 'z_hhbs'
group_name = 'acbs'
catalog_table_name = f'{group_name}_{obj_name}'
job_name = f'landing2transform-acbs-validation'  
dag_id = f'landing2transform_{group_name}_{obj_name}_validation'
date2process = datetime.now().strftime('%Y/%m/%d')

default_args = {
    'owner': 'DJ',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    dag_id=dag_id,
    default_args=default_args,
    description='Glue test DAG scheduled to run on 11:00 and 23:00 UTC',
    schedule_interval='0 11,23 * * *',  # Run at 11:00 and 23:00 UTC
    catchup=False,
    tags=['validation'],
    start_date=start_date,
    default_view='graph',
    max_active_runs=1, 
    on_failure_callback=[sns_notifier.failure_notification] 
)

script_arguments = {
    "--groupname": group_name,
    "--date2process": date2process,
    "--objectname": obj_name,
    "--catalog_table_name": catalog_table_name
}

glue_job_operator = GlueJobOperator(
    job_name=job_name,
    task_id = f"validation_{group_name}_{obj_name}_landing2transform",
    dag=dag,
    script_args=script_arguments
)

job_status = PythonOperator(
        task_id = 'save_audit_status_to_db',
        python_callable=save_job_status,
        op_kwargs={'job_name': job_name},
        dag=dag
    )


# Define tasks/operators
start_task = DummyOperator(task_id='start', dag=dag)
end_task = DummyOperator(task_id='end', dag=dag)

start_task >> glue_job_operator >> job_status >> end_task
