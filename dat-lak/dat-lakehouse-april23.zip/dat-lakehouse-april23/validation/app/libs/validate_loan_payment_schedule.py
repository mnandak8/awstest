loan_payment_source_query = """
SELECT acbs_z_hhps.z_cif as cif_num,
acbs_z_hhps.z_fobl as obligation_num,
llc_bi__account__c as party_guid, 
master_party_id__c as master_party_id, 
--acbs_z_hhps.z_we10 as effective_dt,
substr(acbs_z_hhps.z_we10, 7,4)||substr(acbs_z_hhps.z_we10, 1,2)||substr(acbs_z_hhps.z_we10, 4,2) as effective_dt,
acbs_z_hhps.zjobnbr as job_num,
--acbs_z_hhps.z_mou82 as sched_due_dt,
substr(acbs_z_hhps.z_mou82, 7,4)||substr(acbs_z_hhps.z_mou82, 1,2)||substr(acbs_z_hhps.z_mou82, 4,2) as sched_due_dt,
acbs_z_hhps.z_ffa1 as scheduled_prin_amt,
acbs_z_hhps.update_ident as update_identifier, 
tpa.tot_prin_amt
FROM transform_db.acbs_z_hhps
LEFT OUTER JOIN (SELECT distinct llc_bi__account__c, cif__c, sfa.master_party_id__c 
    FROM transform_db.salesforce_llc_bi_loan_c sflc
    JOIN transform_db.salesforce_account sfa on sfa.id=sflc.llc_bi__account__c
    JOIN transform_db.acbs_j_cams on acbs_j_cams.j_baci = sflc.Commitment_Number__c) sflc  
ON acbs_z_hhps.z_cif = sflc.cif__c 
LEFT OUTER JOIN 
(SELECT distinct z_fobl   AS   Obligation_Num, z_ffa1 AS Tot_Prin_Amt 
FROM transform_db.acbs_z_hhps WHERE  z_mou82 like'TOTAL%' ) tpa
ON tpa.Obligation_Num = acbs_z_hhps.z_fobl
WHERE transform_db.acbs_z_hhps.z_mou82  NOT LIKE 'TOTAL%' 
ORDER BY cif_num,obligation_num,effective_dt,sched_due_dt"""


loan_payment_target_query = """SELECT cif_num,
obligation_num,
party_guid, 
master_party_id, 
effective_dt,
job_num,
sched_due_dt,
scheduled_prin_amt,
update_identifier, 
tot_prin_amt
FROM curate_db.curate_loanpaymentschedule
ORDER BY cif_num,obligation_num,effective_dt"""

loan_payment_key_combination = ["cif_num","obligation_num","effective_dt","sched_due_dt"]