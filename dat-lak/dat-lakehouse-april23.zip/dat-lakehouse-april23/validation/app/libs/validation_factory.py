from datetime import datetime
from datetime import timezone
from logging import getLogger
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from read_sources import ReadSources
from validation_utils import ValidationUtilities
from validation import Validation
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from validate_party import *
from validate_loan_billing_summary import *
from validate_loan_detail import *
from validate_loan_payment_schedule import *
from validate_loan_transaction import *

class ValidationFactory:
    def __init__(self) -> None:
        self.log = getLogger(__name__)
        pass

    def spark(self):
        glue_ctx = self.glueContext()
        spark =  glue_ctx.spark_session
        spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")
        return spark
 
    def glueContext(self):
        return GlueContext(SparkContext.getOrCreate())
   
    
    def countandschemaforacbs(self, args) -> None:
        audit_columns = ['raw_utc']
        #extraction
        catalog_table_name = args.get('catalog_table_name')
        landing_latest_path = ValidationUtilities().get_latest_path_acbs(args)
        landing_df = ReadSources.read_from_bucket(self.spark(),landing_latest_path)
        raw_df = ReadSources.read_from_catalog(self.glueContext(), 'raw_db', catalog_table_name )
        transform_df = ReadSources.read_from_catalog(self.glueContext(), 'transform_db', catalog_table_name)
        print(f"Count validation between landing and raw for table: {catalog_table_name}")
        landing2Raw_count_result = Validation().count(landing_df,raw_df)
        print(f"Count validation between raw and transform for table: {catalog_table_name}")
        raw2Transform_count_result = Validation().count(raw_df,transform_df)

        ignore_columns = audit_columns + ValidationUtilities().get_partition_keys('raw_db',catalog_table_name) + ValidationUtilities().get_partition_keys('transform_db',catalog_table_name)
        print(f"Schema validation between landing and raw for table: {catalog_table_name}")
        landing2Raw_schema_result = Validation().schema(landing_df,raw_df,ignore_columns)
        print(f"Schema validation between raw and transform for table: {catalog_table_name}")
        raw2Transform_schema_result = Validation().schema(raw_df,transform_df,ignore_columns)

        if landing2Raw_count_result == 0:
            raise Exception(f"Count check failed between landing and raw for table: {catalog_table_name}")
        elif raw2Transform_count_result == 0:
            raise Exception(f"Count check failed between raw and transform for table: {catalog_table_name}")
        elif landing2Raw_schema_result == 0:
            raise Exception(f"Schema check failed between landing and raw for table: {catalog_table_name}")
        elif raw2Transform_schema_result == 0:
            raise Exception(f"Schema check failed between raw and transform for table: {catalog_table_name}")
        else:
            print("Data has no Data quality issues at landing to transorm layer")
        return 0

    def curate(self, args):
        grp_name = args.get('groupname')
        print(grp_name)
        match grp_name:
            case "party":
                source_query=party_source_query
                target_query=party_target_query
                key_combination=party_key_combination
                print(key_combination)
            case "loanDetail":
                source_query=loan_detail_source_query
                target_query=loan_detail_target_query
                key_combination=loan_detail_key_combination
            case "loanBillingSummary":
                source_query=loan_billing_source_query
                target_query=loan_billing_target_query
                key_combination=loan_billing_key_combination
            case "loanPaymentSchedule":
                source_query=loan_payment_source_query
                target_query=loan_payment_target_query
                key_combination=loan_payment_key_combination
            case "loanTransaction":
                source_query=loan_transaction_source_query
                target_query=loan_transaction_target_query
                key_combination=loan_transaction_key_combination
            case _:
                curateTestJob = None


        source_df=self.spark().sql(source_query)
        target_df=self.spark().sql(target_query)

        # Count Validation 
        print(f"Count validation between transform and curate for table: {grp_name}")
        count_result=Validation().count(source_df, target_df)
            
        #Schema Validate
        print(f"Schema validation between transform and curate for table: {grp_name}")
        schema_result=Validation().schema(source_df, target_df)

        #Data Validation
        data_result=Validation().data_validation(source_df, target_df)

        #Duplicate data Validation 
        dedup_reult=Validation().duplicate_validation(target_df,key_combination)

        #Null Validation
        null_reult=Validation().null_validation(target_df,key_combination)

        # Check if any validation result equals 0 and fail glue job
        if ((count_result == 0) or (schema_result == 0) or (data_result == 0) or (dedup_reult == 0) or (null_reult == 0)):
            print("The Glue job failed since Data quality issues found.")
            raise Exception("The Glue job failed since Data quality issues found.")
        else:
            print("Data has no dq issues")

        return 0  
                
