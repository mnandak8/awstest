loan_transaction_source_query="""Select  RTRIM(acbs_z_hhtr.j_mbui) as cif_num,
RTRIM(acbs_z_hhtr.j_mbti) as obligation_num,
RTRIM(acbs_z_hhtr.j_mpw8) as loan_tran_eff_dt,
CAST(acbs_z_hhtr.j_jgsn as Integer) as tran_ref_num,
RTRIM(acbs_z_hhtr.j_mpyc) as tran_type_cd,
RTRIM(sflc.llc_bi__account__c) as party_guid,
RTRIM(sflc.master_party_id__c) as master_party_id,
RTRIM(acbs_z_hhtr.j_mbsi) as loan_portfolio_id,
RTRIM(acbs_z_hhtr.coagv8) as process_dt,
RTRIM(acbs_z_hhtr.zjobnbr) as job_num,
RTRIM(acbs_z_hhtr.j_mpx8) as loan_tran_post_dt,
RTRIM(acbs_z_hhtr.j_nlrt) as loan_tran_desc,
TRY_CAST(acbs_z_hhtr.j_tranval as decimal(18,2)) as loan_tran_amt,
TRY_CAST(acbs_z_hhtr.z_ffa1 as decimal(18,2)) as loan_tran_new_prin_bal,
TRY_CAST(acbs_z_hhtr.z_cdzr as decimal(18,2))  as loan_tran_int_current_accruing_rt,
TRY_CAST(acbs_z_hhtr.z_ffa2 as decimal(18,2))loan_tran_accrued_interest_amt,
RTRIM(acbs_z_hhtr.z_wrfl) as colink_wireable_ind
FROM transform_db.acbs_z_hhtr 
LEFT JOIN  
    (Select distinct llc_bi__account__c, cif__c, sfa.master_party_id__c 
    from transform_db.salesforce_llc_bi_loan_c sflc
    Join transform_db.salesforce_account sfa on sfa.id=sflc.llc_bi__account__c
    Join transform_db.acbs_j_cams on acbs_j_cams.j_baci = sflc.Commitment_Number__c
    ) sflc on acbs_z_hhtr.j_mbui = sflc.cif__c
ORDER BY cif_num,obligation_num,job_num"""

loan_transaction_target_query="""SELECT cif_num,
obligation_num, 
loan_tran_eff_dt,
tran_ref_num, 
tran_type_cd,
party_guid,
master_party_id, 
loan_portfolio_id, 
process_dt, 
job_num,
loan_tran_post_dt,
loan_tran_desc, 
loan_tran_amt, 
loan_tran_new_prin_bal,
loan_tran_int_current_accruing_rt,
loan_tran_accrued_interest_amt,
colink_wireable_ind
FROM curate_db.curate_loantransaction
ORDER BY cif_num,obligation_num,tran_ref_num"""  

loan_transaction_key_combination = ["cif_num","obligation_num","job_num"]