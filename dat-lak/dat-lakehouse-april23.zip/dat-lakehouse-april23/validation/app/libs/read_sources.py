

class ReadSources:

    def read_from_catalog(glueContext,catalog_database,catalog_table_name):
        df = glueContext.create_dynamic_frame.from_catalog(database=catalog_database, table_name=catalog_table_name)
        df = df.toDF()
        return df 
    
    def read_from_bucket(spark, data_source, format='parquet', options = dict()):
        print('.......... About to read data from bucket .......... ')
        options['recursiveFileLookup'] = 'true'
        df = spark.read.load(path=data_source, format=format, **options)
        print('.......... Finished reading data from bucket .......... ')
        return df