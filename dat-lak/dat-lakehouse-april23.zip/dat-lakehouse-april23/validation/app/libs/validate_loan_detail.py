loan_detail_source_query = """select acbs_j_cums.J_MRUI as cif_num,
ltrim(rtrim(acbs_j_cams.j_bagt)) as agreement_num,
acbs_j_cams.j_baci as facility_num,
acbs_j_cams.j_bbs_ as facility_comm_amt,
acbs_j_cams.j_bao8 as facility_maturity_dt,
acbs_j_cams.j_bbu_ as facility_outstanding_bal,
acbs_j_cams.j_bbv_ as facility_available_bal,
acbs_j_cami.j_bcac as facility_active_ind,
acbs_j_clms.j_mee_ as loan_bal,
acbs_j_clms.j_mci8 as loan_eff_dt,
acbs_j_clms.j_MCJ8 as loan_maturity_dt,
acbs_j_clms.j_dhd8 as loan_rt_set_dt,
acbs_j_clms.J_MBTI as obligation_num,
acbs_j_clms.j_mck8 as rt_maturity_dt,
acbs_j_clms.j_awac as loan_active_ind,
acbs_j_clms.year|| acbs_j_clms.month||acbs_j_clms.day  as_of_dt,
sflc.master_party_id__c as master_party_id,
acbs_j_clmi.J_duec as account_nm,
acbs_j_clas.J_CDZR as loan_interest_rt,
cb.customer_outstanding_bal,
cb.customer_tot_comm_amt,
cb.customer_tot_available_bal,
ndd.loan_next_due_dt,
x.loan_next_pmt_amt,
sflc.LLC_BI__Account__c as source_system_unique_key,
loan_secondary_billing_segment_frequency_cd
from transform_db.acbs_j_cums
left join transform_db.acbs_j_cams on acbs_j_cums.J_MRUI = acbs_j_cams.J_BABI
left join transform_db.acbs_j_cami on acbs_j_cams.j_baci = acbs_j_cami.j_baci
and acbs_j_cams.j_baai = acbs_j_cami.j_baai
left join transform_db.acbs_j_clms on acbs_j_cams.j_baci = acbs_j_clms.j_mbxi
and acbs_j_cams.j_baai = acbs_j_clms.j_mbsi
left join transform_db.acbs_j_clmi on acbs_j_clms.j_mbti = acbs_j_clmi.j_mbti
and acbs_j_clms.j_mbsi = acbs_j_clmi.j_mbsi
left join transform_db.acbs_j_clas on acbs_j_clms.j_mbti = acbs_j_clas.j_ccwi
 --and acbs_j_clms.j_mbsi = acbs_j_clas.j_ccvi
and transform_db.acbs_j_clas.j_cddc = 'INTLN'
and acbs_j_clas.J_CDCC = '1' and acbs_j_clas.j_cczc in ('100', '600')  -- FILTER CRITERIA ADDED 8-2024
left join (
SELECT j_babi,
  sum(j_bbu_) AS Customer_Outstanding_Bal,
  sum(j_bbs_) AS Customer_Tot_Comm_Amt,
  sum(j_bbv_) AS Customer_Tot_Available_Bal
      FROM transform_db.acbs_j_cams
      GROUP BY acbs_j_cams.j_babi
          ) cb on acbs_j_cums.j_mrui = cb.j_babi --Aggregates balances by customer id
left join (
      select j_mori,
       max(j_mou8) as Loan_Next_Due_Dt
          from transform_db.acbs_j_clli
          where j_cxic in ('100', '600')
          group by j_mori
             ) NDD on ndd.j_mori = acbs_j_clms.J_MBTI --Gets max due date from invoice table per obligation
left join (
Select distinct lnpa.j_mori,
  Loan_Next_Pmt_Amt
from (
   Select acbs_j_clli.j_mori,
    sum(acbs_j_clli.j_mox_) over (partition by acbs_j_clli.j_mori) + sum(acbs_j_clli.j_moy_) over (partition by acbs_j_clli.j_mori) + sum(acbs_j_clli.j_moz_) over (partition by acbs_j_clli.j_mori) as Loan_Next_Pmt_Amt
   from transform_db.acbs_j_clli
    left join (
     select j_mori,
      max(j_mou8) as Loan_Next_Due_Dt
     from transform_db.acbs_j_clli
     where j_cxic in ('100', '600')
     group by j_mori
    ) MDD on mdd.j_mori = acbs_j_clli.j_mori
   where j_cxic in ('100', '600')
    and mdd.Loan_Next_Due_Dt = acbs_j_clli.j_mou8
  ) lnpa --gets to total of invoice payments.  prin, interest, fees are separate rows in the invoice table
) x on acbs_j_clms.j_mbti = x.j_mori
 
 --left join salesforce_llc_bi_loan_c sflc on acbs_j_cams.j_baci = sflc.Commitment_Number__c
--join to sfdc to get source system key (LLC_BI__Account__c= partyguid)
LEFT JOIN  
(Select distinct llc_bi__account__c, sfa.master_party_id__c, Commitment_Number__c
   from transform_db.salesforce_llc_bi_loan_c sflc
   Join transform_db.salesforce_account sfa on sfa.id=sflc.llc_bi__account__c
   ) sflc on acbs_j_cams.j_baci = sflc.Commitment_Number__c
 
LEFT JOIN
    (Select
    distinct(acbs_j_clsb.j_mnei) j_mnei,
    acbs_j_clsb.j_mnic as Loan_Secondary_Billing_Segment_Frequency_Cd
    from transform_db.acbs_j_clsb
    join
    (Select
    j_mnei,
    min(j_fmln) as MinSeq
FROM transform_db.acbs_j_clsb
GROUP BY j_mnei) MS on acbs_j_clsb.j_mnei = ms.j_mnei and acbs_J_clsb.j_fmln = ms.MinSeq
WHERE transform_db.acbs_j_clsb.j_cxec in ('100','600')) FreqCD on acbs_j_clms.j_mbti=FreqCD.j_mnei
    """

loan_detail_target_query = """SELECT  cif_num, 
  ltrim(rtrim(agreement_num)) agreement_num, 
  facility_num, 
  facility_comm_amt, 
  facility_maturity_dt, 
  facility_outstanding_bal, 
  facility_available_bal, 
  facility_active_ind, 
  loan_bal, 
  loan_eff_dt, 
  loan_maturity_dt, 
  loan_rt_set_dt, 
  obligation_num, 
  rt_maturity_dt, 
  loan_active_ind, 
  CONCAT(YEAR(CAST(to_timestamp(replace(as_of_dt, '+00:00', ''), 'yyyy-MM-dd HH:mm:ss.SSSSSS') AS DATE)), LPAD(MONTH(CAST(to_timestamp(replace(as_of_dt, '+00:00', ''), 'yyyy-MM-dd HH:mm:ss.SSSSSS') AS DATE)), 2, '0'), LPAD(DAY(CAST(to_timestamp(replace(as_of_dt, '+00:00', ''), 'yyyy-MM-dd HH:mm:ss.SSSSSS') AS DATE)), 2, '0') ) AS as_of_dt,
  master_party_id, 
  account_nm, 
  loan_interest_rt, 
  customer_outstanding_bal, 
  customer_tot_comm_amt, 
  customer_tot_available_bal, 
  loan_next_due_dt, 
  loan_next_pmt_amt, 
  source_system_unique_key, 
  loan_secondary_billing_segment_frequency_cd 
  FROM curate_db.curate_loandetail"""

loan_detail_key_combination = ["cif_num","obligation_num","facility_num"]
