loan_billing_source_query="""SELECT
acbs_z_hhbs.j_mbui as cif_num,
acbs_z_hhbs.j_axv8 as interim_statement_dt,
sflc.llc_bi__account__c as party_guid,
sflc.master_party_id__c as master_party_id, 
acbs_z_hhbs.j_mbsi as loan_portfolio_id,
acbs_z_hhbs.dsdyw8 as pmt_due_dt,
acbs_z_hhbs.zjobnbr as job_num,
acbs_z_hhbs.j_javc as currency_cd,
acbs_z_hhbs.zbsora as total_prin_amt,
acbs_z_hhbs.zbsosa as total_int_amt,
acbs_z_hhbs.zbsota as total_fees_amt,
acbs_z_hhbs.zbsoua as total_other_amt,
acbs_z_hhbs.zbsnya as grand_total_due_amt
FROM transform_db.acbs_z_hhbs
LEFT JOIN 
(Select distinct llc_bi__account__c, cif__c, sfa.master_party_id__c 
    from transform_db.salesforce_llc_bi_loan_c sflc
    Join transform_db.salesforce_account sfa on sfa.id=sflc.llc_bi__account__c
    Join transform_db.acbs_j_cams on acbs_j_cams.j_baci = sflc.Commitment_Number__c
    ) sflc on acbs_z_hhbs.j_mbui = sflc.cif__c
ORDER BY cif_num, interim_statement_dt,loan_portfolio_id"""


loan_billing_target_query="""SELECT cif_num,
   interim_statement_dt,  
   party_guid,     
   master_party_id,
   loan_portfolio_id,
   pmt_due_dt,
   job_num,
   currency_cd,    
   total_prin_amt,     
   total_int_amt,     
   total_fees_amt,     
   total_other_amt,     
   grand_total_due_amt
FROM curate_db.curate_loanbillingsummary
ORDER BY cif_num,interim_statement_dt,loan_portfolio_id"""

loan_billing_key_combination =["cif_num","loan_portfolio_id","interim_statement_dt","job_num"]