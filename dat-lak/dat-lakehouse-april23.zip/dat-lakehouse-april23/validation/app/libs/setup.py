from setuptools import setup, find_packages
 
setup(
    name='libs',
    version='0.1',
    packages=find_packages(),
    include_dirs=True,
    include_package_data=True
)
 