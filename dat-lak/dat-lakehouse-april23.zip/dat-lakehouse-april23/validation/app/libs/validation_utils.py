    
import boto3
from botocore.exceptions import ClientError
from logging import getLogger

class ValidationUtilities:
    def __init__(self) -> None:
        self.log = getLogger('logger')
        
    def get_latest_path_acbs(self, args):
        date_path = f"{args.get('date2process')}"
        data_source = args.get('datasource')
        table_name = args.get('objectname')
        prefix= 'acbs/{table_name}/{date_path}/'.format(table_name=table_name,date_path=date_path)
        latest = self.getLatest(bucket_name=data_source[5:].rstrip('/'), 
            prefix='acbs/{table_name}/{date_path}/'.format(table_name=table_name,date_path=date_path))
        if latest is None:
            self.log.error(f'No data found for {date_path}')
            return None
        latest_path = f"{data_source}{latest[:latest.rfind('/')+1]}"
        return latest_path

    def getLatest(self, bucket_name, prefix):
        s3 = boto3.client('s3')
        modified_at = lambda x: x['LastModified']
        s3_object = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        if 'Contents' in s3_object:
            last_update = max(s3_object['Contents'], key=modified_at)
            return last_update['Key']
        return None

    def get_partition_keys(self,glue_catalog_database,glue_catalog_table_name):
        '''
        This function to get schema from glue database table.
        '''
        partition_keys = []
        try:
            glue_client = boto3.client('glue')
            response = glue_client.get_table(DatabaseName=glue_catalog_database,Name=glue_catalog_table_name)
            if 'PartitionKeys' in response['Table'] and response['Table']['PartitionKeys']:
                partition_keys = [partition['Name'] for partition in response['Table']['PartitionKeys']]
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'EntityNotFoundException':
                print(f"Error: The table '{glue_catalog_table_name}' does not exist in database: '{glue_catalog_database}'")
            else:
                print(f"Unexpected error: {e}")
        return partition_keys


# args = {'date2process': '2024/07/16', 'datasource':'s3://cobank-dl-471112929721-us-west-2-landing-dev/', 'objectname' : 'j_cate'}