from logging import getLogger
from awsglue.transforms import *
from awsglue.dynamicframe import DynamicFrame

class Validation():
    def __init__(self) -> None:
        self.log = getLogger(__name__)
        pass

    # Count Validation 
    def count(self, source_df, target_df):
        source_count=source_df.count()
        print("Source Count : ",source_count)
        target_count=target_df.count()
        print("Target Count : ",target_count)
        if (source_count==target_count):
            self.log.info("Total Row count is equal between source and target.")
            result = 1
        else:
            self.log.warn("Total Row count is not equal between source and target.")
            result = 0
        return result
            
    #Schema Validation
    def schema(self,source_df,target_df,ignore_columns=[]):
        if isinstance(source_df,DynamicFrame):
            #if dataftame is DynamicFrame conver it to Spark Dataframe
            source_df = source_df.toDF()
        source_schema= {field.name:field.dataType for field in source_df.schema.fields if field.name not in ignore_columns}
        if isinstance(target_df,DynamicFrame):
            #if dataftame is DynamicFrame conver it to Spark Dataframe
            target_df = target_df.toDF()
        target_schema= {field.name:field.dataType for field in target_df.schema.fields if field.name not in ignore_columns}
        only_in_source = {k: v for k,v in source_schema.items() if k not in target_schema}
        only_in_target = {k: v for k,v in target_schema.items() if k not in source_schema}
        mismatched_types = {k: (source_schema[k], target_schema[k]) for k in source_schema if k in target_schema and source_schema[k] != target_schema[k]}
        if not only_in_source and not only_in_target and not mismatched_types:
            print("Schema matches")
            result=1
        else:
            if only_in_source:
                print(f"Schema do not match: between source and target: Columns only in source: {only_in_source}")
                result=0
            if only_in_target:
                print(f"Schema do not match: between source and target: Columns only in target: {only_in_target}")
                result=0
            if mismatched_types:
                print(f"Schema do not match (DataType mismatch): Column(s): {mismatched_types}")
                result=0
        return result

    #Data Validation
    def data_validation(self, source_df, target_df):
        src_diff_df = source_df.subtract(target_df)
        tar_diff_df = target_df.subtract(source_df)
        if ((src_diff_df.count()==0) & (tar_diff_df.count()==0)):
            self.log.info("Data is identical between source and target.")
            result = 1
        else:
            self.log.warn("Data is not identical between source and target.")
            result = 0
        return result

    #Duplicate data Validation 
    def duplicate_validation(self, target_df,key_combination):
        target_count=target_df.count()
        dedup_df= target_df.dropDuplicates(key_combination)
        if ((dedup_df.count()==target_count)):
            self.log.info("No duplicate rows exists in target.")
            result = 1
        else:
            self.log.warn("Duplicate rows found in target.")
            result = 0
        return result
       
    #Null Validation 
    def null_validation(self, target_df,key_combination):
        dropped_df= target_df.na.drop(subset=key_combination, how="all")
        target_count=target_df.count()
        #dropped_df= df_Target.na.drop() #Drop rows with null values 
        if ((dropped_df.count()==target_count)):
            self.log.info("No null values in target combination of key columns.")
            result = 1
        else:
            self.log.warn("Null values found in target combination of key columns.")
            result = 0
        return result