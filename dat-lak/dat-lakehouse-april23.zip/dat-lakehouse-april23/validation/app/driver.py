import sys
from awsglue.utils import getResolvedOptions
from validation_factory import ValidationFactory

def main():
    validation_case = getResolvedOptions(sys.argv, ['JOB_NAME', 'validation_case'])
    factory = ValidationFactory()
    match validation_case.get('validation_case'):
        case 'countandschemaforacbs':
            args = getResolvedOptions(sys.argv, ['JOB_NAME', 'datasource',  'date2process', 'catalog_table_name','groupname', 'objectname'])
            job = factory.countandschemaforacbs(args)
        case 'curate':
            args = getResolvedOptions(sys.argv, ['JOB_NAME', 'groupname'])
            job = factory.curate(args)                      
        case _:
            raise Exception(f'Invalid layer name: {args.get("layer")}. Valid layer names are: raw, transorm, curate, consumption, test_raw and test_transform')


if __name__ == '__main__':
    main()


