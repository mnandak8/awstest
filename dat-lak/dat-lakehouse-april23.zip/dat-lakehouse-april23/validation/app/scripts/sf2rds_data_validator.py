import sys
import json
import boto3
from botocore.exceptions import ClientError
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from datetime import datetime

class SF2RDSValidator:
	def __init__(self, args): 
		secrets = self.__secrets(args.get('secretArn'), args.get('region'))
		self.dbEndpoint = f"jdbc:postgresql://{secrets['host']}:{secrets['port']}/Salesforce"
		self.s3Bucket = args.get('sourceBucket')
		self.user = secrets['username']
		self.password = secrets['password']
		self.cDate = args.get('cDate')
		self.jobName = args.get('JOB_NAME')
		# log = PySparkLogger.getLogger(__name__)
		
		pass

	def __secrets(self, secretArn, region):
		session = boto3.session.Session()
		client = session.client(service_name='secretsmanager', region_name=region)
		try:
			response = client.get_secret_value(SecretId=secretArn)
			if 'SecretString' in response:
				secret = response['SecretString']
			else:
				secret = response['SecretBinary'].decode('utf-8')

			return json.loads(secret)
		except ClientError as e:
			raise e
	
	def __getLatest(self, prefix):
		s3 = boto3.client('s3')
		modified_at = lambda x: x['LastModified']
		s3_object = s3.list_objects_v2(Bucket=self.s3Bucket, Prefix=prefix)
		if 'Contents' in s3_object:
			last_update = max(s3_object['Contents'], key=modified_at)['Key']
			return f"s3://{self.s3Bucket}/{last_update[:last_update.rfind('/')+1]}"
		return None
	
	def __readRds(self, spark, tableName):
		df = spark.read.jdbc(
			url= self.dbEndpoint,
			table=tableName,
			properties={
				"user": self.user,
				"password": self.password,
				"driver": "org.postgresql.Driver"
			})
		return df
	
	def __readS3(self, spark, key, dt):
		prefix = f'{key}/{dt}/'
		df = spark.read.option('recursiveFileLookup', 'true').parquet(self.__getLatest(prefix))
		return df

	def validate(self, objects, clmns):
		        
		start_time = datetime.now()
		## Initialize spark configs
		sc = SparkContext()
		glue_context = GlueContext(sc)
		spark = glue_context.spark_session
		job = Job(glue_context)
		log = glue_context.get_logger()
		job.init(self.jobName)

		for key, tbl in objects:
			df_rds = self.__readRds(spark, tbl)
			log.info(f"rds {tbl[4:]} table row count: {df_rds.count()}")
			df_sf = self.__readS3(spark, key, self.cDate)
			log.info(f"sf {tbl[4:]} table row count: {df_sf.count()}")
			
			log.info(f"rds & sf schemas in sync? {df_sf.schema == df_rds.schema}")
			log.info(f"columns in rds but missing in sf: {set(df_rds.columns) - set(df_sf.columns)}")
			log.info(f"columns in fs but missing in rds: {set(df_sf.columns) - set(df_rds.columns)}")
			df_trimed = df_rds.drop(*clmns)
			rdsOnlyCols = set(df_trimed.columns) - set(df_sf.columns)
			sfOnlyCols = set(df_sf.columns) - set(df_rds.columns)
			log.info(f"columns in rds but missing in sf after triming: {rdsOnlyCols}")
			if (len(rdsOnlyCols) == 0 | len(sfOnlyCols) ==0):
				sf_exclusive = df_sf.subtract(df_trimed)
				rds_exclusive = df_trimed.subtract(df_sf)
				sf_only_count=sf_exclusive.count()
				rds_only_count=rds_exclusive.count()
				log.info(f"rds & sf data for {tbl[4:]} table in sync? {sf_only_count==0 and rds_only_count==0}")
				log.info(f"records in sf not in rds for {tbl[4:]} table with count: {sf_only_count}")
				log.info(f"records in rds not in sf for {tbl[4:]} table with count: {rds_only_count}")
			log.info('===============================================================================================')
		job.commit()

		end_time = datetime.now()
		duration = ((end_time - start_time).total_seconds() / 60)
		log.info(f'Salesforce_validation Job completed in {duration:.2f} minutes')


if __name__ == "__main__":
	args = getResolvedOptions(sys.argv, ['JOB_NAME','sourceBucket','cDate','secretArn','region'])
	objects = [
			('salesforce/account/salesforce_to_landing_account','dbo.account'),
			('salesforce/contact/salesforce_to_landing_contact','dbo.contact'),
			('salesforce/recordtype/salesforce_to_landing_recordtype','dbo.recordtype'),
			('salesforce/account_address_c/salesforce_to_landing_accountAddress','dbo.account_address__c'),
			('salesforce/account_contact_relation/salesforce_to_landing_accountContactRelation','dbo.accountcontactrelation'),
			('salesforce/llc_bi_loan_c/salesforce_to_landing_llcBiLoanC','dbo.llc_bi__loan__c')]
	clmns = ['execution_user', 'load_operation', 'update_timestamp', 'raw_utc', 'load_timestamp']
	sf2rds = SF2RDSValidator(args=args)
	sf2rds.validate(objects=objects, clmns=clmns)