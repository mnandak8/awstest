
data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
}

module "curate_validation_glue_job" {
    depends_on = [ aws_s3_object.zipupload, aws_s3_object.driverupload ]
    for_each = var.curate_validation_jobs
    source = "./modules/curate_validation"
    glue-job-name               =  each.key
    validation-case             = each.value.validation-case
    groupname                   = each.value.groupname
    environment                 = var.default_settings.environment
    glue-job-tags               = var.default_settings.tags
    glue-job-role               = var.default_settings.job_role_arn
    glue-job-timeout            = var.default_settings.job_timeout
    glue-job-max-retries        = var.default_settings.max_retries
    enable-metrics              = var.default_settings.enable-metrics
    enable-spark-ui             = var.default_settings.enable-spark-ui
    spark-logs-path             = "${var.default_settings.spark-logs-path}${each.key}/"
    extra-py-files              = "s3://${var.default_settings.target_log_bucket}/validation/library/libs.zip"
    etl-script-location         = "s3://${var.default_settings.target_log_bucket}/validation/driver/driver.py"
    enable-continous-log-filter = var.default_settings.enable-continous-log-filter
    glue-security-configuration-name = var.default_settings.glue_security
}

module "acbs_validation_glue_job" {
    depends_on = [ aws_s3_object.zipupload, aws_s3_object.driverupload ]
    for_each = var.acbs_validation_jobs
    source = "./modules/acbs_validation"
    glue-job-name               =  each.key
    validation-case             = each.value.validation-case
    datasource                  = each.value.datasource
    environment                 = var.default_settings.environment
    glue-job-tags               = var.default_settings.tags
    glue-job-role               = var.default_settings.job_role_arn
    glue-job-timeout            = var.default_settings.job_timeout
    glue-job-max-retries        = var.default_settings.max_retries
    enable-metrics              = var.default_settings.enable-metrics
    enable-spark-ui             = var.default_settings.enable-spark-ui
    spark-logs-path             = "${var.default_settings.spark-logs-path}${each.key}/"
    extra-py-files              = "s3://${var.default_settings.target_log_bucket}/validation/library/libs.zip"
    etl-script-location         = "s3://${var.default_settings.target_log_bucket}/validation/driver/driver.py"
    enable-continous-log-filter = var.default_settings.enable-continous-log-filter
    glue-security-configuration-name = var.default_settings.glue_security
}

data "archive_file" "source" {
  type        = "zip"
  source_dir  = "./app/libs"
  output_path = "./app/libs.zip"
}


# upload zip to s3 and then update lamda function from s3
# parameterise the bucket name
resource "aws_s3_object" "zipupload" {
  bucket = var.default_settings.target_log_bucket
  key    = "validation/library/libs.zip"
  source = "${data.archive_file.source.output_path}" 
  source_hash = data.archive_file.source.output_base64sha256
  # source_hash = filemd5("${data.archive_file.source.output_path}")
  
}

# parameterise the bucket name
resource "aws_s3_object" "driverupload" {
  bucket = var.default_settings.target_log_bucket
  key    = "validation/driver/driver.py"
  source = "./app/driver.py" 
  source_hash = filemd5("./app/driver.py" )
}


resource "aws_s3_object" "acbs_upload_dags" {
  for_each = fileset("./app/airflow/dags/acbs_validation", "*.py")
  bucket = var.default_settings.airflow-bucket 
  key    = "dags/validation/acbs_validation/${each.key}"
  source = "./app/airflow/dags/acbs_validation/${each.key}"
  source_hash = filemd5("./app/airflow/dags/acbs_validation/${each.key}")
}

resource "aws_s3_object" "curate_upload_dags" {
  for_each = fileset("./app/airflow/dags/curate_validation", "*.py")
  bucket = var.default_settings.airflow-bucket
  key    = "dags/validation/curate_validation/${each.key}"
  source = "./app/airflow/dags/curate_validation/${each.key}"
  source_hash = filemd5("./app/airflow/dags/curate_validation/${each.key}")
}

resource "aws_s3_object" "validation_utils_upload" {
  for_each = fileset("./app/airflow/dags/validation_common", "*.py")
  bucket = var.default_settings.airflow-bucket
  key    = "dags/validation/validation_common/${each.key}"
  source = "./app/airflow/dags/validation_common/${each.key}"
  source_hash = filemd5("./app/airflow/dags/validation_common/${each.key}")
}

# salesforce to rds validation
module "sf2rds_validation" {
  source                    = "./modules/sf2rds_validation"
  job-role                  = var.job-role
  data-source-bucket        = var.data-source-bucket
  environment               = var.default_settings.environment
  dag_bucket                = var.dag_bucket
  dag_key                   = var.dag_key
  rds_host                  = var.rds_host
  subnet_id                 = var.subnet_id
  secret_arn                = var.secret_arn
  validation_script_bucket  = var.validation_script_bucket
}