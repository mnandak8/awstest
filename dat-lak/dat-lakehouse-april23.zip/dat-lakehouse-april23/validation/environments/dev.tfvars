default_settings = {
    enable-glue-datacatalog     = true
    enable-metrics              = false
    enable-spark-ui             = true
    enable-continous-log-filter = false
    spark-logs-path             = "s3://cobank-dl-654654598303-us-west-2-logs-dev/"
    job_role_arn                = "arn:aws:iam::654654598303:role/cobank-dev-glue-role"
    tags                        = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation" 
    }
    max_retries                 = 0
    job_timeout                 = 2800
    environment                 = "dev"
    glue-table-prefix           = "na"
    objectname                  = "na"
    airflow-bucket              = "cobank-dl-654654598303-us-west-2-airflow-dev"
    target_log_bucket           = "cobank-dl-654654598303-us-west-2-tooling-dev"
    glue_security               = "glue_security_configuration-dev"
}


tooling_bucket_name = "cobank-dl-654654598303-us-west-2-tooling-dev"
curate_validation_jobs = {
      "transform2curate-validation" = {
        validation-case = "curate"
        groupname = "xyz"
    },  
}
acbs_validation_jobs = {
      "landing2transform-acbs-validation" = {
        validation-case = "countandschemaforacbs"
        datasource ="s3://cobank-dl-471112929721-us-west-2-landing-dev/"
    },  
}

# salesforce to rds validation
job-role                 = "arn:aws:iam::654654598303:role/cobank-dev-glue-role"
data-source-bucket       = "cobank-dl-471112929721-us-west-2-landing-dev"
dag_bucket               = "cobank-dl-654654598303-us-west-2-airflow-dev"
dag_key                  = "dags/validation/sf2rds_validation_dag.py"
rds_host                 = "cobank-590184072445-rds-proxy-ods-dev.proxy-c96wwwa2i2gu.us-west-2.rds.amazonaws.com"
secret_arn               = "arn:aws:secretsmanager:us-west-2:590184072445:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-dev-JCcSTY"
subnet_id                = "subnet-0a21e91a3e4c26ac8"
validation_script_bucket = "cobank-dl-654654598303-us-west-2-glue-etl-script-dev"