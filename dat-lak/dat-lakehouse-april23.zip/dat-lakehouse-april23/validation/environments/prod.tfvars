default_settings = {
    enable-glue-datacatalog     = true
    enable-metrics              = false
    enable-spark-ui             = true
    enable-continous-log-filter = false
    spark-logs-path             = "s3://cobank-dl-767397798595-us-west-2-logs-prod/"
    job_role_arn                = "arn:aws:iam::767397798595:role/cobank-prod-glue-role"
    tags                        = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation" 
    }
    max_retries                 = 0
    job_timeout                 = 2800
    environment                 = "prod"
    glue-table-prefix           = "na"
    objectname                  = "na"
    airflow-bucket              = "cobank-dl-767397798595-us-west-2-airflow-prod"
    target_log_bucket           = "cobank-dl-767397798595-us-west-2-tooling-prod"
    glue_security               = "glue_security_configuration-prod"
}

tooling_bucket_name = "cobank-dl-767397798595-us-west-2-tooling-prod"
curate_validation_jobs = {
      "transform2curate-validation" = {
        validation-case = "curate"
        groupname = "xyz"
    },  
}
acbs_validation_jobs = {
      "landing2transform-acbs-validation" = {
        validation-case = "countandschemaforacbs"
        datasource ="s3://cobank-dl-654654446028-us-west-2-landing-prod/"
    },  
}

# salesforce to rds validation
job-role                 = "arn:aws:iam::767397798595:role/cobank-prod-glue-role"
data-source-bucket       = "cobank-dl-654654446028-us-west-2-landing-prod"
dag_bucket               = "cobank-dl-767397798595-us-west-2-airflow-prod"
dag_key                  = "dags/validation/sf2rds_validation_dag.py"
rds_host                 = "cobank-767397911309-rds-proxy-endpoint-ods-prod.endpoint.proxy-ctuyq6iok2oi.us-west-2.rds.amazonaws.com"
secret_arn               = "arn:aws:secretsmanager:us-west-2:767397911309:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-prod-yBe0dp"
subnet_id                = "subnet-0fd78011b9e2a54c0"
validation_script_bucket = "cobank-dl-767397798595-us-west-2-glue-etl-script-prod"
