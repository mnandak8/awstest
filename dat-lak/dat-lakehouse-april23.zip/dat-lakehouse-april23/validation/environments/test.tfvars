default_settings = {
    enable-glue-datacatalog     = true
    enable-metrics              = false
    enable-spark-ui             = true
    enable-continous-log-filter = false
    spark-logs-path             = "s3://cobank-dl-767398005888-us-west-2-logs-test/"
    job_role_arn                = "arn:aws:iam::767398005888:role/cobank-test-glue-role"
    tags                        = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation" 
    }
    max_retries                 = 0
    job_timeout                 = 2800
    environment                 = "test"
    glue-table-prefix           = "na"
    objectname                  = "na"
    airflow-bucket              = "cobank-dl-767398005888-us-west-2-airflow-test"
    target_log_bucket           = "cobank-dl-767398005888-us-west-2-tooling-test"
    glue_security               = "glue_security_configuration-test"
}

tooling_bucket_name = "cobank-dl-767398005888-us-west-2-tooling-test"
curate_validation_jobs = {
      "transform2curate-validation" = {
        validation-case = "curate"
        groupname = "xyz"
    },  
}
acbs_validation_jobs = {
      "landing2transform-acbs-validation" = {
        validation-case = "countandschemaforacbs"
        datasource ="s3://cobank-dl-533267072724-us-west-2-landing-test/"
    },  
}

# salesforce to rds validation
job-role                 = "arn:aws:iam::767398005888:role/cobank-test-glue-role"
data-source-bucket       = "cobank-dl-533267072724-us-west-2-landing-test"
dag_bucket               = "cobank-dl-767398005888-us-west-2-airflow-test"
dag_key                  = "dags/validation/sf2rds_validation_dag.py"
rds_host                 = "cobank-905418335811-rds-proxy-endpoint-ods-test.endpoint.proxy-cxeo0ycaorz4.us-west-2.rds.amazonaws.com"
secret_arn               = "arn:aws:secretsmanager:us-west-2:905418335811:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-test-blyihK"
subnet_id                = "subnet-0ad8831b6c443b00b"
validation_script_bucket = "cobank-dl-767398005888-us-west-2-glue-etl-script-test"
