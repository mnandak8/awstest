default_settings = {
    enable-glue-datacatalog     = true
    enable-metrics              = false
    enable-spark-ui             = true
    enable-continous-log-filter = false
    spark-logs-path             = "s3://cobank-dl-654654411062-us-west-2-logs-preprod/"
    job_role_arn                = "arn:aws:iam::654654411062:role/cobank-preprod-glue-role"
    tags                        = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation" 
    }
    max_retries                 = 0
    job_timeout                 = 2800
    environment                 = "preprod"
    glue-table-prefix           = "na"
    objectname                  = "na"
    airflow-bucket              = "cobank-dl-654654411062-us-west-2-airflow-preprod"
    target_log_bucket           = "cobank-dl-654654411062-us-west-2-tooling-preprod"
    glue_security               = "glue_security_configuration-preprod"
}

tooling_bucket_name = "cobank-dl-654654411062-us-west-2-tooling-preprod"
curate_validation_jobs = {
      "transform2curate-validation" = {
        validation-case = "curate"
        groupname = "xyz"
    },  
}
acbs_validation_jobs = {
      "landing2transform-acbs-validation" = {
        validation-case = "countandschemaforacbs"
        datasource ="s3://cobank-dl-211125365237-us-west-2-landing-preprod/"
    },  
}

# salesforce to rds validation
job-role                 = "arn:aws:iam::654654411062:role/cobank-preprod-glue-role"
data-source-bucket       = "cobank-dl-211125365237-us-west-2-landing-preprod"
dag_bucket               = "cobank-dl-654654411062-us-west-2-airflow-preprod"
dag_key                  = "dags/validation/sf2rds_validation_dag.py"
rds_host                 = "cobank-905418043661-rds-proxy-endpoint-ods-preprod.endpoint.proxy-cfmu2i8kac4e.us-west-2.rds.amazonaws.com"
secret_arn               = "arn:aws:secretsmanager:us-west-2:905418043661:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-preprod-JoJIKU"
subnet_id                = "subnet-02f2c78618d40e397"
validation_script_bucket = "cobank-dl-654654411062-us-west-2-glue-etl-script-preprod"

