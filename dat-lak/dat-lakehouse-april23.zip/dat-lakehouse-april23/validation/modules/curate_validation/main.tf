resource "aws_glue_job" "glue-job" {
  name = var.glue-job-name
  role_arn =var.glue-job-role 
  description = "glue job to perform curate validation"
  max_retries = var.glue-job-max-retries
  timeout = var.glue-job-timeout
  
  command {
    script_location = var.etl-script-location
    python_version = local.python-version
  }
  execution_property {
    max_concurrent_runs = local.glue-max-concurrent-runs
  }
  glue_version = local.glue-version

  default_arguments = {
    "--enable-continous-log-filter"     = var.enable-continous-log-filter
    "--extra-py-files"                  = var.extra-py-files
    "--enable-metrics"                  = var.enable-metrics
    "--enable-glue-datacatalog"         = var.enable-glue-datacatalog
    "--enable-spark-ui"                 = var.enable-spark-ui
    "--spark-event-logs-path"           = var.spark-logs-path
    "--env"                            = var.environment
    "--enable-auto-scaling"            = true
    "--validation_case"                = var.validation-case
    "--groupname"                     = var.groupname
  }
  worker_type       = "G.1X"
  number_of_workers = "10"

  tags = var.glue-job-tags
  security_configuration = var.glue-security-configuration-name
}

# module "log-group" {
#   source = "../aws_services/cloudwatch"
#   account_num = data.aws_caller_identity.current-identity.account_id
#   aws_region  = data.aws_region.current-region.name
#   job-name    = var.glue-job-name
#   cloudwatch_key-alias = "alias/key-${var.glue-job-name}"
#   cloudwatch-log-group-name = "/aws-glue/datalake/jobs/${var.glue-job-name}/log_group"
#   coudwatch-tags = var.glue-job-tags
# }

