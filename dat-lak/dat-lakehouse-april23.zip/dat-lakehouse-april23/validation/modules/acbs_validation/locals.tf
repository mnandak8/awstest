locals {
  glue-max-concurrent-runs = 10
  aws-policy-service-role-AWSGlueServiceRole = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
  python-version = 3
  glue-version = "4.0"
  glue-role-name = "AWSGlueServiceRole-ETL-Layers"
  glue-role-policy-name = "Glue-ETLS3Access"
}