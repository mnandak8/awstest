variable "environment" {
  type = string
  description = "specify the environment to deploy the resources"
}


# Glue Job
variable "glue-job-name" {
  type = string
  nullable = false
}
variable "glue-job-role" {
  type = string
  nullable = false
  
}
variable "glue-job-max-retries" {
  type = number
  nullable = false
}
variable "glue-job-timeout" {
  type = number
  nullable = false
}
variable "glue-job-tags" {
  type = map(string)
}
variable "etl-script-location" {
  type = string
  nullable = false
}
variable "extra-py-files" {
  type = string
  nullable = false
}

variable "date-to-process" {
  type = string
  default = "2024/03/30"
  description = "specifys the date to be ingested or processed"
}

variable "enable-continous-log-filter" {
  type = bool
} 

variable "validation-case" {
  type = string
  nullable = false
  description = "validation case name"
}

variable "enable-metrics" {
  type = bool
}
variable "enable-spark-ui" {
  type = bool
}
variable "spark-logs-path" {
  type = string
}


# Glue catalog
variable "enable-glue-datacatalog" {
  type = bool
  default = true
}

variable "glue-security-configuration-name" {
  type = string
}

variable "datasource" {
  type = string
  default = "2024/03/30"
}

variable "catalog_table_name" {
  type = string
  default = "2024/03/30"
}

variable "groupname" {
  type = string
  default = "2024/03/30"
}

variable "objectname" {
  type = string
  default = "2024/03/30"
}

