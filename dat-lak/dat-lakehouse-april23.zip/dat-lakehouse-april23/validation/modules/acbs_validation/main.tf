resource "aws_glue_job" "glue-job" {
  name = var.glue-job-name
  role_arn =var.glue-job-role 
  description = "glue job to perform acbs validation"
  max_retries = var.glue-job-max-retries
  timeout = var.glue-job-timeout
  
  command {
    script_location = var.etl-script-location
    python_version = local.python-version
  }
  execution_property {
    max_concurrent_runs = local.glue-max-concurrent-runs
  }
  glue_version = local.glue-version

  default_arguments = {
    "--enable-continous-log-filter"     = var.enable-continous-log-filter
    "--extra-py-files"                  = var.extra-py-files
    "--enable-metrics"                  = var.enable-metrics
    "--enable-spark-ui"                 = var.enable-spark-ui
    "--spark-event-logs-path"           = var.spark-logs-path
    "--enable-glue-datacatalog"         = var.enable-glue-datacatalog
    "--env"                            = var.environment
    "--validation_case"                 = var.validation-case
    "--enable-auto-scaling"            = true
    "--datasource"                     = var.datasource
    "--date2process"                  = var.date-to-process
    "--catalog_table_name"            = var.catalog_table_name
    "--groupname"                      = var.groupname
    "--objectname"                    = var.objectname
  }
  worker_type       = "G.1X"
  number_of_workers = "10"

  tags = var.glue-job-tags
  security_configuration = var.glue-security-configuration-name
}

# module "log-group" {
#   source = "../aws_services/cloudwatch"
#   account_num = data.aws_caller_identity.current-identity.account_id
#   aws_region  = data.aws_region.current-region.name
#   job-name    = var.glue-job-name
#   cloudwatch_key-alias = "alias/key-${var.glue-job-name}"
#   cloudwatch-log-group-name = "/aws-glue/datalake/jobs/${var.glue-job-name}/log_group"
#   coudwatch-tags = var.glue-job-tags
# }

data "aws_cloudwatch_log_group" "acbs_validation_glue_job_error_log_group" {
  name = "/aws-glue/jobs/${var.glue-security-configuration-name}-role/cobank-${var.environment}-glue-role/error"
}
data "aws_cloudwatch_log_group" "acbs_validation_glue_job_output_log_group" {
  name = "/aws-glue/jobs/${var.glue-security-configuration-name}-role/cobank-${var.environment}-glue-role/output"
}

resource "null_resource" "update_output_log_group_config" {
  triggers = {
    log_group_name = data.aws_cloudwatch_log_group.acbs_validation_glue_job_output_log_group.name
  }

  provisioner "local-exec" {
    command = <<EOT
      aws logs tag-log-group \
        --log-group-name "${data.aws_cloudwatch_log_group.acbs_validation_glue_job_output_log_group.name}" \
        --tags "Splunk=${true}"
    EOT
  }
}
resource "null_resource" "update_error_log_group_config" {
  triggers = {
    log_group_name = "${data.aws_cloudwatch_log_group.acbs_validation_glue_job_error_log_group.name}"
  }

  provisioner "local-exec" {
    command = <<EOT
      aws logs tag-log-group \
        --log-group-name "${data.aws_cloudwatch_log_group.acbs_validation_glue_job_error_log_group.name}" \
        --tags "Splunk=${true}"
    EOT
  }
}


