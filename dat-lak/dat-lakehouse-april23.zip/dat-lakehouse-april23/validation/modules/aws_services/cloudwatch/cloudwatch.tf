resource "aws_kms_key" "cloudwatch-kms-key" {
  description = "KMS key CloudWatch Logs"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${var.account_num}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${var.aws_region}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}
resource "aws_kms_alias" "cloudwatch-kms-key-alias"{
  name          = var.cloudwatch_key-alias 
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}

resource "aws_cloudwatch_log_group" "cloudwatch-log-group" {
  name              = var.cloudwatch-log-group-name 
  retention_in_days = 365
  kms_key_id = aws_kms_key.cloudwatch-kms-key.arn
  tags = merge(var.coudwatch-tags, {Splunk = true})
}