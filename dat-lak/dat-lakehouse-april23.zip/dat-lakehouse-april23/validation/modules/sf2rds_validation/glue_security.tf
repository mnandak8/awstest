resource "aws_kms_key" "this" {
  description = "KMS key glue job"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${data.aws_caller_identity.this.id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${data.aws_region.this.name}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}

resource "aws_kms_alias" "this" {
  name          = "alias/sf2rds_validation_key_glue_job"
  target_key_id = aws_kms_key.this.key_id
}

resource "aws_glue_security_configuration" "this" {
    depends_on = [ aws_kms_alias.this ]
    name = local.security_name

    encryption_configuration {
        cloudwatch_encryption {
            cloudwatch_encryption_mode    = "SSE-KMS"
            kms_key_arn                   = aws_kms_key.this.arn
        }
        job_bookmarks_encryption {
            job_bookmarks_encryption_mode = "CSE-KMS"
            kms_key_arn                   = aws_kms_key.this.arn
        }
        s3_encryption {
            s3_encryption_mode            = "SSE-KMS"
            kms_key_arn                   = aws_kms_key.this.arn
            }
  }
}