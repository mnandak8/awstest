locals {
    glue-max-concurrent-runs = 1
    python-version = 3
    glue-version = "4.0"
    job-name = "sf2rds_data_validation_job"
    security_name = "sf2rds_validation_glue_security_configuration"
    job-max-retries = 0
    resource_suffix = "sf2rds_validation"
    glue-job-script = "${path.root}/app/scripts/sf2rds_data_validator.py"
    dag-script = "${path.root}/app/airflow/dags/sf2rds/sf2rds_validation_dag.py"
    validation_script_key = "scripts/sf2rds_data_validator.py"
    worker_type       = "G.1X"
    number_of_workers = "2"
    /*validator_job_tags = {
        "cobank:cost-allocation:cost-center" = "8030",
        "cobank:operations:support-group"    = "Data Innovation"
    }*/
    glue-job-script-args = {
        "--job-language"          = "python"
        "--sourceBucket"         = var.data-source-bucket
        "--env"                  = var.environment
        "--enable-auto-scaling"  = true
        "--secretArn"           = var.secret_arn
        "--region"               = data.aws_region.this.name
        "--cDate"                = "2024/08/22"
  }
}