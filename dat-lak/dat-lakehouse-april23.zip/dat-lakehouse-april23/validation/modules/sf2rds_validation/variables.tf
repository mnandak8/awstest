variable "job-role" {
  description = "Role ARN for the glue job"
  type        = string
}

variable "data-source-bucket" {
  description = "S3 location of the data source bucket"
  type        = string
}

variable "environment" {
  description = "Environment"
  type        = string
}

variable "dag_bucket" {
  description = "S3 bucket for the dag script"
  type        = string
}

variable "dag_key" {
  description = "S3 path for the dag script"
  type        = string
}

variable "secret_arn" {
  description = "Secret manager arn"
  type        = string
}

variable "rds_host" {
  description = "RDS host"
  type        = string
}
variable "rds_port" {
  description = "RDS port"
  type        = number
  default = 5432
}

variable "subnet_id" {
  description = "Subnet id"
  type        = string
}

variable "egress_cidr_blocks" {
  description = "Egress cider blocks"
  type        = list(string)
  default = ["0.0.0.0/0"]
}
/*
variable "ingress_cidr_blocks" {
  description = "Ingress cider blocks"
  type        = list(string)
}
*/
variable "validation_script_bucket" {
  description = "S3 bucket for the validation script"
  type        = string
}