resource "aws_security_group" "connection_security_group" {
  # checkov:skip=CKV2_AWS_5: This security group is connected to the Glue connection.
  name        = "cobank-dl-rds-connection-security-${local.resource_suffix}-${var.environment}"
  description = "Allow Traffic for the ${local.resource_suffix} Glue connection"
  vpc_id      = data.aws_subnet.subnet.vpc_id
}

resource "aws_security_group_rule" "connection_security_group_egr1" {
  type              = "egress"
  description       = "Allow PostgreSQL Traffic Out of Connector"
  security_group_id = aws_security_group.connection_security_group.id
  from_port         = "-1"
  to_port           = "-1"
  protocol          = "-1"
  cidr_blocks       = var.egress_cidr_blocks
}

resource "aws_security_group_rule" "connection_security_group_ing1" {
  type              = "ingress"
  description       = "Allow all traffic into Connector"
  security_group_id = aws_security_group.connection_security_group.id
  from_port         = "-1"
  to_port           = "-1"
  protocol          = "-1"
  self              = true
}

resource "aws_glue_connection" "connection" {
  name = "cobank-dl-rds-connection-${local.resource_suffix}-${var.environment}"
  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:postgresql://${var.rds_host}:${var.rds_port}/Salesforce"
    SECRET_ID           = var.secret_arn
  }
  physical_connection_requirements {
    subnet_id = data.aws_subnet.subnet.id
    security_group_id_list = [
      aws_security_group.connection_security_group.id
    ]
    availability_zone = data.aws_subnet.subnet.availability_zone
  }
}