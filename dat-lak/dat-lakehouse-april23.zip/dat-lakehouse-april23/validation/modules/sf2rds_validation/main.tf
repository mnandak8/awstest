resource "aws_glue_job" "data_validator_glue_job" {
  name = local.job-name
  role_arn = var.job-role 
  description = "glue job to perform salesforce-to-rds data validation"
  max_retries = local.job-max-retries
  connections = [aws_glue_connection.connection.name]
  command {
    script_location = "s3://${var.validation_script_bucket}/${local.validation_script_key}"
    python_version = local.python-version
  }
  execution_property {
    max_concurrent_runs = local.glue-max-concurrent-runs
  }
  glue_version = local.glue-version
  default_arguments = local.glue-job-script-args
  worker_type       = local.worker_type
  number_of_workers = local.number_of_workers
  security_configuration = local.security_name
  #tags = local.validator_job_tags
}

resource "aws_s3_object" "validation_script" {
  bucket = var.validation_script_bucket
  key = local.validation_script_key
  source = local.glue-job-script
  source_hash = filebase64sha256(local.glue-job-script)
}

resource "aws_s3_object" "dag_script" {
  bucket = var.dag_bucket
  key = var.dag_key
  source = local.dag-script
  source_hash = filebase64sha256(local.dag-script)
}
  
# Null Resource to enable Splunk Tag to the Glue Job Output Log Group  
resource "null_resource" "update_output_log_group_config" {
  triggers = {
    log_group_name = "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/output"
  }
 
  provisioner "local-exec" {
    command = <<EOT
      if aws logs describe-log-groups --log-group-name-prefix "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/output" | grep -q "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/output"; then
        aws logs tag-log-group \
          --log-group-name "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/output" \
          --tags "Splunk=true";
      else
        echo "Log group '/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/output' does not exist. Skipping tagging.";
      fi
    EOT
  }
}

# Null Resource to enable Splunk Tag to the Glue Job Error Log Group  
resource "null_resource" "update_error_log_group_config" {
  triggers = {
    log_group_name = "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/error"
  }
 
  provisioner "local-exec" {
    command = <<EOT
      if aws logs describe-log-groups --log-group-name-prefix "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/error" | grep -q "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/error"; then
        aws logs tag-log-group \
          --log-group-name "/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/error" \
          --tags "Splunk=true";
      else
        echo "Log group '/aws-glue/jobs/${local.security_name}-role/cobank-${var.environment}-glue-role/error' does not exist. Skipping tagging.";
      fi
    EOT
  }
}