Copy data from higher environments to lower environments
# Copy data from higher environments to lower environments

## Pre-requisites:
### Windows:
- Install the [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) for Windows. Verify the installation by running the command `aws --version`.
- Programmatic set up to access AWS resources using CLI. More details are in [AWS CLI Setup](#aws-cli-setup).
- Install either Windows Subsystem for Linux (WSL) or GitBash or Cygwin.

### Mac:
- Install the [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) for Mac. Verify the installation by running the command `aws --version`.
- Programmatic set up to access AWS resources using CLI. More details are in [AWS CLI Setup](#aws-cli-setup).
- Terminal or iTerm2 App

## Limitations:
- Currently, this process is restricted to dat-lak-* AWS accounts. The following diagram illustrates the access configuration.
- This process enables copying data into a designated bucket within each environment. 
- Copying data from production and pre-production to development and test environments is not permitted.
- Copying test data to the development bucket is allowed, but not vice versa.
- Copying production data to the pre-production bucket is allowed, but not vice versa.
- All data elements from S3 are copied regardless of their sensitivity.  
  <img src="./images/dat-lak-accounts-setup-for-copy-data.png" width="800" height="auto" alt="dat-lak aws accounts setup">

## Deployment:
### Cross Account Access Setup:
Before executing the script, ensure that cross-account access is configured based on the source and target environments. By default, the setup in dat-lak-* accounts permits data copying with the following restrictions:
- Data can be copied from the Test account to the Dev account.
- Data can be copied from the Prod account to the Preprod account.

Create a temporary bucket to copy the data from higher environment to lower environment as mentioned below.

```tf
module "raw_temp_bucket" {
  source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241212.66"
  resource_suffix           = "temp-raw"
  environment               = var.environment
  terra_factory_aws_id      = var.terra_factory_aws_id
  expiration_days           = 0
  governance_account_id     = var.governance_account_id
  log_bucket_name           = module.logging_bucket.bucket_name
  access_service_user_names = ["glue"]
  outside_account_ids       = ["arn:aws:iam::${var.next_higher_env_lake_acct_id}:root"]
}
```

### AWS CLI Setup:
Below steps will allow you to copy the Access keys for the source aws account
1. Open the [AWS access portal](https://d-9267769525.awsapps.com/start/#/?tab=accounts) in your browser.
2. Locate and select the designated AWS account. Expand the account details and click on `Access keys` for the `Administrator_NEW` role.
3. Copy the environment-specific variables: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and `AWS_SESSION_TOKEN` based on the operating system.
4. Set these variables in your Command Prompt (Windows) or Terminal (Mac).
5. Verify the setup by running the `aws s3 ls` command in your CLI.

### Script Deployment & Run Details:
In local computer create a new bash script file with the name as `copyData.sh` and place the below code.

```shell
#!/bin/sh

source_bucket="$1"
source_prefix="$2"
source_month=("$3")
target_bucket="$4"
target_prefix="$5"

for month in "${source_month[@]}"; do
    source_path="$source_bucket/$source_prefix/month=$month/"
    target_path="$target_bucket/$target_prefix/month=$month/"
    aws s3 cp "s3://$source_path" "s3://$target_path" --recursive
done
```

To call the copyData.sh script with arguments, you need to provide the required parameters in the correct order. Based on your script, you need to provide the source bucket, source prefix, source months (as a space-separated list), target bucket, and target prefix. Below is the snippet to call this script.

```shell 
./copyData.sh source-bucket-name source-prefix "01 02 03" target-bucket-name target-prefix
```

In this snippet:

- `source-bucket-name` is the name of the source S3 bucket.  
- `source-prefix` is the prefix in the source bucket.  
- `"01 02 03"` is a space-separated list of months.  
- `target-bucket-name` is the name of the target S3 bucket.  
- `target-prefix` is the prefix in the target bucket.  


Here are the examples of how to call the script:

```shell 
# This command sequentially copies data for Jan, Feb, and Mar from the `cobank-dl-767398005888-us-west-2-raw-test` bucket to the `dev-acb-dat-lak-temp-raw` bucket. (Copy from test bucket to dev bucket)
./copyData.sh "cobank-dl-767398005888-us-west-2-raw-test" "salesforce/llc_bi_loan_c/history/year=2024" "01 02 03" "dev-acb-dat-lak-temp-raw" "salesforce/llc_bi_loan_c/history/year=2024"  
```
```shell
# This command sequentially copies data for Oct, Nov, and Dec from the `cobank-dl-767397798595-us-west-2-raw-prod` bucket to the `preprod-acb-dat-lak-temp-raw` bucket. (Copy from prod bucket to pre-prod bucket)
./copyData.sh "cobank-dl-767397798595-us-west-2-raw-prod" "salesforce/llc_bi_loan_c/history/year=2024" "10 11 12" "preprod-acb-dat-lak-temp-raw" "salesforce/llc_bi_loan_c/history/year=2024"  
```
```shell
# These commands will copy data for Apr and May from the `cobank-dl-767397798595-us-west-2-raw-prod` bucket to the `preprod-acb-dat-lak-temp-raw` bucket in parallel. (Copy from prod bucket to pre-prod bucket)
./copyData.sh "cobank-dl-767397798595-us-west-2-raw-prod" "salesforce/llc_bi_loan_c/history/year=2024" "04" "preprod-acb-dat-lak-temp-raw" "salesforce/llc_bi_loan_c/history/year=2024" &
./copyData.sh "cobank-dl-767397798595-us-west-2-raw-prod" "salesforce/llc_bi_loan_c/history/year=2024" "05" "preprod-acb-dat-lak-temp-raw" "salesforce/llc_bi_loan_c/history/year=2024" &
```


Make sure the script has execute permissions. You can set the execute permission using the following command:

```shell 
chmod +x copyData.sh
```