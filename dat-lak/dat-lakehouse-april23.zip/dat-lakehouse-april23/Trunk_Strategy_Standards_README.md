# Trunk Strategy Standards

Please click here:[**Trunk Strategy Standards**](https://cobank.sharepoint.com/:p:/s/Applications/Cloud-Data-Platform/Ed19e0i5E6RJh46DBjDQljIBeOcat2rYfnVi8ErrgZDBFg?e=snXKJS).
(See slide 7 for step by step instructions)
