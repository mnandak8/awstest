CONFIG = {
    "ing": {
        "dev": {
		"acc_num": "471112929721"
        },
        "test": {
            "acc_num": "533267072724"
        },
		"preprod": {
            "acc_num": "211125365237"
        },
		"prod": {
            "acc_num": "654654446028"
        }
    }
}