from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'Glue',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load',
    description='ACBS SOD files Decrypt and Load 2 Raw',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule_interval=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)

#J_CAMS,J_CAMI,J_CUMS

J_CAMS = GlueJobOperator(task_id = 'J_CAMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMS"},dag=dag)
J_CUMS = GlueJobOperator(task_id = 'J_CUMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUMS"},dag=dag)
J_CAMI = GlueJobOperator(task_id = 'J_CAMI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMI"},dag=dag)
COADOB = GlueJobOperator(task_id = 'COADOB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COADOB"},dag=dag)
COCMAA = GlueJobOperator(task_id = 'COCMAA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAA"},dag=dag)
COCMAF = GlueJobOperator(task_id = 'COCMAF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAF"},dag=dag)
COCMAG = GlueJobOperator(task_id = 'COCMAG',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAG"},dag=dag)
COCMAI = GlueJobOperator(task_id = 'COCMAI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAI"},dag=dag)
COCMAJ = GlueJobOperator(task_id = 'COCMAJ',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAJ"},dag=dag)
COCMAN = GlueJobOperator(task_id = 'COCMAN',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAN"},dag=dag)
COCMAO = GlueJobOperator(task_id = 'COCMAO',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAO"},dag=dag)
COCMAP = GlueJobOperator(task_id = 'COCMAP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAP"},dag=dag)
COCMAU = GlueJobOperator(task_id = 'COCMAU',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAU"},dag=dag)
COCMAV = GlueJobOperator(task_id = 'COCMAV',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAV"},dag=dag)
COCMAW = GlueJobOperator(task_id = 'COCMAW',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAW"},dag=dag)
COCMAY = GlueJobOperator(task_id = 'COCMAY',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAY"},dag=dag)
COCMAZ = GlueJobOperator(task_id = 'COCMAZ',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAZ"},dag=dag)
COCMBA = GlueJobOperator(task_id = 'COCMBA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMBA"},dag=dag)
COCMBD = GlueJobOperator(task_id = 'COCMBD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMBD"},dag=dag)
DMEXAF = GlueJobOperator(task_id = 'DMEXAF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DMEXAF"},dag=dag)
DSCAGH = GlueJobOperator(task_id = 'DSCAGH',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGH"},dag=dag)
DSCAGL = GlueJobOperator(task_id = 'DSCAGL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGL"},dag=dag)
DSCAGP = GlueJobOperator(task_id = 'DSCAGP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGP"},dag=dag)
DSCAIL = GlueJobOperator(task_id = 'DSCAIL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAIL"},dag=dag)
DSCAPI = GlueJobOperator(task_id = 'DSCAPI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPI"},dag=dag)
DSCAPL = GlueJobOperator(task_id = 'DSCAPL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPL"},dag=dag)
DSGNEB = GlueJobOperator(task_id = 'DSGNEB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSGNEB"},dag=dag)
DSLWLA = GlueJobOperator(task_id = 'DSLWLA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLA"},dag=dag)
DSLWLB = GlueJobOperator(task_id = 'DSLWLB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLB"},dag=dag)
DSLWLM = GlueJobOperator(task_id = 'DSLWLM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLM"},dag=dag)
DSLWLR = GlueJobOperator(task_id = 'DSLWLR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLR"},dag=dag)
DSLWNL = GlueJobOperator(task_id = 'DSLWNL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWNL"},dag=dag)
DSLWTB = GlueJobOperator(task_id = 'DSLWTB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTB"},dag=dag)
DSLWTI = GlueJobOperator(task_id = 'DSLWTI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTI"},dag=dag)
DSLWTR = GlueJobOperator(task_id = 'DSLWTR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTR"},dag=dag)
DSLWTRR = GlueJobOperator(task_id = 'DSLWTRR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTRR"},dag=dag)
DSLWUT = GlueJobOperator(task_id = 'DSLWUT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWUT"},dag=dag)
DSTRDM = GlueJobOperator(task_id = 'DSTRDM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRDM"},dag=dag)
DSTRMS = GlueJobOperator(task_id = 'DSTRMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRMS"},dag=dag)
FNGNED = GlueJobOperator(task_id = 'FNGNED',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNED"},dag=dag)
FNGNEL = GlueJobOperator(task_id = 'FNGNEL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNEL"},dag=dag)
J_CACG = GlueJobOperator(task_id = 'J_CACG',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CACG"},dag=dag)
J_CADT = GlueJobOperator(task_id = 'J_CADT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADT"},dag=dag)
J_CADTW = GlueJobOperator(task_id = 'J_CADTW',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADTW"},dag=dag)
J_CAFB = GlueJobOperator(task_id = 'J_CAFB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFB"},dag=dag)
J_CAFE = GlueJobOperator(task_id = 'J_CAFE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFE"},dag=dag)
J_CAFF = GlueJobOperator(task_id = 'J_CAFF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFF"},dag=dag)
J_CAFI = GlueJobOperator(task_id = 'J_CAFI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFI"},dag=dag)
J_CAFT = GlueJobOperator(task_id = 'J_CAFT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFT"},dag=dag)
J_CAGU = GlueJobOperator(task_id = 'J_CAGU',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAGU"},dag=dag)
J_CAHS = GlueJobOperator(task_id = 'J_CAHS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAHS"},dag=dag)
J_CALM = GlueJobOperator(task_id = 'J_CALM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CALM"},dag=dag)
J_CAPF = GlueJobOperator(task_id = 'J_CAPF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAPF"},dag=dag)
J_CATE = GlueJobOperator(task_id = 'J_CATE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CATE"},dag=dag)
J_CLAC = GlueJobOperator(task_id = 'J_CLAC',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAC"},dag=dag)
J_CLAD = GlueJobOperator(task_id = 'J_CLAD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAD"},dag=dag)
J_CLAP = GlueJobOperator(task_id = 'J_CLAP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAP"},dag=dag)
J_CLAS = GlueJobOperator(task_id = 'J_CLAS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAS"},dag=dag)
J_CLBC = GlueJobOperator(task_id = 'J_CLBC',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLBC"},dag=dag)
J_CLDT = GlueJobOperator(task_id = 'J_CLDT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDT"},dag=dag)
J_CLDTW = GlueJobOperator(task_id = 'J_CLDTW',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDTW"},dag=dag)
J_CLFD = GlueJobOperator(task_id = 'J_CLFD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFD"},dag=dag)
J_CLFP = GlueJobOperator(task_id = 'J_CLFP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFP"},dag=dag)
J_CLGU = GlueJobOperator(task_id = 'J_CLGU',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLGU"},dag=dag)
J_CLIS = GlueJobOperator(task_id = 'J_CLIS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIS"},dag=dag)
J_CLIX = GlueJobOperator(task_id = 'J_CLIX',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIX"},dag=dag)
J_CLLA = GlueJobOperator(task_id = 'J_CLLA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLA"},dag=dag)
J_CLLI = GlueJobOperator(task_id = 'J_CLLI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLI"},dag=dag)
J_CLMI = GlueJobOperator(task_id = 'J_CLMI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMI"},dag=dag)
J_CLMS = GlueJobOperator(task_id = 'J_CLMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMS"},dag=dag)
J_CLMX = GlueJobOperator(task_id = 'J_CLMX',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMX"},dag=dag)
J_CLPB = GlueJobOperator(task_id = 'J_CLPB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPB"},dag=dag)
J_CLPC = GlueJobOperator(task_id = 'J_CLPC',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPC"},dag=dag)
J_CLPF = GlueJobOperator(task_id = 'J_CLPF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPF"},dag=dag)
J_CLPS = GlueJobOperator(task_id = 'J_CLPS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPS"},dag=dag)
J_CLRM = GlueJobOperator(task_id = 'J_CLRM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRM"},dag=dag)
J_CLRR = GlueJobOperator(task_id = 'J_CLRR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRR"},dag=dag)
J_CLRS = GlueJobOperator(task_id = 'J_CLRS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRS"},dag=dag)
J_CLSB = GlueJobOperator(task_id = 'J_CLSB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLSB"},dag=dag)
J_CLTE = GlueJobOperator(task_id = 'J_CLTE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTE"},dag=dag)
J_CLTP = GlueJobOperator(task_id = 'J_CLTP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTP"},dag=dag)
J_CTDE = GlueJobOperator(task_id = 'J_CTDE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTDE"},dag=dag)
J_CTID = GlueJobOperator(task_id = 'J_CTID',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTID"},dag=dag)
J_CTIM = GlueJobOperator(task_id = 'J_CTIM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTIM"},dag=dag)
J_CTMS = GlueJobOperator(task_id = 'J_CTMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTMS"},dag=dag)
J_CTPD = GlueJobOperator(task_id = 'J_CTPD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPD"},dag=dag)
J_CTPG = GlueJobOperator(task_id = 'J_CTPG',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPG"},dag=dag)
J_CTUH = GlueJobOperator(task_id = 'J_CTUH',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUH"},dag=dag)
J_CTUN = GlueJobOperator(task_id = 'J_CTUN',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUN"},dag=dag)
J_CUAD = GlueJobOperator(task_id = 'J_CUAD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAD"},dag=dag)
J_CUAF = GlueJobOperator(task_id = 'J_CUAF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAF"},dag=dag)
J_CUAL = GlueJobOperator(task_id = 'J_CUAL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAL"},dag=dag)
J_CUCR = GlueJobOperator(task_id = 'J_CUCR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUCR"},dag=dag)
J_CUDT = GlueJobOperator(task_id = 'J_CUDT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUDT"},dag=dag)
J_CUIN = GlueJobOperator(task_id = 'J_CUIN',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIN"},dag=dag)
J_CUIS = GlueJobOperator(task_id = 'J_CUIS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIS"},dag=dag)
J_CULB = GlueJobOperator(task_id = 'J_CULB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CULB"},dag=dag)
J_CUPI = GlueJobOperator(task_id = 'J_CUPI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUPI"},dag=dag)
J_CUTE = GlueJobOperator(task_id = 'J_CUTE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUTE"},dag=dag)
J_GLAS = GlueJobOperator(task_id = 'J_GLAS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLAS"},dag=dag)
J_GLBS = GlueJobOperator(task_id = 'J_GLBS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLBS"},dag=dag)
J_GLCC = GlueJobOperator(task_id = 'J_GLCC',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLCC"},dag=dag)
J_GLER = GlueJobOperator(task_id = 'J_GLER',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLER"},dag=dag)
J_GLNO = GlueJobOperator(task_id = 'J_GLNO',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLNO"},dag=dag)
J_SCMS = GlueJobOperator(task_id = 'J_SCMS',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SCMS"},dag=dag)
J_SYCD = GlueJobOperator(task_id = 'J_SYCD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYCD"},dag=dag)
J_SYCE = GlueJobOperator(task_id = 'J_SYCE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYCE"},dag=dag)
J_SYDC = GlueJobOperator(task_id = 'J_SYDC',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDC"},dag=dag)
J_SYDM = GlueJobOperator(task_id = 'J_SYDM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDM"},dag=dag)
J_SYDMR = GlueJobOperator(task_id = 'J_SYDMR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDMR"},dag=dag)
J_SYDR = GlueJobOperator(task_id = 'J_SYDR',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDR"},dag=dag)
J_SYFL = GlueJobOperator(task_id = 'J_SYFL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYFL"},dag=dag)
J_SYXL = GlueJobOperator(task_id = 'J_SYXL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXL"},dag=dag)
J_SYXM = GlueJobOperator(task_id = 'J_SYXM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXM"},dag=dag)
Z_ACCLSM = GlueJobOperator(task_id = 'Z_ACCLSM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACCLSM"},dag=dag)
Z_ACSOLD = GlueJobOperator(task_id = 'Z_ACSOLD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACSOLD"},dag=dag)
Z_ADCA = GlueJobOperator(task_id = 'Z_ADCA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ADCA"},dag=dag)
Z_ATCI = GlueJobOperator(task_id = 'Z_ATCI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCI"},dag=dag)
Z_ATCUST = GlueJobOperator(task_id = 'Z_ATCUST',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCUST"},dag=dag)
Z_CAADDI = GlueJobOperator(task_id = 'Z_CAADDI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAADDI"},dag=dag)
Z_CAMA = GlueJobOperator(task_id = 'Z_CAMA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAMA"},dag=dag)
Z_CAP = GlueJobOperator(task_id = 'Z_CAP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAP"},dag=dag)
Z_CAPEQ = GlueJobOperator(task_id = 'Z_CAPEQ',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPEQ"},dag=dag)
Z_CAPINM = GlueJobOperator(task_id = 'Z_CAPINM',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINM"},dag=dag)
Z_CAPINT = GlueJobOperator(task_id = 'Z_CAPINT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINT"},dag=dag)
Z_CAPPF = GlueJobOperator(task_id = 'Z_CAPPF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPPF"},dag=dag)
Z_CDERV = GlueJobOperator(task_id = 'Z_CDERV',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CDERV"},dag=dag)
Z_CIB = GlueJobOperator(task_id = 'Z_CIB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CIB"},dag=dag)
Z_CLPPF = GlueJobOperator(task_id = 'Z_CLPPF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPPF"},dag=dag)
Z_CLPY = GlueJobOperator(task_id = 'Z_CLPY',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPY"},dag=dag)
Z_CUEX = GlueJobOperator(task_id = 'Z_CUEX',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUEX"},dag=dag)
Z_CUMA = GlueJobOperator(task_id = 'Z_CUMA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUMA"},dag=dag)
Z_CUSNAI = GlueJobOperator(task_id = 'Z_CUSNAI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUSNAI"},dag=dag)
Z_FCLACT = GlueJobOperator(task_id = 'Z_FCLACT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_FCLACT"},dag=dag)
Z_GLDT = GlueJobOperator(task_id = 'Z_GLDT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_GLDT"},dag=dag)
Z_LBRHST = GlueJobOperator(task_id = 'Z_LBRHST',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_LBRHST"},dag=dag)
ZCMXAI = GlueJobOperator(task_id = 'ZCMXAI',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXAI"},dag=dag)
ZCMXRF = GlueJobOperator(task_id = 'ZCMXRF',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXRF"},dag=dag)
ZFBPCFE = GlueJobOperator(task_id = 'ZFBPCFE',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPCFE"},dag=dag)
ZFBPEXT = GlueJobOperator(task_id = 'ZFBPEXT',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPEXT"},dag=dag)
ZFMIFB = GlueJobOperator(task_id = 'ZFMIFB',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFMIFB"},dag=dag)
ZFPACK = GlueJobOperator(task_id = 'ZFPACK',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFPACK"},dag=dag)
ZFPINA = GlueJobOperator(task_id = 'ZFPINA',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFPINA"},dag=dag)
ZQRMEX = GlueJobOperator(task_id = 'ZQRMEX',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZQRMEX"},dag=dag)
ZSEDTL = GlueJobOperator(task_id = 'ZSEDTL',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZSEDTL"},dag=dag)
ZWFBLH = GlueJobOperator(task_id = 'ZWFBLH',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFBLH"},dag=dag)
ZWFCUD = GlueJobOperator(task_id = 'ZWFCUD',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFCUD"},dag=dag)
ZWFPLN = GlueJobOperator(task_id = 'ZWFPLN',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFPLN"},dag=dag)
ZWFTYP = GlueJobOperator(task_id = 'ZWFTYP',job_name='mnk_acbs_decrypt_load2_raw',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFTYP"},dag=dag)

# Set the task dependencies
ACBS_EOD_Raw_Start_Task >> [COADOB,COCMAA,COCMAF,COCMAG,COCMAI,COCMAJ,COCMAN,COCMAO,COCMAP,COCMAU,COCMAV,COCMAW,COCMAY,COCMAZ,COCMBA,COCMBD,DMEXAF,DSCAGH,DSCAGL,DSCAGP,DSCAIL,DSCAPI,DSCAPL,DSGNEB,DSLWLA,DSLWLB,DSLWLM,DSLWLR,DSLWNL,DSLWTB,DSLWTI,DSLWTR,DSLWTRR,DSLWUT,DSTRDM,DSTRMS,FNGNED,FNGNEL,J_CACG,J_CADT,J_CADTW,J_CAFB,J_CAFE,J_CAFF,J_CAFI,J_CAFT,J_CAGU,J_CAHS,J_CALM,J_CAMI,J_CAMS,J_CAPF,J_CATE,J_CLAC,J_CLAD,J_CLAP,J_CLAS,J_CLBC,J_CLDT,J_CLDTW,J_CLFD,J_CLFP,J_CLGU,J_CLIS,J_CLIX,J_CLLA,J_CLLI,J_CLMI,J_CLMS,J_CLMX,J_CLPB,J_CLPC,J_CLPF,J_CLPS,J_CLRM,J_CLRR,J_CLRS,J_CLSB,J_CLTE,J_CLTP,J_CTDE,J_CTID,J_CTIM,J_CTMS,J_CTPD,J_CTPG,J_CTUH,J_CTUN,J_CUAD,J_CUAF,J_CUAL,J_CUCR,J_CUDT,J_CUIN,J_CUIS,J_CULB,J_CUMS,J_CUPI,J_CUTE,J_GLAS,J_GLBS,J_GLCC,J_GLER,J_GLNO,J_SCMS,J_SYCD,J_SYCE,J_SYDC,J_SYDM,J_SYDMR,J_SYDR,J_SYFL,J_SYXL,J_SYXM,Z_ACCLSM,Z_ACSOLD,Z_ADCA,Z_ATCI,Z_ATCUST,Z_CAADDI,Z_CAMA,Z_CAP,Z_CAPEQ,Z_CAPINM,Z_CAPINT,Z_CAPPF,Z_CDERV,Z_CIB,Z_CLPPF,Z_CLPY,Z_CUEX,Z_CUMA,Z_CUSNAI,Z_FCLACT,Z_GLDT,Z_LBRHST,ZCMXAI,ZCMXRF,ZFBPCFE,ZFBPEXT,ZFMIFB,ZFPACK,ZFPINA,ZQRMEX,ZSEDTL,ZWFBLH,ZWFCUD,ZWFPLN,ZWFTYP]  
[COADOB,COCMAA,COCMAF,COCMAG,COCMAI,COCMAJ,COCMAN,COCMAO,COCMAP,COCMAU,COCMAV,COCMAW,COCMAY,COCMAZ,COCMBA,COCMBD,DMEXAF,DSCAGH,DSCAGL,DSCAGP,DSCAIL,DSCAPI,DSCAPL,DSGNEB,DSLWLA,DSLWLB,DSLWLM,DSLWLR,DSLWNL,DSLWTB,DSLWTI,DSLWTR,DSLWTRR,DSLWUT,DSTRDM,DSTRMS,FNGNED,FNGNEL,J_CACG,J_CADT,J_CADTW,J_CAFB,J_CAFE,J_CAFF,J_CAFI,J_CAFT,J_CAGU,J_CAHS,J_CALM,J_CAMI,J_CAMS,J_CAPF,J_CATE,J_CLAC,J_CLAD,J_CLAP,J_CLAS,J_CLBC,J_CLDT,J_CLDTW,J_CLFD,J_CLFP,J_CLGU,J_CLIS,J_CLIX,J_CLLA,J_CLLI,J_CLMI,J_CLMS,J_CLMX,J_CLPB,J_CLPC,J_CLPF,J_CLPS,J_CLRM,J_CLRR,J_CLRS,J_CLSB,J_CLTE,J_CLTP,J_CTDE,J_CTID,J_CTIM,J_CTMS,J_CTPD,J_CTPG,J_CTUH,J_CTUN,J_CUAD,J_CUAF,J_CUAL,J_CUCR,J_CUDT,J_CUIN,J_CUIS,J_CULB,J_CUMS,J_CUPI,J_CUTE,J_GLAS,J_GLBS,J_GLCC,J_GLER,J_GLNO,J_SCMS,J_SYCD,J_SYCE,J_SYDC,J_SYDM,J_SYDMR,J_SYDR,J_SYFL,J_SYXL,J_SYXM,Z_ACCLSM,Z_ACSOLD,Z_ADCA,Z_ATCI,Z_ATCUST,Z_CAADDI,Z_CAMA,Z_CAP,Z_CAPEQ,Z_CAPINM,Z_CAPINT,Z_CAPPF,Z_CDERV,Z_CIB,Z_CLPPF,Z_CLPY,Z_CUEX,Z_CUMA,Z_CUSNAI,Z_FCLACT,Z_GLDT,Z_LBRHST,ZCMXAI,ZCMXRF,ZFBPCFE,ZFBPEXT,ZFMIFB,ZFPACK,ZFPINA,ZQRMEX,ZSEDTL,ZWFBLH,ZWFCUD,ZWFPLN,ZWFTYP]     >> ACBS_EOD_Raw_End_Task