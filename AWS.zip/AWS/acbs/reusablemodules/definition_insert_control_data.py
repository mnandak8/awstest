import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger



#######################
def definition_insert_control_data(spark,business_date,control_table,jobname,tgt_table_name):
    try:
        spark.sql(f"""
            INSERT INTO {control_table} (
            select  'loans' as asset ,'acbs' as source_system ,'{tgt_table_name}' as target_table ,
            to_date('{business_date}', 'yyyy-MM-dd') as business_date ,'STARTED' as status,
            null as src_record_count,null  as inserts_record_count,null as updates_record_count,
            current_timestamp - INTERVAL 7 HOURS  as load_start_dttm,null as load_end_dttm,
            '{jobname}' as job_name, 'CDCTYPE-2' as job_type,null as error_message  )
            """)
        logger.info(f"Success Inserting into Control Table")
    except Exception as error:
        logger.error(f"Error Inserting into Control Table --> {error}")
        sys.exit(20)
    
############################################################# 
