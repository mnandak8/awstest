import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 

sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

def definition_read_stt_mapping_data(spark,s3_mapping_path,tgt_table_name,raw_src_sql_join_condition):
    s3_mapping_path_file= f"{s3_mapping_path}{tgt_table_name}.csv"
    try:
        df_mapping_data = spark.read.option("header", "true").csv(s3_mapping_path_file)
    except Exception as error:
        logger.error(f"Error Reading the Config Mapings  --> {error}")
        sys.exit(5)
    
    df_md5_columns = df_mapping_data.filter(df_mapping_data.include_md5_ind == "Y").select(trim("column"))
    df_pk_columns = df_mapping_data.filter(df_mapping_data.unique_index_ind == "Y").select(trim("column"))
    df_src_dataformat = df_mapping_data.select(trim("column").alias("column"), trim("src_column_dataformat").alias("src_column_dataformat"))
    df_src_sql=df_mapping_data.select(trim("column").alias("column"), trim("alias_src_table").alias("alias_src_table"),trim("src_column").alias("src_column"))
    dist_src_tables = df_mapping_data.select("alias_src_table").distinct()
    list_dist_src_tables=dist_src_tables.rdd.flatMap(lambda x: x).collect()
    list_pk_columns = df_pk_columns.rdd.flatMap(lambda x: x).collect()
    list_md5_columns = df_md5_columns.rdd.flatMap(lambda x: x).collect()
    
    join_condition=""
    for col_nm in list_pk_columns:
        join_condition=join_condition + " and "  + "src." + col_nm + " = tgt." + col_nm 
    join_condition = join_condition[5:]
    
    all_src_tables=""
    for src_table in list_dist_src_tables:
        all_src_tables=all_src_tables +  "," + src_table
        
    df_src_dataformat = df_src_dataformat.withColumn('column', lower(col('column')))
    
    rows_df_sql = df_src_sql.collect()
    
    sql_string=""
    for row in rows_df_sql:
        tcol=row['column']
        als=row['alias_src_table']
        scol=row['src_column']
        if scol is not None and "$" in scol:  
            sql_string = sql_string + " , " + als + "." + "`" + scol + "`" + " as " + tcol
        else:
            if scol is None:
                sql_string = sql_string + " , " + " null " + " as " + tcol
            else:
                sql_string = sql_string + " , " + als + "." + scol + " as " + tcol
  
    if raw_src_sql_join_condition == ""   :
        f_sql_string = "select " + sql_string[3:] + " from  "  + all_src_tables[1:]  
    else :
        f_sql_string = "select " + sql_string[3:] + " from  "  + raw_src_sql_join_condition.lower()
    return(join_condition,list_md5_columns,df_src_dataformat,f_sql_string,list_dist_src_tables,list_pk_columns)