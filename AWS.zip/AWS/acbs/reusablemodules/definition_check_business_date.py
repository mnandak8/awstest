import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

def definition_check_business_date(spark,business_date,tgt_table_name,control_table):
    
    logger.info(f" Cheking the Business Date {business_date}")
    business_date_f=datetime.strptime(business_date, '%Y-%m-%d').date()
    try:
        df_cntrl_data = spark.read.format("iceberg").load(f"{control_table}").filter(f"target_table = '{tgt_table_name}'")
    except Exception as error:
        logger.error(f"Error Reading into Control Table {control_table} --> {error}")
        sys.exit(10) 
    business_date_c=""
    run_cdc_restart_ind = ""
    status_c=""
    run_cdc_ind="N"
    if df_cntrl_data.count() == 0: 
        run_cdc_ind = 'Y'
    else:    
        df_cntrl_data_latest = df_cntrl_data.orderBy(col("business_date").desc()).limit(1)
        business_date_c= df_cntrl_data_latest.select("business_date").first()['business_date']
        status_c= df_cntrl_data_latest.select("status").first()['status']
        logger.info(f" Business Date from Raw Layer  --> {business_date_f} and Control Table  --> {business_date_c} and status is --> {status_c} ")
        run_cdc_ind=""
        run_cdc_restart_ind=""
        if business_date_f == business_date_c and status_c == "COMPLETED":
            run_cdc_ind = 'N'
            logger.info(f" The Load for the business_date {business_date_f} is already complete exiting the CDC Existing job gracefully")
            job.commit() 
            os._exit(0)
        if business_date_f == business_date_c and status_c == "STARTED":
	        run_cdc_ind = 'Y'
	        run_cdc_restart_ind = 'Y'    
        if business_date_f > business_date_c :
            run_cdc_ind='Y'
            logger.info(f" The Load for the business_date from RAW {business_date_f} is greater than date from control table {business_date_c} Running the CDC")
        if business_date_f < business_date_c :
            run_cdc_ind='N'
            logger.info(f" The Load for the business_date from RAW {business_date_f} is less than date from control table {business_date_c} exiting the CDC")
            job.commit() 
            os._exit(0)
        if run_cdc_ind == "" : 
            run_cdc_ind='N'
            job.commit() 
            os._exit(0)
    logger.info(f" The Final Run Status code {run_cdc_ind}")
    return(run_cdc_ind,run_cdc_restart_ind,status_c,business_date_c)