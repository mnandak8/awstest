import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 

sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

def definition_read_source_raw(src_data_format_type,spark,raw_src_s3_path,raw_src_sql,list_md5_columns,f_sql_string,list_dist_src_tables):
    
    df_raw_data_all ={}
    for src_table_name in list_dist_src_tables:
        u_src_table_name=src_table_name.upper()
        src_table_name_path=f"{raw_src_s3_path}/{u_src_table_name}.DAT"
        
        if src_data_format_type == "parquet":
            logger.info(f"Reading  parquet file {src_table_name} ")    
            try:
                df_raw_data_all[src_table_name] = spark.read.parquet(src_table_name_path)
            except Exception as error:
                logger.error(f"Reading S3 Raw bucket {src_table_name_path} --> Failed with Error {error}")
                sys.exit(40)
        if src_data_format_type == "csv":
            logger.info(f"Reading  csv file {src_table_name} ")    
            try:
                df_raw_data_all[src_table_name] = spark.read.csv(path=src_table_name_path,sep ='|',header=True)
            except Exception as error:
                logger.error(f"Reading S3 Raw bucket {src_table_name_path} --> Failed with Error {error}")
                sys.exit(45)
        
        logger.info(f"src count of {src_table_name} -->  {df_raw_data_all[src_table_name].count()}")    
        
        
        source_column_names = df_raw_data_all[src_table_name].columns
        for src_column in source_column_names:
            df_raw_data_all[src_table_name] = df_raw_data_all[src_table_name].withColumn(src_column,when(col(src_column).rlike(r"\t"),  None ).otherwise(col(src_column))) #replace tab with nulls.
        
        df_raw_data_temp_view=f"{src_table_name}"
        df_raw_data_all[src_table_name].createOrReplaceTempView(df_raw_data_temp_view)
    
    f_raw_src_sql=""
    if raw_src_sql == "": f_raw_src_sql=f_sql_string 
    else: f_raw_src_sql=raw_src_sql  
    try:
        df_raw_data=spark.sql(f"""{f_raw_src_sql}""")
    except Exception as error:
        logger.error(f"Error Executing the Src Query {error}")
        sys.exit(50)
    
    md5_columns=list_md5_columns
    if len(md5_columns) == 0: df_raw_datacolumns=df_raw_data.columns
    else: df_raw_datacolumns=md5_columns
    
    df_raw_data_md5=df_raw_data.withColumn("audit_hash_key", md5(concat_ws("|", *df_raw_datacolumns)))
    logger.info(f"Final Src Record Count --> {df_raw_data_md5.count()}")
    return(df_raw_data_md5)
