########################################################################################################################
#definition_check_business_date --> Check the Business date if data already processed or old data. 
#definition_insert_control_data --> Insert into Control Table 
#definition_read_mapping_data --> the read the Mapping file 
#definition_read_source_raw --> Read the Source Data 
#definition_validate_and_format_src_data --> validate the Source Data
#definition_join_and_generate_cdc_df --> Join the Src to Tgt and create the CDC data Set 
#definition_insert_tgt_table --> Insert new records
#definition_update_tgt_table --> Update and Insert Chnages records 
#definition_update_control_data --> Update control table with the stats.
########################################################################################################################
import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
from pyspark.sql import functions as F


########### Arguments  
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'ENV'])
jobname = args['JOB_NAME']
env = args['ENV']
#########################################
sys.path.append('s3://dev-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')

import definition_check_business_date
import definition_insert_control_data
import definition_update_control_data
import definition_read_stt_mapping_data
import definition_read_source_raw
import definition_validate_and_format_src_data
import definition_join_and_generate_cdc_df
import definition_insert_tgt_table
import definition_update_tgt_table
from logger_setup import logger

                
s3_warehouse_path ="s3://cobank-dl-654654598303-us-west-2-transformed-dev/iceberg/"


spark = SparkSession.builder.config("spark.sql.catalog.glue_catalog", "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.glue_catalog.warehouse", s3_warehouse_path) \
    .config("spark.sql.catalog.glue_catalog.catalog-impl", "org.apache.iceberg.aws.glue.GlueCatalog") \
    .config("spark.sql.catalog.glue_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO") \
    .config("spark.sql.catalog.glue_catalog.glue.lakeformation-enabled", "true") \
    .config("spark.sql.iceberg.handle-timestamp-without-timezone", "true") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .getOrCreate()
    


sc = spark.sparkContext
glueContext = GlueContext(sc)
job = Job(glueContext)
job.commit()
#################### Vars


business_date="2024-11-26" 
src_data_format_type="csv"
raw_src_sql=""
#tgt_table_name="acbs_ca_sub_limits"
tgt_table_name="acbs_credit_arrangements"
#raw_src_sql_join_condition=""
raw_src_sql_join_condition=" J_CAMS left join J_CAMI on  J_CAMS.`J$BAAI`=J_CAMI.`J$BAAI` AND J_CAMS.`J$BACI`=J_CAMI.`J$BACI`  left join J_CALM  on J_CAMS.`J$BAAI`=J_CALM.`J$BFAI` AND J_CAMS.`J$BACI`=J_CALM.`J$BFCI` AND J_CALM.`J$BFFC` = '00' "

################################
my_catalog="glue_catalog"
database_name="raw_icebergdb"
s3_mapping_path = f"s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/acbsconfigmappings/"
target_table=f"{my_catalog}.{database_name}.{tgt_table_name}"
control_table=f"{my_catalog}.{database_name}.acbs_control_table"
raw_src_s3_path = f"s3://{env}-acb-dl-dat-lak-raw-loan-acbs-asset/acbsdatfiles/{business_date}"
 
########################################
if __name__ == '__main__':
    
    #Function : definition_check_business_date
    run_cdc_ind,run_cdc_restart_ind,status_c,business_date_c=definition_check_business_date.definition_check_business_date(spark,business_date,tgt_table_name,control_table)
    if run_cdc_ind == 'Y':
        if run_cdc_restart_ind == 'Y': logger.info(f"Restarting for the Failed/Previous Load for Businesss date : {business_date}")
        else: definition_insert_control_data.definition_insert_control_data(spark,business_date,control_table,jobname,tgt_table_name)
        
        #Function : definition_read_stt_mapping_data
        cdc_join_condition_src_tgt,list_md5_columns,df_src_dataformat,f_sql_string,list_dist_src_tables,list_pk_columns=definition_read_stt_mapping_data.definition_read_stt_mapping_data(spark,s3_mapping_path,tgt_table_name,raw_src_sql_join_condition)
        
        #Functions : definition_read_source_raw
        df_raw_data=definition_read_source_raw.definition_read_source_raw(src_data_format_type,spark,raw_src_s3_path,raw_src_sql,list_md5_columns,f_sql_string,list_dist_src_tables)
        #function: definition_validate_and_format_src_data
        tgt_iceberg_columns_df,df_raw_data_fmtd=definition_validate_and_format_src_data.definition_validate_and_format_src_data(target_table,spark,df_raw_data,df_src_dataformat,list_pk_columns)
        #Function : definition_join_and_generate_cdc_df
        insert_tgt_df,update_tgt_df=definition_join_and_generate_cdc_df.definition_join_and_generate_cdc_df(business_date,spark,target_table,df_raw_data_fmtd,cdc_join_condition_src_tgt,tgt_iceberg_columns_df)
        #function: definition_insert_tgt_table
        if insert_tgt_df.count() > 0 : definition_insert_tgt_table.definition_insert_tgt_table(insert_tgt_df,target_table)
        # FUnction: definition_update_tgt_table
        if update_tgt_df.count() > 0 : 
            definition_update_tgt_table.definition_update_tgt_table(spark,update_tgt_df,target_table,cdc_join_condition_src_tgt,business_date)
        #Function : definition_update_control_data  
        definition_update_control_data.definition_update_control_data(jobname,business_date,tgt_table_name,control_table,spark,df_raw_data_fmtd,insert_tgt_df,update_tgt_df)
        
    logger.info("Glue job finished successfully.") 
