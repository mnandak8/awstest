import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger


#############################################################
def definition_update_control_data(jobname,business_date,tgt_table_name,control_table,spark,df_raw_data,insert_tgt_df,update_tgt_df) :
    df_raw_data_count=df_raw_data.count()
    insert_tgt_df_count=insert_tgt_df.count()
    update_tgt_df_count=update_tgt_df.count()
    try:
        spark.sql(f"""
         MERGE INTO {control_table} tgt  using 
        (select '{tgt_table_name}' as target_table ,  to_date('{business_date}', 'yyyy-MM-dd') as business_date, '{jobname}'  as job_name  ) src  ON  
            tgt.target_table = src.target_table and tgt.business_date =src.business_date and tgt.job_name = src.job_name
        WHEN MATCHED THEN UPDATE  set
            status = 'COMPLETED', src_record_count = {df_raw_data_count} ,inserts_record_count = {insert_tgt_df_count} , updates_record_count = {update_tgt_df_count} ,load_end_dttm = (current_timestamp - INTERVAL 7 HOURS) 
             """)
        logger.info(f"Success Updating into Control Table")
    except Exception as error:
        logger.error(f"Error Updating into Control Table --> {error}")
        sys.exit(30)
    
#########################################