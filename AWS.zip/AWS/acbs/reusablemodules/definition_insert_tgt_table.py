import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger


def definition_insert_tgt_table(insert_tgt_df,target_table):
    
    logger.info(f"New Inserts loaded into Target Table : {insert_tgt_df.count()}")
    try:
        insert_tgt_df.writeTo(target_table).tableProperty("format-version", "2").append()
    except Exception as e:
        logger.error(f"Error when writing into the {target_table}: {e}")  
        sys.exit(70)