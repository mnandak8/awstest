import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

def definition_join_and_generate_cdc_df(business_date,spark,target_table,df_raw_data,cdc_join_condition_src_tgt,tgt_iceberg_columns_df):
    df_raw_data.createOrReplaceTempView("df_raw_data")
    df_raw_data.cache()
    try:
        df_joined_data = spark.sql(f"""
                SELECT src.*,
                CASE
                    WHEN tgt.AUDIT_HASH_KEY IS NULL THEN 'INSERT'      
                    WHEN tgt.AUDIT_HASH_KEY != src.AUDIT_HASH_KEY THEN 'UPDATE'
                ELSE 'NO_CHANGE' END AS change_type,
                to_date('{business_date}' , 'yyyy-MM-dd' )  as audit_row_effective_dttm, to_date('9999-12-31' , 'yyyy-MM-dd' ) as audit_row_end_dttm,
                'Y' as audit_active_row_ind,current_date as audit_insert_dttm,current_date as audit_update_dttm,'I' as audit_activity_cd
                FROM df_raw_data src
                LEFT JOIN {target_table} tgt ON {cdc_join_condition_src_tgt} 
                and tgt.audit_active_row_ind = 'Y'
        """)
    except Exception as error:
        logger.error(f"Error Executing the joining the SRC and Target ")
        sys.exit(60)
    logger.info(f"Left join count --> {df_joined_data.count()}")
    
    tgt_column_names = tgt_iceberg_columns_df.columns
    tgt_column_names += ['change_type']
    cdc_tgt_df = df_joined_data.select(*tgt_column_names)
    insert_tgt_df = cdc_tgt_df.filter(cdc_tgt_df.change_type == "INSERT").drop("change_type")
    update_tgt_df = cdc_tgt_df.filter(cdc_tgt_df.change_type == "UPDATE").drop("change_type")
    logger.info(f"New Records count --> {insert_tgt_df.count()}")
    logger.info(f"Updated Record count --> {update_tgt_df.count()}")
    return(insert_tgt_df,update_tgt_df)

