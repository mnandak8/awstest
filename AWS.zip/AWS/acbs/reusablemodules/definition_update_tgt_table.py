import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

def definition_update_tgt_table(spark,update_tgt_df,target_table,cdc_join_condition_src_tgt,business_date):
    update_ins_tgt_df=update_tgt_df
    update_tgt_df.createOrReplaceTempView("update_tgt_df")
    try:
        spark.sql(f"""
            MERGE INTO {target_table} tgt USING update_tgt_df src ON {cdc_join_condition_src_tgt} WHEN MATCHED THEN UPDATE  
            SET  tgt.audit_active_row_ind = 'N', tgt.audit_update_dttm=current_date , tgt.audit_activity_cd = 'U', tgt.audit_row_end_dttm=to_date('{business_date}' , 'yyyy-MM-dd' ) 
            """)
        logger.info(f"Update updates Merged into Target Table : {update_ins_tgt_df.count()}")
    except Exception as e:
        logger.error(f"Error when writing into the {target_table} for Upd Upd: {e}")  
        sys.exit(80)
    
    try:
        update_ins_tgt_df.writeTo(target_table).tableProperty("format-version", "2").append()
        logger.info(f"Update Inserts loaded into Target Table : {update_ins_tgt_df.count()}")
    except Exception as e:
        logger.error(f"Error when writing into the {target_table} for Upd Ins: {e}")  
        sys.exit(85)