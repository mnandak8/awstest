import boto3
import sys
import os
import pandas as pd 
from datetime import datetime

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job

from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql.window import Window
from pyspark.sql.functions import * 
from pyspark.sql import functions as F
sys.path.append('s3://{env}-acb-dl-dat-lak-tooling-asset/acbs/pythonmodules/acbsreusablemodules.zip')
from logger_setup import logger

########################################
def definition_validate_and_format_src_data(target_table,spark,df_raw_data,df_src_dataformat,list_pk_columns):
    
    try:
        tgt_iceberg_columns_df = spark.read.format("iceberg").load(f"{target_table}")  
    except Exception as error:
        logger.error(f"Error reading the Iceberg Target Table {target_table} --> error {error} ")
        sys.exit(50)
    for pk in list_pk_columns:
        pk_col=pk
    window_spec = Window.partitionBy(list_pk_columns).orderBy(F.col(pk_col).desc())
    df_raw_data_with_rownum = df_raw_data.withColumn("row_num", F.row_number().over(window_spec))
    df_no_duplicates = df_raw_data_with_rownum.filter(F.col('row_num') == 1).drop("row_num")
    df_raw_data=df_no_duplicates
    logger.info(f"Final Count after removing the Dups from SRC  {df_raw_data.count()} ")    
    tgt_column_data_types = tgt_iceberg_columns_df.dtypes
    tgt_column_data_types_schema = ["column", "tgt_colum_datatype"]
    df_tgt_column_data_types = spark.createDataFrame(tgt_column_data_types, tgt_column_data_types_schema)
    df_joined_columns_datatypes = df_tgt_column_data_types.join(df_src_dataformat, on='column', how='inner')
    rows_df = df_joined_columns_datatypes.collect()
    for row in rows_df:
        src_column=row['column']
        src_dtype=row['tgt_colum_datatype']
        src_column_dataformat=row['src_column_dataformat']
        if src_dtype == "date" and  "audit_" not in src_column:
            df_raw_data = df_raw_data.withColumn(src_column,when(to_date(col(src_column), src_column_dataformat).isNotNull(),  to_date(col(src_column), src_column_dataformat) ).otherwise(None) ) # convert to date
        if  "decimal" in src_dtype and  "audit_" not in src_column:
            df_raw_data = df_raw_data.withColumn(src_column,when(col(src_column).rlike(r"^[-+]?\d*\.?\d+$"), col(src_column).cast("double")).otherwise(None) ) # convert to decimal 
        if  "int" in src_dtype and  "audit_" not in src_column:
            df_raw_data = df_raw_data.withColumn(src_column,when(col(src_column).rlike(r"^[-+]?\d*"), col(src_column).cast("int")).otherwise(None) ) # convert to integer
    return(tgt_iceberg_columns_df,df_raw_data)