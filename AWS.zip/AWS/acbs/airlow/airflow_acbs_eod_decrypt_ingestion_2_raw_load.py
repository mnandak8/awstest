from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 1,
    'email_on_failure': False,
    'retry_delay': timedelta(minutes=5)
}
start_date = datetime(2025, 1, 1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ing2raw',
    description='ACBS SOD files Decrypt and Load 2 Raw',
    default_args=default_args,
    tags=['ACBS'],
    schedule=None,  
    catchup=False, 
    max_active_tasks=15,
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag ,on_success_callback=[sns_notifier.success_notification])
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag ,on_success_callback=[sns_notifier.success_notification])

COCMAW = GlueJobOperator(task_id = 'COCMAW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAW"},dag=dag)
COCMAW_crawler = GlueCrawlerOperator(task_id="COCMAW_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAW" } , poll_interval=30, dag = dag)

COCMAZ = GlueJobOperator(task_id = 'COCMAZ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAZ"},dag=dag)
COCMAZ_crawler = GlueCrawlerOperator(task_id="COCMAZ_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAZ" } , poll_interval=30, dag = dag)

COCMAU = GlueJobOperator(task_id = 'COCMAU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAU"},dag=dag)
COCMAU_crawler = GlueCrawlerOperator(task_id="COCMAU_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAU" } , poll_interval=30, dag = dag)

COCMAV = GlueJobOperator(task_id = 'COCMAV',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAV"},dag=dag)
COCMAV_crawler = GlueCrawlerOperator(task_id="COCMAV_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAV" } , poll_interval=30, dag = dag)

J_CLFD = GlueJobOperator(task_id = 'J_CLFD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFD"},dag=dag)
J_CLFD_crawler = GlueCrawlerOperator(task_id="J_CLFD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLFD" } , poll_interval=30, dag = dag)

ZSEDTL = GlueJobOperator(task_id = 'ZSEDTL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZSEDTL"},dag=dag)
ZSEDTL_crawler = GlueCrawlerOperator(task_id="ZSEDTL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZSEDTL" } , poll_interval=30, dag = dag)

J_GLAS = GlueJobOperator(task_id = 'J_GLAS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLAS"},dag=dag)
J_GLAS_crawler = GlueCrawlerOperator(task_id="J_GLAS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_GLAS" } , poll_interval=30, dag = dag)

FNGNEL = GlueJobOperator(task_id = 'FNGNEL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNEL"},dag=dag)
FNGNEL_crawler = GlueCrawlerOperator(task_id="FNGNEL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_FNGNEL" } , poll_interval=30, dag = dag)

J_CLLI = GlueJobOperator(task_id = 'J_CLLI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLI"},dag=dag)
J_CLLI_crawler = GlueCrawlerOperator(task_id="J_CLLI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLLI" } , poll_interval=30, dag = dag)

DSLWTI = GlueJobOperator(task_id = 'DSLWTI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTI"},dag=dag)
DSLWTI_crawler = GlueCrawlerOperator(task_id="DSLWTI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTI" } , poll_interval=30, dag = dag)

J_SYFL = GlueJobOperator(task_id = 'J_SYFL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYFL"},dag=dag)
J_SYFL_crawler = GlueCrawlerOperator(task_id="J_SYFL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYFL" } , poll_interval=30, dag = dag)

DSCAGL = GlueJobOperator(task_id = 'DSCAGL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGL"},dag=dag)
DSCAGL_crawler = GlueCrawlerOperator(task_id="DSCAGL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAGL" } , poll_interval=30, dag = dag)

DSLWTRR = GlueJobOperator(task_id = 'DSLWTRR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTRR"},dag=dag)
DSLWTRR_crawler = GlueCrawlerOperator(task_id="DSLWTRR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTRR" } , poll_interval=30, dag = dag)

DSTRDM = GlueJobOperator(task_id = 'DSTRDM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRDM"},dag=dag)
DSTRDM_crawler = GlueCrawlerOperator(task_id="DSTRDM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSTRDM" } , poll_interval=30, dag = dag)

DSTRMS = GlueJobOperator(task_id = 'DSTRMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRMS"},dag=dag)
DSTRMS_crawler = GlueCrawlerOperator(task_id="DSTRMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSTRMS" } , poll_interval=30, dag = dag)

J_CUIS = GlueJobOperator(task_id = 'J_CUIS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIS"},dag=dag)
J_CUIS_crawler = GlueCrawlerOperator(task_id="J_CUIS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUIS" } , poll_interval=30, dag = dag)

J_SYDMR = GlueJobOperator(task_id = 'J_SYDMR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDMR"},dag=dag)
J_SYDMR_crawler = GlueCrawlerOperator(task_id="J_SYDMR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYDMR" } , poll_interval=30, dag = dag)

Z_CLPY = GlueJobOperator(task_id = 'Z_CLPY',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPY"},dag=dag)
Z_CLPY_crawler = GlueCrawlerOperator(task_id="Z_CLPY_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CLPY" } , poll_interval=30, dag = dag)

COCMAF = GlueJobOperator(task_id = 'COCMAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAF"},dag=dag)
COCMAF_crawler = GlueCrawlerOperator(task_id="COCMAF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAF" } , poll_interval=30, dag = dag)

J_SYXM = GlueJobOperator(task_id = 'J_SYXM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXM"},dag=dag)
J_SYXM_crawler = GlueCrawlerOperator(task_id="J_SYXM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYXM" } , poll_interval=30, dag = dag)

J_SYXL = GlueJobOperator(task_id = 'J_SYXL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXL"},dag=dag)
J_SYXL_crawler = GlueCrawlerOperator(task_id="J_SYXL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYXL" } , poll_interval=30, dag = dag)

J_CTPG = GlueJobOperator(task_id = 'J_CTPG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPG"},dag=dag)
J_CTPG_crawler = GlueCrawlerOperator(task_id="J_CTPG_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTPG" } , poll_interval=30, dag = dag)

J_CTPD = GlueJobOperator(task_id = 'J_CTPD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPD"},dag=dag)
J_CTPD_crawler = GlueCrawlerOperator(task_id="J_CTPD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTPD" } , poll_interval=30, dag = dag)

DSLWUT = GlueJobOperator(task_id = 'DSLWUT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWUT"},dag=dag)
DSLWUT_crawler = GlueCrawlerOperator(task_id="DSLWUT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWUT" } , poll_interval=30, dag = dag)


J_CLAS = GlueJobOperator(task_id = 'J_CLAS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAS"},dag=dag)
J_CLAS_crawler = GlueCrawlerOperator(task_id="J_CLAS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAS"  } , poll_interval=30, dag = dag)

ZFBPEXT = GlueJobOperator(task_id = 'ZFBPEXT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPEXT"},dag=dag)
ZFBPEXT_crawler = GlueCrawlerOperator(task_id="ZFBPEXT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFBPEXT"  } , poll_interval=30, dag = dag)

J_CAFE = GlueJobOperator(task_id = 'J_CAFE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFE"},dag=dag)   
J_CAFE_crawler = GlueCrawlerOperator(task_id="J_CAFE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFE"  } , poll_interval=30, dag = dag)

J_CAFI = GlueJobOperator(task_id = 'J_CAFI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFI"},dag=dag)   
J_CAFI_crawler = GlueCrawlerOperator(task_id="J_CAFI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFI"  } , poll_interval=30, dag = dag)

J_CLLA = GlueJobOperator(task_id = 'J_CLLA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLA"},dag=dag)   
J_CLLA_crawler = GlueCrawlerOperator(task_id="J_CLLA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLLA"  } , poll_interval=30, dag = dag)

J_CLIS = GlueJobOperator(task_id = 'J_CLIS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIS"},dag=dag)   
J_CLIS_crawler = GlueCrawlerOperator(task_id="J_CLIS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLIS"  } , poll_interval=30, dag = dag)

DMEXAF = GlueJobOperator(task_id = 'DMEXAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DMEXAF"},dag=dag)   
DMEXAF_crawler = GlueCrawlerOperator(task_id="DMEXAF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DMEXAF"  } , poll_interval=30, dag = dag)

J_CLRS = GlueJobOperator(task_id = 'J_CLRS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRS"},dag=dag)   
J_CLRS_crawler = GlueCrawlerOperator(task_id="J_CLRS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLRS"  } , poll_interval=30, dag = dag)

ZQRMEX = GlueJobOperator(task_id = 'ZQRMEX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZQRMEX"},dag=dag)   
ZQRMEX_crawler = GlueCrawlerOperator(task_id="ZQRMEX_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZQRMEX"  } , poll_interval=30, dag = dag)

J_CLPB = GlueJobOperator(task_id = 'J_CLPB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPB"},dag=dag)   
J_CLPB_crawler = GlueCrawlerOperator(task_id="J_CLPB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPB"  } , poll_interval=30, dag = dag)

J_CLPS = GlueJobOperator(task_id = 'J_CLPS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPS"},dag=dag)
J_CLPS_crawler = GlueCrawlerOperator(task_id="J_CLPS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPS"  } , poll_interval=30, dag = dag)

ZWFBLH = GlueJobOperator(task_id = 'ZWFBLH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFBLH"},dag=dag)
ZWFBLH_crawler = GlueCrawlerOperator(task_id="ZWFBLH_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFBLH"  } , poll_interval=30, dag = dag)

COCMAG = GlueJobOperator(task_id = 'COCMAG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAG"},dag=dag)
COCMAG_crawler = GlueCrawlerOperator(task_id="COCMAG_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAG"  } , poll_interval=30, dag = dag)

J_CLMS = GlueJobOperator(task_id = 'J_CLMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMS"},dag=dag)
J_CLMS_crawler = GlueCrawlerOperator(task_id="J_CLMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLMS"  } , poll_interval=30, dag = dag)

J_CAFB = GlueJobOperator(task_id = 'J_CAFB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFB"},dag=dag)
J_CAFB_crawler = GlueCrawlerOperator(task_id="J_CAFB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFB"  } , poll_interval=30, dag = dag)

Z_LBRHST = GlueJobOperator(task_id = 'Z_LBRHST',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_LBRHST"},dag=dag)
Z_LBRHST_crawler = GlueCrawlerOperator(task_id="Z_LBRHST_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_LBRHST"  } , poll_interval=30, dag = dag)

DSLWTR = GlueJobOperator(task_id = 'DSLWTR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTR"},dag=dag)
DSLWTR_crawler = GlueCrawlerOperator(task_id="DSLWTR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTR"  } , poll_interval=30, dag = dag)

J_CALM = GlueJobOperator(task_id = 'J_CALM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CALM"},dag=dag)
J_CALM_crawler = GlueCrawlerOperator(task_id="J_CALM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CALM"  } , poll_interval=30, dag = dag)

J_CAFF = GlueJobOperator(task_id = 'J_CAFF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFF"},dag=dag)
J_CAFF_crawler = GlueCrawlerOperator(task_id="J_CAFF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFF"  } , poll_interval=30, dag = dag)

DSLWTB = GlueJobOperator(task_id = 'DSLWTB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTB"},dag=dag)
DSLWTB_crawler = GlueCrawlerOperator(task_id="DSLWTB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWTB"  } , poll_interval=30, dag = dag)

J_CLMI = GlueJobOperator(task_id = 'J_CLMI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMI"},dag=dag)
J_CLMI_crawler = GlueCrawlerOperator(task_id="J_CLMI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLMI"  } , poll_interval=30, dag = dag)

J_CLTP = GlueJobOperator(task_id = 'J_CLTP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTP"},dag=dag)
J_CLTP_crawler = GlueCrawlerOperator(task_id="J_CLTP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLTP"  } , poll_interval=30, dag = dag)

ZWFCUD = GlueJobOperator(task_id = 'ZWFCUD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFCUD"},dag=dag)
ZWFCUD_crawler = GlueCrawlerOperator(task_id="ZWFCUD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFCUD"  } , poll_interval=30, dag = dag)

Z_GLDT = GlueJobOperator(task_id = 'Z_GLDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_GLDT"},dag=dag)
Z_GLDT_crawler = GlueCrawlerOperator(task_id="Z_GLDT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_GLDT"  } , poll_interval=30, dag = dag)

J_CAMS = GlueJobOperator(task_id = 'J_CAMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMS"},dag=dag)
J_CAMS_crawler = GlueCrawlerOperator(task_id="J_CAMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAMS"  } , poll_interval=30, dag = dag)

J_CLDTW = GlueJobOperator(task_id = 'J_CLDTW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDTW"},dag=dag)
J_CLDTW_crawler = GlueCrawlerOperator(task_id="J_CLDTW_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLDTW"  } , poll_interval=30, dag = dag)

J_CUPI = GlueJobOperator(task_id = 'J_CUPI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUPI"},dag=dag)
J_CUPI_crawler = GlueCrawlerOperator(task_id="J_CUPI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUPI"  } , poll_interval=30, dag = dag)

J_CLAP = GlueJobOperator(task_id = 'J_CLAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAP"},dag=dag)
J_CLAP_crawler = GlueCrawlerOperator(task_id="J_CLAP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAP"  } , poll_interval=30, dag = dag)

DSGNEB = GlueJobOperator(task_id = 'DSGNEB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSGNEB"},dag=dag)
DSGNEB_crawler = GlueCrawlerOperator(task_id="DSGNEB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSGNEB"  } , poll_interval=30, dag = dag)

Z_ACCLSM = GlueJobOperator(task_id = 'Z_ACCLSM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACCLSM"},dag=dag)
Z_ACCLSM_crawler = GlueCrawlerOperator(task_id="Z_ACCLSM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ACCLSM"  } , poll_interval=30, dag = dag)


##

J_CAMI = GlueJobOperator(task_id = 'J_CAMI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMI"},dag=dag)
J_CAMI_crawler = GlueCrawlerOperator(task_id="J_CAMI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAMI"  } , poll_interval=30, dag = dag)

COADOB = GlueJobOperator(task_id = 'COADOB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COADOB"},dag=dag)      
COADOB_crawler = GlueCrawlerOperator(task_id="COADOB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COADOB"  } , poll_interval=30, dag = dag)

J_CUMS = GlueJobOperator(task_id = 'J_CUMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUMS"},dag=dag)      
J_CUMS_crawler = GlueCrawlerOperator(task_id="J_CUMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUMS"  } , poll_interval=30, dag = dag)

J_CUAD = GlueJobOperator(task_id = 'J_CUAD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAD"},dag=dag)      
J_CUAD_crawler = GlueCrawlerOperator(task_id="J_CUAD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUAD"  } , poll_interval=30, dag = dag)

J_CUDT = GlueJobOperator(task_id = 'J_CUDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUDT"},dag=dag)      
J_CUDT_crawler = GlueCrawlerOperator(task_id="J_CUDT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUDT"  } , poll_interval=30, dag = dag)

J_CLSB = GlueJobOperator(task_id = 'J_CLSB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLSB"},dag=dag)      
J_CLSB_crawler = GlueCrawlerOperator(task_id="J_CLSB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLSB"  } , poll_interval=30, dag = dag)

J_SYDM = GlueJobOperator(task_id = 'J_SYDM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDM"},dag=dag)      
J_SYDM_crawler = GlueCrawlerOperator(task_id="J_SYDM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYDM"  } , poll_interval=30, dag = dag)

J_SYDR = GlueJobOperator(task_id = 'J_SYDR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDR"},dag=dag)      
J_SYDR_crawler = GlueCrawlerOperator(task_id="J_SYDR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYDR"  } , poll_interval=30, dag = dag)

Z_CAPINM = GlueJobOperator(task_id = 'Z_CAPINM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINM"},dag=dag)
Z_CAPINM_crawler = GlueCrawlerOperator(task_id="Z_CAPINM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAPINM"  } , poll_interval=30, dag = dag)

DSLWLR = GlueJobOperator(task_id = 'DSLWLR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLR"},dag=dag)      
DSLWLR_crawler = GlueCrawlerOperator(task_id="DSLWLR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWLR"  } , poll_interval=30, dag = dag)

J_CUCR = GlueJobOperator(task_id = 'J_CUCR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUCR"},dag=dag)
J_CUCR_crawler = GlueCrawlerOperator(task_id="J_CUCR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUCR"  } , poll_interval=30, dag = dag)

J_CACG = GlueJobOperator(task_id = 'J_CACG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CACG"},dag=dag)
J_CACG_crawler = GlueCrawlerOperator(task_id="J_CACG_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CACG"  } , poll_interval=30, dag = dag)

J_CLRR = GlueJobOperator(task_id = 'J_CLRR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRR"},dag=dag)
J_CLRR_crawler = GlueCrawlerOperator(task_id="J_CLRR_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLRR"  } , poll_interval=30, dag = dag)

J_GLER = GlueJobOperator(task_id = 'J_GLER',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLER"},dag=dag)
J_GLER_crawler = GlueCrawlerOperator(task_id="J_GLER_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_GLER"  } , poll_interval=30, dag = dag)

J_CUAL = GlueJobOperator(task_id = 'J_CUAL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAL"},dag=dag)
J_CUAL_crawler = GlueCrawlerOperator(task_id="J_CUAL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUAL"  } , poll_interval=30, dag = dag)

Z_CUEX = GlueJobOperator(task_id = 'Z_CUEX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUEX"},dag=dag)
Z_CUEX_crawler = GlueCrawlerOperator(task_id="Z_CUEX_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CUEX"  } , poll_interval=30, dag = dag)

DSLWNL = GlueJobOperator(task_id = 'DSLWNL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWNL"},dag=dag)
DSLWNL_crawler = GlueCrawlerOperator(task_id="DSLWNL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWNL"  } , poll_interval=30, dag = dag)

J_CTDE = GlueJobOperator(task_id = 'J_CTDE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTDE"},dag=dag)
J_CTDE_crawler = GlueCrawlerOperator(task_id="J_CTDE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTDE"  } , poll_interval=30, dag = dag)

Z_ATCI = GlueJobOperator(task_id = 'Z_ATCI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCI"},dag=dag)
Z_ATCI_crawler = GlueCrawlerOperator(task_id="Z_ATCI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ATCI"  } , poll_interval=30, dag = dag)

Z_ATCUST = GlueJobOperator(task_id = 'Z_ATCUST',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCUST"},dag=dag)
Z_ATCUST_crawler = GlueCrawlerOperator(task_id="Z_ATCUST_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ATCUST"  } , poll_interval=30, dag = dag)

J_SYCD = GlueJobOperator(task_id = 'J_SYCD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYCD"},dag=dag)
J_SYCD_crawler = GlueCrawlerOperator(task_id="J_SYCD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYCD"  } , poll_interval=30, dag = dag)

DSLWLA = GlueJobOperator(task_id = 'DSLWLA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLA"},dag=dag)
DSLWLA_crawler = GlueCrawlerOperator(task_id="DSLWLA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWLA"  } , poll_interval=30, dag = dag)

J_CUIN = GlueJobOperator(task_id = 'J_CUIN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIN"},dag=dag)
J_CUIN_crawler = GlueCrawlerOperator(task_id="J_CUIN_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUIN"  } , poll_interval=30, dag = dag)

Z_CAPINT = GlueJobOperator(task_id = 'Z_CAPINT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINT"},dag=dag)
Z_CAPINT_crawler = GlueCrawlerOperator(task_id="Z_CAPINT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAPINT"  } , poll_interval=30, dag = dag)

DSLWLB = GlueJobOperator(task_id = 'DSLWLB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLB"},dag=dag)
DSLWLB_crawler = GlueCrawlerOperator(task_id="DSLWLB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWLB"  } , poll_interval=30, dag = dag)

J_GLBS = GlueJobOperator(task_id = 'J_GLBS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLBS"},dag=dag)
J_GLBS_crawler = GlueCrawlerOperator(task_id="J_GLBS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_GLBS"  } , poll_interval=30, dag = dag)

DSCAGP = GlueJobOperator(task_id = 'DSCAGP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGP"},dag=dag)
DSCAGP_crawler = GlueCrawlerOperator(task_id="DSCAGP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAGP"  } , poll_interval=30, dag = dag)

Z_CAMA = GlueJobOperator(task_id = 'Z_CAMA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAMA"},dag=dag)
Z_CAMA_crawler = GlueCrawlerOperator(task_id="Z_CAMA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAMA"  } , poll_interval=30, dag = dag)

J_CLPC = GlueJobOperator(task_id = 'J_CLPC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPC"},dag=dag)
J_CLPC_crawler = GlueCrawlerOperator(task_id="J_CLPC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPC"  } , poll_interval=30, dag = dag)

J_CLDT = GlueJobOperator(task_id = 'J_CLDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDT"},dag=dag)
J_CLDT_crawler = GlueCrawlerOperator(task_id="J_CLDT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLDT"  } , poll_interval=30, dag = dag)

###

DSCAPL = GlueJobOperator(task_id = 'DSCAPL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPL"},dag=dag)
DSCAPL_crawler = GlueCrawlerOperator(task_id="DSCAPL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAPL"  } , poll_interval=30, dag = dag)

Z_CAPPF = GlueJobOperator(task_id = 'Z_CAPPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPPF"},dag=dag)   
Z_CAPPF_crawler = GlueCrawlerOperator(task_id="Z_CAPPF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAPPF"  } , poll_interval=30, dag = dag)

DSLWLM = GlueJobOperator(task_id = 'DSLWLM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLM"},dag=dag)      
DSLWLM_crawler = GlueCrawlerOperator(task_id="DSLWLM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSLWLM"  } , poll_interval=30, dag = dag)

COCMAP = GlueJobOperator(task_id = 'COCMAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAP"},dag=dag)      
COCMAP_crawler = GlueCrawlerOperator(task_id="COCMAP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAP"  } , poll_interval=30, dag = dag)

J_CLGU = GlueJobOperator(task_id = 'J_CLGU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLGU"},dag=dag)      
J_CLGU_crawler = GlueCrawlerOperator(task_id="J_CLGU_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLGU"  } , poll_interval=30, dag = dag)

DSCAPI = GlueJobOperator(task_id = 'DSCAPI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPI"},dag=dag)      
DSCAPI_crawler = GlueCrawlerOperator(task_id="DSCAPI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAPI"  } , poll_interval=30, dag = dag)

J_CLFP = GlueJobOperator(task_id = 'J_CLFP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFP"},dag=dag)      
J_CLFP_crawler = GlueCrawlerOperator(task_id="J_CLFP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLFP"  } , poll_interval=30, dag = dag)

Z_ACSOLD = GlueJobOperator(task_id = 'Z_ACSOLD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACSOLD"},dag=dag)
Z_ACSOLD_crawler = GlueCrawlerOperator(task_id="Z_ACSOLD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ACSOLD"  } , poll_interval=30, dag = dag)

Z_CAADDI = GlueJobOperator(task_id = 'Z_CAADDI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAADDI"},dag=dag)
Z_CAADDI_crawler = GlueCrawlerOperator(task_id="Z_CAADDI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAADDI"  } , poll_interval=30, dag = dag)

DSCAGH = GlueJobOperator(task_id = 'DSCAGH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGH"},dag=dag)      
DSCAGH_crawler = GlueCrawlerOperator(task_id="DSCAGH_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAGH"  } , poll_interval=30, dag = dag)

DSCAIL = GlueJobOperator(task_id = 'DSCAIL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAIL"},dag=dag)
DSCAIL_crawler = GlueCrawlerOperator(task_id="DSCAIL_crawler",config={"Name": "lending_acbs_raw_dataasset_db_DSCAIL"  } , poll_interval=30, dag = dag)

J_GLNO = GlueJobOperator(task_id = 'J_GLNO',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLNO"},dag=dag)
J_GLNO_crawler = GlueCrawlerOperator(task_id="J_GLNO_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_GLNO"  } , poll_interval=30, dag = dag)

ZCMXRF = GlueJobOperator(task_id = 'ZCMXRF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXRF"},dag=dag)
ZCMXRF_crawler = GlueCrawlerOperator(task_id="ZCMXRF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZCMXRF"  } , poll_interval=30, dag = dag)

J_SCMS = GlueJobOperator(task_id = 'J_SCMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SCMS"},dag=dag)
J_SCMS_crawler = GlueCrawlerOperator(task_id="J_SCMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SCMS"  } , poll_interval=30, dag = dag)

COCMAJ = GlueJobOperator(task_id = 'COCMAJ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAJ"},dag=dag)
COCMAJ_crawler = GlueCrawlerOperator(task_id="COCMAJ_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAJ"  } , poll_interval=30, dag = dag)

J_CTUN = GlueJobOperator(task_id = 'J_CTUN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUN"},dag=dag)
J_CTUN_crawler = GlueCrawlerOperator(task_id="J_CTUN_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTUN"  } , poll_interval=30, dag = dag)

J_CULB = GlueJobOperator(task_id = 'J_CULB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CULB"},dag=dag)
J_CULB_crawler = GlueCrawlerOperator(task_id="J_CULB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CULB"  } , poll_interval=30, dag = dag)

Z_CUSNAI = GlueJobOperator(task_id = 'Z_CUSNAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUSNAI"},dag=dag)   
Z_CUSNAI_crawler = GlueCrawlerOperator(task_id="Z_CUSNAI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CUSNAI"  } , poll_interval=30, dag = dag)

Z_CAP = GlueJobOperator(task_id = 'Z_CAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAP"},dag=dag)
Z_CAP_crawler = GlueCrawlerOperator(task_id="Z_CAP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAP"  } , poll_interval=30, dag = dag)

J_CLIX = GlueJobOperator(task_id = 'J_CLIX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIX"},dag=dag)
J_CLIX_crawler = GlueCrawlerOperator(task_id="J_CLIX_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLIX"  } , poll_interval=30, dag = dag)

Z_CUMA = GlueJobOperator(task_id = 'Z_CUMA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUMA"},dag=dag)
Z_CUMA_crawler = GlueCrawlerOperator(task_id="Z_CUMA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CUMA"  } , poll_interval=30, dag = dag)

COCMAO = GlueJobOperator(task_id = 'COCMAO',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAO"},dag=dag)
COCMAO_crawler = GlueCrawlerOperator(task_id="COCMAO_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAO"  } , poll_interval=30, dag = dag)

J_CTMS = GlueJobOperator(task_id = 'J_CTMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTMS"},dag=dag)
J_CTMS_crawler = GlueCrawlerOperator(task_id="J_CTMS_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTMS"  } , poll_interval=30, dag = dag)

ZCMXAI = GlueJobOperator(task_id = 'ZCMXAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXAI"},dag=dag)
ZCMXAI_crawler = GlueCrawlerOperator(task_id="ZCMXAI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZCMXAI"  } , poll_interval=30, dag = dag)

J_CLTE = GlueJobOperator(task_id = 'J_CLTE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTE"},dag=dag)
J_CLTE_crawler = GlueCrawlerOperator(task_id="J_CLTE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLTE"  } , poll_interval=30, dag = dag)

Z_FCLACT = GlueJobOperator(task_id = 'Z_FCLACT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_FCLACT"},dag=dag)   
Z_FCLACT_crawler = GlueCrawlerOperator(task_id="Z_FCLACT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_FCLACT"  } , poll_interval=30, dag = dag)

ZFMIFB = GlueJobOperator(task_id = 'ZFMIFB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFMIFB"},dag=dag)
ZFMIFB_crawler = GlueCrawlerOperator(task_id="ZFMIFB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFMIFB"  } , poll_interval=30, dag = dag)

J_CAGU = GlueJobOperator(task_id = 'J_CAGU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAGU"},dag=dag)
J_CAGU_crawler = GlueCrawlerOperator(task_id="J_CAGU_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAGU"  } , poll_interval=30, dag = dag)

J_GLCC = GlueJobOperator(task_id = 'J_GLCC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLCC"},dag=dag)
J_GLCC_crawler = GlueCrawlerOperator(task_id="J_GLCC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_GLCC"  } , poll_interval=30, dag = dag)

Z_CIB = GlueJobOperator(task_id = 'Z_CIB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CIB"},dag=dag)
Z_CIB_crawler = GlueCrawlerOperator(task_id="Z_CIB_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CIB"  } , poll_interval=30, dag = dag)

###
J_CLRM = GlueJobOperator(task_id = 'J_CLRM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRM"},dag=dag)
J_CLRM_crawler = GlueCrawlerOperator(task_id="J_CLRM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLRM"  } , poll_interval=30, dag = dag)

COCMBD = GlueJobOperator(task_id = 'COCMBD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMBD"},dag=dag)   
COCMBD_crawler = GlueCrawlerOperator(task_id="COCMBD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMBD"  } , poll_interval=30, dag = dag)

J_CTUH = GlueJobOperator(task_id = 'J_CTUH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUH"},dag=dag)   
J_CTUH_crawler = GlueCrawlerOperator(task_id="J_CTUH_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTUH"  } , poll_interval=30, dag = dag)

Z_CDERV = GlueJobOperator(task_id = 'Z_CDERV',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CDERV"},dag=dag)
Z_CDERV_crawler = GlueCrawlerOperator(task_id="Z_CDERV_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CDERV"  } , poll_interval=30, dag = dag)

Z_ADCA = GlueJobOperator(task_id = 'Z_ADCA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ADCA"},dag=dag)   
Z_ADCA_crawler = GlueCrawlerOperator(task_id="Z_ADCA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_ADCA"  } , poll_interval=30, dag = dag)

J_CATE = GlueJobOperator(task_id = 'J_CATE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CATE"},dag=dag)   
J_CATE_crawler = GlueCrawlerOperator(task_id="J_CATE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CATE"  } , poll_interval=30, dag = dag)

Z_CAPEQ = GlueJobOperator(task_id = 'Z_CAPEQ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPEQ"},dag=dag)
Z_CAPEQ_crawler = GlueCrawlerOperator(task_id="Z_CAPEQ_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CAPEQ"  } , poll_interval=30, dag = dag)

J_CTID = GlueJobOperator(task_id = 'J_CTID',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTID"},dag=dag)
J_CTID_crawler = GlueCrawlerOperator(task_id="J_CTID_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTID"  } , poll_interval=30, dag = dag)

J_CLMX = GlueJobOperator(task_id = 'J_CLMX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMX"},dag=dag)
J_CLMX_crawler = GlueCrawlerOperator(task_id="J_CLMX_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLMX"  } , poll_interval=30, dag = dag)

COCMAN = GlueJobOperator(task_id = 'COCMAN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAN"},dag=dag)
COCMAN_crawler = GlueCrawlerOperator(task_id="COCMAN_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAN"  } , poll_interval=30, dag = dag)

J_CADT = GlueJobOperator(task_id = 'J_CADT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADT"},dag=dag)
J_CADT_crawler = GlueCrawlerOperator(task_id="J_CADT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CADT"  } , poll_interval=30, dag = dag)

J_CUAF = GlueJobOperator(task_id = 'J_CUAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAF"},dag=dag)
J_CUAF_crawler = GlueCrawlerOperator(task_id="J_CUAF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUAF"  } , poll_interval=30, dag = dag)

J_CLAC = GlueJobOperator(task_id = 'J_CLAC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAC"},dag=dag)
J_CLAC_crawler = GlueCrawlerOperator(task_id="J_CLAC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAC"  } , poll_interval=30, dag = dag)

J_CLBC = GlueJobOperator(task_id = 'J_CLBC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLBC"},dag=dag)
J_CLBC_crawler = GlueCrawlerOperator(task_id="J_CLBC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLBC"  } , poll_interval=30, dag = dag)

J_CUTE = GlueJobOperator(task_id = 'J_CUTE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUTE"},dag=dag)
J_CUTE_crawler = GlueCrawlerOperator(task_id="J_CUTE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CUTE"  } , poll_interval=30, dag = dag)

COCMAI = GlueJobOperator(task_id = 'COCMAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAI"},dag=dag)
COCMAI_crawler = GlueCrawlerOperator(task_id="COCMAI_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAI"  } , poll_interval=30, dag = dag)

J_CAFT = GlueJobOperator(task_id = 'J_CAFT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFT"},dag=dag)
J_CAFT_crawler = GlueCrawlerOperator(task_id="J_CAFT_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAFT"  } , poll_interval=30, dag = dag)

ZFBPCFE = GlueJobOperator(task_id = 'ZFBPCFE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPCFE"},dag=dag)      
ZFBPCFE_crawler = GlueCrawlerOperator(task_id="ZFBPCFE_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZFBPCFE"  } , poll_interval=30, dag = dag)

COCMAA = GlueJobOperator(task_id = 'COCMAA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAA"},dag=dag)
COCMAA_crawler = GlueCrawlerOperator(task_id="COCMAA_crawler",config={"Name": "lending_acbs_raw_dataasset_db_COCMAA"  } , poll_interval=30, dag = dag)

J_CTIM = GlueJobOperator(task_id = 'J_CTIM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTIM"},dag=dag)
J_CTIM_crawler = GlueCrawlerOperator(task_id="J_CTIM_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CTIM"  } , poll_interval=30, dag = dag)

J_CLAD = GlueJobOperator(task_id = 'J_CLAD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAD"},dag=dag)
J_CLAD_crawler = GlueCrawlerOperator(task_id="J_CLAD_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLAD"  } , poll_interval=30, dag = dag)

J_CADTW = GlueJobOperator(task_id = 'J_CADTW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADTW"},dag=dag)      
J_CADTW_crawler = GlueCrawlerOperator(task_id="J_CADTW_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CADTW"  } , poll_interval=30, dag = dag)

J_CLPF = GlueJobOperator(task_id = 'J_CLPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPF"},dag=dag)
J_CLPF_crawler = GlueCrawlerOperator(task_id="J_CLPF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CLPF"  } , poll_interval=30, dag = dag)

Z_CLPPF = GlueJobOperator(task_id = 'Z_CLPPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPPF"},dag=dag)      
Z_CLPPF_crawler = GlueCrawlerOperator(task_id="Z_CLPPF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_Z_CLPPF"  } , poll_interval=30, dag = dag)

J_CAPF = GlueJobOperator(task_id = 'J_CAPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAPF"},dag=dag)
J_CAPF_crawler = GlueCrawlerOperator(task_id="J_CAPF_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_CAPF"  } , poll_interval=30, dag = dag)

ZWFTYP = GlueJobOperator(task_id = 'ZWFTYP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFTYP"},dag=dag)
ZWFTYP_crawler = GlueCrawlerOperator(task_id="ZWFTYP_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFTYP"  } , poll_interval=30, dag = dag)

FNGNED = GlueJobOperator(task_id = 'FNGNED',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNED"},dag=dag)
FNGNED_crawler = GlueCrawlerOperator(task_id="FNGNED_crawler",config={"Name": "lending_acbs_raw_dataasset_db_FNGNED"  } , poll_interval=30, dag = dag)

ZWFPLN = GlueJobOperator(task_id = 'ZWFPLN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFPLN"},dag=dag)
ZWFPLN_crawler = GlueCrawlerOperator(task_id="ZWFPLN_crawler",config={"Name": "lending_acbs_raw_dataasset_db_ZWFPLN"  } , poll_interval=30, dag = dag)


 

ACBS_EOD_Raw_Start_Task >> [J_CLRM,COCMBD,J_CTUH,Z_CDERV,Z_ADCA,J_CATE,Z_CAPEQ,J_CTID,J_CLMX,COCMAN,J_CADT,J_CUAF,J_CLAC,J_CLBC,J_CUTE,COCMAI,J_CAFT,ZFBPCFE,COCMAA,J_CTIM,J_CLAD,J_CADTW,J_CLPF,Z_CLPPF,J_CAPF,ZWFTYP,FNGNED,ZWFPLN,DSCAPL,Z_CAPPF,DSLWLM,COCMAP,J_CLGU,DSCAPI,J_CLFP,Z_ACSOLD,Z_CAADDI,DSCAGH,DSCAIL,J_GLNO,ZCMXRF,J_SCMS,COCMAJ,J_CTUN,J_CULB,Z_CUSNAI,Z_CAP,J_CLIX,Z_CUMA,COCMAO,J_CTMS,ZCMXAI,J_CLTE,Z_FCLACT,ZFMIFB,J_CAGU,J_GLCC,Z_CIB,J_CAMI,COADOB,J_CUMS,J_CUAD,J_CUDT,J_CLSB,J_SYDM,J_SYDR,Z_CAPINM,DSLWLR,J_CUCR,J_CACG,J_CLRR,J_GLER,J_CUAL,Z_CUEX,DSLWNL,J_CTDE,Z_ATCI,Z_ATCUST,J_SYCD,DSLWLA,J_CUIN,Z_CAPINT,DSLWLB,J_GLBS,DSCAGP,Z_CAMA,J_CLPC,J_CLDT,COCMAW,COCMAZ,COCMAU,COCMAV,J_CLFD,ZSEDTL,J_GLAS,FNGNEL,J_CLLI,DSLWTI,J_SYFL,DSCAGL,DSLWTRR,DSTRDM,DSTRMS,J_CUIS,J_SYDMR,Z_CLPY,COCMAF,J_SYXM,J_SYXL,J_CTPG,J_CTPD,DSLWUT,J_CLAS,ZFBPEXT,J_CAFE,J_CAFI,J_CLLA,J_CLIS,DMEXAF,J_CLRS,ZQRMEX,J_CLPB,J_CLPS,ZWFBLH,COCMAG,J_CLMS,J_CAFB,Z_LBRHST,DSLWTR,J_CALM,J_CAFF,DSLWTB,J_CLMI,J_CLTP,ZWFCUD,Z_GLDT,J_CAMS,J_CLDTW,J_CUPI,J_CLAP,DSGNEB,Z_ACCLSM]

COCMAW >> COCMAW_crawler  
COCMAZ >> COCMAZ_crawler  
COCMAU >> COCMAU_crawler  
COCMAV >> COCMAV_crawler  
J_CLFD >> J_CLFD_crawler  
ZSEDTL >> ZSEDTL_crawler  
J_GLAS >> J_GLAS_crawler  
FNGNEL >> FNGNEL_crawler  
J_CLLI >> J_CLLI_crawler  
DSLWTI >> DSLWTI_crawler  
J_SYFL >> J_SYFL_crawler  
DSCAGL >> DSCAGL_crawler  
DSLWTRR >> DSLWTRR_crawler
DSTRDM >> DSTRDM_crawler  
DSTRMS >> DSTRMS_crawler  
J_CUIS >> J_CUIS_crawler  
J_SYDMR >> J_SYDMR_crawler
Z_CLPY >> Z_CLPY_crawler  
COCMAF >> COCMAF_crawler  
J_SYXM >> J_SYXM_crawler  
J_SYXL >> J_SYXL_crawler  
J_CTPG >> J_CTPG_crawler  
J_CTPD >> J_CTPD_crawler  
DSLWUT >> DSLWUT_crawler 
J_CLAS >> J_CLAS_crawler
ZFBPEXT >> ZFBPEXT_crawler  
J_CAFE >> J_CAFE_crawler    
J_CAFI >> J_CAFI_crawler    
J_CLLA >> J_CLLA_crawler    
J_CLIS >> J_CLIS_crawler    
DMEXAF >> DMEXAF_crawler    
J_CLRS >> J_CLRS_crawler    
ZQRMEX >> ZQRMEX_crawler    
J_CLPB >> J_CLPB_crawler    
J_CLPS >> J_CLPS_crawler    
ZWFBLH >> ZWFBLH_crawler    
COCMAG >> COCMAG_crawler    
J_CLMS >> J_CLMS_crawler    
J_CAFB >> J_CAFB_crawler    
Z_LBRHST >> Z_LBRHST_crawler
DSLWTR >> DSLWTR_crawler    
J_CALM >> J_CALM_crawler    
J_CAFF >> J_CAFF_crawler    
DSLWTB >> DSLWTB_crawler    
J_CLMI >> J_CLMI_crawler    
J_CLTP >> J_CLTP_crawler    
ZWFCUD >> ZWFCUD_crawler    
Z_GLDT >> Z_GLDT_crawler    
J_CAMS >> J_CAMS_crawler    
J_CLDTW >> J_CLDTW_crawler  
J_CUPI >> J_CUPI_crawler    
J_CLAP >> J_CLAP_crawler    
DSGNEB >> DSGNEB_crawler    
Z_ACCLSM >> Z_ACCLSM_crawler

J_CAMI >> J_CAMI_crawler
COADOB >> COADOB_crawler    
J_CUMS >> J_CUMS_crawler    
J_CUAD >> J_CUAD_crawler    
J_CUDT >> J_CUDT_crawler    
J_CLSB >> J_CLSB_crawler    
J_SYDM >> J_SYDM_crawler    
J_SYDR >> J_SYDR_crawler    
Z_CAPINM >> Z_CAPINM_crawler
DSLWLR >> DSLWLR_crawler    
J_CUCR >> J_CUCR_crawler    
J_CACG >> J_CACG_crawler    
J_CLRR >> J_CLRR_crawler    
J_GLER >> J_GLER_crawler    
J_CUAL >> J_CUAL_crawler    
Z_CUEX >> Z_CUEX_crawler    
DSLWNL >> DSLWNL_crawler    
J_CTDE >> J_CTDE_crawler    
Z_ATCI >> Z_ATCI_crawler    
Z_ATCUST >> Z_ATCUST_crawler
J_SYCD >> J_SYCD_crawler    
DSLWLA >> DSLWLA_crawler    
J_CUIN >> J_CUIN_crawler    
Z_CAPINT >> Z_CAPINT_crawler
DSLWLB >> DSLWLB_crawler    
J_GLBS >> J_GLBS_crawler    
DSCAGP >> DSCAGP_crawler    
Z_CAMA >> Z_CAMA_crawler    
J_CLPC >> J_CLPC_crawler    
J_CLDT >> J_CLDT_crawler 
DSCAPL >> DSCAPL_crawler
Z_CAPPF >> Z_CAPPF_crawler  
DSLWLM >> DSLWLM_crawler    
COCMAP >> COCMAP_crawler    
J_CLGU >> J_CLGU_crawler    
DSCAPI >> DSCAPI_crawler    
J_CLFP >> J_CLFP_crawler    
Z_ACSOLD >> Z_ACSOLD_crawler
Z_CAADDI >> Z_CAADDI_crawler
DSCAGH >> DSCAGH_crawler    
DSCAIL >> DSCAIL_crawler    
J_GLNO >> J_GLNO_crawler    
ZCMXRF >> ZCMXRF_crawler    
J_SCMS >> J_SCMS_crawler    
COCMAJ >> COCMAJ_crawler    
J_CTUN >> J_CTUN_crawler    
J_CULB >> J_CULB_crawler    
Z_CUSNAI >> Z_CUSNAI_crawler
Z_CAP >> Z_CAP_crawler      
J_CLIX >> J_CLIX_crawler    
Z_CUMA >> Z_CUMA_crawler    
COCMAO >> COCMAO_crawler    
J_CTMS >> J_CTMS_crawler    
ZCMXAI >> ZCMXAI_crawler    
J_CLTE >> J_CLTE_crawler    
Z_FCLACT >> Z_FCLACT_crawler
ZFMIFB >> ZFMIFB_crawler    
J_CAGU >> J_CAGU_crawler    
J_GLCC >> J_GLCC_crawler    
Z_CIB >> Z_CIB_crawler
J_CLRM >> J_CLRM_crawler
COCMBD >> COCMBD_crawler  
J_CTUH >> J_CTUH_crawler  
Z_CDERV >> Z_CDERV_crawler
Z_ADCA >> Z_ADCA_crawler  
J_CATE >> J_CATE_crawler  
Z_CAPEQ >> Z_CAPEQ_crawler
J_CTID >> J_CTID_crawler  
J_CLMX >> J_CLMX_crawler  
COCMAN >> COCMAN_crawler  
J_CADT >> J_CADT_crawler  
J_CUAF >> J_CUAF_crawler  
J_CLAC >> J_CLAC_crawler  
J_CLBC >> J_CLBC_crawler  
J_CUTE >> J_CUTE_crawler  
COCMAI >> COCMAI_crawler  
J_CAFT >> J_CAFT_crawler  
ZFBPCFE >> ZFBPCFE_crawler
COCMAA >> COCMAA_crawler  
J_CTIM >> J_CTIM_crawler
J_CLAD >> J_CLAD_crawler
J_CADTW >> J_CADTW_crawler
J_CLPF >> J_CLPF_crawler
Z_CLPPF >> Z_CLPPF_crawler
J_CAPF >> J_CAPF_crawler
ZWFTYP >> ZWFTYP_crawler
FNGNED >> FNGNED_crawler
ZWFPLN >> ZWFPLN_crawler



[J_CLRM_crawler ,COCMBD_crawler ,J_CTUH_crawler ,Z_CDERV_crawler ,Z_ADCA_crawler ,J_CATE_crawler ,Z_CAPEQ_crawler ,J_CTID_crawler ,J_CLMX_crawler ,COCMAN_crawler ,J_CADT_crawler ,J_CUAF_crawler ,J_CLAC_crawler ,J_CLBC_crawler ,J_CUTE_crawler ,COCMAI_crawler ,J_CAFT_crawler ,ZFBPCFE_crawler ,COCMAA_crawler ,J_CTIM_crawler ,J_CLAD_crawler ,J_CADTW_crawler ,J_CLPF_crawler ,Z_CLPPF_crawler ,J_CAPF_crawler ,ZWFTYP_crawler  ,FNGNED_crawler ,ZWFPLN_crawler,DSCAPL_crawler ,Z_CAPPF_crawler ,DSLWLM_crawler ,COCMAP_crawler ,J_CLGU_crawler ,DSCAPI_crawler ,J_CLFP_crawler ,Z_ACSOLD_crawler ,Z_CAADDI_crawler ,DSCAGH_crawler ,DSCAIL_crawler ,J_GLNO_crawler ,ZCMXRF_crawler ,J_SCMS_crawler ,COCMAJ_crawler ,J_CTUN_crawler ,J_CULB_crawler ,Z_CUSNAI_crawler ,Z_CAP_crawler ,J_CLIX_crawler ,Z_CUMA_crawler ,COCMAO_crawler ,J_CTMS_crawler ,ZCMXAI_crawler ,J_CLTE_crawler ,Z_FCLACT_crawler ,ZFMIFB_crawler ,J_CAGU_crawler ,J_GLCC_crawler ,Z_CIB_crawler ,J_CAMI_crawler ,COADOB_crawler ,J_CUMS_crawler ,J_CUAD_crawler ,J_CUDT_crawler ,J_CLSB_crawler ,J_SYDM_crawler ,J_SYDR_crawler ,Z_CAPINM_crawler ,DSLWLR_crawler ,J_CUCR_crawler ,J_CACG_crawler ,J_CLRR_crawler ,J_GLER_crawler ,J_CUAL_crawler ,Z_CUEX_crawler ,DSLWNL_crawler ,J_CTDE_crawler ,Z_ATCI_crawler ,Z_ATCUST_crawler ,J_SYCD_crawler ,DSLWLA_crawler ,J_CUIN_crawler ,Z_CAPINT_crawler ,DSLWLB_crawler ,J_GLBS_crawler ,DSCAGP_crawler ,Z_CAMA_crawler ,J_CLPC_crawler ,J_CLDT_crawler,COCMAW_crawler ,COCMAZ_crawler ,COCMAU_crawler ,COCMAV_crawler ,J_CLFD_crawler ,ZSEDTL_crawler ,J_GLAS_crawler ,FNGNEL_crawler ,J_CLLI_crawler ,DSLWTI_crawler ,J_SYFL_crawler ,DSCAGL_crawler ,DSLWTRR_crawler ,DSTRDM_crawler ,DSTRMS_crawler ,J_CUIS_crawler ,J_SYDMR_crawler ,Z_CLPY_crawler ,COCMAF_crawler ,J_SYXM_crawler ,J_SYXL_crawler ,J_CTPG_crawler ,J_CTPD_crawler ,DSLWUT_crawler,J_CLAS_crawler ,ZFBPEXT_crawler ,J_CAFE_crawler ,J_CAFI_crawler ,J_CLLA_crawler ,J_CLIS_crawler ,DMEXAF_crawler ,J_CLRS_crawler ,ZQRMEX_crawler ,J_CLPB_crawler ,J_CLPS_crawler ,ZWFBLH_crawler ,COCMAG_crawler ,J_CLMS_crawler ,J_CAFB_crawler ,Z_LBRHST_crawler ,DSLWTR_crawler ,J_CALM_crawler ,J_CAFF_crawler ,DSLWTB_crawler ,J_CLMI_crawler ,J_CLTP_crawler ,ZWFCUD_crawler ,Z_GLDT_crawler ,J_CAMS_crawler ,J_CLDTW_crawler ,J_CUPI_crawler ,J_CLAP_crawler ,DSGNEB_crawler ,Z_ACCLSM_crawler  ] >> ACBS_EOD_Raw_End_Task
 

