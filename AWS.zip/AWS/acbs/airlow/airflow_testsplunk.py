from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.sensors.time_delta import TimeDeltaSensor
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.splunk_test_common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG
from datetime import datetime, timedelta
import pendulum  
import logging 

# Define MST timezone
mst_tz = pendulum.timezone("America/Denver")
mst_now = pendulum.now(mst_tz)  # Get current time in MST
formatted_date = mst_now.format('YYYYMMDD') 



sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']
message_type="CRITICAL-PAGEONCALL"

acbs_eod_raw_schedule=CONFIG[environment]['acbs_eod_raw_schedule']

# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 0,
    'email_on_success': False ,
    'email_on_failure': False
}


start_date = datetime(2025, 1, 1)
dag = DAG(
    'ACBS_EOD_splunk_alerts',
    description='ACBS_EOD_splunk_alerts',
    default_args=default_args,
    tags=['ACBS'],
    dagrun_timeout=timedelta(minutes=4),
    catchup=False,  
    start_date=start_date,
    schedule=acbs_eod_raw_schedule
)

EOD_Raw_s3_spl_Start_Task = DummyOperator(task_id='EOD_Raw_s3_spl_Start_Task',dag=dag,on_success_callback=[sns_notifier.success_notification] )
EOD_Raw_s3_spl_End_Task = DummyOperator(task_id='EOD_Raw_s3_spl_End_Task',dag=dag )

SPL_SYDC = GlueJobOperator(task_id = 'SPL_SYDC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDC"},dag=dag,on_failure_callback= [sns_notifier.splunk_low_severity_failure_notification])


EOD_Raw_s3_spl_Start_Task >> SPL_SYDC
SPL_SYDC  >> EOD_Raw_s3_spl_End_Task
