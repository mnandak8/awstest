from logging import getLogger
import logging
import boto3
import json
import requests
import awswrangler as wr
from cb_common.configs import CONFIG
from airflow.models import Variable


log = getLogger(__name__)

def __read_athena_query(env, acc_num):
    query = 'SELECT * FROM "raw_db"."salesforce_account"'
    df = wr.athena.read_sql_query(
        query, 
        database='raw_db',
        s3_output=f's3://cobank-dl-{acc_num}-us-west-2-logs-{env}/athena-query-results/', 
        ctas_approach=True)
    return df.shape[0] # is num of raws and df.shape[1] is num of columns

def __get_job(job_name):
    glue_client = boto3.client('glue', region_name='us-west-2')
    try:
        job_detail = glue_client.get_job(JobName=job_name)
        return job_detail["Job"]["DefaultArguments"]
    except Exception as ex:
        log.error(f'Fail while processing job: {ex}')
        pass

def archive(job_name):
    default_args =  __get_job(job_name) #TODO: cache this value, since it's being called many times
    if default_args["--objectname"] is None:
        key = f'{default_args["--layer"]}/{default_args["--groupname"]}'
    else:
        key = f'{default_args["--groupname"]}/{default_args["--objectname"]}'
    path = f'{default_args["--datasink"]}{key}/'
    return f'aws s3 cp --recursive {path}latest/ {path}history/ && aws s3 rm --recursive {path}latest/'

def save_job_status(job_name):
    default_args =  __get_job(job_name)
    url = CONFIG[default_args['--env']]['audit_api']
    glue_client = boto3.client('glue', region_name='us-west-2')
    try:
        date2process = default_args['--date2process']
    except Exception as ex:
        date2process = None
        log.error(f'this job does not required date2process attribute: {ex}')
    try:
        status_detail = glue_client.get_job_runs(JobName=job_name)
        if len(status_detail) > 0:
            last_run = status_detail['JobRuns'][0]
            payload = json.dumps({ 
                        "jobName": last_run['JobName'],  
                        "jobRunId": last_run['Id'], 
                        "source": default_args['--datasource'],
                        "target": default_args['--datasink'],
                        "runStartDateTime": str(last_run['StartedOn']), 
                        "runBy": "airflow",
                        "runStatus": last_run['JobRunState'],
                        "runStatusDesc": f"It took {last_run['Attempt']} retries, with allocation capacity of {last_run['AllocatedCapacity']} GPU, worker type {last_run['WorkerType']} and glue version {last_run['GlueVersion']} to complete the job",
                        "executionTime": str(last_run['ExecutionTime']),
                        "lastModifiedDataDate": str(last_run['LastModifiedOn']),
                        "runEndDateTime": str(last_run['CompletedOn']),
                        "objectName": default_args['--objectname'],
                        "groupName": default_args['--groupname'],
                        "layer": default_args['--layer'],
                        "date2Process": date2process,
                        "targetRecordCount": __read_athena_query(default_args['--env'], CONFIG[default_args['--env']]['acc_num']),
                        })

            response = requests.post(url, data=payload) #, headers=headers)
            #assert response.status_code is response.ok
        return (f'payload: {payload}\nresponse: {response.status_code}')
    except Exception as ex:
        log.error(f'Fail while processing job status: {ex}')
        
class SNSNotifier:
    def __init__(self, region_name='us-west-2', sns_topic_arn=None, env=None):
        self.sns_client = boto3.client('sns', region_name=region_name)
        self.environment = Variable.get('env_vars', deserialize_json=True)['environment']
        self.acc_num =  CONFIG[self.environment]['acc_num']
        if sns_topic_arn:
            self.sns_topic_arn = sns_topic_arn
        else:           
            self.sns_topic_arn = f"arn:aws:sns:{region_name}:{self.acc_num}:cobank-dl-sns-topic-airflow-alerting-mwaa-errors-{self.environment}"

    def send_notification(self, subject, message):
        print("sending notifications")
        try:
            response = self.sns_client.publish(TopicArn=self.sns_topic_arn, Message=message, Subject=subject)
            logging.info(f"SNS notification sent: {response}")
        except Exception as e:
            logging.error(f"Failed to send Notification: {e}")

    def success_notification(self, context):
        task_instance = context['task_instance']
        task_id = task_instance.task_id
        dag_id = task_instance.dag_id
        execution_date = context['execution_date']

        subject = f'Task Succeeded: {task_id} in DAG {dag_id} in {self.environment}'
        message = f'Task {task_id} in DAG {dag_id} succeeded on {execution_date} in {self.environment}'
        self.send_notification(subject, message)

    def failure_notification(self, context):
        task_instance = context['task_instance']
        task_id = task_instance.task_id
        dag_id = task_instance.dag_id
        execution_date = context['execution_date']
        log_url = task_instance.log_url

        subject = f'Task Failed: {task_id} in DAG {dag_id} in {self.environment}'
        message = f'Task {task_id} in DAG {dag_id} failed on {execution_date} in {self.environment} with log url: {log_url}'
        self.send_notification(subject, message)
        
    def splunk_critical_failure_notification(self, context):
        message_type="CRITICAL-PAGEONCALL"
        task_instance = context['task_instance']
        task_id = task_instance.task_id
        dag_id = task_instance.dag_id
        execution_date = context['execution_date']
        log_url = task_instance.log_url
        
        subject = f'Task Failed: {task_id} in DAG {dag_id} in {self.environment}'
        message = f'Task {task_id} in DAG {dag_id} failed on {execution_date} in {self.environment} with log url: {log_url}'
        self.send_notification(subject, message)
        
        """
        logging.error(f"Alert: SPLUNK environment:{self.environment} ")
        logging.error(f"Alert: SPLUNK message_type:{message_type} ")
        logging.error(f"Alert: SPLUNK DAG:{dag_id} ")
        logging.error(f"Alert: SPLUNK TASK:{task_id} ")
        logging.error(f"Alert: SPLUNK execution_date:{execution_date} ")
        logging.error(f"Alert: SPLUNK task_instance:{task_instance} ")
        
        """
        json_payload = {
            "environment": self.environment,
            "message_type": message_type,
            "DAG": dag_id,
            "TASK": task_id,
            "execution_date": execution_date
         }
        logging.error(f"Alert: SPLUNK {json_payload} ")
    def splunk_low_severity_failure_notification(self, context):
        message_type="LOW-SEVERITY"
        task_instance = context['task_instance']
        task_id = task_instance.task_id
        dag_id = task_instance.dag_id
        execution_date = context['execution_date']
        log_url = task_instance.log_url
        
        subject = f'Task Failed: {task_id} in DAG {dag_id} in {self.environment}'
        message = f'Task {task_id} in DAG {dag_id} failed on {execution_date} in {self.environment} with log url: {log_url}'
        self.send_notification(subject, message)
        
        """
        logging.error(f"Alert: SPLUNK environment:{self.environment} ")
        logging.error(f"Alert: SPLUNK message_type:{message_type} ")
        logging.error(f"Alert: SPLUNK DAG:{dag_id} ")
        logging.error(f"Alert: SPLUNK TASK:{task_id} ")
        logging.error(f"Alert: SPLUNK execution_date:{execution_date} ")
        logging.error(f"Alert: SPLUNK task_instance:{task_instance} ")
        
        """
        json_payload = {
            "environment": self.environment,
            "message_type": message_type,
            "DAG": dag_id,
            "TASK": task_id,
            "execution_date": execution_date
         }
        logging.error(f"Alert: SPLUNK {json_payload} ")


   