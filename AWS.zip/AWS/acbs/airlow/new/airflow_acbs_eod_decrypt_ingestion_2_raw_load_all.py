from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 0,
    'email_on_failure': True
}
start_date = datetime(2025, 1, 1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load_all',
    description='ACBS SOD files Decrypt and Load 2 Raw all',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)
ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)


J_SYDC = GlueJobOperator(task_id = 'J_SYDC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDC"},dag=dag)
J_SYDC_crawler = GlueCrawlerOperator(task_id="J_SYDC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYDC" }, poll_interval=30, dag = dag)

ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1 = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1",trigger_dag_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1",wait_for_completion=True,poke_interval=30,dag = dag)
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_2 = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_2",trigger_dag_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_2",wait_for_completion=True,poke_interval=30,dag = dag)
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3 = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3",trigger_dag_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3",wait_for_completion=True,poke_interval=30,dag = dag)
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4 = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4",trigger_dag_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4",wait_for_completion=True,poke_interval=30,dag = dag)
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5 = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5",trigger_dag_id="ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5",wait_for_completion=True,poke_interval=30,dag = dag)


ACBS_EOD_Raw_Start_Task >> [J_SYDC]
J_SYDC >> J_SYDC_crawler
J_SYDC >> ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1 >> ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_2
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_2 >> ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3 >> ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4
ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4 >> ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5
[J_SYDC_crawler,ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5] >> ACBS_EOD_Raw_End_Task