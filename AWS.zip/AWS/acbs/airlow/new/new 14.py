from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.sensors.time_delta import TimeDeltaSensor
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG
from datetime import datetime, timedelta
import pendulum  
    

# Define MST timezone
mst_tz = pendulum.timezone("America/Denver")
mst_now = pendulum.now(mst_tz)  # Get current time in MST
formatted_date = mst_now.format('YYYYMMDD') 



sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

landing_acbs_bucket=f"{environment}-acb-dat-ing-acbs-landing"
landing_trigger_key="SVCAWSSFTP/ZWFTYP.DAT.asc"
acbs_eod_raw_schedule=CONFIG[environment]['acbs_eod_raw_schedule']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 0,
    'email_on_success': False ,
    'email_on_failure': False
}


start_date = datetime(2025, 1, 1)
dag = DAG(
    'ACBS_EOD_Decrypt_Ing_2_raw_load_FW',
    description='ACBS SOD files Decrypt and Load 2 Raw file watcher',
    default_args=default_args,
    tags=['ACBS'],
    dagrun_timeout=timedelta(hours=4),
    catchup=False,  
    start_date=start_date,
    schedule=acbs_eod_raw_schedule
)


ACBS_EOD_Raw_s3_FW_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_s3_FW_Start_Task',dag=dag,on_success_callback=[sns_notifier.success_notification] )
ACBS_EOD_Raw_s3_FW_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_s3_FW_End_Task',dag=dag )

acbs_eod_FW_s3keysensor = S3KeySensor(
    task_id="acbs_eod_FW_s3keysensor",
    bucket_name=landing_acbs_bucket,
    bucket_key=landing_trigger_key, 
    timeout=3600 * 5,  # 5 hrs timeout
    poke_interval=120,  # Check every 2 min
    mode="poke",
    dag=dag, on_success_callback=[sns_notifier.success_notification] ,
    
)

J_SYDC = GlueJobOperator(task_id = 'J_SYDC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDC"},dag=dag,on_failure_callback=[sns_notifier.failure_notification] )
J_SYDC_crawler = GlueCrawlerOperator(task_id="J_SYDC_crawler",config={"Name": "lending_acbs_raw_dataasset_db_J_SYDC" }, poll_interval=30, dag = dag,on_failure_callback=[sns_notifier.failure_notification])


ACBS_EOD_Decrypt_Ing2raw = TriggerDagRunOperator(task_id="ACBS_EOD_Decrypt_Ing2raw",trigger_dag_id="ACBS_EOD_Decrypt_Ing2raw",dag = dag,on_failure_callback=[sns_notifier.failure_notification] )

ACBS_EOD_Raw_s3_FW_Start_Task >> acbs_eod_FW_s3keysensor
acbs_eod_FW_s3keysensor >> J_SYDC
J_SYDC >> J_SYDC_crawler
J_SYDC_crawler >> ACBS_EOD_Decrypt_Ing2raw 
ACBS_EOD_Decrypt_Ing2raw >> ACBS_EOD_Raw_s3_FW_End_Task