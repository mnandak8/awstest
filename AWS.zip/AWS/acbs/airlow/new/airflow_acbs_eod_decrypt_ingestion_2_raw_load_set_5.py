from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'Glue',
    'depends_on_past': False,
    'retries': 0,
    'email_on_failure': True
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_5',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_5',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule_interval=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)

J_CLRM = GlueJobOperator(task_id = 'J_CLRM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRM"},dag=dag)
J_CLRM_crawler = GlueCrawlerOperator(task_id="J_CLRM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLRM"  } , poll_interval=30, dag = dag)

COCMBD = GlueJobOperator(task_id = 'COCMBD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMBD"},dag=dag)   
COCMBD_crawler = GlueCrawlerOperator(task_id="COCMBD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMBD"  } , poll_interval=30, dag = dag)

J_CTUH = GlueJobOperator(task_id = 'J_CTUH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUH"},dag=dag)   
J_CTUH_crawler = GlueCrawlerOperator(task_id="J_CTUH_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTUH"  } , poll_interval=30, dag = dag)

Z_CDERV = GlueJobOperator(task_id = 'Z_CDERV',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CDERV"},dag=dag)
Z_CDERV_crawler = GlueCrawlerOperator(task_id="Z_CDERV_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CDERV"  } , poll_interval=30, dag = dag)

Z_ADCA = GlueJobOperator(task_id = 'Z_ADCA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ADCA"},dag=dag)   
Z_ADCA_crawler = GlueCrawlerOperator(task_id="Z_ADCA_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_ADCA"  } , poll_interval=30, dag = dag)

J_CATE = GlueJobOperator(task_id = 'J_CATE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CATE"},dag=dag)   
J_CATE_crawler = GlueCrawlerOperator(task_id="J_CATE_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CATE"  } , poll_interval=30, dag = dag)

Z_CAPEQ = GlueJobOperator(task_id = 'Z_CAPEQ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPEQ"},dag=dag)
Z_CAPEQ_crawler = GlueCrawlerOperator(task_id="Z_CAPEQ_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAPEQ"  } , poll_interval=30, dag = dag)

J_CTID = GlueJobOperator(task_id = 'J_CTID',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTID"},dag=dag)
J_CTID_crawler = GlueCrawlerOperator(task_id="J_CTID_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTID"  } , poll_interval=30, dag = dag)

J_CLMX = GlueJobOperator(task_id = 'J_CLMX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLMX"},dag=dag)
J_CLMX_crawler = GlueCrawlerOperator(task_id="J_CLMX_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLMX"  } , poll_interval=30, dag = dag)

COCMAN = GlueJobOperator(task_id = 'COCMAN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAN"},dag=dag)
COCMAN_crawler = GlueCrawlerOperator(task_id="COCMAN_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAN"  } , poll_interval=30, dag = dag)

J_CADT = GlueJobOperator(task_id = 'J_CADT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADT"},dag=dag)
J_CADT_crawler = GlueCrawlerOperator(task_id="J_CADT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CADT"  } , poll_interval=30, dag = dag)

J_CUAF = GlueJobOperator(task_id = 'J_CUAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAF"},dag=dag)
J_CUAF_crawler = GlueCrawlerOperator(task_id="J_CUAF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUAF"  } , poll_interval=30, dag = dag)

J_CLAC = GlueJobOperator(task_id = 'J_CLAC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAC"},dag=dag)
J_CLAC_crawler = GlueCrawlerOperator(task_id="J_CLAC_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLAC"  } , poll_interval=30, dag = dag)

J_CLBC = GlueJobOperator(task_id = 'J_CLBC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLBC"},dag=dag)
J_CLBC_crawler = GlueCrawlerOperator(task_id="J_CLBC_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLBC"  } , poll_interval=30, dag = dag)

J_CUTE = GlueJobOperator(task_id = 'J_CUTE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUTE"},dag=dag)
J_CUTE_crawler = GlueCrawlerOperator(task_id="J_CUTE_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUTE"  } , poll_interval=30, dag = dag)

COCMAI = GlueJobOperator(task_id = 'COCMAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAI"},dag=dag)
COCMAI_crawler = GlueCrawlerOperator(task_id="COCMAI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAI"  } , poll_interval=30, dag = dag)

J_CAFT = GlueJobOperator(task_id = 'J_CAFT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAFT"},dag=dag)
J_CAFT_crawler = GlueCrawlerOperator(task_id="J_CAFT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CAFT"  } , poll_interval=30, dag = dag)

ZFBPCFE = GlueJobOperator(task_id = 'ZFBPCFE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFBPCFE"},dag=dag)      
ZFBPCFE_crawler = GlueCrawlerOperator(task_id="ZFBPCFE_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZFBPCFE"  } , poll_interval=30, dag = dag)

COCMAA = GlueJobOperator(task_id = 'COCMAA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAA"},dag=dag)
COCMAA_crawler = GlueCrawlerOperator(task_id="COCMAA_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAA"  } , poll_interval=30, dag = dag)

J_CTIM = GlueJobOperator(task_id = 'J_CTIM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTIM"},dag=dag)
J_CTIM_crawler = GlueCrawlerOperator(task_id="J_CTIM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTIM"  } , poll_interval=30, dag = dag)

J_CLAD = GlueJobOperator(task_id = 'J_CLAD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLAD"},dag=dag)
J_CLAD_crawler = GlueCrawlerOperator(task_id="J_CLAD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLAD"  } , poll_interval=30, dag = dag)

J_CADTW = GlueJobOperator(task_id = 'J_CADTW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CADTW"},dag=dag)      
J_CADTW_crawler = GlueCrawlerOperator(task_id="J_CADTW_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CADTW"  } , poll_interval=30, dag = dag)

J_CLPF = GlueJobOperator(task_id = 'J_CLPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPF"},dag=dag)
J_CLPF_crawler = GlueCrawlerOperator(task_id="J_CLPF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLPF"  } , poll_interval=30, dag = dag)

Z_CLPPF = GlueJobOperator(task_id = 'Z_CLPPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPPF"},dag=dag)      
Z_CLPPF_crawler = GlueCrawlerOperator(task_id="Z_CLPPF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CLPPF"  } , poll_interval=30, dag = dag)

J_CAPF = GlueJobOperator(task_id = 'J_CAPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAPF"},dag=dag)
J_CAPF_crawler = GlueCrawlerOperator(task_id="J_CAPF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CAPF"  } , poll_interval=30, dag = dag)

ZWFTYP = GlueJobOperator(task_id = 'ZWFTYP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFTYP"},dag=dag)
ZWFTYP_crawler = GlueCrawlerOperator(task_id="ZWFTYP_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZWFTYP"  } , poll_interval=30, dag = dag)

FNGNED = GlueJobOperator(task_id = 'FNGNED',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNED"},dag=dag)
FNGNED_crawler = GlueCrawlerOperator(task_id="FNGNED_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_FNGNED"  } , poll_interval=30, dag = dag)

ZWFPLN = GlueJobOperator(task_id = 'ZWFPLN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZWFPLN"},dag=dag)
ZWFPLN_crawler = GlueCrawlerOperator(task_id="ZWFPLN_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZWFPLN"  } , poll_interval=30, dag = dag)


ACBS_EOD_Raw_Start_Task >> [J_CLRM,COCMBD,J_CTUH,Z_CDERV,Z_ADCA,J_CATE,Z_CAPEQ,J_CTID,J_CLMX,COCMAN,J_CADT,J_CUAF,J_CLAC,J_CLBC,J_CUTE,COCMAI,J_CAFT,ZFBPCFE,COCMAA,J_CTIM,J_CLAD,J_CADTW,J_CLPF,Z_CLPPF,J_CAPF,ZWFTYP,FNGNED,ZWFPLN]
J_CLRM >> J_CLRM_crawler
COCMBD >> COCMBD_crawler  
J_CTUH >> J_CTUH_crawler  
Z_CDERV >> Z_CDERV_crawler
Z_ADCA >> Z_ADCA_crawler  
J_CATE >> J_CATE_crawler  
Z_CAPEQ >> Z_CAPEQ_crawler
J_CTID >> J_CTID_crawler  
J_CLMX >> J_CLMX_crawler  
COCMAN >> COCMAN_crawler  
J_CADT >> J_CADT_crawler  
J_CUAF >> J_CUAF_crawler  
J_CLAC >> J_CLAC_crawler  
J_CLBC >> J_CLBC_crawler  
J_CUTE >> J_CUTE_crawler  
COCMAI >> COCMAI_crawler  
J_CAFT >> J_CAFT_crawler  
ZFBPCFE >> ZFBPCFE_crawler
COCMAA >> COCMAA_crawler  
J_CTIM >> J_CTIM_crawler
J_CLAD >> J_CLAD_crawler
J_CADTW >> J_CADTW_crawler
J_CLPF >> J_CLPF_crawler
Z_CLPPF >> Z_CLPPF_crawler
J_CAPF >> J_CAPF_crawler
ZWFTYP >> ZWFTYP_crawler
FNGNED >> FNGNED_crawler
ZWFPLN >> ZWFPLN_crawler
[J_CLRM_crawler ,COCMBD_crawler ,J_CTUH_crawler ,Z_CDERV_crawler ,Z_ADCA_crawler ,J_CATE_crawler ,Z_CAPEQ_crawler ,J_CTID_crawler ,J_CLMX_crawler ,COCMAN_crawler ,J_CADT_crawler ,J_CUAF_crawler ,J_CLAC_crawler ,J_CLBC_crawler ,J_CUTE_crawler ,COCMAI_crawler ,J_CAFT_crawler ,ZFBPCFE_crawler ,COCMAA_crawler ,J_CTIM_crawler ,J_CLAD_crawler ,J_CADTW_crawler ,J_CLPF_crawler ,Z_CLPPF_crawler ,J_CAPF_crawler ,ZWFTYP_crawler  ,FNGNED_crawler ,ZWFPLN_crawler] >> ACBS_EOD_Raw_End_Task


