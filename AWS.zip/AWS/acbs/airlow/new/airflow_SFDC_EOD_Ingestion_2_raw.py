from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.sensors.time_delta import TimeDeltaSensor
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG
from datetime import datetime, timedelta
import pendulum  
    

# Define MST timezone
mst_tz = pendulum.timezone("America/Denver")
mst_now = pendulum.now(mst_tz)  # Get current time in MST
formatted_date = mst_now.format('YYYYMMDD') 



sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 0,
    'email_on_success': False ,
    'email_on_failure': False
}


start_date = datetime(2025, 1, 1)
dag = DAG(
    'SFDC_EOD_Ingestion_2_raw',
    description='SFDC EOD files Decrypt and Load 2 Raw ',
    default_args=default_args,
    tags=['SFDC'],
    dagrun_timeout=timedelta(hours=2),
    catchup=False, 
    start_date=start_date,
    schedule=None,
    on_failure_callback=[sns_notifier.failure_notification] 
    
    
)



SFDC_EOD_Raw_Start_Task = DummyOperator(task_id='SFDC_EOD_Raw_Start_Task',dag=dag,on_success_callback=[sns_notifier.success_notification])
SFDC_EOD_Raw_End_Task = DummyOperator(task_id='SFDC_EOD_Raw_End_Task',dag=dag, on_success_callback=[sns_notifier.success_notification] )


Account_Raw = GlueJobOperator(task_id = 'Account_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "Account", "--date2process": f"{formatted_date}"},dag=dag)
Account_raw_crawler = GlueCrawlerOperator(task_id="Account_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_Account" }, poll_interval=30, dag = dag)

Contact_Raw = GlueJobOperator(task_id = 'Contact_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "Contact", "--date2process": f"{formatted_date}"},dag=dag)
Contact_raw_crawler = GlueCrawlerOperator(task_id="Contact_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_Contact" }, poll_interval=30, dag = dag)

LLC_BI__Loan__c_Raw = GlueJobOperator(task_id = 'LLC_BI__Loan__c_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "LLC_BI__Loan__c", "--date2process": f"{formatted_date}"},dag=dag)
LLC_BI__Loan__c_raw_crawler = GlueCrawlerOperator(task_id="LLC_BI__Loan__c_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_LLC_BI__Loan__c" }, poll_interval=30, dag = dag)

AccountContactRelation_Raw = GlueJobOperator(task_id = 'AccountContactRelation_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "AccountContactRelation", "--date2process": f"{formatted_date}"},dag=dag)
AccountContactRelation_raw_crawler = GlueCrawlerOperator(task_id="AccountContactRelation_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_AccountContactRelation" }, poll_interval=30, dag = dag)

Account_Address__c_Raw = GlueJobOperator(task_id = 'Account_Address__c_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "Account_Address__c", "--date2process": f"{formatted_date}"},dag=dag)
Account_Address__c_raw_crawler = GlueCrawlerOperator(task_id="Account_Address__c_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_Account_Address__c" }, poll_interval=30, dag = dag)


RecordType_Raw = GlueJobOperator(task_id = 'RecordType_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "RecordType21", "--date2process": f"{formatted_date}"},dag=dag)
RecordType_raw_crawler = GlueCrawlerOperator(task_id="RecordType_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_RecordType" }, poll_interval=30, dag = dag)


LLC_BI__Loan__History_Raw = GlueJobOperator(task_id = 'LLC_BI__Loan__History_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "LLC_BI__Loan__History", "--date2process": f"{formatted_date}"},dag=dag)
LLC_BI__Loan__History_raw_crawler = GlueCrawlerOperator(task_id="LLC_BI__Loan__History_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_LLC_BI__Loan__History" }, poll_interval=30, dag = dag)

LLC_BI__Product_Package__c_Raw = GlueJobOperator(task_id = 'LLC_BI__Product_Package__c_Raw',job_name='party_salesforce_eod_landing2raw',script_args={"--env": f"{environment}","--objectname": "LLC_BI__Product_Package__c", "--date2process": f"{formatted_date}"},dag=dag)
LLC_BI__Product_Package__c_raw_crawler = GlueCrawlerOperator(task_id="LLC_BI__Product_Package__c_Raw_crawler",config={"Name": "party_salesforce_raw_dataasset_db_LLC_BI__Product_Package__c" }, poll_interval=30, dag = dag)

SFDC_EOD_Raw_Start_Task >>  [Account_Raw ,Contact_Raw ,LLC_BI__Loan__c_Raw ,AccountContactRelation_Raw ,Account_Address__c_Raw ,RecordType_Raw,LLC_BI__Loan__History_Raw ,LLC_BI__Product_Package__c_Raw]
Account_Raw  >> Account_raw_crawler
Contact_Raw  >> Contact_raw_crawler
LLC_BI__Loan__c_Raw  >> LLC_BI__Loan__c_raw_crawler 
AccountContactRelation_Raw  >> AccountContactRelation_raw_crawler
Account_Address__c_Raw  >> Account_Address__c_raw_crawler
RecordType_Raw  >> RecordType_raw_crawler
LLC_BI__Loan__History_Raw  >> LLC_BI__Loan__History_raw_crawler
LLC_BI__Product_Package__c_Raw >> LLC_BI__Product_Package__c_raw_crawler
[Account_raw_crawler ,Contact_raw_crawler ,LLC_BI__Loan__c_raw_crawler ,AccountContactRelation_raw_crawler ,Account_Address__c_raw_crawler ,RecordType_raw_crawler ,LLC_BI__Loan__History_raw_crawler ,LLC_BI__Product_Package__c_raw_crawler] >> SFDC_EOD_Raw_End_Task