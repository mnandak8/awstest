from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'Glue',
    'depends_on_past': False,
    'retries': 0,
    'email_on_failure': True
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_1',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_1',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule_interval=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)

COCMAW = GlueJobOperator(task_id = 'COCMAW',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAW"},dag=dag)
COCMAW_crawler = GlueCrawlerOperator(task_id="COCMAW_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAW" } , poll_interval=30, dag = dag)

COCMAZ = GlueJobOperator(task_id = 'COCMAZ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAZ"},dag=dag)
COCMAZ_crawler = GlueCrawlerOperator(task_id="COCMAZ_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAZ" } , poll_interval=30, dag = dag)

COCMAU = GlueJobOperator(task_id = 'COCMAU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAU"},dag=dag)
COCMAU_crawler = GlueCrawlerOperator(task_id="COCMAU_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAU" } , poll_interval=30, dag = dag)

COCMAV = GlueJobOperator(task_id = 'COCMAV',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAV"},dag=dag)
COCMAV_crawler = GlueCrawlerOperator(task_id="COCMAV_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAV" } , poll_interval=30, dag = dag)

J_CLFD = GlueJobOperator(task_id = 'J_CLFD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFD"},dag=dag)
J_CLFD_crawler = GlueCrawlerOperator(task_id="J_CLFD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLFD" } , poll_interval=30, dag = dag)

ZSEDTL = GlueJobOperator(task_id = 'ZSEDTL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZSEDTL"},dag=dag)
ZSEDTL_crawler = GlueCrawlerOperator(task_id="ZSEDTL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZSEDTL" } , poll_interval=30, dag = dag)

J_GLAS = GlueJobOperator(task_id = 'J_GLAS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLAS"},dag=dag)
J_GLAS_crawler = GlueCrawlerOperator(task_id="J_GLAS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_GLAS" } , poll_interval=30, dag = dag)

FNGNEL = GlueJobOperator(task_id = 'FNGNEL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "FNGNEL"},dag=dag)
FNGNEL_crawler = GlueCrawlerOperator(task_id="FNGNEL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_FNGNEL" } , poll_interval=30, dag = dag)

J_CLLI = GlueJobOperator(task_id = 'J_CLLI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLLI"},dag=dag)
J_CLLI_crawler = GlueCrawlerOperator(task_id="J_CLLI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLLI" } , poll_interval=30, dag = dag)

DSLWTI = GlueJobOperator(task_id = 'DSLWTI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTI"},dag=dag)
DSLWTI_crawler = GlueCrawlerOperator(task_id="DSLWTI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWTI" } , poll_interval=30, dag = dag)

J_SYFL = GlueJobOperator(task_id = 'J_SYFL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYFL"},dag=dag)
J_SYFL_crawler = GlueCrawlerOperator(task_id="J_SYFL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYFL" } , poll_interval=30, dag = dag)

DSCAGL = GlueJobOperator(task_id = 'DSCAGL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGL"},dag=dag)
DSCAGL_crawler = GlueCrawlerOperator(task_id="DSCAGL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAGL" } , poll_interval=30, dag = dag)

DSLWTRR = GlueJobOperator(task_id = 'DSLWTRR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWTRR"},dag=dag)
DSLWTRR_crawler = GlueCrawlerOperator(task_id="DSLWTRR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWTRR" } , poll_interval=30, dag = dag)

DSTRDM = GlueJobOperator(task_id = 'DSTRDM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRDM"},dag=dag)
DSTRDM_crawler = GlueCrawlerOperator(task_id="DSTRDM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSTRDM" } , poll_interval=30, dag = dag)

DSTRMS = GlueJobOperator(task_id = 'DSTRMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSTRMS"},dag=dag)
DSTRMS_crawler = GlueCrawlerOperator(task_id="DSTRMS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSTRMS" } , poll_interval=30, dag = dag)

J_CUIS = GlueJobOperator(task_id = 'J_CUIS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIS"},dag=dag)
J_CUIS_crawler = GlueCrawlerOperator(task_id="J_CUIS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUIS" } , poll_interval=30, dag = dag)

J_SYDMR = GlueJobOperator(task_id = 'J_SYDMR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDMR"},dag=dag)
J_SYDMR_crawler = GlueCrawlerOperator(task_id="J_SYDMR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYDMR" } , poll_interval=30, dag = dag)

Z_CLPY = GlueJobOperator(task_id = 'Z_CLPY',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CLPY"},dag=dag)
Z_CLPY_crawler = GlueCrawlerOperator(task_id="Z_CLPY_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CLPY" } , poll_interval=30, dag = dag)

COCMAF = GlueJobOperator(task_id = 'COCMAF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAF"},dag=dag)
COCMAF_crawler = GlueCrawlerOperator(task_id="COCMAF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAF" } , poll_interval=30, dag = dag)

J_SYXM = GlueJobOperator(task_id = 'J_SYXM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXM"},dag=dag)
J_SYXM_crawler = GlueCrawlerOperator(task_id="J_SYXM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYXM" } , poll_interval=30, dag = dag)

J_SYXL = GlueJobOperator(task_id = 'J_SYXL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYXL"},dag=dag)
J_SYXL_crawler = GlueCrawlerOperator(task_id="J_SYXL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYXL" } , poll_interval=30, dag = dag)

J_CTPG = GlueJobOperator(task_id = 'J_CTPG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPG"},dag=dag)
J_CTPG_crawler = GlueCrawlerOperator(task_id="J_CTPG_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTPG" } , poll_interval=30, dag = dag)

J_CTPD = GlueJobOperator(task_id = 'J_CTPD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTPD"},dag=dag)
J_CTPD_crawler = GlueCrawlerOperator(task_id="J_CTPD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTPD" } , poll_interval=30, dag = dag)

DSLWUT = GlueJobOperator(task_id = 'DSLWUT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWUT"},dag=dag)
DSLWUT_crawler = GlueCrawlerOperator(task_id="DSLWUT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWUT" } , poll_interval=30, dag = dag)


ACBS_EOD_Raw_Start_Task >> [COCMAW,COCMAZ,COCMAU,COCMAV,J_CLFD,ZSEDTL,J_GLAS,FNGNEL,J_CLLI,DSLWTI,J_SYFL,DSCAGL,DSLWTRR,DSTRDM,DSTRMS,J_CUIS,J_SYDMR,Z_CLPY,COCMAF,J_SYXM,J_SYXL,J_CTPG,J_CTPD,DSLWUT]
COCMAW >> COCMAW_crawler  
COCMAZ >> COCMAZ_crawler  
COCMAU >> COCMAU_crawler  
COCMAV >> COCMAV_crawler  
J_CLFD >> J_CLFD_crawler  
ZSEDTL >> ZSEDTL_crawler  
J_GLAS >> J_GLAS_crawler  
FNGNEL >> FNGNEL_crawler  
J_CLLI >> J_CLLI_crawler  
DSLWTI >> DSLWTI_crawler  
J_SYFL >> J_SYFL_crawler  
DSCAGL >> DSCAGL_crawler  
DSLWTRR >> DSLWTRR_crawler
DSTRDM >> DSTRDM_crawler  
DSTRMS >> DSTRMS_crawler  
J_CUIS >> J_CUIS_crawler  
J_SYDMR >> J_SYDMR_crawler
Z_CLPY >> Z_CLPY_crawler  
COCMAF >> COCMAF_crawler  
J_SYXM >> J_SYXM_crawler  
J_SYXL >> J_SYXL_crawler  
J_CTPG >> J_CTPG_crawler  
J_CTPD >> J_CTPD_crawler  
DSLWUT >> DSLWUT_crawler 
[COCMAW_crawler ,COCMAZ_crawler ,COCMAU_crawler ,COCMAV_crawler ,J_CLFD_crawler ,ZSEDTL_crawler ,J_GLAS_crawler ,FNGNEL_crawler ,J_CLLI_crawler ,DSLWTI_crawler ,J_SYFL_crawler ,DSCAGL_crawler ,DSLWTRR_crawler ,DSTRDM_crawler ,DSTRMS_crawler ,J_CUIS_crawler ,J_SYDMR_crawler ,Z_CLPY_crawler ,COCMAF_crawler ,J_SYXM_crawler ,J_SYXL_crawler ,J_CTPG_crawler ,J_CTPD_crawler ,DSLWUT_crawler  ] >> ACBS_EOD_Raw_End_Task


