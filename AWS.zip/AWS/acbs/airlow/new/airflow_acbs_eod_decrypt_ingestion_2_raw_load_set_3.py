from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'Glue',
    'depends_on_past': False,
    'retries': 0,
    'email_on_failure': True
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_3',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_3',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule_interval=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)
ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)
J_CAMI = GlueJobOperator(task_id = 'J_CAMI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAMI"},dag=dag)
J_CAMI_crawler = GlueCrawlerOperator(task_id="J_CAMI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CAMI"  } , poll_interval=30, dag = dag)

COADOB = GlueJobOperator(task_id = 'COADOB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COADOB"},dag=dag)      
COADOB_crawler = GlueCrawlerOperator(task_id="COADOB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COADOB"  } , poll_interval=30, dag = dag)

J_CUMS = GlueJobOperator(task_id = 'J_CUMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUMS"},dag=dag)      
J_CUMS_crawler = GlueCrawlerOperator(task_id="J_CUMS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUMS"  } , poll_interval=30, dag = dag)

J_CUAD = GlueJobOperator(task_id = 'J_CUAD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAD"},dag=dag)      
J_CUAD_crawler = GlueCrawlerOperator(task_id="J_CUAD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUAD"  } , poll_interval=30, dag = dag)

J_CUDT = GlueJobOperator(task_id = 'J_CUDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUDT"},dag=dag)      
J_CUDT_crawler = GlueCrawlerOperator(task_id="J_CUDT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUDT"  } , poll_interval=30, dag = dag)

J_CLSB = GlueJobOperator(task_id = 'J_CLSB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLSB"},dag=dag)      
J_CLSB_crawler = GlueCrawlerOperator(task_id="J_CLSB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLSB"  } , poll_interval=30, dag = dag)

J_SYDM = GlueJobOperator(task_id = 'J_SYDM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDM"},dag=dag)      
J_SYDM_crawler = GlueCrawlerOperator(task_id="J_SYDM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYDM"  } , poll_interval=30, dag = dag)

J_SYDR = GlueJobOperator(task_id = 'J_SYDR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYDR"},dag=dag)      
J_SYDR_crawler = GlueCrawlerOperator(task_id="J_SYDR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYDR"  } , poll_interval=30, dag = dag)

Z_CAPINM = GlueJobOperator(task_id = 'Z_CAPINM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINM"},dag=dag)
Z_CAPINM_crawler = GlueCrawlerOperator(task_id="Z_CAPINM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAPINM"  } , poll_interval=30, dag = dag)

DSLWLR = GlueJobOperator(task_id = 'DSLWLR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLR"},dag=dag)      
DSLWLR_crawler = GlueCrawlerOperator(task_id="DSLWLR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWLR"  } , poll_interval=30, dag = dag)

J_CUCR = GlueJobOperator(task_id = 'J_CUCR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUCR"},dag=dag)
J_CUCR_crawler = GlueCrawlerOperator(task_id="J_CUCR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUCR"  } , poll_interval=30, dag = dag)

J_CACG = GlueJobOperator(task_id = 'J_CACG',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CACG"},dag=dag)
J_CACG_crawler = GlueCrawlerOperator(task_id="J_CACG_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CACG"  } , poll_interval=30, dag = dag)

J_CLRR = GlueJobOperator(task_id = 'J_CLRR',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLRR"},dag=dag)
J_CLRR_crawler = GlueCrawlerOperator(task_id="J_CLRR_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLRR"  } , poll_interval=30, dag = dag)

J_GLER = GlueJobOperator(task_id = 'J_GLER',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLER"},dag=dag)
J_GLER_crawler = GlueCrawlerOperator(task_id="J_GLER_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_GLER"  } , poll_interval=30, dag = dag)

J_CUAL = GlueJobOperator(task_id = 'J_CUAL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUAL"},dag=dag)
J_CUAL_crawler = GlueCrawlerOperator(task_id="J_CUAL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUAL"  } , poll_interval=30, dag = dag)

Z_CUEX = GlueJobOperator(task_id = 'Z_CUEX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUEX"},dag=dag)
Z_CUEX_crawler = GlueCrawlerOperator(task_id="Z_CUEX_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CUEX"  } , poll_interval=30, dag = dag)

DSLWNL = GlueJobOperator(task_id = 'DSLWNL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWNL"},dag=dag)
DSLWNL_crawler = GlueCrawlerOperator(task_id="DSLWNL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWNL"  } , poll_interval=30, dag = dag)

J_CTDE = GlueJobOperator(task_id = 'J_CTDE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTDE"},dag=dag)
J_CTDE_crawler = GlueCrawlerOperator(task_id="J_CTDE_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTDE"  } , poll_interval=30, dag = dag)

Z_ATCI = GlueJobOperator(task_id = 'Z_ATCI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCI"},dag=dag)
Z_ATCI_crawler = GlueCrawlerOperator(task_id="Z_ATCI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_ATCI"  } , poll_interval=30, dag = dag)

Z_ATCUST = GlueJobOperator(task_id = 'Z_ATCUST',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ATCUST"},dag=dag)
Z_ATCUST_crawler = GlueCrawlerOperator(task_id="Z_ATCUST_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_ATCUST"  } , poll_interval=30, dag = dag)

J_SYCD = GlueJobOperator(task_id = 'J_SYCD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SYCD"},dag=dag)
J_SYCD_crawler = GlueCrawlerOperator(task_id="J_SYCD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SYCD"  } , poll_interval=30, dag = dag)

DSLWLA = GlueJobOperator(task_id = 'DSLWLA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLA"},dag=dag)
DSLWLA_crawler = GlueCrawlerOperator(task_id="DSLWLA_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWLA"  } , poll_interval=30, dag = dag)

J_CUIN = GlueJobOperator(task_id = 'J_CUIN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CUIN"},dag=dag)
J_CUIN_crawler = GlueCrawlerOperator(task_id="J_CUIN_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CUIN"  } , poll_interval=30, dag = dag)

Z_CAPINT = GlueJobOperator(task_id = 'Z_CAPINT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPINT"},dag=dag)
Z_CAPINT_crawler = GlueCrawlerOperator(task_id="Z_CAPINT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAPINT"  } , poll_interval=30, dag = dag)

DSLWLB = GlueJobOperator(task_id = 'DSLWLB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLB"},dag=dag)
DSLWLB_crawler = GlueCrawlerOperator(task_id="DSLWLB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWLB"  } , poll_interval=30, dag = dag)

J_GLBS = GlueJobOperator(task_id = 'J_GLBS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLBS"},dag=dag)
J_GLBS_crawler = GlueCrawlerOperator(task_id="J_GLBS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_GLBS"  } , poll_interval=30, dag = dag)

DSCAGP = GlueJobOperator(task_id = 'DSCAGP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGP"},dag=dag)
DSCAGP_crawler = GlueCrawlerOperator(task_id="DSCAGP_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAGP"  } , poll_interval=30, dag = dag)

Z_CAMA = GlueJobOperator(task_id = 'Z_CAMA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAMA"},dag=dag)
Z_CAMA_crawler = GlueCrawlerOperator(task_id="Z_CAMA_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAMA"  } , poll_interval=30, dag = dag)

J_CLPC = GlueJobOperator(task_id = 'J_CLPC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLPC"},dag=dag)
J_CLPC_crawler = GlueCrawlerOperator(task_id="J_CLPC_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLPC"  } , poll_interval=30, dag = dag)

J_CLDT = GlueJobOperator(task_id = 'J_CLDT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLDT"},dag=dag)
J_CLDT_crawler = GlueCrawlerOperator(task_id="J_CLDT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLDT"  } , poll_interval=30, dag = dag)


ACBS_EOD_Raw_Start_Task >> [J_CAMI,COADOB,J_CUMS,J_CUAD,J_CUDT,J_CLSB,J_SYDM,J_SYDR,Z_CAPINM,DSLWLR,J_CUCR,J_CACG,J_CLRR,J_GLER,J_CUAL,Z_CUEX,DSLWNL,J_CTDE,Z_ATCI,Z_ATCUST,J_SYCD,DSLWLA,J_CUIN,Z_CAPINT,DSLWLB,J_GLBS,DSCAGP,Z_CAMA,J_CLPC,J_CLDT]
J_CAMI >> J_CAMI_crawler
COADOB >> COADOB_crawler    
J_CUMS >> J_CUMS_crawler    
J_CUAD >> J_CUAD_crawler    
J_CUDT >> J_CUDT_crawler    
J_CLSB >> J_CLSB_crawler    
J_SYDM >> J_SYDM_crawler    
J_SYDR >> J_SYDR_crawler    
Z_CAPINM >> Z_CAPINM_crawler
DSLWLR >> DSLWLR_crawler    
J_CUCR >> J_CUCR_crawler    
J_CACG >> J_CACG_crawler    
J_CLRR >> J_CLRR_crawler    
J_GLER >> J_GLER_crawler    
J_CUAL >> J_CUAL_crawler    
Z_CUEX >> Z_CUEX_crawler    
DSLWNL >> DSLWNL_crawler    
J_CTDE >> J_CTDE_crawler    
Z_ATCI >> Z_ATCI_crawler    
Z_ATCUST >> Z_ATCUST_crawler
J_SYCD >> J_SYCD_crawler    
DSLWLA >> DSLWLA_crawler    
J_CUIN >> J_CUIN_crawler    
Z_CAPINT >> Z_CAPINT_crawler
DSLWLB >> DSLWLB_crawler    
J_GLBS >> J_GLBS_crawler    
DSCAGP >> DSCAGP_crawler    
Z_CAMA >> Z_CAMA_crawler    
J_CLPC >> J_CLPC_crawler    
J_CLDT >> J_CLDT_crawler 
[J_CAMI_crawler ,COADOB_crawler ,J_CUMS_crawler ,J_CUAD_crawler ,J_CUDT_crawler ,J_CLSB_crawler ,J_SYDM_crawler ,J_SYDR_crawler ,Z_CAPINM_crawler ,DSLWLR_crawler ,J_CUCR_crawler ,J_CACG_crawler ,J_CLRR_crawler ,J_GLER_crawler ,J_CUAL_crawler ,Z_CUEX_crawler ,DSLWNL_crawler ,J_CTDE_crawler ,Z_ATCI_crawler ,Z_ATCUST_crawler ,J_SYCD_crawler ,DSLWLA_crawler ,J_CUIN_crawler ,Z_CAPINT_crawler ,DSLWLB_crawler ,J_GLBS_crawler ,DSCAGP_crawler ,Z_CAMA_crawler ,J_CLPC_crawler ,J_CLDT_crawler ] >> ACBS_EOD_Raw_End_Task



