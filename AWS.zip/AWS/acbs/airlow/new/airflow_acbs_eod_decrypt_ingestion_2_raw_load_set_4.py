from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


# Define default arguments for the DAG
default_args = {
    'owner': 'Glue',
    'depends_on_past': False,
    'retries': 0,
    'email_on_failure': True
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    'ACBS_EOD_Decrypt_Ingestion_2_raw_load_set_4',
    description='ACBS SOD files Decrypt and Load 2 Raw_set_4',
    default_args=default_args,
    tags=['ACBSEODRAW'],
    schedule_interval=None,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

ACBS_EOD_Raw_Start_Task = DummyOperator(task_id='ACBS_EOD_Raw_Start_Task',dag=dag)
ACBS_EOD_Raw_End_Task = DummyOperator(task_id='ACBS_EOD_Raw_End_Task',dag=dag)

DSCAPL = GlueJobOperator(task_id = 'DSCAPL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPL"},dag=dag)
DSCAPL_crawler = GlueCrawlerOperator(task_id="DSCAPL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAPL"  } , poll_interval=30, dag = dag)

Z_CAPPF = GlueJobOperator(task_id = 'Z_CAPPF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAPPF"},dag=dag)   
Z_CAPPF_crawler = GlueCrawlerOperator(task_id="Z_CAPPF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAPPF"  } , poll_interval=30, dag = dag)

DSLWLM = GlueJobOperator(task_id = 'DSLWLM',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSLWLM"},dag=dag)      
DSLWLM_crawler = GlueCrawlerOperator(task_id="DSLWLM_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSLWLM"  } , poll_interval=30, dag = dag)

COCMAP = GlueJobOperator(task_id = 'COCMAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAP"},dag=dag)      
COCMAP_crawler = GlueCrawlerOperator(task_id="COCMAP_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAP"  } , poll_interval=30, dag = dag)

J_CLGU = GlueJobOperator(task_id = 'J_CLGU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLGU"},dag=dag)      
J_CLGU_crawler = GlueCrawlerOperator(task_id="J_CLGU_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLGU"  } , poll_interval=30, dag = dag)

DSCAPI = GlueJobOperator(task_id = 'DSCAPI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAPI"},dag=dag)      
DSCAPI_crawler = GlueCrawlerOperator(task_id="DSCAPI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAPI"  } , poll_interval=30, dag = dag)

J_CLFP = GlueJobOperator(task_id = 'J_CLFP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLFP"},dag=dag)      
J_CLFP_crawler = GlueCrawlerOperator(task_id="J_CLFP_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLFP"  } , poll_interval=30, dag = dag)

Z_ACSOLD = GlueJobOperator(task_id = 'Z_ACSOLD',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_ACSOLD"},dag=dag)
Z_ACSOLD_crawler = GlueCrawlerOperator(task_id="Z_ACSOLD_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_ACSOLD"  } , poll_interval=30, dag = dag)

Z_CAADDI = GlueJobOperator(task_id = 'Z_CAADDI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAADDI"},dag=dag)
Z_CAADDI_crawler = GlueCrawlerOperator(task_id="Z_CAADDI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAADDI"  } , poll_interval=30, dag = dag)

DSCAGH = GlueJobOperator(task_id = 'DSCAGH',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAGH"},dag=dag)      
DSCAGH_crawler = GlueCrawlerOperator(task_id="DSCAGH_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAGH"  } , poll_interval=30, dag = dag)

DSCAIL = GlueJobOperator(task_id = 'DSCAIL',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "DSCAIL"},dag=dag)
DSCAIL_crawler = GlueCrawlerOperator(task_id="DSCAIL_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_DSCAIL"  } , poll_interval=30, dag = dag)

J_GLNO = GlueJobOperator(task_id = 'J_GLNO',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLNO"},dag=dag)
J_GLNO_crawler = GlueCrawlerOperator(task_id="J_GLNO_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_GLNO"  } , poll_interval=30, dag = dag)

ZCMXRF = GlueJobOperator(task_id = 'ZCMXRF',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXRF"},dag=dag)
ZCMXRF_crawler = GlueCrawlerOperator(task_id="ZCMXRF_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZCMXRF"  } , poll_interval=30, dag = dag)

J_SCMS = GlueJobOperator(task_id = 'J_SCMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_SCMS"},dag=dag)
J_SCMS_crawler = GlueCrawlerOperator(task_id="J_SCMS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_SCMS"  } , poll_interval=30, dag = dag)

COCMAJ = GlueJobOperator(task_id = 'COCMAJ',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAJ"},dag=dag)
COCMAJ_crawler = GlueCrawlerOperator(task_id="COCMAJ_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAJ"  } , poll_interval=30, dag = dag)

J_CTUN = GlueJobOperator(task_id = 'J_CTUN',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTUN"},dag=dag)
J_CTUN_crawler = GlueCrawlerOperator(task_id="J_CTUN_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTUN"  } , poll_interval=30, dag = dag)

J_CULB = GlueJobOperator(task_id = 'J_CULB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CULB"},dag=dag)
J_CULB_crawler = GlueCrawlerOperator(task_id="J_CULB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CULB"  } , poll_interval=30, dag = dag)

Z_CUSNAI = GlueJobOperator(task_id = 'Z_CUSNAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUSNAI"},dag=dag)   
Z_CUSNAI_crawler = GlueCrawlerOperator(task_id="Z_CUSNAI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CUSNAI"  } , poll_interval=30, dag = dag)

Z_CAP = GlueJobOperator(task_id = 'Z_CAP',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CAP"},dag=dag)
Z_CAP_crawler = GlueCrawlerOperator(task_id="Z_CAP_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CAP"  } , poll_interval=30, dag = dag)

J_CLIX = GlueJobOperator(task_id = 'J_CLIX',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLIX"},dag=dag)
J_CLIX_crawler = GlueCrawlerOperator(task_id="J_CLIX_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLIX"  } , poll_interval=30, dag = dag)

Z_CUMA = GlueJobOperator(task_id = 'Z_CUMA',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CUMA"},dag=dag)
Z_CUMA_crawler = GlueCrawlerOperator(task_id="Z_CUMA_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CUMA"  } , poll_interval=30, dag = dag)

COCMAO = GlueJobOperator(task_id = 'COCMAO',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "COCMAO"},dag=dag)
COCMAO_crawler = GlueCrawlerOperator(task_id="COCMAO_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_COCMAO"  } , poll_interval=30, dag = dag)

J_CTMS = GlueJobOperator(task_id = 'J_CTMS',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CTMS"},dag=dag)
J_CTMS_crawler = GlueCrawlerOperator(task_id="J_CTMS_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CTMS"  } , poll_interval=30, dag = dag)

ZCMXAI = GlueJobOperator(task_id = 'ZCMXAI',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZCMXAI"},dag=dag)
ZCMXAI_crawler = GlueCrawlerOperator(task_id="ZCMXAI_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZCMXAI"  } , poll_interval=30, dag = dag)

J_CLTE = GlueJobOperator(task_id = 'J_CLTE',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CLTE"},dag=dag)
J_CLTE_crawler = GlueCrawlerOperator(task_id="J_CLTE_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CLTE"  } , poll_interval=30, dag = dag)

Z_FCLACT = GlueJobOperator(task_id = 'Z_FCLACT',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_FCLACT"},dag=dag)   
Z_FCLACT_crawler = GlueCrawlerOperator(task_id="Z_FCLACT_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_FCLACT"  } , poll_interval=30, dag = dag)

ZFMIFB = GlueJobOperator(task_id = 'ZFMIFB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "ZFMIFB"},dag=dag)
ZFMIFB_crawler = GlueCrawlerOperator(task_id="ZFMIFB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_ZFMIFB"  } , poll_interval=30, dag = dag)

J_CAGU = GlueJobOperator(task_id = 'J_CAGU',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_CAGU"},dag=dag)
J_CAGU_crawler = GlueCrawlerOperator(task_id="J_CAGU_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_CAGU"  } , poll_interval=30, dag = dag)

J_GLCC = GlueJobOperator(task_id = 'J_GLCC',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "J_GLCC"},dag=dag)
J_GLCC_crawler = GlueCrawlerOperator(task_id="J_GLCC_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_J_GLCC"  } , poll_interval=30, dag = dag)

Z_CIB = GlueJobOperator(task_id = 'Z_CIB',job_name='lending_acbs_eod_landing2raw_extract_decrypt',script_args={"--ENV": f"{environment}","--ACBS_TABLE": "Z_CIB"},dag=dag)
Z_CIB_crawler = GlueCrawlerOperator(task_id="Z_CIB_crawler",config={"Name": "lending_acbs_raw_dataasset_rl_db_Z_CIB"  } , poll_interval=30, dag = dag)



ACBS_EOD_Raw_Start_Task >> [DSCAPL,Z_CAPPF,DSLWLM,COCMAP,J_CLGU,DSCAPI,J_CLFP,Z_ACSOLD,Z_CAADDI,DSCAGH,DSCAIL,J_GLNO,ZCMXRF,J_SCMS,COCMAJ,J_CTUN,J_CULB,Z_CUSNAI,Z_CAP,J_CLIX,Z_CUMA,COCMAO,J_CTMS,ZCMXAI,J_CLTE,Z_FCLACT,ZFMIFB,J_CAGU,J_GLCC,Z_CIB]
DSCAPL >> DSCAPL_crawler
Z_CAPPF >> Z_CAPPF_crawler  
DSLWLM >> DSLWLM_crawler    
COCMAP >> COCMAP_crawler    
J_CLGU >> J_CLGU_crawler    
DSCAPI >> DSCAPI_crawler    
J_CLFP >> J_CLFP_crawler    
Z_ACSOLD >> Z_ACSOLD_crawler
Z_CAADDI >> Z_CAADDI_crawler
DSCAGH >> DSCAGH_crawler    
DSCAIL >> DSCAIL_crawler    
J_GLNO >> J_GLNO_crawler    
ZCMXRF >> ZCMXRF_crawler    
J_SCMS >> J_SCMS_crawler    
COCMAJ >> COCMAJ_crawler    
J_CTUN >> J_CTUN_crawler    
J_CULB >> J_CULB_crawler    
Z_CUSNAI >> Z_CUSNAI_crawler
Z_CAP >> Z_CAP_crawler      
J_CLIX >> J_CLIX_crawler    
Z_CUMA >> Z_CUMA_crawler    
COCMAO >> COCMAO_crawler    
J_CTMS >> J_CTMS_crawler    
ZCMXAI >> ZCMXAI_crawler    
J_CLTE >> J_CLTE_crawler    
Z_FCLACT >> Z_FCLACT_crawler
ZFMIFB >> ZFMIFB_crawler    
J_CAGU >> J_CAGU_crawler    
J_GLCC >> J_GLCC_crawler    
Z_CIB >> Z_CIB_crawler
[DSCAPL_crawler ,Z_CAPPF_crawler ,DSLWLM_crawler ,COCMAP_crawler ,J_CLGU_crawler ,DSCAPI_crawler ,J_CLFP_crawler ,Z_ACSOLD_crawler ,Z_CAADDI_crawler ,DSCAGH_crawler ,DSCAIL_crawler ,J_GLNO_crawler ,ZCMXRF_crawler ,J_SCMS_crawler ,COCMAJ_crawler ,J_CTUN_crawler ,J_CULB_crawler ,Z_CUSNAI_crawler ,Z_CAP_crawler ,J_CLIX_crawler ,Z_CUMA_crawler ,COCMAO_crawler ,J_CTMS_crawler ,ZCMXAI_crawler ,J_CLTE_crawler ,Z_FCLACT_crawler ,ZFMIFB_crawler ,J_CAGU_crawler ,J_GLCC_crawler ,Z_CIB_crawler ] >> ACBS_EOD_Raw_End_Task


