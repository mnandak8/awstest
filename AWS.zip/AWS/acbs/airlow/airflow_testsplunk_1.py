from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.sensors.time_delta import TimeDeltaSensor
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from datetime import datetime,timedelta
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs import CONFIG
from datetime import datetime, timedelta
import pendulum  
import logging




# Define MST timezone
mst_tz = pendulum.timezone("America/Denver")
mst_now = pendulum.now(mst_tz)  # Get current time in MST
formatted_date = mst_now.format('YYYYMMDD') 



sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

landing_acbs_bucket=f"{environment}-acb-dat-ing-acbs-landing"
landing_trigger_key="SVCAWSSFTP/test1.txt"
acbs_eod_raw_schedule=CONFIG[environment]['acbs_eod_raw_schedule']


# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'retries': 0,
    'email_on_success': False ,
    'email_on_failure': False
}
#On-Call API ID 
#c625mqldbal8h7lu5orl5hcrs

#API key assigned to dataenineering-datalake 
#cdcff4241f9f42d59bc2dda7901a873a




"""
SPLUNK_ONCALL_URL = "https://alert.victorops.com/integrations/generic/20131114/alert/62d46c97-fdee-4c0f-9115-3ab616eb28c4/dataengineering-datalake"
def send_alert_to_splunk_oncall(context):
    print(f"Python OpenSSL Version: {ssl.OPENSSL_VERSION}")
    dag_id = 'ACBS_EOD_test_oncall_splunk'
    execution_date = '2024-03-5'
    task_id = 's_acbs_eod_FW_s3keysensor'
    error_message = 'job failed'
    payload = {
        "message_type": "CRITICAL",
        "entity_id": f"airflow-{dag_id}-{task_id}",
        "entity_display_name": f"Airflow DAG {dag_id} failed at {execution_date}. Error: {error_message}",
        "state_message": "Failed"
    }
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    response = requests.post(SPLUNK_ONCALL_URL, json=payload , verify=False)
    if response.status_code != 200:
        print(f"Failed to send alert to Splunk On-Call: {response.text}")
def splunk_log_messages(context):
    print(f"DAG {context['dag'].dag_id} has failed!")
    logging.error(f"DAG {context['dag'].dag_id} has failed Nanda !")
    logging.error(f"Execution Date Nanda : {context['execution_date']}")
    
"""


start_date = datetime(2025, 1, 1)
dag = DAG(
    'ACBS_EOD_test_oncall_splunk',
    description='ACBS SOD files splunk',
    default_args=default_args,
    tags=['ACBS'],
    dagrun_timeout=timedelta(minutes=1),
    catchup=False,  
    start_date=start_date,
    schedule=acbs_eod_raw_schedule,
    on_failure_callback=[sns_notifier.failure_notification] 
)
 

EOD_Raw_s3_FW_Start_Task = DummyOperator(task_id='EOD_Raw_s3_FW_Start_Task',dag=dag,on_success_callback=[sns_notifier.success_notification])
EOD_Raw_s3_FW_End_Task = DummyOperator(task_id='EOD_Raw_s3_FW_End_Task',dag=dag,on_success_callback=[sns_notifier.success_notification])

s_acbs_eod_FW_s3keysensor = S3KeySensor(
    task_id="s_acbs_eod_FW_s3keysensor",
    bucket_name=landing_acbs_bucket,
    bucket_key=landing_trigger_key, 
    timeout=60,  
    poke_interval=5, 
    mode="poke",
    dag=dag  
)


EOD_Raw_s3_FW_Start_Task >> s_acbs_eod_FW_s3keysensor
s_acbs_eod_FW_s3keysensor >> EOD_Raw_s3_FW_End_Task




