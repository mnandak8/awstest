variable "resource_prefix" {type        = string}
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "lw_server" {type        = string}
variable "lw_onprem_sqlserver_db" {type        = string}
variable "vpc_name" {type        = string}
variable "dms_data_app_subnets" { type = list}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_ingress" { type = set(string)}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_egress" { type = set(string)}
variable "dms_lw_allocated_storage" {type        = string}
variable "dms_replication_instance_class" {type        = string}
variable "dms_lw_engine_version" {type        = string}
variable "dms_lw_multi_az" {type        = string}
variable "dms_replication_migration_type" { type = string }
variable "cdc_max_batch_interval" { type = string }
variable "dms_replication_migration_type_rds" {type        = string}  
variable "ods_consumption_secrets_manager_arn_id" {type        = string}  
variable "ods_consumption_secrets_manager_arn_kms_key_id" { type = string }     
variable "consumption_account_id" { type = string }     
variable "lake_account_id" { type = string }     
variable "email_address" { type = string }   
variable "cust-kms-key-lw-dms" { type = string }   
variable "instance_var" { type = string }   


#leasewave ods s3 validation tf variables
variable "ods_rds_host" {type = string}
variable "ods_rds_db" {type = string}


# Rapport Database replication DMS variables
variable "replication_instance_arn_for_dms" {
  type        = string
}

variable "rapport_database_name" {
  type        = string
}

#Rapport SQS variables
variable "sqs_max_message_size" { 
   type = number 
}
variable "sqs_message_retention_seconds" { 
   type = number 
}
variable "sqs_receive_wait_time_seconds" { 
   type = number 
}
variable "sqs_kms_data_key_reuse_period_seconds" { 
   type = number 
}
 
variable "sqs_delay_seconds" { 
   type = number 
}
variable "sqs_visibility_timeout_seconds" { 
   type = number 
}
#variable "environment" { type = string }

#variable "terra_factory_aws_id" {
#  type        = string
#  description = "Name of the aws account."
#}

#variable "replication_instance_arn_for_dms" {
#  type        = string
#}


