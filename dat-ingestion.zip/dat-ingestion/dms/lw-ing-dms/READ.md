# DMS 

Data Migration Service, used to replicate the LeaswWave Onprem SQL Server Lease data to S3 on Kae and ODS on Cnsumption.


- [Replication-Instance](#Replication-Instance)
- [Security](#Security])
- [IAM](#IAM)
- [Secrets](#Secrets)
- [End-Points](#End-Points)
- [Replication-Task-ODS](#Replication-Task-ODS)
- [Replication-Task-S3](#Replication-Task-S3)
- [Table-list-PI2](#Table-list-PI2)
- [Adding-new-tables](#Adding-new-tables)
- [Adding-new-columns](#Adding-new-columns)
- [Events](#Events)
- [Dags](#Dags)

  
 [Architecture](https://projects.insidecobank.com/PRJ0047911/_layouts/15/WopiFrame.aspx?sourcedoc=%7B99165008-2A1C-47A3-B5FF-7804DC879950%7D&file=LWDMS.pdf&action=default&IsList=1&ListId=%7BEB6030B3-61DA-4A24-A686-FE0C69045299%7D&ListItemId=14360) 
 ![image](https://github.com/cobank-acb/dat-ingestion/assets/159950633/80ccd178-0298-4c0f-b44f-0ff30c850000)
 


# Replication-Instance
    

  AWS DMS creates it on an Amazon EC2 instance in a virtual private cloud (VPC) based on the Amazon VPC service. 
  -	cobank-${environment}-${aws_ing_account_id}-mssqlserver-lw-onprem-${lw_sqlserver_host}
  
    


# Security

[Inbound and OutBound Security Groups](https://projects.insidecobank.com/PRJ0047911/Project%20Team%20Working%20Documents/Technical%20Documents/LWDMS/LWDMS%20Security%20Grp%20Rules.xlsx?d=w4d31973c5c934b128b4f171de8cdad30)

# IAM Roles

cobank-dev-lw-dms-role 

-	AmazonDMSCloudWatchLogsRole:For the CLud Watch Logs
-	AmazonEC2ContainerRegistryReadOnly:This is for the Glue Job for Validation Script                
-	AmazonS3FullAccess :For the S3
-	AWSGlueConsoleFullAccess :This is for the Glue Job for Validation Script                                        
-	AWSGlueServiceRole:This is for the Glue Job for Validation Script                                        
-	cobank-dev-dms-pass-role :This is for the Glue Job for Validation Script
-	cobank-dev-dms-secret-read-policy :To read the Secrets for LW SQl server and ODS in COnsumption                                                
-	cobank-dev-dms-start-stop-replicationTasks :Airflow DAGS for the Tasks                        
-	KMSFullAccess :Access for the KMS.
- 	Consumption: Add the Role "cobank-dev-lw-dms-role" to The secrets (cobank-dl-rds-user-secret-ods-svclwdms-dev)	that has the ODS credentails and KMS keys used to decrypt the secret.
- 	Consumption: Add the Role "terra-factory-github-actions" to The secrets (cobank-dl-rds-user-secret-ods-svclwdms-dev) hat has the ODS credentails and KMS keys used to decrypt the secret, so that the Terraform  an create the End point using the 	ODSsecrets.
- 	Lake:	Add DMS role "cobank-dev-lw-dms-role" to S3 bucket on S3 for Cross account access.
    	

# Secrets
	
1.	dms-lw-dev-credentails-sqlserver-on-prem : Secrects for the LW on prem Credentials. The entries have to be added manually to the Secrects, it exists in Ingestion Acct. 

2.	cobank-dl-rds-user-secret-ods-svclwdms-dev : Secrects for the COnsumption ODS, the entries are maintained by the DU team. This Exists in the COnsumption Account. 

# End-Points
**cobank-dev-${aws_ing_account_id}-src-mssqlserver-lw-onprem-sgnddvlease001** -->Connects to LeaseWave on-prem SqlServer

Settings
| Option | Value |
| --- | --- |
|End Point Type|Source |
|Secret ID | cobank-dl-rds-user-secret-ods-svclwdms-dev |
|Database name | LeaseWave |
|Extra connection attributes |EnableNonSysadminWrapper=true;SetUpMsCdcForTables= false|


**cobank-dev-${aws_ing_account_id}-tgt-lw-rds-dat-consumption** -->Connects to Amazon Aurora RDS on consumption Account.

Settings
| Option | Value |
| --- | --- |
|SSL mode|Use Certificate|
|Secret ID |dms-lw-dev-credentails-sqlserver-on-prem |


**cobank-dev-${aws_ing_account_id}-tgt-lw-s3-dat-lak-raw** -->Connects to S3 on Lake Account. 

Settings
| Option | Value |
| --- | --- |
|End Point Type|Target |
|bucketFolder|leasewave |
|bucketName|cobank-dat-lak-us-west-2-leasewave-raw-dev |
|datePartitionDelimiter|NONE |
|datePartitionEnabled|true |
|datePartitionSequence|YYYYMMDD |
|datePartitionTimezone|US/Mountain |
|CdcMaxBatchInterval|100 |
|TimestampColumnName|dms_tx_commit_Timestamp |
|IncludeOpForFullLoad|true |
|DataFormat|parquet |


# Replication-Task-ODS
**cobank-dev-471112929721-lw-sqlserver-rds-consumption** This tasks replicates the data to the ODS on Cosumption Account

-	**End-Points**
	```
		Source:cobank-dev-${aws_ing_account_id}-src-mssqlserver-lw-onprem-sgnddvlease001
		Target:cobank-dev-${aws_ing_account_id}-tgt-lw-rds-dat-consumption
 	```
-	**Mapping Rules**
   		
MetadataColumns

| Option | Value |
| --- | --- |
|Column|Use |
|AH_STREAM_POSITION|The stream position value from the source, null for fullload|
|AR_H_OPERATION|INSERT UPDATE |
|AR_H_USER|The user name, ID|
|AR_H_TIMESTAMP|Time of the change|
|AR_H_COMMIT_TIMESTAMP|Time of the commit|
|AR_H_CHANGE_SEQ|A unique incrementing number from the source database that consists of a timestamp and an auto incrementing number|



-	**Configuration**
  
| Option | Value | Notes |
| --- | --- | --- |
|TargetTablePrepMode|TRUNCATE_BEFORE_LOAD|when we do a Restart, if exist truncate else create|
|MaxFullLoadSubTasks|15|Threads Parallel Loads|
|ControlSchema|dbo|Schema for the COntrol Tables|
|StatusTableEnabled|true|DMS Metadata Table|
|SuspendedTablesTableEnabled|true|DMS Metadata Table|
|HistoryTableEnabled|true|DMS Metadata Table|
|FullLoadExceptionTableEnabled|true|DMS Metadata Table|
|CommitRate|50000|Max COmmit load|
|StopTaskCachedChangesApplied|false|Stop after Full load|
|StopTaskCachedChangesNotApplied|false|Stop after Full load|
-	**Performance**
  
Range Parttions on the Large Tables
```
RemainingNetInvestments
ReceivableInvoices
LeasePaymentSchedules
ReceiptApplicationReceivableDetails
ReceivableTaxes		
```

# Replication-Task-S3
**cobank-dev-471112929721-lw-sqlserver-rds-consumption** This tasks replicates the data to the ODS on Cosumption Account

-	**End-Points**
	```
		Source:cobank-dev-${aws_ing_account_id}-src-mssqlserver-lw-onprem-sgnddvlease001
		Target:cobank-dev-${aws_ing_account_id}-tgt-lw-s3-dat-lak-raw
 	```
-	**Mapping Rules**
   		
MetadataColumns

| Option | Value |
| --- | --- |
|Column|Use |
|dms_tx_commit_timestamp|Commit timestamp on source|
|OP|INSERT UPDATE DELETE|


-	**Configuration**
  
| Option | Value | Notes |
| --- | --- | --- |
|TargetTablePrepMode|TRUNCATE_BEFORE_LOAD|when we do a Restart, if exist delete files else create new files|
|MaxFullLoadSubTasks|15|Threads Parallel Loads|
|MaxFullLoadSubTasks|15|Threads Parallel Loads|

# Table-list-PI2
| list | List | list |
| --- | --- | --- |
|Assets|LeaseFinanceDetails|LeasePaymentSchedules|
|CollateralTrackings|LeaseFinances|RemainingNetInvestments|
|ContractOriginations|Locations|ReportingChannelConfigs|
|Contracts|Parties|States|
|Customers|PayoffInvoices|ReceiptApplicationReceivableDetails|
|InvoiceExtractCustomerDetails|Payoffs|ReceiptApplications|
|AssetLocations|ProgramIndicatorConfigs|ReceivableCatagories|
|InvoiceTypes|Receipts|ReceivableCodes|
|LeaseAssets|ReceiptTypes|ReceivableDetails|
|LeaseFinanceDetails|CustomerACHAssignments|Receivables|
|LeaseFinances|ReceivableInvoices|ReceivableTaxes|

# Adding-new-tables
Add tables to the mapping rules json file, make sure the the Rule-is is unique
# Adding-new-columns
When columns are added, DMS automatically creates new columns and populate the data, in S3 there will be a update record. Need to regenrate the schema in GLue/Athena. 
# Events
# Dags




