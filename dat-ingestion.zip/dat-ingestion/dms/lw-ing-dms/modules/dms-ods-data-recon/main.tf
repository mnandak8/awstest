
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

# Retrieve the VPC in the current account and region using the VPC name
data "aws_vpc" "selected_vpc" {
  filter {
    name   = "tag:Name"
    values = [var.vpc_name]
  }
}

# Retrieve available subnets in the selected VPC
data "aws_subnets" "available_subnets" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.selected_vpc.id]
  }

  filter {
    name   = "tag:Name"
    values = ["*data-application*"]
  }
  
  filter {
    name   = "state"
    values = ["available"]
  }
}

# Retrieve one of the available subnets using aws_subnet
data "aws_subnet" "selected_subnet" {
  id = element(data.aws_subnets.available_subnets.ids, 0)  # Select the first available subnet ID
}

# Retrieve the Onprem SQL Server Secrets from Ingestion Account Secrets Manager
data "aws_secretsmanager_secret" "onprem_sqlserver_secret" {
  name = "dms-lw-${var.environment}-credentails-sqlserver-on-prem"
}

data "aws_secretsmanager_secret_version" "onprem" {
  secret_id = data.aws_secretsmanager_secret.onprem_sqlserver_secret.id
}



locals {
  account_id            = data.aws_caller_identity.current.account_id
  region_name           = data.aws_region.current.name
  lw_dms_role           = "cobank-${var.environment}-lw-dms-role"
  selected_subnet_id    = data.aws_subnet.selected_subnet.id
  onprem_sqlserver_host = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.onprem.secret_string)).host
  onprem_sqlserver_port = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.onprem.secret_string)).port
  onprem_sqlserver_db   = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.onprem.secret_string)).dbname

  # ods_rds_host = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.ods.secret_string)).host
  # ods_rds_port = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.ods.secret_string)).port
  ods_rds_port = 5432
  ods_rds_db   = var.ods_rds_db
}



resource "aws_security_group" "jdbc_connections_security_group" {
  name        = "dms_jdbc_connections_security_group"
  vpc_id      = data.aws_vpc.selected_vpc.id
  description = "Security group for glue jdbc connectors "

}

###
resource "aws_vpc_security_group_ingress_rule" "connection_security_group_ingress" {
    description      = "GLue Job connector Ingress"
    for_each = var.lw_onprem_mssqlserver_vpc_cidr_blocks_ingress
    security_group_id = aws_security_group.jdbc_connections_security_group.id
    cidr_ipv4   = each.value
    ip_protocol = "-1"
}

resource "aws_vpc_security_group_egress_rule" "connection_security_group_egress" {
    description      = "GLue Job connector egress"
    for_each = var.lw_onprem_mssqlserver_vpc_cidr_blocks_egress
    security_group_id = aws_security_group.jdbc_connections_security_group.id
    cidr_ipv4   = each.value
    ip_protocol = "-1"
  }
resource "aws_vpc_security_group_ingress_rule" "connection_security_group_ingress_self" {
    description      = "GLue Job connector Ingress self"
    security_group_id = aws_security_group.jdbc_connections_security_group.id
    referenced_security_group_id=aws_security_group.jdbc_connections_security_group.id
    ip_protocol = "-1"
  }

resource "aws_vpc_security_group_egress_rule" "connection_security_group_egress_self" {
    description      = "GLue Job connector egress self"
    security_group_id = aws_security_group.jdbc_connections_security_group.id
    referenced_security_group_id = aws_security_group.jdbc_connections_security_group.id
    ip_protocol = "-1"
  }

###
# Create the Onprem SQL Server JDBC connection
resource "aws_glue_connection" "onprem_sql_connection" {
  name = "cobank-onprem-sqlserver-jdbc-connection-${var.environment}"

  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:sqlserver://${local.onprem_sqlserver_host}:${local.onprem_sqlserver_port};database=${local.onprem_sqlserver_db}"
    SECRET_ID           = data.aws_secretsmanager_secret.onprem_sqlserver_secret.arn
  }

  physical_connection_requirements {
    subnet_id                = local.selected_subnet_id
    security_group_id_list   = [aws_security_group.jdbc_connections_security_group.id]
    availability_zone        = data.aws_subnet.selected_subnet.availability_zone
  }
}

# Create the ODS RDS PostgreSQL JDBC connection
resource "aws_glue_connection" "ods_rds_connection" {
  name = "cobank-ods-rds-jdbc-connection-${var.environment}"

  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:postgresql://${var.ods_rds_host}:${local.ods_rds_port}/${local.ods_rds_db}"
    SECRET_ID           = "arn:aws:secretsmanager:${local.region_name}:${var.ods_account_id}:secret:${var.ods_rds_secrets_name}"
  }

  physical_connection_requirements {
    subnet_id                = local.selected_subnet_id
    security_group_id_list   = [aws_security_group.jdbc_connections_security_group.id]
    availability_zone        = data.aws_subnet.selected_subnet.availability_zone
  }
}

# Upload the Glue script and config file to the tooling bucket
resource "aws_s3_object" "leasewave_upload_glue_config" {
  bucket = "cobank-dl-${local.account_id}-${local.region_name}-tooling-${var.environment}"
  key    = "ingestion/glue-scripts/leasewave/leasewave_ods_s3_validation.json"
  source = "${path.module}/../../src/main/leasewave/configs/leasewave_ods_s3_validation.json"
  etag   = filemd5("${path.module}/../../src/main/leasewave/configs/leasewave_ods_s3_validation.json")
}

resource "aws_s3_object" "leasewave_upload_glue_scripts" {
  bucket = "cobank-dl-${local.account_id}-${local.region_name}-tooling-${var.environment}"
  key    = "ingestion/glue-scripts/leasewave/leasewave_ods_s3_validation.py"
  source = "${path.module}/../../src/main/leasewave/glue/leasewave_ods_s3_validation.py"
  source_hash = filemd5("${path.module}/../../src/main/leasewave/glue/leasewave_ods_s3_validation.py")
}

# Upload the Airflow DAG to the Airflow DAG bucket
resource "aws_s3_object" "leasewave_validation_dags" {
  bucket =  "cobank-dl-${var.lake_account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/ingestion/leasewave/leasewave_ods_s3_validation_dag.py"
  source = "${path.module}/../../src/main/leasewave/airflow/leasewave_ods_s3_validation_dag.py"
  source_hash = filemd5("${path.module}/../../src/main/leasewave/airflow/leasewave_ods_s3_validation_dag.py")
}


# Create the leasewave-ods-s3-validation-glue-job
resource "aws_glue_job" "leasewave_ods_s3_validation_glue_job" {
  depends_on = [
    aws_s3_object.leasewave_upload_glue_scripts,
    aws_s3_object.leasewave_upload_glue_config,
    #aws_s3_object.leasewave_validation_dags
  ]

  name       = "leasewave-ods-s3-validation-glue-job-${var.environment}"
  role_arn   = "arn:aws:iam::${local.account_id}:role/${local.lw_dms_role}" 

  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.leasewave_upload_glue_scripts.bucket}/${aws_s3_object.leasewave_upload_glue_scripts.key}"
    python_version  = "3"
  }

  default_arguments = {
    "--configLocation"         = "s3://${aws_s3_object.leasewave_upload_glue_config.bucket}/${aws_s3_object.leasewave_upload_glue_config.key}"
    "--S3_REPORTS_BUCKET"      = "cobank-dat-lak-us-west-2-leasewave-raw-${var.environment}"
    "--ONPREM_CONNECTION_NAME" = aws_glue_connection.onprem_sql_connection.name
    "--ODS_CONNECTION_NAME"    = aws_glue_connection.ods_rds_connection.name
    "--landingBucket"          = "cobank-dat-lak-us-west-2-leasewave-raw-${var.environment}"
    "--enable-continuous-cloudwatch-log" = "false"
  }

  connections = [
    aws_glue_connection.onprem_sql_connection.name,
    aws_glue_connection.ods_rds_connection.name
  ]

  glue_version      = "4.0"
  worker_type       = "G.2X"
  number_of_workers = "10"
}
