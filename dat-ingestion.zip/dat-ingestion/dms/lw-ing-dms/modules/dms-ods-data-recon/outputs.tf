

output "glue_job_name" {
  value = aws_glue_job.leasewave_ods_s3_validation_glue_job.name
}
