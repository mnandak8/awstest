
variable "vpc_name" { type = string }
variable "lake_account_id" { type = string }     
variable "ods_account_id" { type = string }
variable "ods_rds_secrets_name" { type = string }
variable "environment" { type = string }
variable "ods_rds_host" {type = string}
variable "ods_rds_db" {type = string}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_ingress" { type = set(string)}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_egress" { type = set(string)}
