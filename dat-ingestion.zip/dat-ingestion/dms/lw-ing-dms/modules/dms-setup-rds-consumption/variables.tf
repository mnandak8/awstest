
variable "resource_prefix" {type        = string}
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}



variable "environment" { type = string }
variable "cust_dms_kms_key_id_arn" {type        = string}  
variable "cust_dms_kms_key_id" {type        = string}  
variable "dms_lw_src_endpoint_srn" {type        = string}	
variable "dms_repl_inst_arn" {type        = string}	      
variable "dms_secrects_kms_arn" {type        = string}  
variable "dms_replication_migration_type_rds" {type        = string}  
#variable "kms_key_dms_id" {type        = string}  
variable "ods_consumption_secrets_manager_arn_id" {type        = string}  
variable "consumption_account_id" {type        = string}  
variable "email_address" {type        = string}  

