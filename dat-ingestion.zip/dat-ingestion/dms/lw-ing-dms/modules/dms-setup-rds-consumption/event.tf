
# trivy:ignore:AVD-AWS-0095: KMS key is added through the module, manually checked. checkov would need to be refactored to correctly see the kms encryption key
resource "aws_sns_topic" "dms_topic" {
  name = local.sns_failure_topic
  tags            = var.tags
  kms_master_key_id = var.cust_dms_kms_key_id
  policy            = jsonencode(
  {
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RootAccess",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::${local.account_id}:root"
      },
      "Action": "SNS:Publish",
      "Resource": "*"
    },
    {
      "Sid": "dms-allow-publish",
      "Effect": "Allow",
      "Principal": {
        "Service": "dms.amazonaws.com"
      },
      "Action": "sns:Publish",
      "Resource": "arn:aws:sns:us-west-2:${local.account_id}:cobank-${var.environment}-${local.account_id}-dms-repl-task-failure-snstopic"
    }
  ]
} 
  )
}

resource "aws_sns_topic_subscription" "dms_alerting_topic_email_subscription" {
  topic_arn = aws_sns_topic.dms_topic.arn
  protocol  = "email"
  endpoint  = var.email_address
}


resource "aws_dms_event_subscription" "dms_leasewave_replication_instance_failure" {
  enabled          = true
  event_categories = ["failure"]
  name             = "dms-leasewave-replication-instance-failure"
  sns_topic_arn    = aws_sns_topic.dms_topic.arn
  source_type      = "replication-instance"
  tags            = var.tags
}


resource "aws_dms_event_subscription" "dms_leasewave_replication_task_failure" {
  enabled          = true
  event_categories = ["failure"]
  name             = "dms-leasewave-replication-task-failure"
  sns_topic_arn    = aws_sns_topic.dms_topic.arn
  source_type      = "replication-task"
  tags            = var.tags
}




