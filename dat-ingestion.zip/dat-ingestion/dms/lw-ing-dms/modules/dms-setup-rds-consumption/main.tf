
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}


locals {
  account_id                                 = data.aws_caller_identity.current.account_id
  region_name                                = data.aws_region.current.name
  lw-dms-role                                = "cobank-${var.environment}-lw-dms-role"
  lw-dms-role-arn                            = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-lw-dms-role"
  dms_endpoint_tgt_rds-consumption-lw        = "${var.resource_prefix}-${var.environment}-${local.account_id}-tgt-lw-rds-dat-consumption"
  dms_repl_task_lw_sql_rds                   = "${var.resource_prefix}-${var.environment}-${local.account_id}-lw-sqlserver-rds-consumption"
  dms_rds_table_mappings                     = file("${path.module}/lw-dms-rds-table-mappings_ph1.json")
  dms-rds_repl-task-settings                 = jsonencode(jsondecode(file("${path.module}/dms-rds-task-settings.json")))
  ods_consumption_secrets_manager_arn = "arn:aws:secretsmanager:${local.region_name}:${var.consumption_account_id}:secret:${var.ods_consumption_secrets_manager_arn_id}"
  sns_failure_topic                  = "${var.resource_prefix}-${var.environment}-${local.account_id}-dms-repl-task-failure-snstopic"                                                        
                      
}


## DMS Endpoint for Tgt RDS on Consumption 
resource "aws_dms_endpoint" "Target_endpoint_rds_consumption" {
  endpoint_id                     = local.dms_endpoint_tgt_rds-consumption-lw
  tags                            = var.tags
  endpoint_type                   = "target"               
  secrets_manager_arn             = local.ods_consumption_secrets_manager_arn
  secrets_manager_access_role_arn = local.lw-dms-role-arn
  kms_key_arn                     = var.cust_dms_kms_key_id_arn
  engine_name                     = "aurora-postgresql"
  database_name                   = "LeaseWave"
  ssl_mode                        = "require"
}

resource "aws_cloudwatch_log_group" "cloudwatch-log-group" {
  #checkov:skip=CKV_AWS_158:Removing kms to read logs in Splunk
  name              = "dms-tasks-${local.dms_repl_task_lw_sql_rds}"
  retention_in_days = 365
  tags = merge(var.tags, {Splunk = true})
}

resource "aws_dms_replication_task" "replication_task" {
  replication_task_id       = local.dms_repl_task_lw_sql_rds
  resource_identifier       = "lw-sqlserver-rds-consumption"
  tags                      = var.tags
  source_endpoint_arn       = var.dms_lw_src_endpoint_srn
  target_endpoint_arn       = aws_dms_endpoint.Target_endpoint_rds_consumption.endpoint_arn
  replication_instance_arn  = var.dms_repl_inst_arn
  migration_type            = var.dms_replication_migration_type_rds
  table_mappings            = local.dms_rds_table_mappings
  replication_task_settings = local.dms-rds_repl-task-settings
}
