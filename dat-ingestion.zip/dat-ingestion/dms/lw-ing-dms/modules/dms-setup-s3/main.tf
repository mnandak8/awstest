data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_vpc" "selected" {
  filter {
    name   = "tag:Name"
    values = [var.vpc_name]
  }
}

locals {
  

  account_id                          = data.aws_caller_identity.current.account_id
  region_name                         = data.aws_region.current.name
  lw-dms-role                         = "cobank-${var.environment}-lw-dms-role"
  lw-dms-role-arn                     = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-lw-dms-role"
  lw-credentails-sqlserver            = "dms-lw-${var.environment}-credentails-sqlserver-on-prem"
  lw-sqlserver-certs                  = file("${path.module}/cert-${var.environment}lwsqlserveronprem.pem")
  dms_src_lw_endpoint                 = "${var.resource_prefix}-${var.environment}-${local.account_id}-src-mssqlserver-lw-onprem-${var.lw_server}"
  dms_endpoint_tgt_s3_ing_landing     = "${var.resource_prefix}-${var.environment}-${local.account_id}-tgt-lw-s3-dat-lak-raw"                                                                                                       
  dms_lw_replication_instance         = "${var.resource_prefix}-${var.environment}-${local.account_id}-${var.instance_var}-lw-onprem-${var.lw_server}"
  dms_lw_subnet_group                 = "${var.resource_prefix}-${var.environment}-${local.account_id}-lw-dms-subnet-group"
  dms_lw_security_group               = "${var.resource_prefix}-${var.environment}-${local.account_id}-lw-dms-security-group"
  dms_repl_task_lw_sql_s3             = "${var.resource_prefix}-${var.environment}-${local.account_id}-lw-sqlserver-s3-lake"
  dms_ing_table_mappings              = file("${path.module}/lw-dms-table-mappings_ph1.json")
  dms-repl-task-settings              = jsonencode(jsondecode(file("${path.module}/dms-task-settings.json")))
  lak_lw_raw_s3_bucket                = "${var.resource_prefix}-dat-lak-${local.region_name}-leasewave-raw-${var.environment}"
  ods_consumption_secrets_manager_arn = "arn:aws:secretsmanager:${local.region_name}:${var.consumption_account_id}:secret:${var.ods_consumption_secrets_manager_arn_id}"
  ods_consumption_secrets_manager_kms_key_arn  = "arn:aws:kms:${local.region_name}:${var.consumption_account_id}:key/${var.ods_consumption_secrets_manager_arn_kms_key_id}"
  sns_failure_topic                  = "${var.resource_prefix}-${var.environment}-${local.account_id}-dms-repl-task-failure-snstopic"                                                        
                              
                                                    
}
resource "aws_cloudwatch_log_group" "dms-replication-cloudwatch-log-group" {
  name              = "dms-tasks-${local.dms_lw_replication_instance}"
  retention_in_days = 365
  kms_key_id = aws_kms_key.kms_key_lw_dms.arn
  tags = merge(var.tags, {Splunk = true})
}

# Create Replication INstance:
# DMS Replication Instance and it's instance class is configurable

resource "aws_dms_replication_instance" "dms_replication_instance_lw_sqlserver_onprem" {
  tags                         = var.tags
  replication_instance_id      = local.dms_lw_replication_instance
  auto_minor_version_upgrade   = true
  apply_immediately            = true
  engine_version               = var.dms_lw_engine_version
  multi_az                     = var.dms_lw_multi_az
  preferred_maintenance_window = "sun:23:45-mon:00:30"
  allocated_storage            = var.dms_lw_allocated_storage
  replication_instance_class   = var.dms_replication_instance_class
  vpc_security_group_ids       = [aws_security_group.lw_dms_security_grp.id]
  replication_subnet_group_id  = aws_dms_replication_subnet_group.lw_dms_subnet_group.id
  publicly_accessible          = false
  kms_key_arn                  =  aws_kms_key.kms_key_lw_dms.arn
 
  

}

## create a certficate for the LWSQL server on prem
resource "aws_dms_certificate" "lw_sqlserver_allcerts" {
  certificate_id  = "lw-sqlserver-onprem-allcerts"
  certificate_pem = local.lw-sqlserver-certs
  tags                            = var.tags
}
# DMS Endpoint for Source LW SQL Server on Prem

resource "aws_dms_endpoint" "source_endpoint_sql_server_lw_onprem" {
  ssl_mode                        = "verify-full"
  certificate_arn                 = aws_dms_certificate.lw_sqlserver_allcerts.certificate_arn
  endpoint_id                     = local.dms_src_lw_endpoint
  tags                            = var.tags
  endpoint_type                   = "source"
  secrets_manager_arn             = aws_secretsmanager_secret.lw_sqlserver_onprem_credentials.arn
  kms_key_arn                     = aws_kms_key.kms_key_lw_dms.arn
  engine_name                     = "sqlserver"
  service_access_role             = local.lw-dms-role-arn
  database_name                   = var.lw_onprem_sqlserver_db
  secrets_manager_access_role_arn = local.lw-dms-role-arn
  extra_connection_attributes= "EnableNonSysadminWrapper=true;SetUpMsCdcForTables=false;connectionTimeout=60;executeTimeout=120"
}



## DMS Endpoint for Tgt LW to the Landing Zone 
resource "aws_dms_s3_endpoint" "Target_endpoint_s3_landing" {
  #checkov:skip=CKV_AWS_298: Adding the KMS_key_arn is causing the Task and endpoint to replace every time when we run the plan. Already has the server_side_encryption_kms_key_id. AWS Documenation states the same.
  endpoint_id                 = local.dms_endpoint_tgt_s3_ing_landing
  tags                        = var.tags
  endpoint_type               = "target"
  bucket_name                 = local.lak_lw_raw_s3_bucket
  service_access_role_arn     = local.lw-dms-role-arn
  bucket_folder               = "leasewave"
  data_format                 = "parquet"
  timestamp_column_name       = "dms_tx_commit_Timestamp"
  include_op_for_full_load    = "true"
  date_partition_delimiter    = "none"
  date_partition_enabled      = true
  date_partition_sequence     = "YYYYMMDD"
  cdc_max_batch_interval      = var.cdc_max_batch_interval
  add_column_name             = "true"
  date_partition_timezone     ="US/Mountain"
  server_side_encryption_kms_key_id= aws_kms_key.kms_key_lw_dms.arn
  #kms_key_arn  = aws_kms_key.kms_key_lw_dms.arn  
  encryption_mode              = "SSE_KMS"
}

resource "aws_cloudwatch_log_group" "cloudwatch-log-group" {
  #checkov:skip=CKV_AWS_158:Removing kms to read logs in Splunk
  name              = "dms-tasks-${local.dms_repl_task_lw_sql_s3}"
  retention_in_days = 365
  tags = merge(var.tags, {Splunk = true})
}
# DMS Replication Task to replicate data from Source SQL Server to Datalake landing zone S3 bucket
resource "aws_dms_replication_task" "replication_task" {
  replication_task_id          = local.dms_repl_task_lw_sql_s3
  resource_identifier          = "lw-sqlserver-s3-lake"
  tags                         = var.tags
  source_endpoint_arn          = aws_dms_endpoint.source_endpoint_sql_server_lw_onprem.endpoint_arn
  target_endpoint_arn          = aws_dms_s3_endpoint.Target_endpoint_s3_landing.endpoint_arn
  replication_instance_arn     = aws_dms_replication_instance.dms_replication_instance_lw_sqlserver_onprem.replication_instance_arn
  migration_type               = var.dms_replication_migration_type
  table_mappings               = local.dms_ing_table_mappings
  replication_task_settings    = local.dms-repl-task-settings
}


