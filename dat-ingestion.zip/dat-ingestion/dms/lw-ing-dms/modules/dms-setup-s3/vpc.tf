
resource "aws_iam_role" "dms-vpc-role" {
  name        = "dms-vpc-role"
  description = "Allows DMS to manage VPC"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "dms.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      },
    ]
  })
}

resource "aws_iam_role_policy_attachment" "add-policy-dmsvpcmanagement-dms-vpc-role" {
  role       = aws_iam_role.dms-vpc-role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole"
}


resource "aws_dms_replication_subnet_group" "lw_dms_subnet_group" {
  replication_subnet_group_id          = "${local.dms_lw_subnet_group}"
  replication_subnet_group_description = "Subnets for DMS Replication Instance"
  subnet_ids                           = var.dms_data_app_subnets
  tags=var.tags
  depends_on = [aws_iam_role_policy_attachment.add-policy-dmsvpcmanagement-dms-vpc-role]
}

# Include SQL server ports Ingress and any other ports required for DMS endpoints


resource "aws_security_group" "lw_dms_security_grp" {
  name        = local.dms_lw_security_group
  vpc_id      = data.aws_vpc.selected.id
  description = "Security group for On-prem MS SQL Server"
  tags = var.tags
}

resource "aws_vpc_security_group_ingress_rule" "lw_dms_security_grp_ingress" {
    description      = "DMS Replicatio Instance Ingress"
    for_each = var.lw_onprem_mssqlserver_vpc_cidr_blocks_ingress
    security_group_id = aws_security_group.lw_dms_security_grp.id
    cidr_ipv4   = each.value
    ip_protocol = "-1"
  }

resource "aws_vpc_security_group_egress_rule" "lw_dms_security_grp_egress" {
    description      = "DMS Replicatio Instance egress"
    for_each = var.lw_onprem_mssqlserver_vpc_cidr_blocks_egress
    security_group_id = aws_security_group.lw_dms_security_grp.id
    cidr_ipv4   = each.value
    ip_protocol = "-1"
  }
