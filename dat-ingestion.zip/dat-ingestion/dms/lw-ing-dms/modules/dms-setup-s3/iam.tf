## KMS Key
resource "aws_kms_key" "kms_key_lw_dms" {
  description             = "kms key for DMS"
  deletion_window_in_days = 7
  enable_key_rotation     = true
  key_usage               = "ENCRYPT_DECRYPT"
  policy                  = jsonencode(
{
    "Version": "2012-10-17",
    "Id": "key-consolepolicy-3",
    "Statement": [
        {
            "Sid": "EnableIAMUserPermissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${local.account_id}:root"
            },
            "Action": "kms:*",
            "Resource": "*"
        },

      {
            "Sid": "EnableIAMUserPermissions",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.lake_account_id}:root" 
            },
            "Action": "kms:*",
            "Resource": "*"
        },
        {
            "Sid": "AllowAccessForKeyAdministrators",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-lw-dms-role"
            },
            "Action": [
                "kms:Create*",
                "kms:Describe*",
                "kms:Enable*",
                "kms:List*",
                "kms:Put*",
                "kms:Update*",
                "kms:Revoke*",
                "kms:Disable*",
                "kms:Get*",
                "kms:Delete*",
                "kms:TagResource",
                "kms:UntagResource",
                "kms:ScheduleKeyDeletion",
                "kms:CancelKeyDeletion"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.${local.region_name}.amazonaws.com"
            },
            "Action": [
                "kms:Encrypt",
                "kms:GenerateDataKey",
                "kms:Decrypt"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Principal": {
              "Service": "logs.${local.region_name}.amazonaws.com"
            },
            "Action": [
              "kms:Encrypt*",
              "kms:Decrypt*",
              "kms:ReEncrypt*",
              "kms:GenerateDataKey*",
              "kms:Describe*"
            ],
            "Resource": "*"
        }
    ]
}
  )
}


resource "aws_kms_alias" "kms_key_lw_dms_add_kms_key_alis" {
  name          = var.cust-kms-key-lw-dms
  target_key_id = aws_kms_key.kms_key_lw_dms.key_id
}


#create the secrets to store the LW on prem Sql server Credentials and attach the policy
resource "aws_secretsmanager_secret" "lw_sqlserver_onprem_credentials" {
  #checkov:skip=CKV2_AWS_57: do not rotate this secret
  name        = local.lw-credentails-sqlserver
  description = "Credentails for on-Prem Leasewave Sql Server"
  tags        = var.tags
  kms_key_id   =aws_kms_key.kms_key_lw_dms.arn
}
resource "aws_secretsmanager_secret_policy" "secret_read_policy" {
  secret_arn = aws_secretsmanager_secret.lw_sqlserver_onprem_credentials.arn
  policy     = <<EOF
{
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Principal" : {
      "Service" : "dms.${local.region_name}.amazonaws.com"
    },
    "Action" : "secretsmanager:*",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  }, {
    "Effect" : "Allow",
    "Principal" : {
      "AWS" : "arn:aws:iam::${local.account_id}:role/${local.lw-dms-role}"
    },
    "Action" : "secretsmanager:GetSecretValue",
    "Resource" : "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
  } ]
}
EOF
}





