
variable "resource_prefix" {type        = string}
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "lw_server" {type        = string}
variable "lw_onprem_sqlserver_db" {type        = string}
variable "vpc_name" {type        = string}
variable "dms_data_app_subnets" { type = list}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_ingress" { type = set(string)}
variable "lw_onprem_mssqlserver_vpc_cidr_blocks_egress" { type = set(string)}
variable "dms_lw_allocated_storage" {type        = string}
variable "dms_replication_instance_class" {type        = string}
variable "dms_lw_engine_version" {type        = string}
variable "dms_lw_multi_az" {type        = string}
variable "dms_replication_migration_type" { type = string }
#variable "kms_key_dms_id" { type = string }
#variable "kms_key_secrects_id" { type = string }
variable "environment" { type = string }
variable "cdc_max_batch_interval" { type = string }
variable "ods_consumption_secrets_manager_arn_kms_key_id" { type = string }                           
variable "ods_consumption_secrets_manager_arn_id" { type = string }
variable "consumption_account_id" { type = string }
variable "lake_account_id" { type = string }     
variable "cust-kms-key-lw-dms" { type = string }   
variable "instance_var" { type = string }   
