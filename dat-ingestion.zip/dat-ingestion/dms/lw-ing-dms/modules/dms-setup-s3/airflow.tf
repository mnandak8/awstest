# Upload the Airflow DAG to the Airflow DAG bucket these are start and stop tasks for DMS
resource "aws_s3_object" "leasewave_dags_start_stop_tasks" {
  bucket =  "cobank-dl-${var.lake_account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/ingestion/leasewave/leasewave-start-stop-tasks.py"
  source = "${path.module}/../../src/main/leasewave/airflow/leasewave-start-stop-tasks.py"
  source_hash = filemd5("${path.module}/../../src/main/leasewave/airflow/leasewave-start-stop-tasks.py")
}
