output "dms_lw_src_endpoint_srn" {
  value = aws_dms_endpoint.source_endpoint_sql_server_lw_onprem.endpoint_arn
}

output "dms_repl_inst_arn" {
  value = aws_dms_replication_instance.dms_replication_instance_lw_sqlserver_onprem.replication_instance_arn
}

output "dms_secrects_kms_arn" {
  value = aws_secretsmanager_secret.lw_sqlserver_onprem_credentials.arn
}

output "cust_dms_kms_key_id_arn" {
  value =  aws_kms_key.kms_key_lw_dms.arn
}

output "cust_dms_kms_key_id" {
  value =  aws_kms_key.kms_key_lw_dms.key_id
}

