import sys
import boto3
import json
import pandas as pd
import logging
from datetime import datetime
from awsglue.context import GlueContext
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from pyspark.context import SparkContext

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def format_table_name(table_name):
    parts = table_name.split('.')  
    formatted_name = '.'.join(f'"{part}"' for part in parts)  
    return formatted_name

def get_row_counts(glue_context, connection_type, connection_name, table_names, datalake_path=None):
    row_counts = []
   
    for table in table_names:
        try:
            logger.info(f"Executing query with connection type {connection_type} for table: {table}")
            if connection_type == 's3':
                # Construct S3 path for Parquet files
                s3_path = f"s3://{datalake_path}/{table.replace('.', '/')}/"
                logger.info(f"Landing zone S3 path: {s3_path}")
                
                # Use Spark session to read Parquet files and count rows
                spark = glue_context.spark_session
                df = spark.read.parquet(s3_path)
                row_count = df.count()
                
            else:
                # Format the table name using the simplified approach
                formatted_table_name = format_table_name(table)
                sample_query = f'SELECT count(*) as row_count FROM {formatted_table_name}'
                
                # Use Glue DynamicFrame with sampleQuery to count rows for relational databases
                df = glue_context.create_dynamic_frame.from_options(
                    connection_type=connection_type,
                    connection_options={
                        "useConnectionProperties": "true",
                        "connectionName": connection_name,
                        "dbtable": table,
                        "sampleQuery": sample_query
                    },
                    transformation_ctx="df"
                ).toDF()
                
                # Extract row count from the result DataFrame
                row_count = df.collect()[0]['row_count']
            
            # Append table name and row count as a tuple
            row_counts.append((table, row_count))
            logger.info(f"{connection_type} Table: {table}, Row Count: {row_count}")
        
        except Exception as e:
            logger.error(f"Error getting row count for table {table}: {e}")

    # Create a DataFrame from the list of tuples
    if connection_type == "s3":
        result_df = pd.DataFrame(row_counts, columns=['table_name', 's3_row_count'])
    elif connection_type == "sqlserver":
        result_df = pd.DataFrame(row_counts, columns=['table_name', 'onprem_row_count'])
    else:
        result_df = pd.DataFrame(row_counts, columns=['table_name', 'ods_row_count'])
    
    return result_df

def compare_row_counts(onprem_df, target_df, target_type):
    logger.info(f"Comparing row counts between onprem and {target_type}")
        
    # Define column names based on target type
    if target_type == "ods":
        target_row_count_col = 'ods_row_count'
    elif target_type == "s3":
        target_row_count_col = 's3_row_count'
    else:
        raise ValueError("Invalid target_type. Must be 'ods' or 's3'.")

    # Merge source and target row counts
    comparison_df = pd.merge(onprem_df, target_df, on='table_name', how='outer')
    comparison_df['difference'] = comparison_df['onprem_row_count'] - comparison_df[target_row_count_col]
    return comparison_df

def generate_report(comparison_df, report_prefix, s3_reports_bucket):
    # Add current date to the report filename in YYYY-MM-DD format
    current_date = datetime.now().strftime('%Y-%m-%d')
    s3_output_path = f"s3://{s3_reports_bucket}/reports/leasewave/{report_prefix}_vs_onprem_data_recon_report_{current_date}.csv"
    try:
        logger.info(f"Generating report: {s3_output_path}")
        comparison_df.to_csv(s3_output_path, index=False)
        logger.info("Report generated successfully")
        return comparison_df.to_html()

    except Exception as e:
        logger.error(f"Error generating report: {e}")

def get_table_names_from_config(bucket_name, config_location):
    try:
        # Initialize Boto3 S3 client
        s3_client = boto3.client('s3')
        bucket, key = config_location.replace("s3://", "").split("/", 1)
        logger.info(f"Fetching table names from config file at {config_location}")
        s3_object = s3_client.get_object(Bucket=bucket, Key=key)

        # Read the content of the file and parse it as JSON
        config_data = json.loads(s3_object['Body'].read().decode('utf-8'))

        # Extract schema and table list from the config data
        schema = config_data.get("schema", "dbo")  
        table_list = config_data.get("tables", [])

        # Combine schema with table names
        table_names = [f"{schema}.{table}" for table in table_list]
        
        logger.info(f"Tables fetched from config: {table_names}")
        return table_names

    except Exception as e:
        logger.error(f"Error fetching table names from config file: {e}")
        return []

def main():
    args = getResolvedOptions(sys.argv, ["JOB_NAME",
        'S3_REPORTS_BUCKET', 'ONPREM_CONNECTION_NAME', 'ODS_CONNECTION_NAME', 
         'landingBucket', 'configLocation'
    ])

    sc = SparkContext()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session
    job = Job(glue_context)
    
    job.init(args["JOB_NAME"], args)

    onprem_conn_name = args['ONPREM_CONNECTION_NAME']
    ods_conn_name = args['ODS_CONNECTION_NAME']
    s3_reports_bucket = args['S3_REPORTS_BUCKET']
    landing_zone_bucket = args['landingBucket']
    datalake_path = f'{landing_zone_bucket}/leasewave'
    config_location = args['configLocation']

    # Fetch table names from the configuration file
    table_names = get_table_names_from_config(config_location, config_location)
    if table_names:
        ods_row_counts_df = get_row_counts(glue_context, 'postgresql' , ods_conn_name, table_names)
        logger.info(f"ods row counts tables Dataframe: {ods_row_counts_df}")
        landing_row_counts_df = get_row_counts(glue_context, "s3" , ods_conn_name, table_names, datalake_path)
        logger.info(f"Landing tables Dataframe: {landing_row_counts_df}")
        onprem_row_counts_df = get_row_counts(glue_context, "sqlserver", onprem_conn_name, table_names)
        logger.info(f"Onprem tables Dataframe: {onprem_row_counts_df}")

        # Compare source to target
        ods_comparison_df = compare_row_counts(onprem_row_counts_df, ods_row_counts_df, "ods")
        s3_comparison_df = compare_row_counts(onprem_row_counts_df, landing_row_counts_df, "s3")
        
        generate_report(ods_comparison_df, "ods", s3_reports_bucket)
        generate_report(s3_comparison_df, "s3", s3_reports_bucket)

    else:
        logger.error(f"Error fetching table names from the config file")

    job.commit()

if __name__ == "__main__":
    main()
