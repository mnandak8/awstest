from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.dms import DmsStartTaskOperator, DmsStopTaskOperator
from airflow.utils.dates import days_ago
from datetime import timedelta
from cb_common.utils.common import SNSNotifier
from cb_common.configs_ing import CONFIG
from airflow.models import Variable

# scripts to create dgas for DMS total 8 
sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

acc_num =  CONFIG['ing'][environment]['acc_num']


# Define the list of ARNs
arn_dict ={'lw-sqlserver-rds-consumption':f'arn:aws:dms:us-west-2:{acc_num}:task:lw-sqlserver-rds-consumption',
'lw-sqlserver-s3-lake': f'arn:aws:dms:us-west-2:{acc_num}:task:lw-sqlserver-s3-lake'}
# Default DAG arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': days_ago(1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    # 
}


def create_dag(dag_id, schedule, default_args, arn, operation):
    """Function to create a DAG."""
    dag = DAG(dag_id, default_args=default_args, schedule_interval=schedule, catchup=False, on_failure_callback=[sns_notifier.failure_notification], tags=['DMS'])
    
    with dag:
        start_task = EmptyOperator(
            task_id='Start_Dag',
        )
        
        if operation == 'start':
            dms_task = DmsStartTaskOperator(
                task_id="start_task",
                replication_task_arn=arn,
                aws_conn_id='ing_dms'
            )

        elif operation == 'stop':
            dms_task = DmsStopTaskOperator(
                task_id="stop_task",
                replication_task_arn=arn,
                aws_conn_id='ing_dms'
            )            
        elif operation == 'resume':
            dms_task = DmsStartTaskOperator(
                task_id="Resume_DMS_Job",
                replication_task_arn=arn,
                start_replication_task_type='resume-processing',
                aws_conn_id='ing_dms'

            ) 
        elif operation == 'reload':
            dms_task = DmsStartTaskOperator(
                task_id="Reload_DMS_Job",
                replication_task_arn=arn,
                start_replication_task_type='reload-target',
                aws_conn_id='ing_dms'

            )             
        
        end_task = EmptyOperator(
            task_id='End_Dag',
        )
        
        # Set task dependencies
        start_task >> dms_task >> end_task
        
    return dag

          
# Generate DAGs for each ARN and operation
# for arn in arn_list:
for task, arn in arn_dict.items():
    for operation in ['start', 'stop','reload', 'resume']:
        dag_id = f'dms_{operation}_job_{task}'
        schedule = None  # or any other schedule you prefer
        globals()[dag_id] = create_dag(dag_id, schedule, default_args, arn, operation)
