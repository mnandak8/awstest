from datetime import datetime, timedelta
import boto3
import pandas as pd
import io
import os
import logging
from airflow import DAG

from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.models import Variable
from airflow.utils.dates import days_ago
from cb_common.utils.common import SNSNotifier
from airflow.operators.python_operator import PythonOperator
from cb_common.configs_ing import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')

# Create a logger object
logger = logging.getLogger(__name__)

environment = Variable.get('env_vars',  deserialize_json=True)['environment']

acc_num =  CONFIG['ing'][environment]['acc_num']
# Define constants
GLUE_JOB_NAME = f"leasewave-ods-s3-validation-glue-job-{environment}"
S3_REPORTS_BUCKET = f"cobank-dat-lak-us-west-2-leasewave-raw-{environment}"
S3_REPORT_PREFIX = "reports/leasewave"
S3_REPORTS_PATH = f"s3://{S3_REPORTS_BUCKET}/{S3_REPORT_PREFIX}/"

# Define default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': days_ago(1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

start_date = datetime.today() - timedelta(days=1)
# Initialize the DAG
dag = DAG(
    'dms_data_recon_glue_job_dag', 
    default_args=default_args,
    tags=['DMS'],
    description='A DAG to run Glue job, for reconcialltion daily at 5 AM MST',
    schedule_interval='0 11 * * *',  
    on_failure_callback=[sns_notifier.failure_notification],
    catchup=False,
    default_view='graph'
)

run_glue_job = GlueJobOperator(
    task_id='run_glue_job',
    job_name=GLUE_JOB_NAME,
    aws_conn_id='ing_glue',
    dag=dag,
)

def process_and_send_reports(**kwargs):
     # Publish HTML content to SNS
    sns_notifier.send_notification(
        subject=f'LeaseWave ODS S3 Validation Report - {environment} created in S3',
        message=S3_REPORTS_PATH,
    )
         
           
# Task to process CSV files and send SNS notifications
process_and_send_reports_task = PythonOperator(
    task_id='process_and_send_reports',
    python_callable=process_and_send_reports,
    provide_context=True,
    dag = dag
)

# Define the DAG's task dependencies    
run_glue_job >> process_and_send_reports_task
