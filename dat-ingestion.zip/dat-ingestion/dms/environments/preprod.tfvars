# Account specific values
                        
lw_server="sgnudvlease001"
lw_onprem_sqlserver_db="LeaseWaveAWS"
vpc_name = "DA_PREPROD-vpc"
dms_data_app_subnets=["subnet-0d1b948af0cbc9222","subnet-0a9392aa624b9f8df"]
lw_onprem_mssqlserver_vpc_cidr_blocks_ingress=["10.70.102.0/23"]
lw_onprem_mssqlserver_vpc_cidr_blocks_egress= ["10.70.102.0/23","10.70.100.0/23","10.70.96.0/23","10.64.0.7/32","10.64.0.105/32","10.64.0.121/32","10.64.0.19/32","172.30.110.0/24"]
instance_var="sqlserver"


#
dms_lw_allocated_storage="550"
dms_replication_instance_class="dms.c5.2xlarge"
dms_lw_engine_version="3.5.2"
dms_lw_multi_az="true"
dms_replication_migration_type="full-load-and-cdc"
cdc_max_batch_interval="100"
dms_replication_migration_type_rds="full-load-and-cdc"
ods_consumption_secrets_manager_arn_id = "cobank-dl-rds-user-secret-ods-svclwdms-preprod-JoJIKU"
ods_consumption_secrets_manager_arn_kms_key_id="a26dc229-ca9f-47bd-b85a-66102dc5dd9b"
consumption_account_id="905418043661"
lake_account_id="654654411062"
email_address="mb_clouddataplatformsupport@cobank.com"
cust-kms-key-lw-dms="alias/cust-kms-key-lw-dms"

# leasewave ods s3 validation tfvars
ods_rds_host="cobank-905418043661-rds-proxy-ods-preprod.proxy-cfmu2i8kac4e.us-west-2.rds.amazonaws.com"
ods_rds_db="LeaseWave"

# Rapport Database replication DMS varaibles
replication_instance_arn_for_dms="arn:aws:dms:us-west-2:211125365237:rep:F324OMT5OREPRDEVH6USKG7OYE"
rapport_database_name="Rapport"
