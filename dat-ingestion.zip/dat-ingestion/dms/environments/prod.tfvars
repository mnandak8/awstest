# Account specific values
                        
lw_server="leasewavesqlp"
lw_onprem_sqlserver_db="LeaseWave"
vpc_name = "DA_PROD-vpc"
dms_data_app_subnets=["subnet-0d705e78961cc5c73","subnet-0890e512e8405060a"]
lw_onprem_mssqlserver_vpc_cidr_blocks_ingress=["10.70.128.0/23"]
lw_onprem_mssqlserver_vpc_cidr_blocks_egress=["10.70.128.0/23","10.70.130.0/23","10.70.134.0/23","10.64.0.7/32","10.64.0.105/32","10.64.0.121/32","10.64.0.19/32","172.30.111.0/24"]
instance_var="sqlserver"


#
dms_lw_allocated_storage="550"
dms_replication_instance_class="dms.c5.2xlarge"
dms_lw_engine_version="3.5.2"
dms_lw_multi_az="true"
dms_replication_migration_type="full-load-and-cdc"
cdc_max_batch_interval="100"
dms_replication_migration_type_rds="full-load-and-cdc"
ods_consumption_secrets_manager_arn_id = "cobank-dl-rds-user-secret-ods-svclwdms-prod-OgXoGD"
ods_consumption_secrets_manager_arn_kms_key_id="22d527c5-7477-4d0d-b7a1-7e5d35995e56"
consumption_account_id="767397911309"
lake_account_id="767397798595"
email_address="mb_clouddataplatformsupport@cobank.com"
cust-kms-key-lw-dms="alias/cust-kms-key-lw-dms"

ods_rds_host="cobank-767397911309-rds-proxy-ods-prod.proxy-ctuyq6iok2oi.us-west-2.rds.amazonaws.com"
ods_rds_db="LeaseWave"

# Rapport Database replication DMS varaibles
replication_instance_arn_for_dms="arn:aws:dms:us-west-2:654654446028:rep:YE3IAY5RXFGE7LNW4ZDPSEZZFU"
rapport_database_name="Rapport"
