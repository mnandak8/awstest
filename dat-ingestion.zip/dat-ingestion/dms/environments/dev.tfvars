# Account specific values "10.65.1.0/27"

                                                                                               
lw_server="sgnddvlease001"
lw_onprem_sqlserver_db="LeaseWaveMaskedAWS"
vpc_name = "DA_DEV-vpc"
dms_data_app_subnets=["subnet-0d557d556afa47606","subnet-0637f1d5b52c2502b"]

lw_onprem_mssqlserver_vpc_cidr_blocks_ingress= ["10.70.4.0/25"]
lw_onprem_mssqlserver_vpc_cidr_blocks_egress= ["10.70.4.0/25","10.70.8.0/22","10.70.0.0/23","10.64.0.7/32","10.64.0.105/32","10.64.0.121/32","10.64.0.19/32","172.30.110.0/24"]
instance_var="mssqlserver"
#
dms_lw_allocated_storage="550"
dms_replication_instance_class="dms.c5.2xlarge"
dms_lw_engine_version="3.5.2"
dms_lw_multi_az="false"
dms_replication_migration_type="full-load-and-cdc"
cdc_max_batch_interval="100"
dms_replication_migration_type_rds="full-load-and-cdc"
ods_consumption_secrets_manager_arn_id = "cobank-dl-rds-user-secret-ods-svclwdms-dev-Kny3FP"
ods_consumption_secrets_manager_arn_kms_key_id="14917b18-7662-46b7-9a74-011c3fd4bc79"
consumption_account_id="590184072445"
lake_account_id="654654598303"
email_address="mb_clouddataplatformsupport@cobank.com"
cust-kms-key-lw-dms="alias/cust-kms-key-lw-dms-v3"

# leasewave ods s3 validation tfvars
ods_rds_host="cobank-590184072445-rds-proxy-ods-dev.proxy-c96wwwa2i2gu.us-west-2.rds.amazonaws.com"
ods_rds_db="LeaseWave"


# Rapport Database replication DMS varaibles
replication_instance_arn_for_dms="arn:aws:dms:us-west-2:471112929721:rep:E7RNLZVPVBGA7ITPIYV4OC5KTM"
rapport_database_name="Rapport_Masked"
