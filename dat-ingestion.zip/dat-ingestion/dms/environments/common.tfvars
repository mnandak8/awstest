tags = {
        "cobank:cost-allocation:cost-center" = "8030"
        "cobank:operations:support-group" = "Transformation Programs"
}
resource_prefix = "cobank"

#Rapport SQS variables
sqs_max_message_size            = 262144
##### 14 days = 1209600 seconds 
sqs_message_retention_seconds   = 1209600
sqs_receive_wait_time_seconds   = 20
sqs_kms_data_key_reuse_period_seconds = 300
sqs_delay_seconds              = 90
sqs_visibility_timeout_seconds = 60