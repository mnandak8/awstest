lw_server="sgntdvlease001"
lw_onprem_sqlserver_db="LeaseWaveMaskedAWS"
vpc_name = "DA_TEST-vpc"
dms_data_app_subnets=["subnet-05a5aaec8c60325fe","subnet-0c1d8d0fe4657a2df"]
lw_onprem_mssqlserver_vpc_cidr_blocks_ingress=["10.70.40.0/22"]
lw_onprem_mssqlserver_vpc_cidr_blocks_egress= ["10.70.40.0/22","10.70.32.0/22","10.70.38.0/23","10.64.0.7/32","10.64.0.105/32","10.64.0.121/32","10.64.0.19/32","172.30.110.0/24"]
instance_var="mssqlserver"
#
dms_lw_allocated_storage="550"
dms_replication_instance_class="dms.c5.2xlarge"
dms_lw_engine_version="3.5.2"
dms_lw_multi_az="false"
dms_replication_migration_type="full-load-and-cdc"
cdc_max_batch_interval="100"
dms_replication_migration_type_rds="full-load-and-cdc"
ods_consumption_secrets_manager_arn_id = "cobank-dl-rds-user-secret-ods-svclwdms-test-sSWL3A"
ods_consumption_secrets_manager_arn_kms_key_id="1e8acf12-0ed7-460e-8509-abaef4e8108e"
consumption_account_id="905418335811"
lake_account_id="767398005888"
email_address="mb_clouddataplatformsupport@cobank.com"
cust-kms-key-lw-dms="alias/cust-kms-key-lw-dms"

# leasewave ods s3 validation tfvars
ods_rds_host="cobank-905418335811-rds-proxy-ods-test.proxy-cxeo0ycaorz4.us-west-2.rds.amazonaws.com"
ods_rds_db="LeaseWave"

# Rapport Database replication DMS varaibles
replication_instance_arn_for_dms="arn:aws:dms:us-west-2:533267072724:rep:D3I2FVORAJEORK3MZXZAESYBM4"
rapport_database_name="Rapport_Masked"
