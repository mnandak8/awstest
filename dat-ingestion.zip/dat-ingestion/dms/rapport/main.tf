 module "dms-s3" { 
   source                                = "./modules/dms-s3-sqs"
   tags                                  = var.tags
   environment                           = var.environment
   terra_factory_aws_id                  = var.terra_factory_aws_id
   replication_instance_arn_for_dms      = var.replication_instance_arn_for_dms
   sqs_max_message_size                  = var.sqs_max_message_size
   sqs_message_retention_seconds         = var.sqs_message_retention_seconds
   sqs_receive_wait_time_seconds         = var.sqs_receive_wait_time_seconds
   sqs_kms_data_key_reuse_period_seconds = var.sqs_kms_data_key_reuse_period_seconds
   sqs_delay_seconds                     = var.sqs_delay_seconds
   sqs_visibility_timeout_seconds        = var.sqs_visibility_timeout_seconds
   rapport_database_name                 = var.rapport_database_name
 }

