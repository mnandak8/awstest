variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "environment" { type = string }

variable "terra_factory_aws_id" {
  type        = string
  description = "Name of the aws account."
}

variable "replication_instance_arn_for_dms" {
  type        = string
}

variable "sqs_max_message_size" { 
   type = number 
}
variable "sqs_message_retention_seconds" { 
   type = number 
}
variable "sqs_receive_wait_time_seconds" { 
   type = number 
}
variable "sqs_kms_data_key_reuse_period_seconds" { 
   type = number 
}
variable "sqs_delay_seconds" { 
   type = number 
}
variable "sqs_visibility_timeout_seconds" { 
   type = number 
}

variable "rapport_database_name" {
  type        = string
}