
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  account_id                                = data.aws_caller_identity.current.account_id
  region_name                               = data.aws_region.current.name
  rapport-sqlserver-certs                   = file("${path.module}/cert-${var.environment}-rapport-sqlserveronprem.pem")
  rapport-credentials-sqlserver             = "dms-rapport-${var.environment}-credentials-sqlserver-onprem"
  rapport-dms-role                          = "cobank-${var.environment}-rapport-dms"
  rapport-dms-secret-policy                 = "cobank-${var.environment}-rapport-dms-secret-policy"
  rapport-sqs-queue                         = "cobank-${var.environment}-rapport-sqs-s3-event-notification-queue"
  rapport-sqs-dead-letter-queue             = "cobank-${var.environment}-rapport-sqs-dead-letter-queue"
  logging_bucket_name                       = "cobank-dl-${local.account_id}-${local.region_name}-logs-${var.environment}"
  dms_repl_task_id_rapport_sql_to_s3        = "rapport-${var.environment}-${var.terra_factory_aws_id}-rpt-co-and-con-setup-s3"
  dms_task_table_mappings_rapport_sql_to_s3 = file("${path.module}/task_config/table_mappings_rpt_co_and_con_setup.json")
  dms_task_settings_rapport_sql_to_s3       = jsonencode(jsondecode(file("${path.module}/task_config/task_setting_rpt_co_and_con_setup.json")))
  dms_src_rapport_endpoint                  = "cobank-${var.environment}-${local.account_id}-src-mssqlserver-rapport-onprem"
  dms_tgt_rapport_endpoint_s3_id            = "cobank-${var.environment}-${local.account_id}-tgt-rapport-s3"

}

resource "aws_dms_certificate" "rapport-sqlserver-certs" {
  certificate_id   = "rapport-sqlserver-certs"
  certificate_pem  = local.rapport-sqlserver-certs
  tags             = var.tags
}

resource "aws_secretsmanager_secret" "dms-rapport-sqlserver-on-prem-credentials" {
  name        = local.rapport-credentials-sqlserver 
  description = "rapport SQL Server connection string"
  tags        = var.tags
}


resource "aws_iam_policy" "dms-rapport-secret-read-policy" {
  name        = local.rapport-dms-secret-policy
  description = "Rapport policy to allow DMS to access secret values"
  policy      = <<EOF
{
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Action" : [
          "secretsmanager:GetSecretValue"
        ],
    "Resource" : "arn:aws:secretsmanager:${local.region_name}:${local.account_id}:secret*"
  } ]
}
EOF
}

resource "aws_iam_role" "create_role_rapport_dms" {
  name               = local.rapport-dms-role 
  tags               = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "",
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.${local.region_name}.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

# adding the roles: S3 full Access
resource "aws_iam_role_policy_attachment" "role_policy_attachment_s3_role_rapport_dms" {
  role       = aws_iam_role.create_role_rapport_dms.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}

# adding the roles: KMS full access
resource "aws_iam_role_policy_attachment" "role-policy-attachment_kms_role_rapport_dms" {
  role       = aws_iam_role.create_role_rapport_dms.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

# AmazonDMSCloudWatchLogsRole
resource "aws_iam_role_policy_attachment" "role_policy_attachment_cloudwatch_role_rapport_dms" {
  role       = aws_iam_role.create_role_rapport_dms.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_dmsvpcmanagment_role_rapport_dms" {
  role       = aws_iam_role.create_role_rapport_dms.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_secrets_role_rapport_dms" {
  role       = aws_iam_role.create_role_rapport_dms.name
  policy_arn = aws_iam_policy.dms-rapport-secret-read-policy.arn
}

module "rapport_bucket" {
  #source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=main"
  source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241127.63"
  environment               = var.environment
  resource_suffix           = "rapport-asset"
  lake_type                 = "dl"
  terra_factory_aws_id      = var.terra_factory_aws_id
  expiration_days           = 2555
  ia_transition_days        = 365
  log_bucket_name           = local.logging_bucket_name
}

resource "aws_dms_endpoint" "source_endpoint_sql_server_rapport_onprem" {
  ssl_mode                        = "verify-full"
  certificate_arn                 = aws_dms_certificate.rapport-sqlserver-certs.certificate_arn
  endpoint_id                     = local.dms_src_rapport_endpoint
  tags                            = var.tags
  endpoint_type                   = "source"
  secrets_manager_arn             = aws_secretsmanager_secret.dms-rapport-sqlserver-on-prem-credentials.arn
  kms_key_arn                     = module.kms_rapport_dms_to_s3.key_arn
  engine_name                     = "sqlserver"
  #service_access_role             = aws_iam_role.create_role_rapport_dms.arn
  database_name                   = var.rapport_database_name
  secrets_manager_access_role_arn = aws_iam_role.create_role_rapport_dms.arn
  extra_connection_attributes     = "EnableNonSysadminWrapper=true;SetUpMsCdcForTables=false;connectionTimeout=60;executeTimeout=120"
}

resource "aws_dms_s3_endpoint" "target_endpoint_s3_rpt_co_and_con_setup" {
  #checkov:skip=CKV_AWS_298: Adding the KMS_key_arn is causing the Task and endpoint to replace every time when we run the plan. Already has the server_side_encryption_kms_key_id. AWS Documenation states the same.
  endpoint_id                       = local.dms_tgt_rapport_endpoint_s3_id
  tags                              = var.tags
  endpoint_type                     = "target"
  bucket_name                       = module.rapport_bucket.bucket_name
  service_access_role_arn           = aws_iam_role.create_role_rapport_dms.arn
  bucket_folder                     = "rapport"
  data_format                       = "csv"
  csv_row_delimiter                 = "\n"
  timestamp_column_name             = "dms_timestamp"
  cdc_inserts_and_updates           = "false"
  date_partition_enabled            = "false"
  add_column_name                   = "true"
  server_side_encryption_kms_key_id = module.kms_rapport_dms_to_s3.key_arn
  #kms_key_arn                      = aws_kms_key.kms_key_lw_dms.arn  
  encryption_mode                   = "SSE_KMS"
}

resource "aws_dms_replication_task" "replication_task" {
  replication_task_id          = local.dms_repl_task_id_rapport_sql_to_s3
  resource_identifier          = "rapport-sqlserver-s3"
  tags                         = var.tags
  source_endpoint_arn          = aws_dms_endpoint.source_endpoint_sql_server_rapport_onprem.endpoint_arn
  target_endpoint_arn          = aws_dms_s3_endpoint.target_endpoint_s3_rpt_co_and_con_setup.endpoint_arn
  replication_instance_arn     = var.replication_instance_arn_for_dms
  migration_type               = "cdc"
  table_mappings               = local.dms_task_table_mappings_rapport_sql_to_s3
  replication_task_settings    = local.dms_task_settings_rapport_sql_to_s3
}

module "kms_rapport_dms_to_s3" {
  source                     = "git::https://github.com/cobank-acb/dat-terraform-modules.git//kms?ref=v20241127.63"
  #source                     = "git::https://github.com/cobank-acb/dat-terraform-modules.git//kms?ref=main"
  environment                = var.environment
  resource_suffix            = "rapport"
  encrypt_service_user_names = ["dms.us-west-2","logs","s3","lambda"]
  decrypt_role_arns          = [aws_iam_role.create_role_rapport_dms.arn]
}

# trivy:ignore:AVD-AWS-0096: KMS key is added through the module, manually checked. checkov would need to be refactored to correctly see the kms encryption key
resource "aws_sqs_queue" "rapport_queue" {
  name                              = local.rapport-sqs-queue
  delay_seconds                     = var.sqs_delay_seconds
  max_message_size                  = var.sqs_max_message_size
  message_retention_seconds         = var.sqs_message_retention_seconds
  receive_wait_time_seconds         = var.sqs_receive_wait_time_seconds
  tags                              = var.tags
  kms_master_key_id                 = module.kms_rapport_dms_to_s3.key_arn
  kms_data_key_reuse_period_seconds = var.sqs_kms_data_key_reuse_period_seconds
  visibility_timeout_seconds        = var.sqs_visibility_timeout_seconds


  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.rapport_dead_letter_queue.arn
    maxReceiveCount     = 5
  })

  policy = <<POLICY
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "s3.amazonaws.com"
      },
      "Action": "sqs:SendMessage",
      "Resource": "arn:aws:sqs:*:*:${local.rapport-sqs-queue}",
      "Condition": {
        "ArnEquals": {"aws:SourceArn": "${module.rapport_bucket.bucket_arn}"}

      }
    }
  ]
}
POLICY
}

resource "aws_s3_bucket_notification" "rapport_s3_bucket_notification" {
  bucket = module.rapport_bucket.bucket_name

  queue {
    queue_arn       = aws_sqs_queue.rapport_queue.arn
    events          = ["s3:ObjectCreated:Put"]
    filter_suffix   = ".csv"
      filter_prefix = "rapport/dbo/CONTRACT_SETUP/"
  }

  queue {
    queue_arn     = aws_sqs_queue.rapport_queue.arn
    events        = ["s3:ObjectCreated:Put"]
    filter_suffix = ".csv"
    filter_prefix = "rapport/dbo/RPT_CO/"
  }
}

# trivy:ignore:AVD-AWS-0096: KMS key is added through the module, manually checked. checkov would need to be refactored to correctly see the kms encryption key
resource "aws_sqs_queue" "rapport_dead_letter_queue" {
  name                              = local.rapport-sqs-dead-letter-queue
  delay_seconds                     = var.sqs_delay_seconds
  max_message_size                  = var.sqs_max_message_size
  message_retention_seconds         = var.sqs_message_retention_seconds
  receive_wait_time_seconds         = var.sqs_receive_wait_time_seconds
  tags                              = var.tags
  kms_master_key_id                 = module.kms_rapport_dms_to_s3.key_arn
  kms_data_key_reuse_period_seconds = var.sqs_kms_data_key_reuse_period_seconds
}

resource "aws_sqs_queue_policy" "rapport_dead_letter_queue_policy" {
  queue_url = aws_sqs_queue.rapport_dead_letter_queue.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action    = "sqs:SendMessage"
        Effect    = "Allow"
        Resource  = aws_sqs_queue.rapport_dead_letter_queue.arn
        Principal = "*"
      }
    ]
  })
}

resource "aws_sqs_queue_redrive_allow_policy" "rapport_queue_redrive_allow_policy" {
  queue_url = aws_sqs_queue.rapport_dead_letter_queue.id

  redrive_allow_policy = jsonencode({
    redrivePermission  = "byQueue",
    sourceQueueArns    = [aws_sqs_queue.rapport_queue.arn]
  })
}
