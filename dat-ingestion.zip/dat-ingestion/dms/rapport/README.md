# Rapport DMS 

Data Migration Service, used to replicate the Rapport on-prem SQL Server data to S3 and on to Treasury Connect.
The Lambda and API's are in application/src/main/transfer-pricing.


- [Replication-Instance](#Replication-Instance)
- [Security](#Security)
- [IAM](#IAM)
- [Secrets](#Secrets)
- [End-Points](#End-Points)
- [Replication-Task-S3](#Replication-Task-S3)
- [S3-Event-to-SQS-to-Lambda](#S3-Event-to-SQS-to-Lambda)
- [API](#API)

  
[Lucid Chart:](https://lucid.app/lucidchart/c9fa81f4-9b69-4010-815c-a96332ab81aa/edit?invitationId=inv_0b817d8e-f964-4542-afaf-309faa3910f2&page=0_0#)
 
![RapportDMS](https://github.com/user-attachments/assets/2c3d1f97-5781-4d3b-a775-7f31360c52ac)


# Replication-Instance
    

  AWS DMS creates it on an Amazon EC2 instance in a virtual private cloud (VPC) based on the Amazon VPC service. 
  -	cobank-${environment}-${aws_ing_account_id}-mssqlserver-lw-onprem-${lw_sqlserver_host}
  -	The DMS instance was originally setup for LeaseWave data, hence the name.  Rapport uses the same DMS instance.
  
    


# Security

[Inbound and OutBound Security Groups](https://projects.insidecobank.com/PRJ0047911/Project%20Team%20Working%20Documents/Technical%20Documents/LWDMS/LWDMS%20Security%20Grp%20Rules.xlsx?d=w4d31973c5c934b128b4f171de8cdad30)

# IAM

cobank-dev-rapport-dms 
-	AmazonDMSCloudWatchLogsRole
-	AmazonDMSVPCManagementRole             
-	AmazonS3FullAccess                                   
-	cobank-dev-rapport-dms-secret-policy
-	KMSFullAccess

dms-s3-access-rapport-dev-role                        
-	rapport-secret
-	test-s3-example-s3-sv-tgt

    	

# Secrets
	
1.	dms-rapport-dev-credentails-sqlserver-onprem : Secrects for the Rapport on-prem Credentials. The entries have to be added manually to the Secrects, it exists in Ingestion Account.
2.	transfer_pricing_api_secret


# End-Points
**cobank-dev-${aws_ing_account_id}-src-mssqlserver-rapport-onprem** --> Connects to Rapport on-prem SQL Server database

Settings
| Option | Value |
| --- | --- |
|End Point Type|Source |
|Secret ID | dms-rapport-dev-credentials-sqlserver-onprem |
|Database name | RapportMasked |
|Extra connection attributes |EnableNonSysadminWrapper=true;SetUpMsCdcForTables= false|


**cobank-dev-${aws_ing_account_id}-tgt-rapport-s3** --> Connects to S3 on Ingestion Account. 

Settings
| Option | Value |
| --- | --- |
|End Point Type|Target|
|bucketFolder|rapport|
|bucketName|dev-acb-dl-dat-ing-rapport-asset|
|datePartitionDelimiter|NONE |
|datePartitionEnabled|true |
|datePartitionSequence|YYYYMMDD |
|datePartitionTimezone|US/Mountain |
|CdcMaxBatchInterval|100 |
|TimestampColumnName|dms_tx_commit_Timestamp |
|IncludeOpForFullLoad|false |
|DataFormat|csv |



# Replication-Task-S3
**rapport-dev-dat-ing-rpt-co-and-con-setup-s3**   --> This tasks replicates the data from Rapport to S3 on Ingestion Account

-	**End-Points**
	```
		Source:  cobank-dev-${aws_ing_account_id}-src-mssqlserver-rapport-onprem
		Target:  cobank-dev-${aws_ing_account_id}-tgt-rapport-s3
 	```
**Mapping Rules**

SelectionRules

| Schema | Table | Value |
| --- | --- | --- |
| dbo | RPT_CO | Include |
| dbo | CONTRACT_SETUP | Include |

TransformationRules

| Schema | Table | Column | Value |
| --- | --- | --- | --- |
| dbo | RPT_CO | CO_UD_APP_STATUS | Include |
| dbo | RPT_CO | SETUP_FKEY | Include |
| dbo | CONTRACT_SETUP | CTS_DECISION_CODE_FKEY | Include |
| dbo | CONTRACT_SETUP | CTS_CONTRACT_SETUP_KEY | Include |

Filters

| Criteria | Value |
| --- | --- |
| CTS_DECISION_CODE_FKEY = 7 |Include|

   		
MetadataColumns

| Option | Value |
| --- | --- |
|Column|Use |
|dms_tx_commit_timestamp|Commit timestamp on source|
|OP|INSERT UPDATE|


-	**Configuration**
  
| Option | Value | Notes |
| --- | --- | --- |
|TargetTablePrepMode|TRUNCATE_BEFORE_LOAD|when we do a Restart, if exist delete files else create new files|
|MaxFullLoadSubTasks|15|Threads Parallel Loads|
|MaxFullLoadSubTasks|15|Threads Parallel Loads|

# S3-Event-to-SQS-to-Lambda
There are 2 events setup on the bucket to send event to SQS - one for each table. SQS event is then used to trigger Lambda

| S3 Event | SQS | Lammbda
| --- | --- | ---|
| tf-s3-queue-{abc}  |  cobank-{env}-rapport-sqs-s3-event-notification-queue | cobank-dl-lambda-function-transfer-pricing-{env} |
| tf-s3-queue-{xyz}  |  cobank-{env}-rapport-sqs-s3-event-notification-queue | cobank-dl-lambda-function-transfer-pricing-{env} |

The Lambda has logic to look at the Before Image from replication task to determine if it should proceed with sending data to Treasury Connect.

# API
Once the Lambda is triggered, it gets the payload/key from S3.  For CONTRACT_SETUP.cts_decision_code_fkey, delete records are ignored, and criteria is if insert/update before image is not 7 and current is.  For RPT_CO.co_ud_app_status, it compares the delete and insert records for key (should be one pair per key) and determines if delete is not 5 and insert is, OR if delete is not 27 and insert is.  If either criteria is met, then it makes 2 API calls.  One to Rapport and one to LeaseWave, using the payload key.
It formulates the data and makes one more API call to Treasury Connect.
If Treasury Connect gets more than 1 API call per per key, then it will fail.



