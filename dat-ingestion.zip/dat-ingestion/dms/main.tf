#############################################################################
## This is the main for the Terrafactory root "application/dms/iw-ing-dms"
#############################################################################
############################################################################ 
# The module  lwdms creaates the                                           
#        Replication Instance
#        Src End point ( On prem), 
#        Tgt end Point to the S3
#        Task to Migrate the Data from LW on prem to S3. 
#        Also Creates the Necessary
#        Roles, Secrects , Permissions to the Secrets. 
############################################################################
############################################################################ 
# The module  lwdms-rds creaates the                                           
#        Tgt end Point to the Consumption RDS
#        Task to Migrate the Data from LW on prem to RDS.
#        Also Creates the Necessary
#        Roles, Secrects , Permissions to the Secrets. 
############################################################################



data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
}

 module "lwdms" { 
   source                            = "./lw-ing-dms/modules/dms-setup-s3"
   tags                              = var.tags
   environment                       = var.environment
   resource_prefix                   = var.resource_prefix
   lw_server                         = var.lw_server
   vpc_name                          = var.vpc_name
   lw_onprem_sqlserver_db            = var.lw_onprem_sqlserver_db
   dms_data_app_subnets              = var.dms_data_app_subnets
   lw_onprem_mssqlserver_vpc_cidr_blocks_ingress=var.lw_onprem_mssqlserver_vpc_cidr_blocks_ingress
   lw_onprem_mssqlserver_vpc_cidr_blocks_egress=var.lw_onprem_mssqlserver_vpc_cidr_blocks_egress
   dms_lw_allocated_storage          = var.dms_lw_allocated_storage
   dms_replication_instance_class    = var.dms_replication_instance_class
   dms_lw_engine_version             = var.dms_lw_engine_version
   dms_lw_multi_az                   = var.dms_lw_multi_az
   dms_replication_migration_type    = var.dms_replication_migration_type
   cdc_max_batch_interval            = var.cdc_max_batch_interval
   ods_consumption_secrets_manager_arn_kms_key_id = var.ods_consumption_secrets_manager_arn_kms_key_id                          
   ods_consumption_secrets_manager_arn_id =var.ods_consumption_secrets_manager_arn_id
   consumption_account_id            =var.consumption_account_id
   lake_account_id                   =var.lake_account_id  
   cust-kms-key-lw-dms               = var.cust-kms-key-lw-dms 
   instance_var                      = var.instance_var
 }
 
 module "lwdms-rds" { 
   source                      = "./lw-ing-dms/modules/dms-setup-rds-consumption"
   tags                        = var.tags
   environment                 = var.environment
   resource_prefix             = var.resource_prefix
   #kms_key_dms_id              = var.kms_key_dms_id
   cust_dms_kms_key_id_arn     = module.lwdms.cust_dms_kms_key_id_arn
   cust_dms_kms_key_id         = module.lwdms.cust_dms_kms_key_id   
   dms_lw_src_endpoint_srn     = module.lwdms.dms_lw_src_endpoint_srn
   dms_repl_inst_arn           = module.lwdms.dms_repl_inst_arn
   dms_secrects_kms_arn        = module.lwdms.dms_secrects_kms_arn
   dms_replication_migration_type_rds=var.dms_replication_migration_type_rds
   ods_consumption_secrets_manager_arn_id =var.ods_consumption_secrets_manager_arn_id
   consumption_account_id=var.consumption_account_id
   email_address                     =var.email_address  
 }


module "onprem_ods_data_recon_glue_job" {
  source = "./lw-ing-dms/modules/dms-ods-data-recon"
  vpc_name                  = var.vpc_name
  lake_account_id           = var.lake_account_id
  ods_account_id            = var.consumption_account_id
  ods_rds_secrets_name      = var.ods_consumption_secrets_manager_arn_id
  ods_rds_host              = var.ods_rds_host
  environment               = var.environment
  ods_rds_db                = var.ods_rds_db
  lw_onprem_mssqlserver_vpc_cidr_blocks_ingress=var.lw_onprem_mssqlserver_vpc_cidr_blocks_ingress
  lw_onprem_mssqlserver_vpc_cidr_blocks_egress=var.lw_onprem_mssqlserver_vpc_cidr_blocks_egress
  
}

module "rapport" { 
   source                                = "./rapport"
   tags                                  = var.tags
   environment                           = var.environment
   terra_factory_aws_id                  = var.terra_factory_aws_id
   replication_instance_arn_for_dms      = var.replication_instance_arn_for_dms
   sqs_max_message_size                  = var.sqs_max_message_size
   sqs_message_retention_seconds         = var.sqs_message_retention_seconds
   sqs_receive_wait_time_seconds         = var.sqs_receive_wait_time_seconds
   sqs_kms_data_key_reuse_period_seconds = var.sqs_kms_data_key_reuse_period_seconds
   sqs_delay_seconds                     = var.sqs_delay_seconds
   sqs_visibility_timeout_seconds        = var.sqs_visibility_timeout_seconds
   rapport_database_name                 = var.rapport_database_name
}
