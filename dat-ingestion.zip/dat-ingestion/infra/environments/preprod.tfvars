# Account specific values
resource_prefix = "cobank"

#S3 policy variables
dat_lake_acct_id = "654654411062"

#RDS specific values
aurora_engine         = "aurora-postgresql"
aurora_engine_version = "15.5"
instance_class        = "db.r5.2xlarge"
database_name         = "acbsdb"
master_username       = "mstrrdsauadbpp"
identifier            = "acbs-db"
vpc_id                = "vpc-0944e72839a713329"
subnets               = ["subnet-0a9392aa624b9f8df", "subnet-07ebc2f41826bd19f"]

db_subnet_group_name            = "acbs-subnet-group"
final_snapshot_identifier       = "acbs-final-snapshot"
db_cluster_parameter_group_name = "acbs-cluster-parameter-group"
db_parameter_group_name         = "acbs-instance-parameter-group"
kms_key_id                      = "arn:aws:kms:us-west-2:832576047628:key/d80ddc81-162a-488c-b9e1-b401d8ee35f7"
# vpc_cidr_blocks                 = ["10.70.102.0/25", "0.0.0.0/0"]
vpc_cidr_blocks = [
  "172.30.114.0/24",
  "10.70.102.0/23"
]

#RDS secret
secret_svc_acct_glue_name = "RDSpreprodACBSDB-ETL"

#appflow
secret_sfdc_clientid_and_Key = "appflow-connector-salesforce-clientId-and-clientSecret"
Consumer_Key                 = "3MVG9mtnSJLqdj7CM.JDNqyYPUv.3m2IbkCvUc7N.2d8rU_l7eOIOFPhoCihSs7hzuZK.bgJNsxAkWJRIm41L"
Consumer_Secret              = "6617C4D598ACB038C981B187BCFF969088EF2BCFE3DC76104D145957BFB097E9"
sfdc_instance_url            = "https://cobank--uat.sandbox.my.salesforce.com"
sfdc_redirect_url            = "https://us-west-2.console.aws.amazon.com/appflow/oauth"
###Authcode Expires every 5 min generate before running the creation
auth_code  = "aPrx_3QDsVo5Q26V2HvMt0KyUAlc2rKolYJgZN4VDuy5kBIzAXHjGA8LPxZ6RbZ_n9rrPJu0oQ%3D%3D"
is_sandbox = "true"

connection_secret_arn    = "arn:aws:secretsmanager:us-west-2:905418043661:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-preprod-JoJIKU"
consumption_rds_endpoint = "cobank-905418043661-rds-proxy-ods-preprod.proxy-cfmu2i8kac4e.us-west-2.rds.amazonaws.com"

glue_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2:211125365237:secret:RDSpreprodACBSDB-ETL-eRzcW1",
  "arn:aws:secretsmanager:us-west-2:211125365237:secret:rds!cluster-628d91db-6712-42e4-86d4-968e6c347fd1-ngvyYo",
  "arn:aws:secretsmanager:us-west-2:905418043661:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-preprod-JoJIKU",
  "arn:aws:secretsmanager:us-west-2:905418043661:secret:cobank-dl-rds-user-secret-ods-svcodsdeploy-preprod-kXaQnI"
]

appflow_secret_access_arn = [
  "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
]

lambda_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2::secret:GetARN"
]

acbs_landing_outside_principals = [
  "arn:aws:iam::730335504053:role/transfer-user-access-role-svcawssftp",
  "arn:aws:iam::654654411062:role/cobank-preprod-lambda-role",
  "arn:aws:iam::654654411062:role/cobank-preprod-glue-role",
  "arn:aws:iam::654654411062:role/cobank-preprod-airflow-environment"
]

#IAMRolesAnywhere for DMS tasks
role_name         = "IAMRolesAnywhereDMSRole"
dms_profile_name      = "IAMRolesanywhereDMSProfile"
trust_anchor_name = "IAMRolesAnywhereDMSTrustAnchor"
dms_policy_name       = "IAMRolesAnywhereDMSManagementPolicy"
certificate_path  = "credentials/cobank-ca-iamrolesanywhere.crt"