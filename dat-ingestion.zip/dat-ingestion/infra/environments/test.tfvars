# Account specific values
resource_prefix = "cobank"

#S3 policy variables
dat_lake_acct_id = "767398005888"

#RDS specific values
aurora_engine         = "aurora-postgresql"
aurora_engine_version = "15.5"
instance_class        = "db.r5.2xlarge"
database_name         = "acbsdb"
master_username       = "mstrrdsauadbt"
identifier            = "acbs-db"
vpc_id                = "vpc-0effe3e07862a80c0"
subnets               = ["subnet-08ded96adee69a1cd", "subnet-05a5aaec8c60325fe"]

db_subnet_group_name            = "acbs-subnet-group"
final_snapshot_identifier       = "acbs-final-snapshot"
db_cluster_parameter_group_name = "acbs-cluster-parameter-group"
db_parameter_group_name         = "acbs-instance-parameter-group"
kms_key_id                      = "arn:aws:kms:us-west-2:832576047628:key/d80ddc81-162a-488c-b9e1-b401d8ee35f7"
vpc_cidr_blocks = [
  "10.70.40.0/22",
  "172.26.80.0/24",
  "172.30.114.0/24",
  "172.30.140.0/22",
  "172.30.160.0/20",
  "172.26.16.0/20"
]

#RDS secret
secret_svc_acct_glue_name = "RDStestACBSDB-ETL"

#appflow
secret_sfdc_clientid_and_Key = "appflow-connector-salesforce-clientId-and-clientSecret"
Consumer_Key                 = "3MVG9qG3qyJ7I8u3zxZxSxX3RFHqVNMF5qfl.dPqbRfdyatXg6h3_vEPXT2IglozitehdOkf1yi6dfd4pSy9."
Consumer_Secret              = "A3D610C0DEF5077A5ACE9D2A7A2A172783796EC60A3A6EF187E98EE2D8883BD5"
sfdc_instance_url            = "https://cobank--qa.sandbox.my.salesforce.com"
sfdc_redirect_url            = "https://us-west-2.console.aws.amazon.com/appflow/oauth"
###Authcode Expires every 5 min generate before running the creation
auth_code  = "aPrxyotxUqfB2Zt6YEZ8eDbphaBVs9WeFa_W15bWp2V7QgY0GQmCwfQU5Lvwzegbz8CmDNjz3A%3D%3D"
is_sandbox = "true"

connection_secret_arn    = "arn:aws:secretsmanager:us-west-2:905418335811:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-test-blyihK"
consumption_rds_endpoint = "cobank-905418335811-rds-proxy-ods-test.proxy-cxeo0ycaorz4.us-west-2.rds.amazonaws.com"

glue_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2:533267072724:secret:RDStestACBSDB-ETL-dw1k1q",
  "arn:aws:secretsmanager:us-west-2:533267072724:secret:rds!cluster-955081b1-b984-437f-8a0a-7ece1ab61797-CAIXI2",
  "arn:aws:secretsmanager:us-west-2:905418335811:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-test-blyihK",
  "arn:aws:secretsmanager:us-west-2:905418335811:secret:cobank-dl-rds-user-secret-ods-svcodsdeploy-test-4oUVYL"
]

appflow_secret_access_arn = [
  "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
]

lambda_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2::secret:GetARN"
]

acbs_landing_outside_principals = [
  "arn:aws:iam::992382374688:role/transfer-user-access-role-svcawssftp",
  "arn:aws:iam::767398005888:role/cobank-test-lambda-role",
  "arn:aws:iam::767398005888:role/cobank-test-glue-role",
  "arn:aws:iam::767398005888:role/cobank-test-airflow-environment"
]

#IAMRolesAnywhere for DMS tasks
role_name         = "IAMRolesAnywhereDMSRole"
dms_profile_name      = "IAMRolesanywhereDMSProfile"
trust_anchor_name = "IAMRolesAnywhereDMSTrustAnchor"
dms_policy_name       = "IAMRolesAnywhereDMSManagementPolicy"
certificate_path  = "credentials/cobank-ca-iamrolesanywhere.crt"