# Account specific values
resource_prefix = "cobank"

#S3 policy variables
dat_lake_acct_id = "767397798595"

#RDS specific values
aurora_engine         = "aurora-postgresql"
aurora_engine_version = "15.5"
instance_class        = "db.r5.2xlarge"
database_name         = "acbsdb"
master_username       = "mstrrdsauadbp"
identifier            = "acbs-db"
vpc_id                = "vpc-0ad64f45f24cbadbd"
subnets               = ["subnet-0890e512e8405060a", "subnet-0d705e78961cc5c73"]

db_subnet_group_name            = "acbs-subnet-group"
final_snapshot_identifier       = "acbs-final-snapshot"
db_cluster_parameter_group_name = "acbs-cluster-parameter-group"
db_parameter_group_name         = "acbs-instance-parameter-group"
kms_key_id                      = "arn:aws:kms:us-west-2:832576047628:key/d80ddc81-162a-488c-b9e1-b401d8ee35f7"
vpc_cidr_blocks = [
  "10.70.128.0/23",
  "172.30.122.0/24"
]

#RDS secret
secret_svc_acct_glue_name = "RDSprodACBSDB-ETL"


#appflow
secret_sfdc_clientid_and_Key = "appflow-connector-salesforce-clientId-and-clientSecret"
Consumer_Key                 = "3MVG9zlTNB8o8BA1Qwon8BwREobZyc3jaFm_WhTcV__RTeNcuQxZ3LQZl3_cn364rb8UjLBn_skHp_.SElSAT"
Consumer_Secret              = "632AD1E9F4553885AF392C2A3232F85C764DCB1786E052AFD3937C051EA7FF14"
sfdc_instance_url            = "https://cobank.my.salesforce.com"
sfdc_redirect_url            = "https://us-west-2.console.aws.amazon.com/appflow/oauth"
###Authcode Expires every 5 min generate before running the creation
auth_code  = "aPrxtfAlIdiLb5uuNyplHEIAvtfUiyXtvzPqixhP0s7caOLgqTCW4sltaXsO7cuq9L0niHUtUQ%3D%3D"
is_sandbox = "false"

connection_secret_arn    = "arn:aws:secretsmanager:us-west-2:767397911309:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-prod-yBe0dp"
consumption_rds_endpoint = "cobank-767397911309-rds-proxy-ods-prod.proxy-ctuyq6iok2oi.us-west-2.rds.amazonaws.com"

glue_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2:654654446028:secret:RDSprodACBSDB-ETL-xXmjgv",
  "arn:aws:secretsmanager:us-west-2:654654446028:secret:rds!cluster-c9e408ea-026f-417f-bb87-72d0f1232742-43gzKn",
  "arn:aws:secretsmanager:us-west-2:767397911309:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-prod-yBe0dp",
  "arn:aws:secretsmanager:us-west-2:767397911309:secret:cobank-dl-rds-user-secret-ods-svcodsdeploy-prod-Vz5sjn"
]

appflow_secret_access_arn = [
  "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
]

lambda_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2::secret:GetARN"
]

acbs_landing_outside_principals = [
  "arn:aws:iam::905418005233:role/transfer-user-access-role-svcawssftp",
  "arn:aws:iam::767397798595:role/cobank-prod-lambda-role",
  "arn:aws:iam::767397798595:role/cobank-prod-glue-role",
  "arn:aws:iam::767397798595:role/cobank-prod-airflow-environment"
]

#IAMRolesAnywhere for DMS tasks
role_name         = "IAMRolesAnywhereDMSRole"
dms_profile_name      = "IAMRolesanywhereDMSProfile"
trust_anchor_name = "IAMRolesAnywhereDMSTrustAnchor"
dms_policy_name       = "IAMRolesAnywhereDMSManagementPolicy"
certificate_path  = "credentials/cobank-ca-iamrolesanywhere.crt"