# Account specific values
resource_prefix = "cobank"

#S3 policy variables
dat_lake_acct_id = "654654598303"

#RDS specific values
aurora_engine         = "aurora-postgresql"
aurora_engine_version = "15.5"
instance_class        = "db.r5.large"
database_name         = "acbsdb"
master_username       = "mstrrdsauadbd"
identifier            = "acbs-db"
vpc_id                = "vpc-067fafb824460e415"
subnets               = ["subnet-044ada5821b98a75b", "subnet-0d557d556afa47606"]

db_subnet_group_name            = "acbs-subnet-group"
final_snapshot_identifier       = "acbs-final-snapshot"
db_cluster_parameter_group_name = "acbs-cluster-parameter-group"
db_parameter_group_name         = "acbs-instance-parameter-group"
kms_key_id                      = "arn:aws:kms:us-west-2:832576047628:key/d80ddc81-162a-488c-b9e1-b401d8ee35f7"
#vpc_cidr_blocks                = ["10.70.4.0/22","172.26.0.0/16","172.30.74.0/23","172.30.76.0/24","172.30.160.0/20","172.30.0.0/18","172.30.224.0/20","172.30.140.0/22","172.30.208.0/20"]
#vpc_cidr_blocks = ["10.70.4.0/22", "0.0.0.0/0"]
vpc_cidr_blocks = [
  "10.70.4.0/22",
  "172.26.80.0/24",
  "172.30.114.0/24",
  "172.30.140.0/22",
  "172.30.160.0/20",
  "172.26.16.0/20"
]
#RDS secret
secret_svc_acct_glue_name = "RDSdevACBSDB-ETL"

#appflow
secret_sfdc_clientid_and_Key = "appflow-connector-salesforce-clientId-and-clientSecret"
Consumer_Key                 = "3MVG9Eroh42Z9.iXaoeQ1mZynR0qtBQjHhFTslWJnTdU9RCBb8bjnBLZW8AAgNy4JzXKnfOkVKd5_MXdijMCC"
Consumer_Secret              = "CAF58E6AEAE1FDD9D8BB42404E8ED301D5C39A8FD4FE906480D87D2A11C6BD6B"
sfdc_instance_url            = "https://cobank--cdmintdev.sandbox.my.salesforce.com"
sfdc_redirect_url            = "https://us-west-2.console.aws.amazon.com/appflow/oauth"
###Authcode Expires every 5 min generate before running the creation
auth_code  = "aPrxlfNgGADv6pVBoxwLvz.UCERKK4bxvYvTCXBW_Q.TlTBeVcsn0JjsmWQOF5OCte.WZ9rNxQ%3D%3D"
is_sandbox = "true"

connection_secret_arn    = "arn:aws:secretsmanager:us-west-2:590184072445:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-dev-JCcSTY"
consumption_rds_endpoint = "cobank-590184072445-rds-proxy-ods-dev.proxy-c96wwwa2i2gu.us-west-2.rds.amazonaws.com"


glue_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:RDSdevACBSDB-ETL-xCf4XY",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:RDSdevACBSDB-mGpu7u",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:rds-db-credentials/cluster-2VEZXXR7RGDDSMF53IRFDAKGRA/svcglueacbsdbd/1715800397630-85qX9n",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:gluecon-4WGSrU",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:rds!cluster-88c27479-8072-4880-b572-68cb41846e9d-GWUcOY",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:rds-db-credentials/cluster-2VEZXXR7RGDDSMF53IRFDAKGRA/mstrrdsauadbd/1709660440148-tHd37N",
  "arn:aws:secretsmanager:us-west-2:471112929721:secret:rds!cluster-f74c945b-f4ef-4b77-9dbf-e5ad4ca92b9b-p24oTa",
  "arn:aws:secretsmanager:us-west-2:590184072445:secret:cobank-dl-rds-user-secret-ods-svcprtyingglue-dev-JCcSTY",
  "arn:aws:secretsmanager:us-west-2:590184072445:secret:cobank-dl-rds-user-secret-ods-svcodsdeploy-dev-IyjvYq" #secret for user svcodsdeploy
]

appflow_secret_access_arn = [
  "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
]

lambda_secret_access_arn = [
  "arn:aws:secretsmanager:us-west-2::secret:GetARN"
]

acbs_landing_outside_principals = [
  "arn:aws:iam::637423528062:role/transfer-user-access-role-svcawssftp",
  "arn:aws:iam::654654598303:role/cobank-dev-lambda-role",
  "arn:aws:iam::654654598303:role/cobank-dev-glue-role",
  "arn:aws:iam::654654598303:role/cobank-dev-airflow-environment"
]

#IAMRolesAnywhere for DMS tasks
role_name         = "IAMRolesAnywhereDMSRole"
dms_profile_name      = "IAMRolesanywhereDMSProfile"
trust_anchor_name = "IAMRolesAnywhereDMSTrustAnchor"
dms_policy_name       = "IAMRoleDMSManagementPolicy"
certificate_path  = "credentials/cobank-ca-iamrolesanywhere.crt"