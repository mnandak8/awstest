data "aws_caller_identity" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
}

resource "aws_iam_role" "lambda_execution_role" {
  name = "cobank-${var.environment}-lambda-role"
  tags = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.dat_lake_acct_id}:role/cobank-${var.environment}-airflow-environment",
                "Service": "lambda.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

resource "aws_iam_policy" "appflow_describe_policy" {
  name        = "cobank-${var.environment}-appflow-describe"
  description = "Policy to enable describe access on Appflows for Lambda jobs"
  tags        = var.tags
policy = jsonencode(
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "appflow:DescribeFlowExecution",
                "appflow:DescribeFlowExecutionRecords",
                "appflow:DescribeFlow",
                "appflow:ListConnectorFields",
                "appflow:DescribeConnectorFields",
                "appflow:ListTagsForResource",
                "appflow:DescribeConnectorEntity"
            ],
            "Resource": [
                "arn:aws:appflow:us-west-2:471112929721:connectorprofile/dev-sfdc-authcode-connector",
                "arn:aws:appflow:*:471112929721:flow/*"
            ]
        },
        {
            "Sid": "VisualEditor1",
            "Effect": "Allow",
            "Action": [
                "appflow:DescribeConnectorProfiles",
                "appflow:DescribeFlows",
                "appflow:DescribeConnectors"
            ],
            "Resource": [
                "arn:aws:appflow:us-west-2::${local.account_id}:connectorprofile/dev-sfdc-authcode-connector",
                "arn:aws:appflow:*::${local.account_id}:flow/*"
            ]
        }
    ]
   }
 )
}


resource "aws_iam_role_policy_attachment" "appflow_describe_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = aws_iam_policy.appflow_describe_policy.arn
}

# TODO: Reevaluate permissions here later.
resource "aws_iam_policy" "secret_read_policy" {
  name        = "cobank-${var.environment}-secret-read-lambda"
  description = "Policy to enable read access on Secrets Manager for Lambda jobs"
  tags        = var.tags
  policy = jsonencode(
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Sid": "AllowReadOnAll",
          "Effect": "Allow",
          "Action": [
              "secretsmanager:GetResourcePolicy",
              "secretsmanager:GetSecretValue",
              "secretsmanager:DescribeSecret",
              "secretsmanager:ListSecretVersionIds",
              "secretsmanager:ListSecrets"
          ],
          "Resource": [
              for lambda_secret_access_arn in var.lambda_secret_access_arn : lambda_secret_access_arn
          ]
        }
      ]
    }
  )
}

resource "aws_iam_role_policy_attachment" "secretsmanager_read_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = aws_iam_policy.secret_read_policy.arn
}

# TODO: Reevaluate these permissions
resource "aws_iam_role_policy_attachment" "kms_full_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "vpc_access_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

resource "aws_iam_role_policy_attachment" "rds_full_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess"
}

resource "aws_iam_role_policy_attachment" "s3_full_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}

resource "aws_iam_role_policy_attachment" "lambda_full_policy_attach" {
  role       = aws_iam_role.lambda_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AWSLambda_FullAccess"
}
