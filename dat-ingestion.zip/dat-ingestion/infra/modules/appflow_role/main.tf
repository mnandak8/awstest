data "aws_caller_identity" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
}

resource "aws_iam_role" "create_role_appflow" {
  name = "cobank-${var.environment}-appflow-role"
  tags=var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.dat_lake_acct_id}:role/cobank-${var.environment}-airflow-environment",
                "Service": "appflow.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

resource "aws_iam_policy" "secret_read_policy_appflow" {
  name        = "cobank-${var.environment}-secret-read-appflow"
  description = "Policy to enable read access on Secrets Manager for appflow jobs"
  tags        = var.tags
  policy = jsonencode(
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Sid": "AllowReadOnAll",
          "Effect": "Allow",
          "Action": [
              "secretsmanager:GetResourcePolicy",
              "secretsmanager:GetSecretValue",
              "secretsmanager:DescribeSecret",
              "secretsmanager:ListSecretVersionIds",
              "secretsmanager:ListSecrets"
          ],
          "Resource": [
              for appflow_secret_access_arn in var.appflow_secret_access_arn : appflow_secret_access_arn
          ]
        }
      ]
    }
  )
}


# TODO: Reevaluate these permissions
resource "aws_iam_role_policy_attachment" "kms_full_policy_attach" {
  role       = aws_iam_role.create_role_appflow.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "rds_full_policy_attach" {
  role       = aws_iam_role.create_role_appflow.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess"
}

resource "aws_iam_role_policy_attachment" "s3_full_policy_attach" {
  role       = aws_iam_role.create_role_appflow.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}
resource "aws_iam_role_policy_attachment" "appflow_full_access_policy_attach" {
  role       = aws_iam_role.create_role_appflow.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonAppFlowFullAccess"
}

resource "aws_iam_role_policy_attachment" "secretsmanager_read_attach_appflow" {
  role       = aws_iam_role.create_role_appflow.name
  policy_arn = aws_iam_policy.secret_read_policy_appflow.arn
 }

