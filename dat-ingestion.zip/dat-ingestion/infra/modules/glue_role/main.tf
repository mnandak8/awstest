
data "aws_caller_identity" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
}

resource "aws_iam_role" "glue_role" {
  name = "cobank-${var.environment}-glue-role"
  tags = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.dat_lake_acct_id}:role/cobank-${var.environment}-airflow-environment",
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}
resource "aws_iam_policy" "secret_read_policy_glue" {
  name        = "cobank-${var.environment}-secret-read-glue"
  description = "Policy to enable read access on Secrets Manager for Glue jobs"
  tags        = var.tags
  policy = jsonencode(
    {
      "Version": "2012-10-17",
      "Statement": [
        {
          "Sid": "AllowReadOnSecretsManager",
          "Effect": "Allow",
          "Action": [
              "secretsmanager:GetResourcePolicy",
              "secretsmanager:GetSecretValue",
              "secretsmanager:DescribeSecret",
              "secretsmanager:ListSecretVersionIds",
              "secretsmanager:ListSecrets"
          ],
          "Resource": [
              for glue_secret_access_arn in var.glue_secret_access_arn : glue_secret_access_arn
          ]
        },
        {
          "Sid": "AllowLogsAccess",
          "Effect": "Allow",
          "Action": [
              "logs:CreateLogGroup",
              "logs:CreateLogStream",
              "logs:PutLogEvents",
              "logs:DescribeLogStreams",
              "logs:DescribeLogGroups",
              "logs:AssociateKmsKey"  # Added the AssociateKmsKey action here
          ],
          "Resource": "*"
        }
      ]
    }
  )
}
resource "aws_iam_policy" "cross_account_lake_airflow_policy" {
  name        = "cobank-${var.environment}-cross-account-lake-airflow-policy"
  description = "Policy to enable ingestion to access the lake airflow environment"
  tags        = var.tags
  policy = jsonencode(
  {
"Statement": [
        {
            "Action": [
                "sts:AssumeRole"
            ],
            "Effect": "Allow",
            "Resource": [
                "arn:aws:iam::${var.dat_lake_acct_id}:role/cobank-${var.environment}-airflow-environment"
            ],
            "Sid": "AirflowAccess"
        }
    ],
  "Version": "2012-10-17"
  }
 )
}

resource "aws_iam_role_policy_attachment" "AmazonEC2ContainerRegistryReadOnly_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}
resource "aws_iam_role_policy_attachment" "AWSGlueConsoleFullAccess_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AWSGlueConsoleFullAccess"
}

resource "aws_iam_role_policy_attachment" "cross_account_lake_airflow_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = aws_iam_policy.cross_account_lake_airflow_policy.arn
 }

resource "aws_iam_role_policy_attachment" "secretsmanager_read_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = aws_iam_policy.secret_read_policy_glue.arn
 }

# TODO: Reevaluate these permissions
resource "aws_iam_role_policy_attachment" "kms_full_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "rds_full_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess"
}

resource "aws_iam_role_policy_attachment" "s3_full_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}

resource "aws_iam_role_policy_attachment" "glue_service_role_policy_attach" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}

resource "aws_secretsmanager_secret" "secret_svc_acct_glue" {
  name        = var.secret_svc_acct_glue_name
  description = "Service account for the ACBS ETL"
}

/*
policy     = jsonencode(
  {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.account_id}:role/cobank-${var.environment}-glue-role}"
            },
            "Action": "secretsmanager:GetSecretValue",
            "Resource": "*"
        }
    ]
}
   )
}

resource "aws_secretsmanager_secret_rotation" "secrects_svc_acct_glue_rotation" {
  secret_id = aws_secretsmanager_secret.secrects_svc_acct_glue.id
  rotation_rules {
    automatically_after_days = 7
  }
}
*/
