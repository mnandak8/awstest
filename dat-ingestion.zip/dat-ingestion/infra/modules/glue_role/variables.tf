variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "environment" {
  description = "Name of the environment we are deploying."
  type        = string
}

variable "secret_svc_acct_glue_name" {
  description = "Name of the secret."
  type        = string
}

variable "dat_lake_acct_id" {
  description = "Lake account id."
  type        = string
}

variable "glue_secret_access_arn" { type = list(string) }
