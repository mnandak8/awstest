data "aws_caller_identity" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
}

#############################################################
# moved block
# NOTE: once you deploy to production, you should remove the moved block
#############################################################

#############################################################
# S3 Buckets: 
# logs
# tooling - v30
# landing - v30
# tooling-asset -v45
# landing - v45
# shared-resources -v45
# acbs_landing - v45 - pbi 322784
#############################################################
module "logging_bucket" {
  source          = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20240918.30"
  environment     = var.environment
  resource_suffix = "logs"
  expiration_days = 7
  include_logging = false
}

module "tooling_bucket" {
  source             = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20240918.30"
  environment        = var.environment
  resource_suffix    = "tooling"
  expiration_days    = 2555
  ia_transition_days = 365
  log_bucket_name    = module.logging_bucket.bucket_name
}

module "landing_bucket" {
  source             = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20240918.30"
  environment        = var.environment
  resource_suffix    = "landing"
  expiration_days    = 2555
  ia_transition_days = 365
  log_bucket_name    = module.logging_bucket.bucket_name
  outside_account_ids = [
    var.dat_lake_acct_id
  ]
  access_service_user_names = [
    "glue",
    "lambda",
    "appflow"
  ]
}

module "dl_tooling_bucket" {
  source               = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241009.45"
  environment          = var.environment
  terra_factory_aws_id = var.terra_factory_aws_id
  resource_suffix      = "tooling-asset"
  lake_type            = "dl"
  expiration_days      = 2555
  ia_transition_days   = 365
  log_bucket_name      = module.logging_bucket.bucket_name
}

module "dl_landing_bucket" {
  source               = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241009.45"
  environment          = var.environment
  terra_factory_aws_id = var.terra_factory_aws_id
  resource_suffix      = "landing"
  expiration_days      = 2555
  ia_transition_days   = 365
  log_bucket_name      = module.logging_bucket.bucket_name
  outside_account_ids  = [var.dat_lake_acct_id]
  access_service_user_names = [
    "glue",
    "lambda",
    "appflow"
  ]
}

module "shared_resources_bucket" {
  source               = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241009.45"
  environment          = var.environment
  terra_factory_aws_id = var.terra_factory_aws_id
  resource_suffix      = "shared-resources"
  expiration_days      = 0
  versioning           = true
  log_bucket_name      = module.logging_bucket.bucket_name
}

module "acbs_landing_bucket" {
  source               = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241009.45"
  environment          = var.environment
  terra_factory_aws_id = var.terra_factory_aws_id
  resource_suffix      = "acbs-landing"
  expiration_days      = 0
  versioning           = true
  log_bucket_name      = module.logging_bucket.bucket_name
  outside_account_ids  = var.acbs_landing_outside_principals
  access_service_user_names = [
    "glue"
  ]
}

#############################################################
# RDS Aurora PostgreSQL
#############################################################
module "aurora_postgres_db" {
  count          = var.environment == "dev" ? 0 : 1
  source         = "git::https://github.com/cobank-acb/dat-terraform-modules.git//rds?ref=v20250218.104"
  name           = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.identifier)
  engine         = var.aurora_engine
  engine_version = var.aurora_engine_version
  instance_class = var.instance_class
  instances = {
    1 = {}
    2 = {
      instance_class = var.instance_class
    }
  }
  database_name                       = var.database_name
  master_username                     = var.master_username
  port                                = "5432"
  tags                                = {}
  iam_database_authentication_enabled = true
  publicly_accessible                 = false
  create_security_group               = true
  #security_group_rules = { ingress_postgressql_traffic =  var.ingress_postgressql_traffic
  vpc_cidr_blocks             = var.vpc_cidr_blocks
  manage_master_user_password = true
  cluster_tags                = {}

  # DB subnet group
  vpc_id                    = var.vpc_id
  create_db_subnet_group    = true
  db_subnet_group_name      = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.db_subnet_group_name)
  subnet_ids                = var.subnets
  final_snapshot_identifier = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.final_snapshot_identifier)

  # DB cluster parameter group
  create_db_cluster_parameter_group      = true
  db_cluster_parameter_group_family      = "aurora-postgresql15"
  db_cluster_parameter_group_description = "This is a cluster parameter group managed by terraform"
  db_cluster_parameter_group_name        = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.db_cluster_parameter_group_name)

  # DB instance parameter group
  create_db_parameter_group      = true
  db_parameter_group_description = "This instance parameter group is managed by terraform and has query logging enabled"
  db_parameter_group_family      = "aurora-postgresql15"
  db_parameter_group_name        = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.db_parameter_group_name)
  db_parameter_group_parameters = [{
    name  = "log_statement"
    value = "all"
    },
    {
      name  = "log_min_duration_statement"
      value = "1"
  }]
  enabled_cloudwatch_logs_exports        = ["postgresql"]
  cloudwatch_log_group_retention_in_days = 365
  monitoring_interval                    = 5
  deletion_protection                    = true
  backup_retention_period                = 30
  storage_encrypted                      = true
  kms_key_id                             = var.kms_key_id

}

#############################################################
# IAM Roles
#############################################################
module "lambda_execution_role" {
  source                   = "./modules/lambda_execution_role"
  tags                     = {}
  environment              = var.environment
  dat_lake_acct_id         = var.dat_lake_acct_id
  lambda_secret_access_arn = var.lambda_secret_access_arn
}

module "glue_role" {
  source                    = "./modules/glue_role"
  tags                      = {}
  environment               = var.environment
  secret_svc_acct_glue_name = var.secret_svc_acct_glue_name
  dat_lake_acct_id          = var.dat_lake_acct_id
  glue_secret_access_arn    = var.glue_secret_access_arn
  #secret_read_policy       = module.lambda_execution_role.secret_read_policy.arn
  #secret_read_policy       = module.lambda_execution_role.cobank-dev-secret-read 
}

module "appflow_role" {
  source                    = "./modules/appflow_role"
  tags                      = {}
  environment               = var.environment
  dat_lake_acct_id          = var.dat_lake_acct_id
  appflow_secret_access_arn = var.appflow_secret_access_arn
}

#############################################################
# AppFlow
#############################################################
module "sfdcappflow" {
  source                       = "git::https://github.com/cobank-acb/dat-terraform-modules.git//sfdcappflow?ref=v20241003.37"
  environment                  = var.environment
  secret_sfdc_clientid_and_Key = var.secret_sfdc_clientid_and_Key
  Consumer_Key                 = var.Consumer_Key
  Consumer_Secret              = var.Consumer_Secret
  sfdc_instance_url            = var.sfdc_instance_url
  sfdc_redirect_url            = var.sfdc_redirect_url
  sfdc_applflow_name           = format("%s-%s-%s-%s", var.resource_prefix, var.environment, local.account_id, var.sfdc_appflow_connector_identifier)
  auth_code                    = var.auth_code
  is_sandbox                   = var.is_sandbox
  tags                         = {}

}

#############################################################
# Glue Connections
# party - v45
#############################################################
module "glue_connection" {
  source                 = "git::https://github.com/cobank-acb/dat-terraform-modules.git//glue_rds_connection?ref=v20241009.45"
  environment            = var.environment
  resource_suffix        = "party"
  subnet_id              = var.subnets[0]
  database_name          = "Salesforce"
  endpoint_url           = var.consumption_rds_endpoint
  credentials_secret_arn = var.connection_secret_arn
}


#############################################################
# IAMRolesAnywhere for DMS tasks
#############################################################
module "iam_roles_anywhere_dms" {
  source            = "git::https://github.com/cobank-acb/dat-terraform-modules.git//iamrolesanywhere_dms?ref=v20250212.96"
  environment       = var.environment
  role_name         = var.role_name
  dms_profile_name  = var.dms_profile_name
  trust_anchor_name = var.trust_anchor_name
  dms_policy_name   = var.dms_policy_name
  certificate_path  = var.certificate_path
}
