provider "aws" {
  default_tags {
    tags = {
      "cobank:cost-allocation:cost-center" = "8103"
      "cobank:operations:support-group"    = "Transformation Programs"
      "cobank:environment"                 = var.environment
    }
  }
} 
