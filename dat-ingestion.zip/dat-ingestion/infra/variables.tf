variable "resource_prefix" {
  type        = string
  description = "Prefix to be added for all resources"
}

#s3 bucket policies for landing 
variable "dat_lake_acct_id" {
  type = string
}

#appflow variables
#variable "sfdc_applflow_name" {type = string}
#variable "sfdc_instance_url" {type = string}

#start rds
variable "aurora_engine" {
  default = "aurora-postgresql"
}

variable "aurora_engine_version" {
  default = ""
}

variable "instance_class" {
  default = ""
}

variable "database_name" {
  default = ""
}

variable "master_username" {
  default = ""
}

variable "identifier" {
  default = ""
}

variable "vpc_id" {
  type    = string
  default = ""
}

variable "vpc_security_group_ids" {
  type    = list(any)
  default = []
}

variable "subnets" {
  type    = list(any)
  default = []
}

variable "db_subnet_group_name" {
  type    = string
  default = ""
}

variable "final_snapshot_identifier" {
  type    = string
  default = ""
}

variable "db_cluster_parameter_group_name" {
  type    = string
  default = ""
}

variable "db_parameter_group_name" {
  type    = string
  default = ""
}

variable "kms_key_id" {
  description = "The ARN for the KMS encryption key. When specifying `kms_key_id`, `storage_encrypted` needs to be set to `true`"
  type        = string
  default     = null
}

variable "vpc_cidr_blocks" { type = list(any) }
#end rds

#RDS secret
variable "secret_svc_acct_glue_name" {
  type        = string
  description = "Secret for glue role"
}


#appflow
variable "secret_sfdc_clientid_and_Key" { type = string }
variable "Consumer_Secret" { type = string }
variable "Consumer_Key" { type = string }
variable "sfdc_instance_url" { type = string }
variable "sfdc_redirect_url" { type = string }
variable "auth_code" { type = string }
variable "is_sandbox" { type = string }
variable "sfdc_appflow_connector_identifier" {
  type    = string
  default = "sfdc-appflow-connector"
}

variable "connection_secret_arn" {
  type        = string
  description = "ARN for the credentials secret we are using to connect to the consumption RDS instance."
}

variable "consumption_rds_endpoint" {
  type        = string
  description = "URL endpoint for the RDS instance in consumption we are populating."
}

variable "glue_secret_access_arn" { type = list(string) }
variable "appflow_secret_access_arn" { type = list(string) }
variable "lambda_secret_access_arn" { type = list(string) }
variable "acbs_landing_outside_principals" { type = list(string) }

#start iamrolesanywhere for dms
variable "role_name" {
  description = "The name of the IAM role for DMS"
  type        = string
}

variable "dms_policy_name" {
  description = "The name of the policy to allow starting and stopping DMS tasks"
  type        = string
}

variable "dms_profile_name" {
  description = "The name of the profile for IAM Roles Anywhere"
  type        = string
}

variable "trust_anchor_name" {
  description = "The name of the trust anchor for IAM Roles Anywhere"
  type        = string
}

variable "certificate_path" {
  description = "The path to the certificate for IAM Roles Anywhere"
  type        = string
}
#end iamrolesnaywhere dms