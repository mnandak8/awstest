#import {
#  to = module.application-infra.aws_secretsmanager_secret.transfer_pricing_api_secret
#  id = "transfer_pricing_api_secret"
#}

module "application-infra" {
  source                                         = "./application-infra"
  cost_center                                    = var.cost_center
  environment                                    = var.environment
  landing_bucket_name                            = var.landing_bucket_name
  tooling_bucket_name                            = var.tooling_bucket_name
  kms_key_arn                                    = var.kms_key_arn
  salesforce_connector_name                      = var.salesforce_connector_name
  airflow_dag_bucket_name                        = var.airflow_dag_bucket_name
  glue_role_name                                 = var.glue_role_name
  rds_connector_name                             = var.rds_connector_name
  sfdc_acbs_connector                            = var.salesforce_connector_name
  rds_secret_name                                = var.rds_secret_name
  env_mask                                       = var.env_mask
  splunk_tag                                     = var.splunk_tag
  consumption_rds_connector_name                 = var.consumption_rds_connector_name
  ods_consumption_secrets_manager_arn_kms_key_id = var.ods_consumption_secrets_manager_arn_kms_key_id
  ods_consumption_secrets_manager_arn_id         = var.ods_consumption_secrets_manager_arn_id
  consumption_account_id                         = var.consumption_account_id
  lake_account_id                                = var.lake_account_id
  tags                                           = var.tags
  email_address                                  = var.email_address
  rapport_db_secret_name                         = var.rapport_db_secret_name
  rapport_sqs_name                               = var.rapport_sqs_name
  rapport_dlq_name                               = var.rapport_dlq_name
  rapport_s3_bucket_name                         = var.rapport_s3_bucket_name
  rapport_sql_query                              = var.rapport_sql_query
  tc_api_url                                     = var.tc_api_url
  rds_vpc_cidr_blocks_ingress                    = var.rds_vpc_cidr_blocks_ingress
  rds_vpc_cidr_blocks_egress                     = var.rds_vpc_cidr_blocks_egress
  dms_kms_key_alias                              = var.dms_kms_key_alias
  terra_factory_aws_id                           = var.terra_factory_aws_id
  governance_account_id                          = var.governance_account_id
  lw-consumption-jdbc-connector                  = var.lw-consumption-jdbc-connector
  leasewave_glue_role                            = var.leasewave_glue_role
  leasewave_landing_bucket_name                  = var.leasewave_landing_bucket_name
}
