provider "aws" {
  default_tags {
      tags = {
        "cobank:cost-allocation:cost-center" = var.cost_center
        "cobank:environment" = var.environment
        }
    }
}
