CONFIG = {
    "ing": {
        "dev": {
		"acc_num": "471112929721",
		"sfdc_appflow_to_ing_schedule":None
        },
        "test": {
            "acc_num": "533267072724",
	     "sfdc_appflow_to_ing_schedule":None
        },
		"preprod": {
            "acc_num": "211125365237",
	    "sfdc_appflow_to_ing_schedule":"30 4 * * 2-6"
        },
		"prod": {
            "acc_num": "654654446028",
	    "sfdc_appflow_to_ing_schedule":"30 4 * * 2-6"
        }
    }
}
