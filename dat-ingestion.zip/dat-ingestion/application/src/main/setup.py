from setuptools import setup

setup(
    name='utils',
    version='0.1',
    packages=["acbs.airflow","acbs.airflow","acbs.configs","acbs.glue","acbs.lambda","utils"],
    include_dirs=True,
    include_package_data=True
)