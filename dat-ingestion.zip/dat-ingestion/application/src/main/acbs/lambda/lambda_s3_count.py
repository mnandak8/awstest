import boto3
import pyarrow.parquet as pq

####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
##### NOT USED ANYMORE
####################################################################
def lambda_handler(event, context):
    # Define S3 bucket and Parquet file path
    s3_bucket_name = 'cobank-dl-471112929721-us-west-2-landing-dev'
    parquet_file_key = 'salesforce/contact/salesforce_to_landing_contact/2024/03/01/9bc590ca-61ba-428b-975a-55b65ad9a100-2024-03-01T21:20:04/2084964579-2024-03-01T21:20:02'

    # Initialize S3 client
    s3_client = boto3.client('s3')

    # Download Parquet file from S3
    response = s3_client.get_object(Bucket=s3_bucket_name, Key=parquet_file_key)
    parquet_object = response['Body'].read()

    # Read Parquet file into a PyArrow Table
    parquet_table = pq.read_table(parquet_object)

    # Count number of records
    num_records = len(parquet_table)

    # Print number of records
    print(f"Number of records: {num_records}")

    return {
        'statusCode': 200,
        'body': f'Number of records: {num_records}'
    }
