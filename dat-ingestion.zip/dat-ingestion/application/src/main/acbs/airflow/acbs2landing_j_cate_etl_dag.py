from airflow import DAG
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.providers.amazon.aws.operators.glue import  GlueJobOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable


sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


obj_name = 'j_cate'
group_name= 'acbs'

default_args = {
    'owner': 'DJ',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    f'{group_name}2landing_{obj_name}_etl',
    default_args=default_args,
    description=f'Glue {group_name} DAG scheduled to run every 2 hours',
    schedule_interval="0 0/2 * * *",
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification]
)

script_arguments = {
    "--tableName": f"{obj_name}"
}

glue_job_operator = GlueJobOperator(
    task_id=f'run_{group_name}_glue_job',
    job_name=f'{group_name}_to_landing_extract',
    dag=dag,
    aws_conn_id='ing_glue',
    script_args=script_arguments
)

# Trigger landing to transform dag
dag_run_operator = TriggerDagRunOperator(
    task_id=f'run_landing2transform-{group_name}-{obj_name}-etl_dag',
    trigger_dag_id=f'landing2transform-{group_name}-{obj_name}-etl',
    trigger_rule = 'all_success',   
    dag=dag
)

# Define tasks/operators
start_task = DummyOperator(task_id='start', dag=dag)
end_task = DummyOperator(task_id='end', dag=dag)

start_task >> glue_job_operator >> dag_run_operator >> end_task