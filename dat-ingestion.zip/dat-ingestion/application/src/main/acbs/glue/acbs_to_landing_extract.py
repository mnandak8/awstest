import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame
from datetime import date, datetime
import configparser
import boto3
from utils.audit_utils import *
from utils.s3_utils import *

####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
##### REFER readme.txt file before updating this file
####################################################################

# Reads config file from S3 bucket
def read_config(bucket_name,config_file_name):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=bucket_name, Key=f'ingestion/glue-scripts/configs/{config_file_name}')
    data = obj['Body'].read()
    config = configparser.ConfigParser()
    config.read_string(data.decode())

    print(config.sections())

    return config


# Generates landing folder path to write the data
def generate_destination_folder_path(bucket_name,source_type, table_name):
    current_time = datetime.now()
    current_year = current_time.year
    current_month = current_time.month
    current_month = f'{current_time:%m}'
    current_date = current_time.day
    current_date = f'{current_time:%d}'
    file_name = f'{source_type}_{table_name}_{current_time.strftime("%Y-%m-%d %H-%M-%S")}'
    s3_path = f's3://{bucket_name}/{source_type}/{table_name}/{current_year}/{current_month}/{current_date}/{file_name}'
    return s3_path


def move_to_failed(current_path,s3_bucket,table_name):
    source_prefix = current_path.replace(f's3://{s3_bucket}/','')

    logger.info(f'{table_name} Moving failed files from {s3_bucket}/{source_prefix} to failed')
    objects = list_files(s3_bucket, source_prefix)

    # Move each object to the destination folder
    for obj in objects.get('Contents', []):
        key = obj['Key']

        failed_key = key.replace(f'{table_name}/',f'failed/{table_name}/')
        move_file(s3_bucket, key, failed_key)


### Validates counts of source and target
### Moves files to failed if count does not match
def validate_count(s3_path,total_count_from_db,s3_bucket,rds_source_type,rds_table_name):
    
    ## Take count from S3
    ## Take count from RDS : Already have count taken after reading
    ## Compare
    ## If not matched --> Move all S3 files to failed/2024 etc
    ## Mark job as failed

    s3_data = glueContext.create_dynamic_frame.from_options(format_options={}, 
                                                        connection_type="s3", format="parquet", 
                                                        connection_options={"paths": [s3_path], "recurse": True}, 
                                                        transformation_ctx="s3_data")

    spark_df = s3_data.toDF()
    s3_count = spark_df.count()
    if s3_count == total_count_from_db :
        logger.info(f'{rds_table_name} Counts matched !')
        return None
    else:
        logger.error(f'{rds_table_name} S3 count {s3_count} does not match with rds count {total_count_from_db} !')
        logger.error(f'{rds_table_name} Moving {s3_path} to failed/')
        move_to_failed(s3_path,s3_bucket,rds_table_name)
        return f'S3 count {s3_count} does not match with rds count {total_count_from_db} !'


def read_from_acbs(rds_dbname, rds_table_name, jdbc_conn_name,glueContext):
    postgreSQL_data = glueContext.create_dynamic_frame.from_options(
                connection_type="postgresql",
                connection_options={
                    "useConnectionProperties": "true",
                    "dbtable": f'{rds_dbname}.{rds_table_name}',
                    "connectionName": jdbc_conn_name,
                },
                transformation_ctx="postgreSQL_data",
        )
    return postgreSQL_data


def write_acbs_to_s3(postgreSQL_data, s3_path):
    s3_data = glueContext.write_dynamic_frame.from_options(
            frame=postgreSQL_data,
            connection_type="s3",
            format="glueparquet",
            connection_options={
                "path": s3_path,
                "partitionKeys": [],
            },
            format_options={"compression": "snappy"},
            transformation_ctx="s3_data",
        )

def main():

    start_time = datetime.now()
    logger.info(f"Starting execution for merge job at {start_time}")
        
    config_file_name = args['configScript']
    rds_table_name = args['tableName']
    config_bucket = args['configBucket']
    s3_bucket = args["landingBucket"]
    
    logger.info(f'{rds_table_name}_2landing Reading configurations from acbs config file')
    configs = read_config(config_bucket,config_file_name)
    rds_dbname = configs.get("RDS_PROPERTIES", "database")
    jdbc_conn_name = configs.get("RDS_PROPERTIES", "jdbc-connection-name")
    rds_source_type = configs.get("RDS_PROPERTIES", "rds-source-type")
    s3_path = generate_destination_folder_path(s3_bucket,rds_source_type,rds_table_name)

    jobName =f'{args["JOB_NAME"]}_{rds_table_name}'
    audit_api_url=configs.get("AUDIT_PROPERTIES", "audit-conn-url")
    logger.info(f'{rds_table_name}_2landing Inserting {jobName} audit entry')
    jobRunId = insert_audit_balance(jobName, f'RDSTABLE_ACBS_{rds_table_name}', f'S3_{s3_bucket}', "Glue", f'Copying {rds_table_name} data to {s3_path}',audit_api_url)

    logger.info(f'{rds_table_name}_2landing Reading data from {rds_dbname}.{rds_table_name} using connection {jdbc_conn_name}')

    postgreSQL_data = None
    try:
        postgreSQL_data = read_from_acbs(rds_dbname, rds_table_name, jdbc_conn_name,glueContext)
    except Exception as e:
        print(Exception, e)
        logger.error(f'{rds_table_name}_2landing [ERROR] Read failed with ERROR {type(e)}: {e}')
        update_audit_balance(jobName, jobRunId, f'Read failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'Error while reading from RDS table {rds_dbname}.{rds_table_name}, Exiting..')
    
    total_records = postgreSQL_data.count()
    logger.info(f'{rds_table_name}_2landing Writing total {total_records} records to landing bucket {s3_path}')

    try:
        write_acbs_to_s3(postgreSQL_data, s3_path)

    except Exception as e:
        print(Exception, e)
        logger.error(f'{rds_table_name}_2landing [ERROR] Write failed with ERROR {type(e)}: {e}')
        update_audit_balance(jobName, jobRunId, f'Write failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'Error while writing to landing bucket {s3_path}, exiting..')
    

    job.commit()
    logger.info(f'{rds_table_name}_2landing Completed writing total {total_records} records from {rds_table_name} to {s3_path}')
    logger.info(f'{rds_table_name}_2landing Validating the counts now..')
    try:
        returnMessage = validate_count(s3_path,total_records,s3_bucket,rds_source_type,rds_table_name)
    except Exception as e:
        print(Exception, e)
        logger.error(f'{rds_table_name}_2landing [ERROR] Validating counts failed with ERROR {type(e)}: {e}! Skipping validation now!')
        returnMessage = None
        
    #LastModifiedDataDate : Not available for acbs
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() / 60

    if returnMessage == None: 
        update_audit_balance(jobName, jobRunId, f'Job execution completed in {duration:.2f} minutes', "Successful",audit_api_url, f'{total_records}')
        logger.info(f'{rds_table_name}_2landing Job execution completed in {duration:.2f} minutes')
    else:
        update_audit_balance(jobName, jobRunId, returnMessage, "Failed",audit_api_url)
        sys.exit(f'{returnMessage}, Exiting..')


if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ["JOB_NAME","configScript","tableName","configBucket","landingBucket"])
    sc = SparkContext()
    glueContext = GlueContext(sc)
    job = Job(glueContext)
    job.init(args["JOB_NAME"], args)
    logger = glueContext.get_logger()

    main()
    