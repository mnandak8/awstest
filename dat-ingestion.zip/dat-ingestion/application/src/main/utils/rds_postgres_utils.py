import pg8000


def read_from_rds(db_endpoint, port, rds_dbname, username, password, schema, rds_table_name, spark ):
    # Database connection properties
    jdbc_url = f'jdbc:postgresql://{db_endpoint}:{port}/{rds_dbname}'
    properties = {
        "user": username,
        "password": password,
        "driver": "org.postgresql.Driver"
    }

    # Read data from the PostgreSQL table
    df = spark.read.jdbc(url=jdbc_url, table=f'{schema}.{rds_table_name}', properties=properties)

    return df


def write_to_rds(landingDf, schema, tableName, dbName, username,password,dbEndpoint,port):
    landingDf.write.format("jdbc") \
        .option("url", f'jdbc:postgresql://{dbEndpoint}:{port}/{dbName}') \
        .option("dbtable", f'{schema}.{tableName}') \
        .option("user", username) \
        .option("password", password) \
        .mode("append") \
        .save()


# Execute the sql statement using pg8000 library
def execute_sql(db_host, db_user, db_password, port, database, sql_commands):

    connection = None
    try:
        # Establish a connection to the database
        connection = pg8000.connect(
            host=db_host,
            database=database,
            user=db_user,
            password=db_password,
            port=port
        )
        cursor = connection.cursor()
        # Execute the sql statement
        # cursor.execute(sql_query)

        for command in sql_commands.split(';'):
            if command.strip():
                cursor.execute(command)
        connection.commit()
        print(f'SQL statement {command} executed successfully')
    except Exception as e:
        print(f"Error executing SQL statement: {e}")
        raise e
    finally:
        if connection is not None:
            cursor.close()
            connection.close()