from pyspark.context import SparkContext
from awsglue.context import GlueContext
import boto3
from datetime import date, datetime

####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
##### REFER readme.txt file before updating this file
####################################################################

s3 = boto3.client('s3')

### Function to read data from bucket
#def read_data(input_path,input_format,header_exists,is_recursive):
    #input_df = spark = glueContext.spark_session.read.format(input_format).option("header",header_exists).option("recursiveFileLookup",is_recursive).load(input_path)
    #return input_df

def read_from_landing(glueContext,input_format, header_exists, is_recursive, s3_path):
    input_df = glueContext.spark_session.read.format(input_format).option("header",header_exists).option("recursiveFileLookup",is_recursive).load(s3_path)
    return input_df

### Function to write data to bucket
def write_data(ouput_df, output_path, format):
    print(f"Writing data to {output_path}")
    if format == "csv":
        ouput_df.write.format(format).option("header","true").save(output_path)
    elif format == "parquet":                          
        ouput_df.write.mode("overwrite").parquet(output_path)


### Function to delete S3 file
def delete_file(bucket,key):
    s3.delete_object(Bucket=bucket, Key=key)


### Function to list files in the bucket
def list_files(source_bucket, source_prefix):

    # List all objects in the source folder
    objects = s3.list_objects_v2(Bucket=source_bucket, Prefix=source_prefix)

    return objects


### Function to move file from source bucket location to target
def move_file(source_bucket, key, destination_key):
    print(f'Moving file {key} to {destination_key}')
    copy_source = {'Bucket': source_bucket, 'Key': key}
    #destination_key = destincation_prefix + key[len(source_prefix):] 
    s3.copy_object(CopySource=copy_source, Bucket=source_bucket, Key=destination_key)
    delete_file(source_bucket,key)

def generate_destination_folder_path(bucket_name,source_type, table_name):
    current_time = datetime.now()
    current_year = current_time.year
    current_month = current_time.month
    current_month = f'{current_time:%m}'
    current_date = current_time.day
    current_date = f'{current_time:%d}'
    file_name = f'{source_type}_{table_name}_{current_time.strftime("%Y-%m-%d %H-%M-%S")}'
    s3_path = f's3://{bucket_name}/{source_type}/{table_name}/{current_year}/{current_month}/{current_date}/{file_name}'
    return s3_path


def get_latest_subfolder(bucket_name, prefix):
    """
    Fetches the latest subfolder within a given S3 prefix.

    Args:
    - bucket_name: Name of the S3 bucket.
    - prefix: S3 prefix representing the directory path.

    Returns:
    - latest_subfolder: The latest subfolder within the specified prefix.
    """
    s3_client = boto3.client('s3')

    # List objects within the specified prefix
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, Delimiter='/')

    # Extract subfolder names from the response
    subfolders = [obj['Prefix'] for obj in response.get('CommonPrefixes', [])]

    if not subfolders:
        return None

    # Extract the date part and sort based on it
    subfolders_with_dates = []
    for subfolder in subfolders:
        # Extract the date part from the subfolder name
        date_list = subfolder.rstrip('/').split('-')[-3:] 
        date_str = ''.join(date_list)

        try:
            # Parse the date part
            date_part = datetime.strptime(date_str, '%Y%m%dT%H:%M:%S')
            subfolders_with_dates.append((subfolder, date_part))
        except ValueError:
            # If date parsing fails, ignore this subfolder
            continue

    if not subfolders_with_dates:
        return None

    # Sort subfolders by the date part in descending order
    sorted_subfolders_with_dates = sorted(subfolders_with_dates, key=lambda x: x[1], reverse=True)

    # Return the first (i.e., latest) subfolder name
    latest_subfolder = sorted_subfolders_with_dates[0][0]
    return latest_subfolder 