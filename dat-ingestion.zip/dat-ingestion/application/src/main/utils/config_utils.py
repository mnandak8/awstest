import configparser
import boto3


# Reads config file from S3 bucket
def read_config(bucket_name,config_file_prefix):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=bucket_name, Key=config_file_prefix)
    data = obj['Body'].read()
    config = configparser.ConfigParser()
    config.read_string(data.decode())

    return config
    