import json
import boto3


def get_secret_value(secret_name):
    # Create a Secrets Manager client
    client = boto3.client('secretsmanager')
    
    try:
        # Get the secret value
        response = client.get_secret_value(SecretId=secret_name)

        # Depending on the secret type, return the appropriate value
        if 'SecretString' in response:
            secret = response['SecretString']
        else:
            secret = response['SecretBinary'].decode('utf-8')
        
        return secret
    
    except Exception as e:
        print(f"Error retrieving secret: {e}")
        return None


def get_creds_from_secret(secret_name):
    secret_value = get_secret_value(secret_name)
    if secret_value:
        try:
            secret_json = json.loads(secret_value)
            
            username = secret_json.get('username')
            password = secret_json.get('password')
            dbendpoint = secret_json.get('host')
            port = secret_json.get('port')

            return username, password, dbendpoint, port
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return None, None, None, None, None
    return None, None, None, None, None