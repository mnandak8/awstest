To update audit_utils.py & s3_utils.py

1. Update audit_utils.py and test it thoroughly.
2. Go to src/main/ and locate setup.py
3. From that path from step 2, Generate whl file using command - py setup.py bdist_wheel
4. Copy whl file to libs folder and discard other generated folders [dist,build,utils.egg-info]