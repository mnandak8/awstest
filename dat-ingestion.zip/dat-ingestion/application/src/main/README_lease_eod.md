# LeaseWave End-of-Day (EOD) data flow to landing, raw, and lake formation 

This process takes data from a LeaseWave on-prem snapshot and loads to landing bucket in dat-ing and then to landing bucket in dat-lak.
The dat-lak bucket is registered with lake formation and has Glue Catalog database tables created in dat-lak.
There are 3 glue jobs and one DAG that load the data.  For each table, there are four tasks in the DAG that run sequentially: landing > raw > audit > crawler.


- [Buckets](#Buckets)
- [SampleFlow](#SampleFlow)
- [IAM](#IAM)
- [GlueJobs-DAG-Crawler](#GlueJobs-DAG-Crawler)
- [AddMoreTables](#AddMoreTables)
- [Lake-Formation-Views](#Lake-Formation-Views)

  
[Lucid Chart:](https://lucid.app/lucidchart/bb36fbf8-6b12-4f07-9123-86fc5f1c4bb6/edit?invitationId=inv_5ed2fd1e-11b2-4e17-b9f6-9acfe3ce08cb&page=YNixrHmhdeth#)
![Lake Hydration Patterns - Data flow patterns for various use cases](https://github.com/user-attachments/assets/4808dfa6-4d9b-48c5-9df6-0d4d93b6eb6d)



# Buckets
    
  Landing bucket 
  -	application/application-infra/leasewave_asset_s3.tf
  -	'env'-acb-dat-ing-leasewave-asset
  -	log:  cobank-dl-'account_id'-'region'-logs-'env'
  -	This bucket is NOT registered with lake formation

  Raw bucket (dat-lakehouse)
  -	application/modules/aws_services/raw/lease_leasewave_s3_raw.tf
  -	'env'-acb-dl-dat-lak-raw-lease-leasewave-asset
  -	log: cobank-dl-'account_id'-'region'-logs-'env'
  -	This bucket is registered with lake formation
  
    


# SampleFlow

[SampleFlow](https://cobank.sharepoint.com/:x:/s/Applications/Cloud-Data-Platform/EdP4i3iV5p9CghphP4dn4VIByc5i3FlEcIkDV0uYQqCjsA?e=BU6D5e)

# IAM

Landing bucket role 
-	application/application-infra/leasewave_glue_role.tf
-	cobank-'env'-leasewave-glue-role

Raw bucket role (dat-lakehouse)                        
-	application/modules/aws_services/raw/glue_role_leasewave.tf
-	cobank-'env'-leasewave-glue-role

    	

# GlueJobs-DAG-Crawler

**Check LeaseWave on-prem snapshot date**
1.	lease_eod_to_check_snapshot
2.	application/application-infra/lease_eod_check_snapshot_glue_job.tf
3.	application/src/main/leasewave/glue/lease_eod_check_snapshot.py in tooling bucket (cobank-dl-'account_id'-'region'-tooling-preprod) has below logic
5.	checks to see if snapshot day = today-1, if true then it proceeds, if false, it waits for a minute and checks again.  After the 60th minute, the job will fail.
6.	Snapshot is generated via a ControlM job

**Load on-prem data to landing**
1.	lease_eod_to_landing_extract
2.	application/application-infra/lease_eod_glue_job.tf
3.	application/src/main/leasewave/glue/lease_eod_to_landing_extract.py in tooling bucket (cobank-dl-'account_id'-'region'-tooling-preprod) has below logic
4.	Loads data from LeaseWave on-prem and loads to landing bucket
5.	CONFIG
	- application/src/main/leasewave/configs/environments/'env'/lease-eod.config
	- this config file contains the properties for on-prem connection

**DAG**
1.	application/src/main/leasewave/airflow/lease_eod_data_landing_to_raw.py
2.	contains a list of tables to load

**Load from landing to raw (dat-lakehouse)**
1.	lease_eod_landingtoraw_extract
2.	application/modules/lease_eod_etl/lease_eod_landing_to_raw_glue_job.tf
3.	application/modules/lease_eod_etl/lease_eod_landingtoraw_extract.py in script bucket (cobank-dl-'account_id'-'region'-glue-etl-script-'env')

**Crawler (dat-lakehouse)**
1.	application/modules/lease_eod_etl/main.tf
2.	uses the variable called lease_eod_table_names in common.tfvars to loop through and create crawler/tables
3.	uses the variable called lease-eod-glue-catalog-db-name in common.tfvars to define database - lease_eod_leasewave_raw_dataasset_db

**ETL config (dat-lakehouse)**
1.	application/src/main/config/etl.conf
2.	contains list of tables to load


# AddMoreTables
The 3 files listed below would need to be edited with updated table names.

	`
		dat-ingestion (DAG):  application/src/main/leasewave/airflow/lease_eod_data_landing_to_raw.py
  		dat-lakehouse (ETL):  application/src/main/config/etl.conf
		dat-lakehouse (Crawler):  application/environments/common.tfvars
  		
 	`

# Lake-Formation-Views

In the dat-governance repo, views are created in the lease_db database.




   		



