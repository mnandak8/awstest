from airflow import DAG
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.providers.amazon.aws.operators.glue import  GlueJobOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable


sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

group_name= 'leasewave_mtvw_rcvble_inv_amt_refresh'

default_args = {
    'owner': 'DA',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    f'{group_name}-dag',
    default_args=default_args,
    description=f'Glue {group_name} DAG scheduled to run every 20 minutes',
    schedule_interval="*/40 * * * *",
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification]
)

glue_job_operator = GlueJobOperator(
    task_id=f'run_{group_name}_glue_job',
    job_name=f'{group_name}_job',
    dag=dag,
    aws_conn_id='ing_glue'
)


# Define tasks/operators
start_task = DummyOperator(task_id='start', dag=dag)
end_task = DummyOperator(task_id='end', dag=dag)

start_task >> glue_job_operator >> end_task