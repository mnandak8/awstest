from datetime import datetime,timedelta
from airflow import DAG
from airflow.decorators import task_group
from airflow.operators.empty import EmptyOperator
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from airflow.operators.python import PythonOperator
from cb_common.utils.common import save_job_status,SNSNotifier
from airflow.providers.amazon.aws.operators.glue_crawler import GlueCrawlerOperator
from airflow.models.baseoperator import chain
import os
import pytz


sns_notifier = SNSNotifier(region_name='us-west-2')

group_name= 'lease_eod'

dag_id = os.path.basename(__file__).replace(".py", "")
obj_names = [
'LeaseFinances','LeaseFinanceDetails','Contracts','Parties','RemainingNetInvestments','DealProductTypes','Users','ContractOriginations','OriginationSourceTypes',
'LeasePaymentSchedules','Receivables','ReceivableDetails','RemitToes','ReceivableCodes','ReceivableTypes',
'ReceivableInvoiceDetails','ReceivableTaxes','ReceivableTaxDetails','ReceivableInvoices',
#Round 1
'AccountsPayableDetails','AccountsPayablePayments','AccountsPayablePaymentVouchers','AccountsPayables','AcquiredPortfolios','Activities',
'ActivityEntityConfigs','ActivityForCollectionWorkLists','ActivityForCustomers','ActivityTypes','AgencyLegalPlacementAmounts','AgencyLegalPlacements',
'AnalysisTypeConfigs','AppraisalDetails','AppraisalRequests','AssetCategories','AssetClassADRConfigs','AssetClassCodes','AssetClassConfigs',
#'AssetFeatures', -- 0 records in source
'AssetGLDetails','AssetGroupByOptions','AssetHistories','AssetIncomeSchedules','AssetLocations',
#'AssetMeters', -- 0 records in source
'Assets','AssetSaleBlendedItems',
'AssetSaleDetails','AssetSales','AssetsValueStatusChangeDetails','AssetTypeAccountingComplianceDetails','AssetTypes','AssetUsages',
'AssetValueHistories','AssumptionAssets','Assumptions','BankAccountCategories','BankAccounts','BankBranches','BillToAssetGroupByOptions','BillToes',
'BillToInvoiceAddendumBodyDynamicContents','BillToInvoiceBodyDynamicContents','BillToInvoiceFormats','BillToInvoiceParameters','BlendedIncomeSchedules',
'BlendedItemAssets','BlendedItemCodes','BlendedItems','BookDepreciations'
#Round 2
,'DiscountingAmortizationSchedules','GLJournalDetails','GLJournals','CustomerBillingPreferences','CustomerLateFeeSetups','DiscountingRepaymentSchedules','DisbursementRequestPayables','DiscountingCapitalizedInterests','ContractLateFeeReceivableTypes','Comments',
'DisbursementRequests','ContractBillingPreferences','ContractACHAssignments','CreditSummaryExposures','ContractReportStatusHistories','EmployeesAssignedToParties','Customers','CreditRiskGrades','CustomerACHAssignments','ContractThirdPartyRelationships','CollectionWorkListContractDetails',
'EmployeesAssignedToContracts','ContractContacts','ContractOriginationServicingDetails','CustomerThirdPartyRelationships','ContractBillings','ContractLateFees','CollateralTrackings','ContractCollectionDetails','CollectionWorkLists','ContractLateFeeDetails','DiscountingContracts',
'DiscountingFinances','DiscountingServicingDetails','Discountings','ContractBankAccountPaymentThresholds','DiscountingPaydowns','CommentSubTypes','CustomerDoingBusinessAs','Counties','CommentResponses','BusinessTypeNAICSCodes','GLTemplateDetails','CollectionCustomerStatusHistories','Funders',
'FunderLegalEntities','BusinessTypesSICsCodes','DiscountingPaydownSundries','DiscountingNonAccrualDetails','GLEntryItems','GLTemplates','FloatRateIndexDetails','DiscountingBlendedItems','DiscountingWriteDowns','GLAccounts','GLTransactionTypes',
'CollectionStatus','CommentTypeSubTypes','ContactTypesForEntityTypes','CashTypes','CommentTypes','CollectionQueues','EligibilityConfigs','BusinessTypes','CoverageTypeConfigs','CustomerBusinessConfigs','CustomerClasses',
'DealTypes','CancellationCodeConfigs','CeclTextConfigs','CourtFilings','ExceptionApprovalConfigs','FloatRateIndexes','Countries','BusinessUnits'
#Round 3
,'LeaseIncomeSchedules','LoanIncomeSchedules','InvoiceExtractReceivableDetails','PayableGLJournals','Payables','InvoiceExtractCustomerDetails','Jobs','JobInstances',
'LeaseYields','PartyContactTypes','PartyAddresses','LeaseContractOptions','PartyContacts','PartyRoles','LeaseAssets','InterestRateDetails','LeaseInterestRates',
'LeaseCustomAmorts','MaturityMonitorActivityTypes','LeaseTaxAssessmentDetails','LeaseTaxAssessmentTaxBasisTypes','InsurancePolicyAssignments','LienCollaterals','LienFilings','LienResponses',
'LocationTaxAreaHistories','LoanPaymentSchedules','Locations','LeaseAmendments','PayableInvoiceAssets','LeaseBlendedItems','PayableInvoices','InsurancePolicyCoverageDetails',
'PayableInvoiceOtherCosts','MaturityMonitors','MaturityMonitorRenewalDetails','MasterAgreements','LeaseAssetVendorResidualGuarantees','LandRecordsContractDetails','MaturityMonitorLesseeNotifications',
'LandRecords','InsurancePolicies','LoanFundings','LeaseAssetPaymentSchedules','PartyBankAccounts','InstrumentTypeGLAccounts','InsuranceAgencies','MaturityMonitorFMVAssetDetails','LoanInterestRates',
'LoanFinances','ParentPartyRelationshipHistories','NonAccrualContracts','InsuranceCompanies','LeaseAmendmentImpairmentAssetDetails','NonAccruals','InstrumentTypes','PayableCodes',
'InvoiceFormats','LegalReliefBankruptcyChapters','LegalReliefs','InvoiceTypes','PayableTypes','LegalFormationTypeConfigs','LossGivenDefaultConfigs','LateFeeTemplateDetails','LateFeeTemplates',
'LegalEntityAddresses','MaturityActivityTypes','LegalEntities','LineOfBusinesses'
#,'InsurancePolicyAssignmentDetails' -- 0 records in source
]

default_args = {
    'owner': 'DJ',
    'depends_on_past': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2),
    'catchup': False,
}

cb_timezone = pytz.timezone('America/Denver')
cb_time = datetime.now(cb_timezone)
yesterday_mt_time = cb_time - timedelta(days=1)
date2process = yesterday_mt_time.strftime('%Y/%m/%d')
start_date = datetime.now(cb_timezone) - timedelta(days=1)
group_name= 'lease_eod'

with DAG(dag_id=dag_id,
         default_args=default_args,
         default_view='graph',
         is_paused_upon_creation=False,
         max_active_runs=1,
         max_active_tasks=10,
         on_failure_callback=[sns_notifier.failure_notification],
         start_date=start_date,
         schedule_interval="0 1 * * 2-6",
         tags=["lease-eod"]
) as dag:
    start = EmptyOperator(task_id='Start_lease_eod_data_load_tasks')
    end = EmptyOperator(task_id='Done_lease_eod_data_load_tasks')
    

    glue_job_lease_eod_snapshot_check = GlueJobOperator(
        job_name="lease_eod_to_check_snapshot",
        task_id = "lease_eod_to_check_snapshot",
        aws_conn_id='ing_glue',
        verbose=False,
        dag=dag
        )


    @task_group
    def lease_eod_data_load():
        for obj in obj_names:
            raw_crawler_name = f'raw-db-crawler-lease-eod-dbo-{obj}',
            glue_ing_trig = GlueJobOperator(
                    job_name=f'{group_name}_to_landing_extract',
                    task_id = f"ingest_{obj}_data_load_task",
                    aws_conn_id='ing_glue',
                    script_args={
                        "--date2process": date2process,
                        "--tableName": obj
                    },
                    verbose=False)
            
            glue_raw_trig = GlueJobOperator(
                    job_name=f'{group_name}_landingtoraw_extract',
                    task_id = f"landing2raw_{obj}_data_load_task",
                    script_args={
                        "--date2process": date2process,
                        "--objectname": obj,
                        "--continuous-log-logGroup": f"/aws-glue/datalake/jobs/lease_eod_landingtoraw_extract_{obj}/log_group/"
                    },
                    verbose=False)
            
            raw_layer_crawler = GlueCrawlerOperator (
                    task_id = f'catalog_raw_{obj}_data',
                    config = { 
                      "Name": raw_crawler_name[0]
                    },
                    poll_interval=30,
                    dag = dag
                    )
            
            push_status_raw = PythonOperator(
                    task_id = f'save_{obj}_audit_status_raw_task',
                    python_callable=save_job_status,
                    op_kwargs={'job_name': f'{group_name}_landingtoraw_extract'})

            # Define the DAG dependencies
            chain(
                 glue_ing_trig,
                 glue_raw_trig,
                 push_status_raw,
                 raw_layer_crawler
                )

             
    start >> glue_job_lease_eod_snapshot_check >> lease_eod_data_load() >>  end