import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from utils.config_utils import *
from utils.rds_postgres_utils import execute_sql
from utils.secret_utils import *
from datetime import datetime

def main(): 
    
    start_time = datetime.now()
    job_name = "lw-mtvw-refresh"
    logger.info(f'{job_name} Starting execution for refreshing materialized view {start_time}')
    
    logger.info(f'{job_name} Retrieving credentials and initializing environment variables...')
    configs = read_config(args['configBucket'],f'consumption/glue-scripts/configs/{args["configScript"]}')
    print(f'configs: {configs}')
    username,password,dbEndpoint,port = get_creds_from_secret(configs.get("RDS_PROPERTIES", "rds-secret_name"))
    
    mtvw_name = args["mtvwName"]
    dbName = configs.get("RDS_PROPERTIES", "database")
    rds_schema_name = configs.get("RDS_PROPERTIES", "schema")
    
    # print(f'username: {username}. dbEndpoint: {dbEndpoint}. port: {port}. rds_schema_name: {rds_schema_name}.')
    
    refresh_query_statement = f'refresh materialized view {rds_schema_name}.{mtvw_name};' 
    
    logger.info(f'{job_name} Refreshing materialized view {mtvw_name} with executing statement {refresh_query_statement}')
    response = execute_sql(dbEndpoint, username, password, port, dbName, refresh_query_statement)
    logger.info(f'materialized view {mtvw_name} refreshed successfully!')
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() / 60
    logger.info(f'{job_name} Job completed in {duration:.2f} minutes')
        
if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ["JOB_NAME","configBucket","configScript","mtvwName"])
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args["JOB_NAME"], args)
    logger = glueContext.get_logger()

    main()