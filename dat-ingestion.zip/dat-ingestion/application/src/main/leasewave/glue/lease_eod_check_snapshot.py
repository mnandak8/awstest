import sys
import boto3
import logging
import configparser
from awsglue.context import GlueContext
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.job import Job
from pyspark.context import SparkContext

import time
from datetime import datetime, timedelta
import pytz

def read_config_file(config_bucket, config_path, config_file):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=config_bucket, Key=f'{config_path}/{config_file}')
    data = obj['Body'].read()
    config_params = configparser.ConfigParser()
    config_params.read_string(data.decode())
    return config_params

def poll_for_date(src_conn, cur_dt_query, table, poll_interval, time_out):
    #Define target date as yesterday's business day
    start_time = time.time()
    mountain_tz = pytz.timezone('America/Denver')
    cur_dt = datetime.now(mountain_tz).date()
    #tgt_dt is the date we want to find the snapshot for
    tgt_dt = cur_dt - timedelta(days=1)
    #tgt_dt = cur_dt
    logger.info(f"Looking for Target Date: {tgt_dt}")

    #Start checking business date available in source database and redo until time out
    cycle_nb = 0
    while time.time() - start_time < time_out:
        cycle_nb = cycle_nb + 1
        df = glue_context.create_dynamic_frame.from_options(
            connection_type = "sqlserver",
            connection_options = {
            "useConnectionProperties": "true",
            "connectionName": src_conn,
            "dbtable": table,
            "sampleQuery": cur_dt_query
            }
        ).toDF()

        if not df.rdd.isEmpty():
            cur_dt = df.collect()[0][0]
            logger.info(f"cur_dt={cur_dt}")
            if cur_dt == tgt_dt:
                logger.info("Target date: {tgt_dt} is available")
                return True
        logger.info(f"Target date is not available,looking for {tgt_dt} but found {cur_dt}. Well, will pause for {poll_interval} seconds, then loop back ;) ")
        time.sleep(poll_interval)

    logger.error(f"cycle_nb={cycle_nb}, time out={time_out} seconds reached, target date: {tgt_dt} still not available instead found {cur_dt}")
    return False

def main():
    start_time = datetime.now()
    logger.info(f"Starting execution for job at {start_time}")
    
    #Read Glue job parameters
    args = getResolvedOptions(sys.argv, ["JOB_NAME", "configBucket", "configPath", "configFile"])
    config_bucket = args['configBucket']
    config_path = args['configPath']
    config_file = args['configFile']
    logger.info(f"config bucket={config_bucket}, config_path={config_path}, config file={config_file}")
    
    #Read config file to get additional parameters
    config_params = read_config_file(config_bucket, config_path, config_file)

    src_conn = config_params.get("SRC_PROPERTIES", "jdbc-connection-name")
    src_db = config_params.get("SRC_PROPERTIES", "database")
    src_owner = config_params.get("SRC_PROPERTIES", "owner")
    logger.info(f"src_conn={src_conn}, src_db={src_db}, src_owner={src_owner}")
    
    #Define additional variables
    table = "businessunits"
    #This is query that retrieves the date for which the current LeaseWave snapshot is
    #cur_dt_query = f'select dateadd(day, 60, CurrentBusinessDate) CurrentBusinessDate from {src_db}.{src_owner}.{table}'
    cur_dt_query = f'select CurrentBusinessDate from {src_db}.{src_owner}.{table}'
    poll_interval = 60
    time_out = 3600

    #Find current bus date available
    return poll_for_date(src_conn, cur_dt_query, table, poll_interval, time_out)

if __name__ == "__main__":
    # Initialize logging and Glue Spark context
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    sc = SparkContext()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session

    rtn = main()
    end_time = datetime.now()
    if not rtn:
        logger.error(f"DB snapshot for yesterday's business date not available, exiting the job at {end_time}")
        sys.exit(0)

    logger.info(f"Completed execution for job at {end_time}")
