import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame
from datetime import date, datetime
import configparser
import boto3
#from utils.audit_utils import *
from utils.s3_utils import *


# Reads config file from S3 bucket
def read_config(bucket_name, config_file_name):
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=bucket_name, Key=f'ingestion/glue-scripts/configs/{config_file_name}')
    data = obj['Body'].read()
    config = configparser.ConfigParser()
    config.read_string(data.decode())

    print(config.sections())

    return config

# Generates target folder path in Landing to write the data
def generate_target_folder_path(bucket_name, src_type, owner, table_name,date2process):
    _date2process = f"{date2process}".split("/")
    _date2process_yr = _date2process[0]
    _date2process_mo = _date2process[1]
    _date2process_day = _date2process[2]
    s3_path = f's3://{bucket_name}/eod/{owner}/{table_name}/{_date2process_yr}/{_date2process_mo}/{_date2process_day}/'
    return s3_path

def move_to_failed(current_path,s3_bucket, table_name):
    source_prefix = current_path.replace(f's3://{s3_bucket}/','')

    logger.info(f'{table_name} Moving failed files from {s3_bucket}/{source_prefix} to failed')
    objects = list_files(s3_bucket, source_prefix)

    # Move each object to target folder
    for obj in objects.get('Contents', []):
        key = obj['Key']

        failed_key = key.replace(f'{table_name}/',f'failed/{table_name}/')
        move_file(s3_bucket, key, failed_key)


### Validates counts of source and target
### Moves files to failed if count does not match
def validate_count(s3_path, total_count_from_db, s3_bucket, table_name):
    
    s3_data = glueContext.create_dynamic_frame.from_options(format_options={}, 
                                                        connection_type="s3", format="parquet", 
                                                        connection_options={"paths": [s3_path], "recurse": True}, 
                                                        transformation_ctx="s3_data")

    spark_df = s3_data.toDF()
    s3_count = spark_df.count()
    if s3_count == total_count_from_db :
        logger.info(f'{table_name} Counts matched !')
        return None
    else:
        logger.error(f'{table_name} S3 count {s3_count} does not match with sql count {total_count_from_db} !')
        logger.error(f'{table_name} Moving {s3_path} to failed/')
        move_to_failed(s3_path, s3_bucket, table_name)
        return f'S3 count {s3_count} does not match with sql count {total_count_from_db} !'

def read_from_src(src_dbname, owner, table_name, jdbc_conn_name, glueContext):
    print("read_from_src")
    SQL_data = glueContext.create_dynamic_frame.from_options(
        connection_type = "sqlserver",
        connection_options = {
        "useConnectionProperties": "true",
        "connectionName": jdbc_conn_name,
        "dbtable": f'{owner}.{table_name}',
        "query": f'select * from {src_dbname}.{owner}.{table_name}'
        }
        ).toDF()
    return SQL_data

def write_to_s3(SQL_data, s3_path, s3_bucket):
    s3 = boto3.client('s3')
    target_prefix = s3_path.replace(f's3://{s3_bucket}/','')
    if target_prefix.endswith('/'):
        target_prefix = target_prefix[:-1]
    response = s3.list_objects_v2(Bucket=s3_bucket, Prefix=target_prefix)
    if 'Contents' in response and response['KeyCount'] > 0:
        for item in response['Contents']:
            s3.delete_object(Bucket=s3_bucket, Key=item['Key'])
        print(f"Deleted all the files in folder: {s3_path}")
    else:
        print(f"Folder or files in folder: {s3_path} does not exist")
    SQL_data = DynamicFrame.fromDF(SQL_data, glueContext, "Convert")
    s3_write_data = glueContext.write_dynamic_frame.from_options(
            frame=SQL_data,
            connection_type="s3",
            format="glueparquet",
            connection_options={
                "path": s3_path,
                "partitionKeys": [],
            },
            format_options={"compression": "snappy"
            },
            transformation_ctx="s3_write_data",
        )

def main():

    start_time = datetime.now()
    logger.info(f"Starting execution for merge job at {start_time}")
        
    config_file_name = args['configScript']
    table_name = args['tableName']
    config_bucket = args['configBucket']
    s3_bucket = args["landingBucket"]
    date2process = args["date2process"]
    
    logger.info(f'{table_name} Reading configurations from lease-eod.config file')
    #####################################################################################
    configs = read_config(config_bucket, config_file_name)
    src_dbname = configs.get("SRC_PROPERTIES", "database")
    owner = configs.get("SRC_PROPERTIES", "owner")
    jdbc_conn_name = configs.get("SRC_PROPERTIES", "jdbc-connection-name")
    src_type = configs.get("SRC_PROPERTIES", "source-type")
    #####################################################################################

    s3_path = generate_target_folder_path(s3_bucket, src_type, owner, table_name,date2process)

    jobName =f'{args["JOB_NAME"]}_{table_name}'
    #audit_api_url=configs.get("AUDIT_PROPERTIES", "audit-conn-url")
    logger.info(f'{table_name}Inserting {jobName} audit entry')
    #jobRunId = insert_audit_balance(jobName, f'sqlTABLE_{src_type}_{table_name}', f'S3_{s3_bucket}', "Glue", f'Copying {table_name} data to {s3_path}', audit_api_url)

    logger.info(f'{table_name} Reading data from {src_dbname}.{table_name} using connection {jdbc_conn_name}')

    SQL_data = None
    try:
        SQL_data = read_from_src(src_dbname, owner, table_name, jdbc_conn_name, glueContext)
    except Exception as e:
        print(Exception, e)
        #update_audit_balance(jobName, jobRunId, f'Read failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'Error while reading from sql table {src_dbname}.{table_name}, Exiting..')

    logger.info(f'{table_name} Writing data to landing bucket {s3_path}')

    total_recosql = SQL_data.count()

    try:
        write_to_s3(SQL_data, s3_path, s3_bucket)

    except Exception as e:
        print(Exception, e)
        #update_audit_balance(jobName, jobRunId, f'Write failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'Error while writing to landing bucket {s3_path}, exiting..')
    

    job.commit()
    logger.info(f'{table_name} Completed loading {table_name} data to path {s3_path}')
    logger.info(f'{table_name} Validating the counts now..')
    returnMessage = validate_count(s3_path, total_recosql, s3_bucket, table_name)
    #LastModifiedDataDate : Not available for lease_eod
    end_time = datetime.now()
    if returnMessage == None: 
        #update_audit_balance(jobName, jobRunId, f'Job execution completed in {(end_time - start_time)/60} minutes', "Successful", audit_api_url, f'{total_recosql}')
        logger.info(f'{table_name} Job execution completed in {((end_time - start_time)/60)} minutes')
    else:
        #update_audit_balance(jobName, jobRunId, returnMessage, "Failed", audit_api_url)
        sys.exit(f'{returnMessage}, Exiting..')


if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ["JOB_NAME","configScript","tableName","configBucket","landingBucket","date2process"])
    sc = SparkContext()
    glueContext = GlueContext(sc)
    job = Job(glueContext)
    job.init(args["JOB_NAME"], args)
    logger = glueContext.get_logger()

    # Set Spark configurations 
    spark = glueContext.spark_session
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

    main()
