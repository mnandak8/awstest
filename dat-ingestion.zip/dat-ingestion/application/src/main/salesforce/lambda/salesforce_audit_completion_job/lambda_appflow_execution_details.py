from audit_utils import update_audit_balance
import boto3
def lambda_handler(event, context):
    parameter_flow_name = event['flow_name_key']
    parameter_run_id = event['run_id_key']
    print(f"runid: {parameter_run_id}")
    audit_api_url = event['audit_api_url']
    # Initialize appflow client
    appflow_client = boto3.client('appflow')

    # getting response from appflow
    response = appflow_client.describe_flow_execution_records(
    flowName= parameter_flow_name
)
    list_execution_executionId = response["flowExecutions"]
    latest_execution_details = list_execution_executionId[0]
    
    latest_executionStatus  = latest_execution_details["executionStatus"]
    
    #record count 
    recordsProcessedCount = str(latest_execution_details["executionResult"]["recordsProcessed"])
        
    update_audit_balance(parameter_flow_name,parameter_run_id, f'Status {latest_executionStatus} recieved form appflow', latest_executionStatus, audit_api_url, recordsProcessedCount)

    return {
        'body': f'runid: {parameter_run_id}'
    }
    