from datetime import datetime,timezone
import requests
import json

####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
##### REFER readme.txt file before updating this file
####################################################################

def call_audit_api(payload,isInsert,api_url):

    # API endpoint URL
    # api_url = 'https://mid3caxpma.execute-api.us-west-2.amazonaws.com/dev/audit'
    json_payload = json.dumps(payload)
    print(f'Calling {api_url} with following json:\n{json_payload}')
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    try:
        # Make the API request
        if isInsert:
            response = requests.post(api_url, data=json_payload, headers=headers)
        else:
            response = requests.put(api_url, data=json_payload, headers=headers)
            
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            print(f'API call successful, with response {response.json()}')
            return response.json()['jobRunId']
        else:
            print("API call failed with status code:", response.status_code)
            print("Response:", response.text)

    except Exception as e:
        print("Error:", str(e))


def insert_audit_balance(jobName, source, target, runBy, statusDesc,api_url):

    #TODO Add isStarted flag in case we have other cases of inserting audit records apart from STARTED

    # Payload to send to the API
    payload = {
        "jobName": jobName,
        "source": source,
        "target": target,
        "runStartDateTime": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S") ,
        "runBy": runBy,
        "runStatus": "Started",
        "runStatusDesc": statusDesc
    }

    jobRunId = call_audit_api(payload,True,api_url)
    return jobRunId


def update_audit_balance(jobName, jobRunId, statusDesc, status, api_url, targetRecordCount=None, lastModifiedDataDate=None):
    # Payload to send to the API

    payload = {
        "jobName": jobName,
        "jobRunId": jobRunId,
        "runEndDateTime": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S") ,
        "runStatus": status,
        "runStatusDesc": statusDesc,
    }

    if lastModifiedDataDate is not None : payload["lastModifiedDataDate"] = lastModifiedDataDate
    if targetRecordCount is not None : payload["targetRecordCount"] = targetRecordCount

    call_audit_api(payload,False,api_url)

