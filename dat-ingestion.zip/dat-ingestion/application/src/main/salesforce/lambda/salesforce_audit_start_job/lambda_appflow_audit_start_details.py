from  audit_utils import insert_audit_balance
import boto3
def lambda_handler(event, context):
    parameter_flow_name = event['flow_name_key']
    parameter_object_name = event['object_name_key']
    audit_api_url = event['audit_api_url']
    source_object = f"Salesforce_{parameter_object_name}"
    #TODO Remove hardcoded landing bucket
    jobRunId = insert_audit_balance(parameter_flow_name, source_object, 'S3_cobank-dl-us-west-2-landing','AppFlow','Extract Records from salesforce and load to s3',audit_api_url)
    
    print(f"jobRunId: {jobRunId}")
    return {
        'statusCode': 200,
        'body': f'jobrunid: {jobRunId}'
    }