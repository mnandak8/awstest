import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import datetime
from utils.config_utils import *
from utils.audit_utils import *
from utils.s3_utils import *
from utils.secret_utils import *
from utils.rds_postgres_utils import read_from_rds,write_to_rds,execute_sql
from datetime import datetime
from pyspark.sql.functions import lit, col,count, when
from pyspark.sql.types import IntegerType,StringType,DoubleType
from pyspark.sql.functions import udf


####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
##### REFER readme.txt file before updating this file
####################################################################

# Generates landing folder path to write the data
def generate_destination_folder_path(bucket_name, source_type, table_name):
    current_time = datetime.now()
    file_name = f'{source_type}_{table_name}_{current_time.strftime("%Y-%m-%d %H-%M-%S")}'
    s3_path = f's3://{bucket_name}/{source_type}/{table_name}/{current_time.year}/{current_time.month}/{current_time.day}/{file_name}'
    return s3_path


def remove_substring_from_end(s, sub):

    if not s.endswith(sub):
        return s
    
    # Find the index of the last occurrence of the substring
    last_index = s.rfind(sub)
    
    # If the substring is not found, return the original string
    if last_index == -1:
        return s
    
    # Remove the last occurrence of the substring
    return s[:last_index] + s[last_index + len(sub):]


def move_to_failed(current_path,s3_bucket,table_name):
    print(f'current path {current_path}')
    source_prefix = current_path.replace(f's3://{s3_bucket}/','')
    print(f'source_prefix {source_prefix}')

    logger.info(f'{table_name}_rds_load Moving failed files from {s3_bucket}/{source_prefix} to consumption_rds_failed/')
    objects = list_files(s3_bucket, source_prefix)

    # Move each object to the destination folder
    for obj in objects.get('Contents', []):
        key = obj['Key']

        failed_key = key.replace(f'{table_name}/',f'consumption_rds_failed/{table_name}/')
        move_file(s3_bucket, key, failed_key)


### Validates counts of source and target
### Moves files to failed if count does not match
def validate_count(s3_path,s3_count, s3_bucket, schema, rds_table_name, username,password,dbEndpoint,port, rds_dbname):
    
    ## Take count from S3 : Already have count taken after reading
    ## Take count from RDS 
    ## Compare
    ## If not matched --> Move all S3 files to failed/2024 etc
    ## Mark job as failed

    # # Database connection properties
    # jdbc_url = f'jdbc:postgresql://{dbEndpoint}:{port}/{rds_dbname}'
    # properties = {
    #     "user": username,
    #     "password": password,
    #     "driver": "org.postgresql.Driver"
    # }

    # # Read data from the PostgreSQL table
    # df = spark.read.jdbc(url=jdbc_url, table=f'{schema}.{rds_table_name}', properties=properties)

    rds_data = read_from_rds(dbEndpoint, port, rds_dbname, username, password, schema, rds_table_name, spark)
    # Count the number of records
    rds_count = rds_data.count()
    print(f'Count from rds {rds_count}')

    if s3_count == rds_count :
        logger.info(f'{rds_table_name}_rds_load Counts matched !')
        return None
    else:
        logger.error(f'{rds_table_name}_rds_load S3 count {s3_count} does not match with rds count {rds_count} ')
        logger.error(f'{rds_table_name}_rds_load Moving {s3_path} to consumption_rds_failed/ ')
        move_to_failed(s3_path,s3_bucket,rds_table_name)
        return f'S3 count {s3_count} does not match with rds count {rds_count} !'

def write_sfdc_to_rds(landingDf, schema, tableName, dbName, username,password,dbEndpoint,port):
    if(not landingDf.isEmpty()):
        # Take backup
        logger.info(f'{tableName}_rds_load Taking backup for the data before updating...')
        backup_query = f'drop table if exists {schema}.{tableName}_backup; create table {schema}.{tableName}_backup as select * from {schema}.{tableName}'
        execute_sql(dbEndpoint, username, password, port, dbName, backup_query)
        # Truncate the table
        logger.info(f'{tableName}_rds_load Truncating table for overwrite!')
        truncate_query = f'truncate table {schema}.{tableName};'
        execute_sql(dbEndpoint, username, password, port, dbName, truncate_query)
        logger.info(f'{tableName} Table truncated! ')
        try:
            logger.info(f'{tableName}_rds_load Writing to Aurora postgresql rds table ')
            write_to_rds(landingDf, schema, tableName, dbName, username,password,dbEndpoint,port)
            logger.info(f'{tableName}_rds_load Finished writing data to Aurora postgresql rds table ')

            drop_backup = f'drop table if exists {schema}.{tableName}_backup;'
            execute_sql(dbEndpoint, username, password, port, dbName, drop_backup)
        except Exception as e:
            print(Exception, e)
            logger.info(f'{tableName}_rds_load ERROR while writing the data to rds table, restoring the backup... ')
            restory_query = f'truncate table {schema}.{tableName}; insert into {schema}.{tableName} select * from {schema}.{tableName}_backup; drop table if exists {schema}.{tableName}_backup;'
            execute_sql(dbEndpoint, username, password, port, dbName, restory_query)
            raise e
    else:
        logger.info(f'{tableName}_rds_load Empty! Skipping the write to rds ')


def add_metadata_columns(df,tableName):
    updatedDf = df.withColumn("execution_user", lit("cobank-glue-role")) \
        .withColumn("load_timestamp", lit(datetime.now())) \
        .withColumn("update_timestamp", lit(datetime.now())) \
        .withColumn("load_operation", lit("Glue"))

    logger.info(f'{tableName}_rds_load metadata columns added!')

    return updatedDf


def remove_null_columns(df,tableName):
    # logger.info(f'{tableName}_rds_load removing null columns if any!')

    null_counts = df.select([count(when(col(c).isNull(), c)).alias(c) for c in df.columns]).collect()[0].asDict() 
    df_null_size = df.count() 
    to_drop = [k for k, v in null_counts.items() if v == df_null_size] 
    logger.info(f'{tableName}_rds_load removing null columns from the list --> {to_drop}')

    # Drop all the columns present in null column list. 
    nonNullDf = df.drop(*to_drop) 

    return nonNullDf

def main():

    start_time = datetime.now()
    logger.info(f'rds_load Starting execution for merge job at {start_time}')
        
    ## STEP1 : Read job arguments
    table_name = args['tableName']
    rds_dbname = args['rdsDatabase']
    s3_bucket = args["landingBucket"]
    jobName =f'{args["JOB_NAME"]}_{table_name}'

    ## STEP2 : Read config file from s3
    logger.info(f'{table_name}_rds_load Reading configurations from {args["configBucket"]} bucket, sfdc config file consumption '\
                f'glue-scripts/configs/{args["configScript"]}')
    configs = read_config(args['configBucket'],f'consumption/glue-scripts/configs/{args["configScript"]}')
    audit_api_url=configs.get("AUDIT_PROPERTIES", "audit-conn-url")
    
    s3_prefix = '/'.join([rds_dbname.lower(), args['s3LandingPath'], args['date2process']])
    s3_latest_path = get_latest_subfolder(s3_bucket, s3_prefix)
    s3_latest_full_path = f's3://{s3_bucket}/{s3_latest_path}'

    if s3_latest_path is None:
        sys.exit(f'No data found for {s3_prefix}, Skipping the load!')
    
    # table_name = remove_substring_from_end(table_name,"_c")

    ## STEP3 : Insert Audit entry before starting logical job parameters
    logger.info(f'{table_name}_rds_load Inserting {jobName} audit entry')
    jobRunId = insert_audit_balance(jobName, f'CON_RDS_{table_name}'
                                    , f'S3_{s3_bucket}'
                                    , "Glue", 
                                    f'Copying {table_name} data from {s3_latest_full_path} to consumption rds table {table_name}'
                                    ,audit_api_url)
    logger.info(f'{table_name}_rds_load Reading data from {s3_latest_full_path}')

    ## STEP4 :  Read from S3 bucket
    landingDf = None
    try:
        landingDf = read_from_landing(glueContext, "parquet", "true", "False", s3_latest_full_path)
        total_records = landingDf.count()
        logger.info(f'{table_name}_rds_load total_records: {total_records}')
    except Exception as e:
        print(Exception, e)
        logger.error(f'{table_name}_rds_load [ERROR] Read failed with ERROR {type(e)}: {e}')
        update_audit_balance(jobName, jobRunId, f'Read failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'{table_name}_rds_load Error while reading from S3 landing bucket {s3_latest_full_path}, Exiting..')
    
    try:
        ## STEP5 : Remove null columns and Add metadata column expected in RDS consumption Table
        nonNullDf = remove_null_columns(landingDf, table_name)
        updatedDf = add_metadata_columns(nonNullDf,table_name)

        ## STEP6 : Read rds creds from secret
        username,password,dbEndpoint,port = get_creds_from_secret(configs.get("RDS_PROPERTIES", "rds-secret_name"))

        ## STEP7 : Write processed data to consumption RDS table
        logger.info(f'{table_name}_rds_load Writing data to rds table {table_name}')
        write_sfdc_to_rds(updatedDf, configs.get("RDS_PROPERTIES", "schema"), table_name, rds_dbname, username,password,dbEndpoint,port)

    except Exception as e:
        print(Exception, e)
        logger.error(f'{table_name}_rds_load [ERROR] Write failed with ERROR {type(e)}: {e}')
        update_audit_balance(jobName, jobRunId, f'Write failed with ERROR {type(e)}: {e}', "Failed",audit_api_url)
        sys.exit(f'Error while writing to consumption RDS table {rds_dbname}.{table_name}, exiting')
    
    job.commit()
    logger.info(f'{table_name}_rds_load Completed writing total {total_records} records from {s3_latest_full_path} to {table_name}, Validating the counts now..')

    try:
        ## STEP8 : Validate counts on source and target side
        returnMessage = validate_count(s3_latest_full_path,total_records,s3_bucket, configs.get("RDS_PROPERTIES", "schema"), table_name, 
                                    username,password,dbEndpoint,port, rds_dbname)
    except Exception as e:
        print(Exception, e)
        logger.error(f'{table_name}_rds_load [ERROR] Validating counts failed with ERROR {type(e)}: {e}! Skipping validation now!')
        returnMessage = None

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds() / 60
    ## STEP9 : Add Audit completed/failed entry
    if returnMessage == None: 
        update_audit_balance(jobName, jobRunId, 
                             f'Job execution completed in {duration:.2f} minutes'
                             , "Successful"
                             ,audit_api_url
                             , f'{total_records}')
        logger.info(f'{table_name}_rds_load Completed loading {s3_latest_full_path} with total {total_records} records to table {table_name}')
        logger.info(f'{table_name}_rds_load Job execution completed in {duration:.2f} minutes')
    else:
        update_audit_balance(jobName, jobRunId, returnMessage, "Failed",audit_api_url)
        sys.exit(f'{returnMessage}, Exiting..')


if __name__ == "__main__":
    args = getResolvedOptions(sys.argv, ["JOB_NAME","configBucket","configScript"
                                         ,"landingBucket","rdsDatabase", "tableName","s3LandingPath","date2process"])
    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(args["JOB_NAME"], args)
    logger = glueContext.get_logger()

    main()
    