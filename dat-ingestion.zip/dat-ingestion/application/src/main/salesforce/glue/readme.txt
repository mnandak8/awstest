#### STEPS FOR SFDC GLUE JOB #### 

Steps to add new sfdc table for ingestion and manually test the load -
1. Create separate airflow dag file for new acbs table similar to "dat-ingestion\application\src\main\acbs\airflow\acbs2landing_j_cami_etl_dag.py"
2. Add another resource for the new table in "dat-ingestion\application\application-infra\acbs_airflow.tf"
3. Test run the Glue job for new table using any of the following way -
    3.1 Run the aws cli command to trigger glue job from local for new table :
        aws glue start-job-run --region us-west-2 --job-name acbs_to_landing_extract --arguments='--tableName="<>"' --profile <>
    3.2 [OR] For dev, go to console, update/verify all the job arguments and run the job for testing. 
4. Monitar glue job progress from the console or through aws cli commands.
5. Validate data populated on S3 landing folder for the new table.
6. If all ok, check-in the code to feature branch, trigger application workflow on the branch.
7. if the build is through, merge with develop or main branch
