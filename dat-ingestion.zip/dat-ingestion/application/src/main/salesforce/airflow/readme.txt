#### STEPS FOR Create Airflow DAG for appflow flows #### 

Steps to schedule new salesforce object to airflow  -
1. Create separate .py file for new salesforce object similar to "\dat-ingestion\application\scripts\salesforce\airflow-dag-scripts\salesforce2landing_account_etl_dag.py"
2. add new salesforce object in dat-ingestion\application\application-infra\salesforce_airflow.tf
3. Commit changes to branch and deploy 
4. Go to Airflow environment and run DAG