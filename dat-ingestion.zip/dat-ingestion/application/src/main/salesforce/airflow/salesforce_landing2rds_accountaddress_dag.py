from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import  GlueJobOperator
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime, timedelta
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

obj_name = 'account_address__c'
date2process = datetime.now().strftime('%Y/%m/%d/')

default_args = {
    'owner': 'DA',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    f'salesforce_landing2rds_{obj_name}_dag',
    default_args=default_args,
    description=f'Glue landing_to_rds_postgres DAG to load data into consumption rds postgres',
    # schedule_interval="0 13 * * *",
    # start_date=start_date
    on_failure_callback=[sns_notifier.failure_notification]
)

script_arguments = {
    "--tableName": f"{obj_name}",
    "--date2process": date2process,
    "--rdsDatabase" : "Salesforce",
    "--s3LandingPath": "account_address_c/salesforce_to_landing_accountAddress"
}

glue_job_operator = GlueJobOperator(
    task_id=f'run_landing_to_rds_postgres_glue_job',
    job_name='landing_to_rds_postgres',
    dag=dag,
    aws_conn_id='ing_glue',
    script_args=script_arguments
)


# Define tasks/operators
start_task = DummyOperator(task_id='start', dag=dag)
end_task = DummyOperator(task_id='end', dag=dag)

start_task >> glue_job_operator >> end_task
