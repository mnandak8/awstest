from airflow import DAG
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.amazon.aws.operators.appflow import (
AppflowRunOperator,
)
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime,timedelta
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable


sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']


obj_name = 'accountAddress'
obj_name2 = 'account_address_c'#Salesforce task in lakehouse is sometimes different
group_name= 'salesforce'

default_args = { 
    'owner': 'DA',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2),
}
start_date = datetime.today() - timedelta(days=1)

dag = DAG(
    f'{group_name}2landing_{obj_name}_etl',
    default_args=default_args,
    description=f'A DAG to trigger AWS Appflow flows for {obj_name} object',
    schedule_interval="0 0/2 * * *",  # daily 2hrs interval 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification]
)
#Dummy Operator for now
start_operator = DummyOperator(task_id='start', dag=dag)
end_operator = DummyOperator(task_id='end', dag=dag)

# Trigger AppFlow flow
appflow_job_run_operator = AppflowRunOperator(
    task_id=f'{group_name}2landing_{obj_name}_etl_task',
    flow_name=f'{group_name}_to_landing_{obj_name}',
    aws_conn_id='ing_appflow',
    dag=dag
)
# Trigger landing to transform dag
dag_run_operator = TriggerDagRunOperator(
    task_id=f'run_landing2transform_{group_name}-{obj_name}_etl_dag',
    trigger_dag_id=f'landing2transform-{group_name}-{obj_name2}-etl',
    trigger_rule = 'all_success',   
    dag=dag
)

# # Trigger landing to rds dag
# dag_run_operator_rds = TriggerDagRunOperator(
#     task_id='salesforce_landing2rds_account_address__c_dag',
#     trigger_dag_id='salesforce_landing2rds_account_address__c_dag',
#     trigger_rule='all_success',
#        dag=dag
# )

start_operator >> appflow_job_run_operator  >> dag_run_operator >> end_operator
