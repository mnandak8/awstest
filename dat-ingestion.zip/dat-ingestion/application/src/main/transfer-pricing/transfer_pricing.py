import time
import requests
import requests_ntlm
import boto3
import logging
import csv
import json
import pyodbc
from botocore.exceptions import ClientError
import os
import pandas as pd
from io import StringIO
import hashlib

region = "us-west-2"

# Initialize logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

MAX_RETRIES = int(os.environ.get('MAX_RETRIES', "5")) # Maximum number of retries before sending to DLQ
sqs_url = os.environ['SQS_URL'] # Will requeue to this queue, presumed to be feeding this lambda, if we need a delayed retry
dlq_url = os.environ['DLQ_URL'] # Will send to this queue if we exceed the maximum retries

# Initialize clients
s3_client = boto3.client('s3', region_name = region)
sqs_client = boto3.client('sqs', region_name = region)

# Function to hash the account number
def hash_account_number(account_number):
    return hashlib.sha256(account_number.encode()).hexdigest()

def get_credentials(secret_name):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region)
    
    try:
        logger.info("Getting credentials..")
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        secret = get_secret_value_response['SecretString']
        return json.loads(secret)
    except ClientError as e:
        raise Exception(f"Failed to retrieve secret: {str(e)}")
    
def connect_to_rapport_db(secret_name):
    logger.info('Retrieving RDS Connection Credentials')
    rapport_secret = get_credentials(secret_name)
    logger.info('Retrieved RDS Connection Credentials')

    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={rapport_secret['host']},{rapport_secret['port']};"
        f"DATABASE={rapport_secret['database']};"
        f"UID={rapport_secret['username']};"
        f"PWD={rapport_secret['password']}"
    )
    conn = pyodbc.connect(conn_str)
    return conn

def reenqueue_message(message_body, delay_seconds, retry_count):
    if retry_count > MAX_RETRIES:
        logger.error(f"Exceeded maximum retries: {MAX_RETRIES}")
        # Send to DLQ since we've exhausted our retries
        send_to_dlq(message_body)
        return
    logger.info("Re-enqueueing message")
    sqs_client.send_message(
        QueueUrl=sqs_url,
        MessageBody=message_body,
        DelaySeconds=delay_seconds,
        MessageAttributes={
            'RetryCount': {
                'DataType': 'Number',
                'StringValue': str(retry_count)
            }
        }
    )
    logger.info(f"Re-enqueued message with delay of {delay_seconds} seconds")

# Send the event to the DLQ if necessary
def send_to_dlq(message_body):
    sqs_client.send_message(
        QueueUrl=dlq_url,
        MessageBody=message_body
    )
    logger.info(f"Sent message to DLQ")


# get bearer token (for Treasury Connect API call)
def get_token(url, clientId, clientSecret, scope):
    logger.info(f"Token Get Request URL: {url}")
    response = requests.post(url, data = {'client_id': clientId, 'client_secret': clientSecret, 'grant_type': 'client_credentials', 'scope': scope})
    logger.info(f"Token Get Response: {response.status_code}")
    response.raise_for_status()
    token = response.json()['access_token']
    return token


def lambda_handler(event, context):

    logger.info(event)

    # TODO Support EventResponse batchItemFailures?  DWill need to set event-source-mapping response type to ReportBatchItemFailures
    if 'Records' in event:
        for record in event['Records']: # this is SQS record
        
            # Read the file from S3 bucket, get bucket name and key name from event
            logger.info(record)

            retry_count = 0
            # TODO Are we retrying this event/message from a previous failure?  Log this so we can make sure it doesn't try forever.
            if record.get('messageAttributes', {}).get('RetryCount', {}).get('stringValue'):
                retry_count = int(record['messageAttributes']['RetryCount']['stringValue'])
                logger.info(f"Retrying message with retry count: {retry_count}")
                if retry_count > MAX_RETRIES:
                    logger.error(f"Exceeded maximum retries: {MAX_RETRIES}")
                    # Send to DLQ since we've exhausted our retries
                    send_to_dlq(json.loads(record['body']))
                    return {
                        'statusCode': 200,
                        'body': json.dumps('Exceeded maximum retries, sent to DLQ')
                    }

            try:
                message_body = record['body'] # this is S3 event record
                message_json = json.loads(message_body)
                bucket_name = message_json['Records'][0]['s3']['bucket']['name'] 
                object_key = message_json['Records'][0]['s3']['object']['key']
                
                logger.info(f"Reading file {object_key} from bucket {bucket_name}")
                bucket_response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
                csv_content = bucket_response['Body'].read().decode('utf-8')
                # Convert the CSV content to a pandas DataFrame
                df = pd.read_csv(StringIO(csv_content))
                logger.info(f"File read successfully with shape: {df.shape}")

                # The SETUP_FKEY could be from one of two tables that has different column names

                # Get the setup key values
                if 'RPT_CO' in object_key:
                    # Only process RPT_CO records whose CO_UD_APP_STATUS has transitioned to 5 or 27
                    # Note: An update through Rapport UI results in a delete and insert, so have to compare across rows in that case
                    df = df[((df.Op == 'I') & (df.Op.shift(1) == 'D') & (df.SETUP_FKEY == df.SETUP_FKEY.shift(1)) & (df.CO_UD_APP_STATUS != df.CO_UD_APP_STATUS.shift(1)) & (df.CO_UD_APP_STATUS.isin([5, 27]))) | ((df.Op == 'U') & (df.CO_UD_APP_STATUS != df.BI_CO_UD_APP_STATUS) & (df.CO_UD_APP_STATUS.isin([5, 27])))]
                    setup_fkey_values = df['SETUP_FKEY'].tolist()
                    logger.info(f"SETUP_FKEY value: {setup_fkey_values}")
                    # Remove duplicates
                    setup_fkey_values = list(set(setup_fkey_values))
                    logger.info(f"SETUP_FKEY value after removing duplicates: {setup_fkey_values}")
                elif 'CONTRACT_SETUP' in object_key:
                    # Only process CONTRACT_SETUP records whose CTS_DECISION_CODE_FKEY has transitioned to 7
                    # Note: These are Update operations only, we can ignore Deletes here
                    df = df[((df.Op == 'U') & (df['CTS_DECISION_CODE_FKEY'] != df['BI_CTS_DECISION_CODE_FKEY']) & (df['CTS_DECISION_CODE_FKEY'] == 7))]
                    setup_fkey_values = df['CTS_CONTRACT_SETUP_KEY'].tolist()
                    logger.info(f"CTS_CONTRACT_SETUP_KEY value: {setup_fkey_values}")
                    # Remove duplicates
                    setup_fkey_values = list(set(setup_fkey_values))
                    logger.info(f"CTS_CONTRACT_SETUP_KEY value after removing duplicates: {setup_fkey_values}")
                else:
                    logger.error(f"File {object_key} not supported")
                    # Send back 200 so this message isn't sent to DLQ.  It can't be processed.
                    return {
                        'statusCode': 200,
                        'body': json.dumps('File not supported')
                    }
                
                if setup_fkey_values == None or len(setup_fkey_values) == 0:
                    logger.info("No valid SETUP_FKEY trigger condition found.  Nothing to process.")
                    # Send back 200 so this message isn't sent to DLQ.  It can't be processed.
                    return {
                        'statusCode': 200,
                        'body': json.dumps('No valid SETUP_FKEY trigger condition found.  Nothing to process.')
                    }
            except Exception as e:
                logger.error(f"Error while retrieving S3 object: {str(e)}")
                # Send back 500 so this message goes to the DLQ via SQS policy.
                # TODO or should we just send to DLQ directly?
                return {
                    'statusCode': 500,
                    'body': json.dumps('Error reading file from S3 bucket')
                }

            logger.info('Fetching Rapport DB Secret Environment Variable')
            rapport_secret_name = os.environ['RAPPORT_DB_SECRET_NAME']
            logger.info('Fetching Rapport DB Secret Environment Variable - Successful')

            logger.info('Fetching TC API Secret Environment Variable')
            tc_secret_name = os.environ['TC_SECRET_NAME']
            logger.info('Fetching TC API Secret Environment Variable - Successful')

            try:
                tc_secret = get_credentials(tc_secret_name)
                logger.info("Connecting to Rapport DB SQL Server..")
                # Initialize connection to SQL Server
                connection = connect_to_rapport_db(rapport_secret_name)
                logger.info("Connected to Rapport DB SQL Server..")
                cursor = connection.cursor()

                for value in setup_fkey_values:

                    logger.info("Executing SQL query..")
                    # Execute SQL query from dev.tfvars
                
                    # Execute the query with the parameter
                    cursor.execute(os.environ['RAPPORT_SQL_QUERY'], value)
                    result = cursor.fetchall()

                    # print result
                    #logger.info(f"Result: {sanitize_obj(result)}")

                    # Convert result to dict
                    result_dict = [dict(zip([column[0] for column in cursor.description], row)) for row in result]
                    logger.info(f"Result Dict: {sanitize_obj(result_dict)}")

                    # Make Leasewave Get API call based on party number from result_dict
                    party_response = None
                    try:
                        # Make Leasewave Get API call based on party number from result_dict
                        party_number = result_dict[0]['Dealer Reference Number']
                        if (party_number):
                            lw_url = f"{tc_secret['lw_url']}partynumber=%22{party_number}%22?select=ParentParty.Id,ParentParty.PartyNumber,ParentParty.PartyName,ParentParty.Alias"
                            logger.info(f"Calling LeaseWave API: {sanitize_obj(lw_url)}")
                            response = requests.get(lw_url, 
                                            auth=requests_ntlm.HttpNtlmAuth(f'NA\\{tc_secret['lw_username']}',f'{tc_secret['lw_password']}'))
                            # Seems that the LW API returns a byte-order-mark in its response
                            response.encoding = 'utf-8-sig'
                            # Log what we got, even if the response is an API failure
                            logger.info(f"Leavewave Get Response: {response.status_code} {sanitize_obj(response.json()) if (response.headers.get('content-type') == 'application/json')  else sanitize_obj(response.text)}")
                            response.raise_for_status()
                            party_response = response.json()[0]
                        else:
                            logger.info("No Dealer Reference Number, will not call LeaseWave API")
                    except Exception as e:
                        logger.error(f"Leasewave Get Error: {str(e)}")
                        reenqueue_message(record['body'], delay_seconds=300, retry_count=retry_count + 1)
                        break

                    # Get token for TC API call
                    token = get_token(tc_secret['tc_token_url'], tc_secret['tc_client_id'], tc_secret['tc_client_secret'], tc_secret['tc_scope'])

                    # Make POST API call
                    url = tc_secret['tc_url']
                    api_key = tc_secret['api_key']
                    logger.info(f"Making TC POST API call: {sanitize_obj(url)}")
                    headers = {
                        "Content-Type": "application/json",
                        "X-Internal-Api-Key": f"{api_key}",
                        "Authorization": f"Bearer {token}"
                    }

                    data = {
                        "SetupFKey": result_dict[0]['SETUP_FKEY'],
                        "AccountNumber": result_dict[0]['AccountNumber'] or "",
                        "CustomerName": result_dict[0]['CustomerName'] or "",
                        "CustomerNumber": result_dict[0]['CustomerNumber'] or "",
                        "BookingDate": convertDateTimeObjectToString(result_dict[0]['BookingDate']) or "",
                        "CoVariablePymtCode": result_dict[0]['CO_VARIABLE_PYMT_CODE'] or "",
                        "CommencementDate": convertDateTimeObjectToString(result_dict[0]['CommencementDate']) or "",
                        "FirstPrincipalPaymentDate": convertDateTimeObjectToString(result_dict[0]['FirstPrincipalPaymentDate']) or "",
                        "FirstInterestPaymentDate": convertDateTimeObjectToString(result_dict[0]['FirstInterestPaymentDate']) or "",
                        "NextRepriceDate": convertDateTimeObjectToString(result_dict[0]['NextRepriceDate']) or "",
                        "MaturityDate": convertDateTimeObjectToString(result_dict[0]['MaturityDate']) or "",
                        "AmortizationMaturityDate": convertDateTimeObjectToString(result_dict[0]['AmortizationMaturityDate']) or "",
                        "PricingAmount": convertDecimalObjectToString(result_dict[0]['PricingAmount']) or "",
                        "LeaseResidualAmount": convertDecimalObjectToString(result_dict[0]['LeaseResidualAmount']) or "",
                        "DayCountConvention": result_dict[0]['DayCountConvention'] or "",
                        "ExpectedRate": convertDecimalObjectToString(result_dict[0]['ExpectedRate']) or "",
                        "ExpectedRate": convertDecimalObjectToString(result_dict[0]['ExpectedRate']) or "",
                        "CoPretaxYield": convertDecimalObjectToString(result_dict[0]['CO_PRETAX_YIELD']) or "",
                        "InterestRate": convertDecimalObjectToString(result_dict[0]['InterestRate']) or "",
                        "LineOfBusiness": result_dict[0]['LineOfBusiness'] or "",
                        "ParticipationTypeId": result_dict[0]['ParticipationTypeId'],
                        "NetHoldPercentage": convertDecimalObjectToString(result_dict[0]['NetHoldPercentage']),
                        "NetHoldAmount": convertDecimalObjectToString(result_dict[0]['NetHoldAmount']),
                        "PartnerName": result_dict[0]['DLR_NAME'] or "",
                        "WholesalePrepaymentOption": result_dict[0]['WholesalePrepaymentOption'] or "",
                        "PrincipalPaymentFrequency": result_dict[0]['PrincipalPaymentFrequency'] or "",
                        "CoUdAmrSoftcostStatusTbdesc": result_dict[0]['CO_UD_AMR_SOFTCOST_STATUS_TBDESC'] or "",
                        "CoLeaseTypeTbdesc": result_dict[0]['CO_LEASE_TYPE_TBDESC'] or "",
                        "CoUdAppStatus": result_dict[0]['CO_UD_APP_STATUS'] or "",
                        "CoUdAppStatusTbdesc": result_dict[0]['CO_UD_APP_STATUS_TBDESC'] or "",
                        "LockoutDate": convertDateTimeObjectToString(result_dict[0]['LockoutDate']) or "",
                        "CtsDecisionCodeFKey": result_dict[0]['CTS_DECISION_CODE_FKEY'] or "",
                        "DefaultDesc": "Booked",
                        "ParentPartyId" : (party_response or {}).get('ParentParty', {}).get('Id'),
                        "PartyNumber" : (party_response or {}).get('ParentParty', {}).get('PartyNumber') or "",
                        "ParentBank" : (party_response or {}).get('ParentParty', {}).get('Alias') or "",
                        "PartyName" : (party_response or {}).get('ParentParty', {}).get('PartyName') or ""
                    }

                    logger.info(f"Data: {json.dumps(sanitize_obj(data))}")

                    response = requests.post(url, headers=headers, data=json.dumps(data))
                    logger.info(f"TC API call response: {response.status_code} {sanitize_obj(response.json()) if (response.headers.get('content-type') == 'application/json')  else sanitize_obj(response.text)}")
                    response.raise_for_status()

                    logger.info(f"TC API call successful: status_code: {response.status_code} json: {sanitize_obj(response.json())}")
                # Close cursor and connection to SQL Server
                cursor.close() 
                connection.close()
                logger.info("Closed connection to Rapport DB SQL Server..")   

            except ConnectionError as ce:
                logger.error(f"Connection Error: {str(ce)}")
                reenqueue_message(record['body'], delay_seconds=300, retry_count=retry_count + 1)
                break
            except Exception as e:
                # this could be a connection issue
                logger.error(f"Error: {str(e)}")
                reenqueue_message(record['body'], delay_seconds=300, retry_count=retry_count + 1)
                break
        
    else:
        logger.error("No records found in event")
        # Send back 200 so this message isn't sent to DLQ.  It can't be processed.
        return {
            'statusCode': 200,
            'body': json.dumps('No records found in event')
        }

def convertDateTimeObjectToString(dateObject):
    # add check if None
    if dateObject is None:
        return None
    return dateObject.strftime("%Y-%m-%d")

def convertDecimalObjectToString(decimalObject):
    if decimalObject is None:
        return None
    return str(decimalObject)

def sanitize_obj(in_obj):
    # Define keys that contain sensitive information
    sensitive_keys = ['password', 'token', 'access_token', 'secret', 'apiKey', 'AccountNumber', 'CustomerName', 'CustomerNumber', 'PartyName']
    
    def mask_value(value):
        return '***MASKED***'
    
    def sanitize(obj):
        if isinstance(obj, dict):
            return {k: (mask_value(v) if k in sensitive_keys else sanitize(v)) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [sanitize(item) for item in obj]
        else:
            return obj
    
    return sanitize(in_obj)
