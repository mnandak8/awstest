import importlib
import sys
import unittest
from unittest.mock import patch, MagicMock
from io import BytesIO
from application.src.main.leasewave.glue.lease_eod_to_landing_extract import generate_target_folder_path, read_config, move_to_failed, validate_count, read_from_src
from application.src.main.leasewave.glue import lease_eod_to_landing_extract as mod

class TestLeaseEODToLandingExtract(unittest.TestCase):

    @patch("application.src.main.leasewave.glue.lease_eod_to_landing_extract.generate_target_folder_path")
    def test_generate_target_folder_path(self, mock_path):
        bucket_name = "dummy-bucket"
        src_type = "dummy-source"
        owner = "dbo"
        table_name = "dummy-table"
        date2process = "2025/01/15"

        mock_path.return_value = f"s3://{bucket_name}/eod/{owner}/{table_name}/"

        s3_path = generate_target_folder_path(bucket_name, src_type, owner, table_name, date2process)
        
        self.assertTrue(s3_path.startswith(mock_path.return_value))

    @patch("application.src.main.leasewave.glue.lease_eod_to_landing_extract.boto3.client")
    def test_read_config(self, mock_boto3_client):
        #Build mock S3 config file with dummy data
        mock_s3 = MagicMock()
        mock_boto3_client.return_value = mock_s3

        config_content = """
        [Section1]
        key1=value1
        key2=value2

        [Section2]
        key3=value3
        key4=value4
        """
        mock_s3.get_object.return_value = {"Body": BytesIO(config_content.encode())}

        #Run function to test on mock and return config
        config = read_config("test-bucket", "config.ini")

        #Compare config results with dummy data
        self.assertTrue(config.has_section('Section1'))
        self.assertEqual(config["Section1"]["key1"], "value1")
        self.assertEqual(config["Section1"]["key2"], "value2")
        self.assertEqual(config["Section2"]["key3"], "value3")
        self.assertEqual(config["Section2"]["key4"], "value4")

    @patch('application.src.main.leasewave.glue.lease_eod_to_landing_extract.list_files')
    @patch('application.src.main.leasewave.glue.lease_eod_to_landing_extract.move_file')
    def test_move_to_failed(self, mock_move_file, mock_list_files):
        mod.logger = MagicMock()
        s3_bucket = "test-bucket"
        table_name = "test_table"
        current_path = f"s3://{s3_bucket}/{table_name}"
        source_prefix = table_name

        mock_list_files.return_value = {
            "Contents": [
                {"Key": f"{source_prefix}/file1"},
                {"Key": f"{source_prefix}/file2"}
            ]
        }

        # Now call the function under test
        mod.move_to_failed(current_path, s3_bucket, table_name)

        # Validate that files were moved
        mock_move_file.assert_any_call(
            s3_bucket,
            f"{source_prefix}/file1",
            f"failed/{table_name}/file1"
        )
        mock_move_file.assert_any_call(
            s3_bucket,
            f"{source_prefix}/file2",
            f"failed/{table_name}/file2"
        )
        self.assertEqual(mock_move_file.call_count, 2)

    #No need to test validate_count as the method is already a test
    #def test_validate_count(self):

    #Read_from_src is not testable as it's not repeatable, all it does is read from the source, and the source info is embedded in the method
    #def test_read_from_src(self):

    #Write_to_s3 is not testable, same reason as above
    #def test_write_to_s3(self):

    if __name__ == "__main__":
        unittest.main()
