import importlib
import sys
import unittest
import runpy
from datetime import datetime
from unittest.mock import MagicMock, patch, ANY
from pyspark.sql import SparkSession
from application.src.main.salesforce.glue import landing_to_rds_postgres as mod
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from application.src.main.salesforce.glue import landing_to_rds_postgres as mod

class TestRdsLoadGlueJob(unittest.TestCase):
    def setUp(self):
        self.spark = SparkSession.builder \
            .master('local[*]') \
            .appName('GlueJobTest') \
            .getOrCreate()
        mod.spark = self.spark
        mod.logger = MagicMock()
        mod.glueContext = MagicMock()
        mod.job = MagicMock()
        mod.args = {
            "JOB_NAME": "test_job",
            "configBucket": "config-bucket",
            "configScript": "config-script",
            "landingBucket": "landing-bucket",
            "rdsDatabase": "test_rds_db",
            "tableName": "test_table",
            "s3LandingPath": "landing/path",
            "date2process": "2025-01-01"
        }
    

    def test_generate_destination_folder_path(self):
        bucket_name = "test-bucket"
        source_type = "source"
        table_name = "test_table"

        dest_folder_path = mod.generate_destination_folder_path(bucket_name, source_type, table_name)

        current_time = datetime.now()
        expected_substring = f's3://{bucket_name}/{source_type}/{table_name}/{current_time.year}/{current_time.month}/{current_time.day}/'
        self.assertIn(expected_substring, dest_folder_path)

    def test_remove_substring_from_end(self):
        s = "test_string_to_remove_suffix"
        sub = "_suffix"

        # Substring at the end
        result = mod.remove_substring_from_end(s, sub)
        self.assertEqual(result, "test_string_to_remove")

        # Substring not at the end
        result = mod.remove_substring_from_end("test_string", sub)
        self.assertEqual(result, "test_string")

        # No match
        result = mod.remove_substring_from_end(s, "non_existent_sub")
        self.assertEqual(result, s)

        #returns -1 for rfind(...). 
        class FakeStr:
            def endswith(self, _):
                return True 
            def rfind(self, _):
                return -1  

        fake_s = FakeStr()
        result = mod.remove_substring_from_end(fake_s, "_suffix")


    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.list_files')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.move_file')
    def test_move_to_failed(self, move_file_mock, list_files_mock):
        s3_bucket = "test-bucket"
        table_name = "test_table"
        current_path = f"s3://{s3_bucket}/{table_name}"
        source_prefix = table_name

        list_files_mock.return_value = {
            "Contents": [
                {"Key": f"{source_prefix}/file1"},
                {"Key": f"{source_prefix}/file2"}
            ]
        }

        # Now call the function under test
        mod.move_to_failed(current_path, s3_bucket, table_name)

        # Validate that files were moved
        move_file_mock.assert_any_call(
            s3_bucket,
            f"{source_prefix}/file1",
            f"consumption_rds_failed/{table_name}/file1"
        )
        move_file_mock.assert_any_call(
            s3_bucket,
            f"{source_prefix}/file2",
            f"consumption_rds_failed/{table_name}/file2"
        )
        self.assertEqual(move_file_mock.call_count, 2)


    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_rds')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.move_to_failed')
    def test_validate_count_counts_match(self, move_to_failed_mock, read_from_rds_mock):
        # Create a sample DataFrame in Spark
        data = [("Alice", 1), ("Bob", 2)]
        df = self.spark.createDataFrame(data, ["name", "value"])
        read_from_rds_mock.return_value = df

        s3_path = "s3://test-bucket/test-folder"
        s3_count = 2  # Matching the 2 rows we created
        s3_bucket = "test-bucket"
        schema = "public"
        rds_table_name = "test_table"
        username = "user"
        password = "pass"
        dbEndpoint = "endpoint"
        port = 5432
        rds_dbname = "test_db"

        result = mod.validate_count(
            s3_path,
            s3_count,
            s3_bucket,
            schema,
            rds_table_name,
            username,
            password,
            dbEndpoint,
            port,
            rds_dbname
        )
        self.assertIsNone(result)
        move_to_failed_mock.assert_not_called()

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_rds')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.move_to_failed')
    def test_validate_count_counts_mismatch(self, move_to_failed_mock, read_from_rds_mock):
        data = [("Alice", 1), ("Bob", 2), ("Charlie", 3)]
        df = self.spark.createDataFrame(data, ["name", "value"])
        read_from_rds_mock.return_value = df

        s3_path = "s3://test-bucket/test-folder"
        s3_count = 2
        s3_bucket = "test-bucket"
        schema = "public"
        rds_table_name = "test_table"
        username = "user"
        password = "pass"
        dbEndpoint = "endpoint"
        port = 5432
        rds_dbname = "test_db"

        result = mod.validate_count(
            s3_path,
            s3_count,
            s3_bucket,
            schema,
            rds_table_name,
            username,
            password,
            dbEndpoint,
            port,
            rds_dbname
        )
        self.assertIsNotNone(result)
        self.assertIn("does not match", result)
        move_to_failed_mock.assert_called_once()


    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.execute_sql')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_to_rds')
    def test_write_sfdc_to_rds_empty_df(self, write_to_rds_mock, execute_sql_mock):
        landingDf = self.spark.createDataFrame([], "id INT, name STRING")
        schema = "public"
        tableName = "test_table"
        dbName = "test_db"
        username = "user"
        password = "pass"
        dbEndpoint = "endpoint"
        port = 5432

        mod.write_sfdc_to_rds(landingDf, schema, tableName, dbName, username, password, dbEndpoint, port)

        write_to_rds_mock.assert_not_called()
        execute_sql_mock.assert_not_called()

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.execute_sql')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_to_rds')
    def test_write_sfdc_to_rds_non_empty_df(self, write_to_rds_mock, execute_sql_mock):
        data = [(1, "Alice"), (2, "Bob")]
        landingDf = self.spark.createDataFrame(data, ["id", "name"])
        schema = "public"
        tableName = "test_table"
        dbName = "test_db"
        username = "user"
        password = "pass"
        dbEndpoint = "endpoint"
        port = 5432

        mod.write_sfdc_to_rds(landingDf, schema, tableName, dbName, username, password, dbEndpoint, port)

        # We expect:
        # 1) Backup query executed
        # 2) Truncate query executed
        # 3) write_to_rds called
        # 4) Drop backup table
        backup_query = f"drop table if exists {schema}.{tableName}_backup; create table {schema}.{tableName}_backup as select * from {schema}.{tableName}"
        truncate_query = f"truncate table {schema}.{tableName};"
        drop_backup = f"drop table if exists {schema}.{tableName}_backup;"

        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, backup_query)
        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, truncate_query)
        write_to_rds_mock.assert_called_once()
        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, drop_backup)

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.execute_sql')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_to_rds')
    def test_write_sfdc_to_rds_error_during_write(self, write_to_rds_mock, execute_sql_mock):
        data = [(1, "Alice"), (2, "Bob")]
        landingDf = self.spark.createDataFrame(data, ["id", "name"])
        schema = "public"
        tableName = "test_table"
        dbName = "test_db"
        username = "user"
        password = "pass"
        dbEndpoint = "endpoint"
        port = 5432

        # Force write_to_rds to raise an exception
        write_to_rds_mock.side_effect = Exception("Write failed")

        with self.assertRaises(Exception):
            mod.write_sfdc_to_rds(landingDf, schema, tableName, dbName, username, password, dbEndpoint, port)

        # Check that backup and truncate were called
        backup_query = f"drop table if exists {schema}.{tableName}_backup; create table {schema}.{tableName}_backup as select * from {schema}.{tableName}"
        truncate_query = f"truncate table {schema}.{tableName};"
        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, backup_query)
        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, truncate_query)

        # Check that restore query was eventually called
        restore_query = f"truncate table {schema}.{tableName}; insert into {schema}.{tableName} select * from {schema}.{tableName}_backup; drop table if exists {schema}.{tableName}_backup;"
        execute_sql_mock.assert_any_call(dbEndpoint, username, password, port, dbName, restore_query)

    def test_add_metadata_columns(self):
        data = [(1, "Alice"), (2, "Bob")]
        df = self.spark.createDataFrame(data, ["id", "name"])
        tableName = "test_table"

        updatedDf = mod.add_metadata_columns(df, tableName)

        self.assertIn("execution_user", updatedDf.columns)
        self.assertIn("load_timestamp", updatedDf.columns)
        self.assertIn("update_timestamp", updatedDf.columns)
        self.assertIn("load_operation", updatedDf.columns)

        row = updatedDf.collect()[0]
        self.assertEqual(row["execution_user"], "cobank-glue-role")
        self.assertEqual(row["load_operation"], "Glue")

    def test_remove_null_columns(self):
        schema = StructType([
            StructField("id", IntegerType(), True),
            StructField("name", StringType(), True),
            StructField("always_null", StringType(), True)
        ])

        data = [
            (1,  "Alice",  None),
            (2,  "Bob",    None),
            (3,  "Charlie", None),
            (None, None, None)
        ]

        df = self.spark.createDataFrame(data, schema=schema)

        tableName = "test_table"
        resultDf = mod.remove_null_columns(df, tableName)

        self.assertNotIn("always_null", resultDf.columns)
        self.assertIn("id", resultDf.columns)
        self.assertIn("name", resultDf.columns)

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing')
    def test_main_no_data_in_s3(
        self,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_read_config,
        mock_get_latest_subfolder,
        mock_sys_exit
    ):
       
        def exit_side_effect(msg=None):
            raise SystemExit(msg)
        mock_sys_exit.side_effect = exit_side_effect
    
        # Setup
        mod.args = {
            "JOB_NAME": "test_job",
            "configBucket": "config-bucket",
            "configScript": "config-script",
            "landingBucket": "landing-bucket",
            "rdsDatabase": "test_rds_db",
            "tableName": "test_table",
            "s3LandingPath": "landing/path",
            "date2process": "2025-01-01"
        }
    
        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }
        mock_get_latest_subfolder.return_value = None
    
        # Act & Assert
        with self.assertRaises(SystemExit) as cm:
            mod.main()
    
        exit_message = str(cm.exception)
        self.assertIn("No data found for test_rds_db/landing/path/2025-01-01", exit_message)
        mock_read_from_landing.assert_not_called()


    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.remove_null_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.add_metadata_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_creds_from_secret')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_sfdc_to_rds')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.validate_count', return_value=None)
    def test_main_successful_run(
        self,
        mock_validate_count,
        mock_write_sfdc_to_rds,
        mock_get_creds_from_secret,
        mock_add_metadata_columns,
        mock_remove_null_columns,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_get_latest_subfolder,
        mock_read_config,
        mock_sys_exit
    ):
        mock_sys_exit.side_effect = lambda msg: self.fail(f"Unexpected sys.exit called with: {msg}")

        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }
        mock_get_latest_subfolder.return_value = "test_rds_db/landing/path/2025-01-01/subfolder"
        mock_read_from_landing.return_value = self.spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
        mock_remove_null_columns.return_value = self.spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
        mock_add_metadata_columns.return_value = self.spark.createDataFrame(
            [(1, "Alice", "cobank-glue-role", "Glue"),
            (2, "Bob",   "cobank-glue-role", "Glue")],
            ["id", "name", "execution_user", "load_operation"]
        )
        mock_get_creds_from_secret.return_value = ("user", "pass", "endpoint", 5432)

        # Execute main()
        mod.main()

        # Verify no sys.exit calls
        mock_sys_exit.assert_not_called()
        # Check that job.commit was called
        mod.job.commit.assert_called_once()

        # Check that write_sfdc_to_rds and validate_count were called
        mock_write_sfdc_to_rds.assert_called_once()
        mock_validate_count.assert_called_once()

        mock_update_audit_balance.assert_called_with(
            "test_job_test_table",
            'mock_job_run_id',
            ANY,          
            "Successful",
            {"audit-conn-url": "http://fake-audit.url"},
            '2'
        )

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder', return_value='some_path')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing', side_effect=Exception("Test S3 read error"))
    def test_main_s3_read_exception(
        self,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_get_latest_subfolder,
        mock_read_config,
        mock_sys_exit
    ):
        def exit_side_effect(msg=None):
            raise SystemExit(msg)
        mock_sys_exit.side_effect = exit_side_effect

        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }

        # Execute
        with self.assertRaises(SystemExit) as cm:
            mod.main()

        exit_message = str(cm.exception)
        self.assertIn("Error while reading from S3 landing bucket", exit_message)
        mock_update_audit_balance.assert_called_once()
        # Ensure it exited without proceeding further
        mod.job.commit.assert_not_called()



    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder', return_value='some_path')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.remove_null_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.add_metadata_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_creds_from_secret', return_value=('user','pass','endpoint',5432))
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_sfdc_to_rds', side_effect=Exception("Test RDS write error"))
    def test_main_rds_write_exception(
        self,
        mock_write_sfdc_to_rds,
        mock_get_creds_from_secret,
        mock_add_metadata_columns,
        mock_remove_null_columns,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_get_latest_subfolder,
        mock_read_config,
        mock_sys_exit
    ):
        def exit_side_effect(msg=None):
            raise SystemExit(msg)
        mock_sys_exit.side_effect = exit_side_effect

        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }

        mock_read_from_landing.return_value = self.spark.createDataFrame([(1, "Alice")], ["id", "name"])
        mock_remove_null_columns.return_value = self.spark.createDataFrame([(1, "Alice")], ["id", "name"])
        mock_add_metadata_columns.return_value = self.spark.createDataFrame([(1, "Alice", "cobank-glue-role", "Glue")],
                                                                            ["id", "name", "execution_user", "load_operation"])

        with self.assertRaises(SystemExit) as cm:
            mod.main()

        exit_message = str(cm.exception)
        self.assertIn("Error while writing to consumption RDS table", exit_message)
        mock_update_audit_balance.assert_called_once()
        mod.job.commit.assert_not_called()

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder', return_value='some_path')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.remove_null_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.add_metadata_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_creds_from_secret', return_value=('user','pass','endpoint',5432))
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_sfdc_to_rds')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.validate_count', return_value="S3 count 2 does not match RDS count 5!")
    def test_main_validate_count_mismatch(
        self,
        mock_validate_count,
        mock_write_sfdc_to_rds,
        mock_get_creds_from_secret,
        mock_add_metadata_columns,
        mock_remove_null_columns,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_get_latest_subfolder,
        mock_read_config,
        mock_sys_exit
    ):
        def exit_side_effect(msg=None):
            raise SystemExit(msg)
        mock_sys_exit.side_effect = exit_side_effect

        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }

        mock_read_from_landing.return_value = self.spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
        mock_remove_null_columns.return_value = self.spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
        mock_add_metadata_columns.return_value = self.spark.createDataFrame(
            [(1, "Alice", "cobank-glue-role", "Glue"), (2, "Bob", "cobank-glue-role", "Glue")],
            ["id", "name", "execution_user", "load_operation"]
        )

        with self.assertRaises(SystemExit) as cm:
            mod.main()

        exit_message = str(cm.exception)
        self.assertIn("S3 count 2 does not match RDS count 5!", exit_message)
        self.assertIn("Exiting..", exit_message)
        mock_update_audit_balance.assert_called_once()

    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.sys.exit')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_config')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_latest_subfolder', return_value='some_path')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.insert_audit_balance', return_value='mock_job_run_id')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.update_audit_balance')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.read_from_landing')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.remove_null_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.add_metadata_columns')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.get_creds_from_secret', return_value=('user', 'pass', 'endpoint', 5432))
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.write_sfdc_to_rds')
    @patch('application.src.main.salesforce.glue.landing_to_rds_postgres.validate_count', side_effect=Exception("Simulated validation error"))
    def test_main_validate_count_exception(
        self,
        mock_validate_count,
        mock_write_sfdc_to_rds,
        mock_get_creds_from_secret,
        mock_add_metadata_columns,
        mock_remove_null_columns,
        mock_read_from_landing,
        mock_update_audit_balance,
        mock_insert_audit_balance,
        mock_get_latest_subfolder,
        mock_read_config,
        mock_sys_exit
    ):
        mock_sys_exit.side_effect = lambda msg: self.fail(f"Unexpected sys.exit called with: {msg}")

        mock_read_config.return_value = {
            "AUDIT_PROPERTIES": {"audit-conn-url": "http://fake-audit.url"},
            "RDS_PROPERTIES":   {"schema": "public", "rds-secret_name": "some-secret"}
        }

        mock_read_from_landing.return_value = self.spark.createDataFrame(
            [(1, "Alice"), (2, "Bob")],
            ["id", "name"]
        )

        mock_remove_null_columns.return_value = self.spark.createDataFrame(
            [(1, "Alice"), (2, "Bob")],
            ["id", "name"]
        )
        mock_add_metadata_columns.return_value = self.spark.createDataFrame(
            [(1, "Alice", "cobank-glue-role", "Glue"), (2, "Bob", "cobank-glue-role", "Glue")],
            ["id", "name", "execution_user", "load_operation"]
        )

        mod.main()

        mock_validate_count.assert_called_once()
        
        mod.logger.error.assert_any_call(
            "test_table_rds_load [ERROR] Validating counts failed with ERROR <class 'Exception'>: Simulated validation error! Skipping validation now!"
        )

        mock_update_audit_balance.assert_called_with(
            'test_job_test_table',
            'mock_job_run_id',
            unittest.mock.ANY,  # The success message with duration
            'Successful',
            {'audit-conn-url': 'http://fake-audit.url'},
            '2'  # We had 2 records in the DF
        )

        mod.job.commit.assert_called_once()
        mock_sys_exit.assert_not_called()


if __name__ == '__main__':
    unittest.main()
