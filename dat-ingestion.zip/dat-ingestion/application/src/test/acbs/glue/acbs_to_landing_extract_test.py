from datetime import datetime
import unittest
from unittest.mock import Mock, ANY
from pyspark.sql import SparkSession, Row
from awsglue import DynamicFrame
from acbs.glue import acbs_to_landing_extract

####################################################################
##### @Author Shruti Ghayal - SGhayal@cobank.com
####################################################################

class TestAcbsGlueJob(unittest.TestCase):

    def test_read_from_postgres(self):
        spark = SparkSession.builder.master('local').getOrCreate()
        data = [Row(id=1, name='Alice'),Row(id=2, name='Bob'),Row(id=3, name='Charlie')]

        df = spark.createDataFrame(data)
        # mock_glue_context = Mock(spec=GlueContext)
        mock_glue_context = Mock()
        mock_dynamic_frame = Mock(spec=DynamicFrame)
        # mock_glue_context.return_value.create_dynamic_frame.return_value = mock_dynamic_frame
        mock_glue_context.create_dynamic_frame.from_options.return_value = mock_dynamic_frame

        result_df = acbs_to_landing_extract.read_from_acbs(ANY,ANY,ANY,mock_glue_context)

        # To validate if read is indeed returning a dynamic frame
        self.assertEqual(result_df, mock_dynamic_frame)


    def test_generate_destination_folder_path(self):
        bucket_name,source_type, table_name = "test-bucket", "acbs", "j_clms"

        dest_folder_path = acbs_to_landing_extract.generate_destination_folder_path(bucket_name,source_type,table_name)
        print(f'dest_folder_path: {dest_folder_path}')

        current_time = datetime.now()
        current_year = current_time.year
        current_month = current_time.month
        current_month = f'{current_time:%m}'
        current_date = current_time.day
        current_date = f'{current_time:%d}'
        s3_path = f's3://{bucket_name}/{source_type}/{table_name}/{current_year}/{current_month}/{current_date}/'

        self.assertIn(s3_path, dest_folder_path, "not in") 
        

#TODO: Add tests for writing to S3

if __name__ == '__main__': 
    unittest.main()