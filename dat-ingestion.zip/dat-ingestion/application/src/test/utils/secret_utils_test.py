from unittest.mock import patch, MagicMock
import unittest
from application.src.main.utils.secret_utils import get_secret_value, get_creds_from_secret
class TestSecretUtils(unittest.TestCase):

    @patch("application.src.main.utils.secret_utils.boto3.client")
    def test_get_secret_value_success(self, mock_boto3_client):
        mock_secrets = MagicMock()
        mock_boto3_client.return_value = mock_secrets

        mock_secrets.get_secret_value.return_value = {
            "SecretString": "test-secret"
        }

        result = get_secret_value("test-secret-name")

        mock_boto3_client.assert_called_with('secretsmanager')
        mock_secrets.get_secret_value.assert_called_with(
            SecretId="test-secret-name"
        )
        self.assertEqual(result, "test-secret")

    @patch("application.src.main.utils.secret_utils.boto3.client")
    def test_get_secret_value_binary(self, mock_boto3_client):
        mock_secrets = MagicMock()
        mock_boto3_client.return_value = mock_secrets

        mock_secrets.get_secret_value.return_value = {
            "SecretBinary": "test-binary".encode('utf-8')
        }

        result = get_secret_value("test-secret-name")

        self.assertEqual(result, "test-binary")

    @patch("application.src.main.utils.secret_utils.boto3.client")
    def test_get_secret_value_error(self, mock_boto3_client):
        mock_secrets = MagicMock()
        mock_boto3_client.return_value = mock_secrets

        mock_secrets.get_secret_value.side_effect = Exception("Secret error")

        result = get_secret_value("test-secret-name")

        self.assertIsNone(result)

    @patch("application.src.main.utils.secret_utils.get_secret_value")
    def test_get_creds_from_secret_success(self, mock_get_secret):
        mock_get_secret.return_value = '''
        {
            "username": "test-user",
            "password": "test-pass",
            "host": "test-host",
            "port": 5432
        }
        '''

        username, password, dbendpoint, port = get_creds_from_secret("test-secret")

        self.assertEqual(username, "test-user")
        self.assertEqual(password, "test-pass")
        self.assertEqual(dbendpoint, "test-host")
        self.assertEqual(port, 5432)

    @patch("application.src.main.utils.secret_utils.get_secret_value")
    def test_get_creds_from_secret_invalid_json(self, mock_get_secret):
        mock_get_secret.return_value = "invalid json"

        result = get_creds_from_secret("test-secret")

        self.assertEqual(result, (None, None, None, None, None))

    @patch("application.src.main.utils.secret_utils.get_secret_value")
    def test_get_creds_from_secret_none(self, mock_get_secret):
        mock_get_secret.return_value = None

        result = get_creds_from_secret("test-secret")

        self.assertEqual(result, (None, None, None, None, None))


if __name__ == '__main__':
    unittest.main()

