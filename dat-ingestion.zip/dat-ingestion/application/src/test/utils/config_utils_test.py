from io import BytesIO
import unittest
from unittest.mock import patch, MagicMock
from application.src.main.utils.config_utils import read_config

class TestConfigUtils(unittest.TestCase):

    @patch("application.src.main.utils.config_utils.boto3.client")
    def test_read_config_success(self, mock_boto3_client):
        mock_s3 = MagicMock()
        mock_boto3_client.return_value = mock_s3

        config_content = """
        [Section1]
        key1=value1
        key2=value2
        """

        mock_s3.get_object.return_value = {
            "Body": BytesIO(config_content.encode())
        }

        config = read_config('test-bucket', 'config.ini')

        self.assertTrue(config.has_section('Section1'))
        self.assertEqual(config.get('Section1', 'key1'), 'value1')
        self.assertEqual(config.get('Section1', 'key2'), 'value2')


if __name__ == '__main__':
    unittest.main()

