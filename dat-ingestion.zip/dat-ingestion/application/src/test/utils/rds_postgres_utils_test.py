import unittest
from unittest.mock import patch, MagicMock
from application.src.main.utils.rds_postgres_utils import read_from_rds, write_to_rds, execute_sql

class TestRDSPostgresUtils(unittest.TestCase):

    @patch("pyspark.sql.SparkSession")
    def test_read_from_rds_success(self, mock_spark):
        mock_df = MagicMock()
        mock_spark.read.jdbc.return_value = mock_df

        df = read_from_rds(
            "test-endpoint", 5432, "test-db", "user", 
            "pass", "schema", "table", mock_spark
        )

        mock_spark.read.jdbc.assert_called_once_with(
            url='jdbc:postgresql://test-endpoint:5432/test-db',
            table='schema.table',
            properties={
                "user": "user",
                "password": "pass",
                "driver": "org.postgresql.Driver"
            }
        )
        self.assertEqual(df, mock_df)

    @patch("pyspark.sql.DataFrame")
    def test_write_to_rds_success(self, mock_df):
        mock_writer = MagicMock()
        mock_df.write.format.return_value = mock_writer
        mock_writer.option.return_value = mock_writer
        mock_writer.mode.return_value = mock_writer

        write_to_rds(
            mock_df, "schema", "table", "db", "user",
            "pass", "endpoint", 5432
        )

        mock_df.write.format.assert_called_with("jdbc")
        mock_writer.option.assert_any_call(
            "url", "jdbc:postgresql://endpoint:5432/db"
        )
        mock_writer.option.assert_any_call("dbtable", "schema.table")
        mock_writer.option.assert_any_call("user", "user")
        mock_writer.option.assert_any_call("password", "pass")
        mock_writer.mode.assert_called_with("append")
        mock_writer.save.assert_called_once()

    @patch("pg8000.connect")
    def test_execute_sql_success(self, mock_connect):
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor

        sql_commands = "UPDATE table SET col=1; DELETE FROM table;"
        
        execute_sql(
            "host", "user", "pass", 5432, "db", sql_commands
        )

        mock_connect.assert_called_with(
            host="host", database="db", user="user",
            password="pass", port=5432
        )
        self.assertEqual(mock_cursor.execute.call_count, 2)
        mock_connection.commit.assert_called_once()
        mock_cursor.close.assert_called_once()
        mock_connection.close.assert_called_once()

    @patch("pg8000.connect")
    def test_execute_sql_error(self, mock_connect):
        mock_connect.side_effect = Exception("Connection error")

        with self.assertRaises(Exception):
            execute_sql(
                "host", "user", "pass", 5432, "db", "SELECT 1"
            )

if __name__ == '__main__':
    unittest.main()
