import unittest
from unittest.mock import patch, MagicMock
from application.src.main.utils.s3_utils import generate_destination_folder_path, get_latest_subfolder, read_from_landing, write_data

class TestS3Utils(unittest.TestCase):

    def test_generate_destination_folder_path(self):
        bucket_name = "test-bucket"
        source_type = "source"
        table_name = "table"

        result = generate_destination_folder_path(bucket_name, source_type, table_name)

        self.assertTrue(result.startswith(f"s3://{bucket_name}/{source_type}/{table_name}/"))

    @patch("application.src.main.utils.s3_utils.boto3.client")
    def test_get_latest_subfolder(self, mock_boto3_client):
        mock_s3 = MagicMock()
        mock_boto3_client.return_value = mock_s3
        mock_s3.list_objects_v2.return_value = {
            "CommonPrefixes": [
                {"Prefix": "prefix1-2023-12-01T10:00:00/"},
                {"Prefix": "prefix2-2023-12-02T12:00:00/"}
            ]
        }

        result = get_latest_subfolder("test-bucket", "test-prefix")

        self.assertEqual(result, "prefix2-2023-12-02T12:00:00/")

    @patch("awsglue.context.GlueContext")
    def test_read_from_landing(self, mock_glue_context):
        mock_spark_session = MagicMock()
        mock_glue_context.return_value.spark_session = mock_spark_session
        mock_spark_session.read.format.return_value.option.return_value.option.return_value.load.return_value = "mock_df"

        result = read_from_landing(mock_glue_context.return_value, "csv", True, False, "s3://test-bucket/path")

        mock_spark_session.read.format.assert_called_with("csv")
        self.assertEqual(result, "mock_df")
        
    @patch("application.src.main.utils.s3_utils.write_data")
    def test_write_data_csv(self, mock_write_data):
        mock_df = MagicMock()

        write_data(mock_df, "s3://test-bucket/path", "csv")

        mock_df.write.format.return_value.option.assert_called_with("header", "true")
        mock_df.write.format.return_value.option.return_value.save.assert_called_with("s3://test-bucket/path")

    @patch("application.src.main.utils.s3_utils.write_data")
    def test_write_data_parquet(self, mock_write_data):
        mock_df = MagicMock()

        write_data(mock_df, "s3://test-bucket/path", "parquet")
        mock_df.write.mode.return_value.parquet.assert_called_with("s3://test-bucket/path")

if __name__ == "__main__":
    unittest.main()
