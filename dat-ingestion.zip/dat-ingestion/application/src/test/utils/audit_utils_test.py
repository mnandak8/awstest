import unittest
from unittest.mock import Mock, patch
from datetime import datetime, timezone
from application.src.main.utils.audit_utils import (
    call_audit_api,
    insert_audit_balance,
    update_audit_balance
)
import requests
import json

class TestAuditUtils(unittest.TestCase):
    def setUp(self):
        self.api_url = "https://test-api.example.com/audit"
        self.mock_datetime = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)

    @patch('application.src.main.utils.audit_utils.requests.post')
    def test_call_audit_api_insert_success(self, mock_post):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"jobRunId": "test123"}
        mock_post.return_value = mock_response

        payload = {"test": "data"}
        result = call_audit_api(payload, True, self.api_url)

        self.assertEqual(result, "test123")
        mock_post.assert_called_with(
            self.api_url,
            data=json.dumps(payload),
            headers={'Content-Type': 'application/json', 'Accept': 'application/json'}
        )

    @patch('application.src.main.utils.audit_utils.requests.put')
    def test_call_audit_api_update_success(self, mock_put):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"jobRunId": "test123"}
        mock_put.return_value = mock_response

        payload = {"test": "data"}
        result = call_audit_api(payload, False, self.api_url)

        self.assertEqual(result, "test123")
        mock_put.assert_called_with(
            self.api_url,
            data=json.dumps(payload),
            headers={'Content-Type': 'application/json', 'Accept': 'application/json'}
        )

    @patch('application.src.main.utils.audit_utils.call_audit_api')
    @patch('application.src.main.utils.audit_utils.datetime')
    def test_insert_audit_balance_full(self, mock_datetime, mock_call_api):
        mock_datetime.now.return_value = self.mock_datetime
        mock_call_api.return_value = "test123"

        result = insert_audit_balance(
            jobName="TestJob",
            source="TestSource",
            target="TestTarget",
            runBy="TestUser",
            statusDesc="Test Description",
            api_url=self.api_url
        )

        expected_payload = {
            "jobName": "TestJob",
            "source": "TestSource",
            "target": "TestTarget",
            "runStartDateTime": "2024-01-01 12:00:00",
            "runBy": "TestUser",
            "runStatus": "Started",
            "runStatusDesc": "Test Description"
        }

        mock_call_api.assert_called_with(expected_payload, True, self.api_url)
        self.assertEqual(result, "test123")

    @patch('application.src.main.utils.audit_utils.call_audit_api')
    @patch('application.src.main.utils.audit_utils.datetime')
    def test_update_audit_balance_full(self, mock_datetime, mock_call_api):
        mock_datetime.now.return_value = self.mock_datetime

        update_audit_balance(
            jobName="TestJob",
            jobRunId="test123",
            statusDesc="Test Update",
            status="Completed",
            api_url=self.api_url,
            targetRecordCount=100,
            lastModifiedDataDate="2024-01-01"
        )

        expected_payload = {
            "jobName": "TestJob",
            "jobRunId": "test123",
            "runEndDateTime": "2024-01-01 12:00:00",
            "runStatus": "Completed",
            "runStatusDesc": "Test Update",
            "targetRecordCount": 100,
            "lastModifiedDataDate": "2024-01-01"
        }

        mock_call_api.assert_called_with(expected_payload, False, self.api_url)

if __name__ == '__main__':
    unittest.main()
