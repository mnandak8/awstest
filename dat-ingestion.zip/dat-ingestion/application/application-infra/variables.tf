
#####################################################################
#---------------------- VARIABLES FROM TFVARS ----------------------#
#####################################################################

variable "cost_center" {
  description = "cost center code for tagging"
  type        = string
}
variable "environment" {
  type = string
}
variable "landing_bucket_name" {
  description = "landing bucket full name"
  type        = string
}
variable "tooling_bucket_name" {
  description = "tooling bucket full name"
  type        = string
}
variable "airflow_dag_bucket_name" {
  description = "airflow DAG  bucket full name"
  type        = string
}
variable "glue_role_name" {
  description = "glue_role_name"
  type        = string
}
variable "rds_connector_name" {
  description = "rds_connector_name"
  type        = string
}

variable "sfdc_acbs_connector" {
  description = "sfdc_acbs_connector"
  type        = string
}

variable "rds_secret_name" {
  description = "rds_secret_name"
  type        = string
}
variable "splunk_tag" {
  description = "splunk_tag"
  type        = string
}
variable "rds_vpc_cidr_blocks_ingress" { type = set(string)}
variable "rds_vpc_cidr_blocks_egress" { type = set(string)}
variable "email_address" {
  description = "email_address"
  type        = string
}


#####################################################################
#---------------------- Financial Pricing VARIABLES -----------------------#
#####################################################################

variable "rapport_db_secret_name" {
  type = string
}

variable "rapport_sqs_name" {
  type = string
}

variable "rapport_dlq_name" {
  type = string
}

variable "rapport_s3_bucket_name" {
  type = string
}

variable "rapport_sql_query" {
  type = string
}

variable "tc_api_url" {
  type = string
}

variable "dms_kms_key_alias" {
  type = string
}
#####################################################################
#---------------------- SALESFORCE VARIABLES -----------------------#
#####################################################################
variable "kms_key_arn" {
  description = "kms key centralized"
  type        = string
}
variable "salesforce_connector_name" {
  description = "Existing salesforce connector name"
  type        = string
}
variable "account_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/account"
  type        = string
}
variable "account_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "Account"
  type        = string
}
variable "contact_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/contact"
  type        = string
}
variable "contact_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "Contact"
  type        = string
}
variable "llc_bi_loan_c_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/llc_bi_loan_c"
  type        = string
}
variable "llc_bi_loan_c_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "LLC_BI__Loan__c"
  type        = string
}
variable "account_contact_relation_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "AccountContactRelation"
  type        = string
}
variable "account_contact_relation_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/account_contact_relation"
  type        = string
}
variable "account_address_c_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "Account_Address__c"
  type        = string
}
variable "account_address_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/account_address_c"
  type        = string
}
variable "recordtype_path_prefix" {
  description = "Prefix path to put the data in landing bucket"
  default     = "salesforce/recordtype"
  type        = string
}
variable "recordtype_salesforce_object_name" {
  description = "Salesforce table name"
  default     = "RecordType"
  type        = string
}
variable "LLC_BI__Loan__c_masking_columns" {
  description = "Mask Columns in LLC_BI__Loan__c"
  default     = ["LLC_BI__Auto_Pay_Account__c", "LLC_BI__Non_Accrual__c"]
  type        = list(any)
}
variable "contact_masking_columns" {
  description = "Mask Columns in contact"
  default = ["Birthdate", "LLC_BI__Drivers_License__c", "LLC_BI__SS__c",
    "LLC_BI__Primary_ID_Expiration_Date__c", "LLC_BI__Permanent_Resident_Number__c",
    "LLC_BI__Form_W7_Birth_Certificate__c", "LLC_BI__Form_W7_Certifying_Acceptance_Date__c",
    "LLC_BI__Form_W7_Exception_1a_Partnership_EIN__c", "LLC_BI__Form_W7_Foreign_Voter_ID_Card_Verifies__c",
    "LLC_BI__Form_W7_Medical_Records_ID_Verifies__c", "LLC_BI__Form_W7_National_ID_Card_Verifies__c",
    "LLC_BI__Form_W7_Passport_Verifies__c", "LLC_BI__Form_W7_Previous_IRSN__c", "LLC_BI__Form_W7_Treaty_Article_Number__c",
    "LLC_BI__Form_W7_USCIS_Verifies__c", "LLC_BI__Former_Employer_EIN__c", "LLC_BI__SS_PE__c",
  "LLC_BI__W7_Foreign_Military_ID_Card_Verifies__c"]
  type = list(any)
}
variable "account_masking_columns" {
  description = "Mask Columns in Account"
  default = ["AnnualRevenue", "Foreign_Individual__c", "LLC_BI__FICO_Score__c", "LLC_BI__GIIN__c",
    "LLC_BI__Global_Cash_Flow__c", "LLC_BI__Tax_Identification_Number__c", "LLC_BI__Tax_Identification_Number_PE__c",
  "Risk_Inform_Person_Score__c", "Tax_Identification_Number__c", "Total_Assets__c"]
  type = list(any)
}
variable "env_mask" {
  description = "env_mask"
  default     = "dev"
  type        = string
}
variable "consumption_rds_connector_name" {
  description = "consumption_rds_connector_name"
  default     = "dev"
  type        = string
}

variable "lake_account_id" { type = string }
variable "consumption_account_id" { type = string }
variable "ods_consumption_secrets_manager_arn_id" { type = string }
variable "ods_consumption_secrets_manager_arn_kms_key_id" { type = string }
variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "terra_factory_aws_id" {
  type        = string
  description = "Name of the aws account."
}

variable "governance_account_id" {
  type        = string
  description = "governance account id"
  default     = ""
}

#####################################################################
#---------------------- LEASEWAVE VARIABLES -----------------------#
#####################################################################
variable "lw-consumption-jdbc-connector" {
  description = "lw connector for glue job"
  type        = string
}

variable "leasewave_glue_role" {
  description = "leasewave_glue_role"
  type        = string
}

variable "leasewave_landing_bucket_name" {
  description = "landing bucket full name for leaewave"
  type        = string
}