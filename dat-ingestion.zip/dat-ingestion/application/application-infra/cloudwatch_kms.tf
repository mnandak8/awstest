resource "aws_kms_key" "cloudwatch-kms-key" {
  description = "KMS key CloudWatch Logs"
  enable_key_rotation = true
  policy = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable KMS Encryption",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${local.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${local.region_name}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}

