# Upload DAG script to lak account
resource "aws_s3_object" "salesforce-dag-scripts-account" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_account_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_account_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_account_etl_dag.py")
}
resource "aws_s3_object" "salesforce-dag-scripts-contact" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_contact_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_contact_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_contact_etl_dag.py")
}
resource "aws_s3_object" "salesforce-dag-scripts-llcbiloanc" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_llcbiloanc_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_llcbiloanc_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_llcbiloanc_etl_dag.py")
}
resource "aws_s3_object" "salesforce-dag-scripts-accountaddressc" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_accountaddressc_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_accountaddressc_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_accountaddressc_etl_dag.py")
}
resource "aws_s3_object" "salesforce-dag-scripts-accountcontactrelation" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_accountcontactrelation_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_accountcontactrelation_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_accountcontactrelation_etl_dag.py")
}
resource "aws_s3_object" "salesforce-dag-scripts-recordtype" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/salesforce/salesforce2landing_recordtype_etl_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce2landing_recordtype_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce2landing_recordtype_etl_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-account" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_account_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_account_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_account_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-accountaddress" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_accountaddress_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_accountaddress_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_accountaddress_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-accountcontactrelation" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_accountcontactrelation_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_accountcontactrelation_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_accountcontactrelation_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-contact" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_contact_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_contact_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_contact_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-llcbiloanc" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_llcbiloanc_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_llcbiloanc_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_llcbiloanc_dag.py")
}
resource "aws_s3_object" "salesforce-rds-load-dag-script-recordtype" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/consumption/salesforce/salesforce_landing2rds_recordtype_unschedule_dag.py"
  source = "${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_recordtype_unschedule_dag.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/airflow/salesforce_landing2rds_recordtype_unschedule_dag.py")
}
