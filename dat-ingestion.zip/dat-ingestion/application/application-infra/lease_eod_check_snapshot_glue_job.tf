# Upload Glue script file to tooling
resource "aws_s3_object" "lease-eod-check-snapshot-glue-script" {
  bucket = var.tooling_bucket_name
  key    = "ingestion/glue-scripts/lease_eod_check_snapshot.py"
  source = "${path.module}/../src/main/leasewave/glue/lease_eod_check_snapshot.py"
  etag   = filemd5("${path.module}/../src/main/leasewave/glue/lease_eod_check_snapshot.py")
}

/* #Not uploading this config file as its being part of other job tf file: lease_eog_glue_job.tf
resource "aws_s3_object" "lease-eod-config" {
  bucket = var.tooling_bucket_name
  key    = "ingestion/glue-scripts/configs/lease-eod.config"
  source = "${path.module}/../src/main/leasewave/configs/environments/${var.environment}/lease-eod.config"
  etag   = filemd5("${path.module}/../src/main/leasewave/configs/environments/${var.environment}/lease-eod.config")
}
*/

resource "aws_cloudwatch_log_group" "lease-eod-check-snapshot-log-group-ingestion" {
  name              = "/aws-glue/jobs/lease-eod-check-snapshot-ingestion-log-group"
  kms_key_id        = aws_kms_key.cloudwatch-kms-key.arn
  retention_in_days = 365
  tags              = { "Splunk" = var.splunk_tag }
}
/*
resource "aws_kms_alias" "KMS_cloudwatch_acbs" {
  name          = "alias/key-cloudwatch-group_acbs"
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}
*/

data "aws_iam_role" "leasewave-glue-role-eod" {
  name = var.leasewave_glue_role
}

resource "aws_glue_job" "lease_eod_to_check_snapshot" {
  name        = "lease_eod_to_check_snapshot"
  role_arn    = data.aws_iam_role.leasewave-glue-role-eod.arn
  connections = ["cobank-onprem-sqlserver-jdbc-connection-${var.environment}"]
  execution_property {
    max_concurrent_runs = 30
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.lease-eod-check-snapshot-glue-script.bucket}/${aws_s3_object.lease-eod-check-snapshot-glue-script.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : aws_cloudwatch_log_group.lease-eod-check-snapshot-log-group-ingestion.name
    "--continuous-log-cloudwatchGroupName" : aws_cloudwatch_log_group.lease-eod-check-snapshot-log-group-ingestion.name
    "--configFile" : "lease-eod.config"
    "--configPath" : "ingestion/glue-scripts/configs"
    "--configBucket" : var.tooling_bucket_name
    "--enable-auto-scaling" = true
    "--enable-job-insights" = true
  }

  glue_version      = "4.0"
  worker_type       = "G.2X"
  number_of_workers = "10"

}
