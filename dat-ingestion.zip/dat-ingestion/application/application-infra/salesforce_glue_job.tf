
# Upload Glue script file to tooling
resource "aws_s3_object" "glue-script-rds" {
  bucket = var.tooling_bucket_name
  key    = "consumption/glue-scripts/landing_to_rds_postgres.py"
  source = "${path.module}/../src/main/salesforce/glue/landing_to_rds_postgres.py"
  etag   = filemd5("${path.module}/../src/main/salesforce/glue/landing_to_rds_postgres.py")
}

# Upload Glue config file to tooling
resource "aws_s3_object" "glue-config_script-rds" {
  bucket = var.tooling_bucket_name
  key    = "consumption/glue-scripts/configs/sfdc_landing_to_rds.config"
  source = join(var.environment, ["${path.module}/../src/main/salesforce/configs/environments/", "/sfdc_landing_to_rds.config"])
  etag   = filemd5(join(var.environment, ["${path.module}/../src/main/salesforce/configs/environments/", "/sfdc_landing_to_rds.config"]))
}

# Upload utils lib to tooling
## TODO Move creation of wheel file to actions module main
resource "aws_s3_object" "glue-utils-script-rds" {
  bucket = var.tooling_bucket_name
  key    = "common-utils/utils-0.1-py3-none-any.whl"
  source = "${path.module}/../src/main/libs/utils-0.1-py3-none-any.whl"
  etag   = filemd5("${path.module}/../src/main/libs/utils-0.1-py3-none-any.whl")
}

resource "aws_s3_object" "pylib-asn1crypto" {
  bucket = var.tooling_bucket_name
  key    = "common-utils/asn1crypto-1.5.1-py2.py3-none-any.whl"
  source = "${path.module}/../src/main/libs/asn1crypto-1.5.1-py2.py3-none-any.whl"
  etag   = filemd5("${path.module}/../src/main/libs/asn1crypto-1.5.1-py2.py3-none-any.whl")
}


resource "aws_s3_object" "pylib-pg8000" {
  bucket = var.tooling_bucket_name
  key    = "common-utils/pg8000-1.31.2-py3-none-any.whl"
  source = "${path.module}/../src/main/libs/pg8000-1.31.2-py3-none-any.whl"
  etag   = filemd5("${path.module}/../src/main/libs/pg8000-1.31.2-py3-none-any.whl")
}


resource "aws_s3_object" "pylib-scramp" {
  bucket = var.tooling_bucket_name
  key    = "common-utils/scramp-1.4.5-py3-none-any.whl"
  source = "${path.module}/../src/main/libs/scramp-1.4.5-py3-none-any.whl"
  etag   = filemd5("${path.module}/../src/main/libs/scramp-1.4.5-py3-none-any.whl")
}


resource "aws_cloudwatch_log_group" "log-group-rds-load" {
  name              = "/aws-glue/jobs/rds-load-log-group"
  kms_key_id        = aws_kms_key.cloudwatch-kms-key.arn
  retention_in_days = 365
  tags              = { "Splunk" = var.splunk_tag }
}

resource "aws_kms_alias" "KMS_cloudwatch_salesforce" {
  name          = "alias/key-cloudwatch-group_salesforce"
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}

data "aws_iam_role" "sf-glue-role-rds" {
  name = "cobank-${var.environment}-glue-party-role"
}

resource "aws_glue_job" "landing_to_rds_postgres" {
  name        = "landing_to_rds_postgres"
  role_arn    = data.aws_iam_role.sf-glue-role-rds.arn
  connections = [var.consumption_rds_connector_name, aws_glue_connection.sfdc-acbs-rds-conn.name]
  execution_property {
    max_concurrent_runs = 20
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.glue-script-rds.bucket}/${aws_s3_object.glue-script-rds.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--continuous-log-cloudwatchGroupName" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--additional-python-modules" : "s3://${aws_s3_object.glue-utils-script-rds.bucket}/${aws_s3_object.glue-utils-script-rds.key},s3://${aws_s3_object.pylib-asn1crypto.bucket}/${aws_s3_object.pylib-asn1crypto.key},s3://${aws_s3_object.pylib-pg8000.bucket}/${aws_s3_object.pylib-pg8000.key},s3://${aws_s3_object.pylib-scramp.bucket}/${aws_s3_object.pylib-scramp.key}"
    "--configScript" : "sfdc_landing_to_rds.config"
    "--configBucket" : var.tooling_bucket_name
    "--landingBucket" : var.landing_bucket_name
  }

  glue_version      = "4.0"
  worker_type       = "G.2X"
  number_of_workers = "10"

  security_configuration = aws_glue_security_configuration.security_configuration.name
}


resource "aws_kms_key" "KMS_Glue" {
  description         = "KMS key glue job"
  enable_key_rotation = true
  policy              = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${data.aws_region.current.name}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}


resource "aws_kms_alias" "KMS_Glue" {
  name          = "alias/key-glue-job"
  target_key_id = aws_kms_key.KMS_Glue.key_id
}

resource "aws_glue_security_configuration" "security_configuration" {
  depends_on = [aws_kms_alias.KMS_Glue]
  name       = "acbs-to-landing-extract-security-configuration"

  encryption_configuration {
    cloudwatch_encryption {
      cloudwatch_encryption_mode = "SSE-KMS"
      kms_key_arn                = aws_kms_key.KMS_Glue.arn
    }
    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = "CSE-KMS"
      kms_key_arn                   = aws_kms_key.KMS_Glue.arn
    }
    s3_encryption {
      s3_encryption_mode = "SSE-KMS"
      kms_key_arn        = aws_kms_key.KMS_Glue.arn
    }
  }
}



data "aws_cloudwatch_log_group" "security-log-group-rds-load" {
  name = "${aws_cloudwatch_log_group.log-group-rds-load.name}-${aws_glue_security_configuration.security_configuration.name}"
}


resource "null_resource" "update_log_group_config" {
  triggers = {
    log_group_name = data.aws_cloudwatch_log_group.security-log-group-rds-load.name
  }

  provisioner "local-exec" {
    command = <<EOT
      aws logs tag-log-group \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --tags "Splunk=${var.splunk_tag}"

      aws logs put-retention-policy \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --retention-in-days 365

      aws logs associate-kms-key \
        --log-group-name "${data.aws_cloudwatch_log_group.security-log-group-rds-load.name}" \
        --kms-key-id "${aws_kms_key.cloudwatch-kms-key.arn}"
    EOT
  }
}
