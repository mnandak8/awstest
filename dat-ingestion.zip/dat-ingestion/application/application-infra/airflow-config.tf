# Upload ING Config  script to lak account
resource "aws_s3_object" "airflow-config-ing" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/cb_common/configs_ing.py"
  source = "${path.module}/../src/main/airflow-config/configs_ing.py"
  etag   = filemd5("${path.module}/../src/main/airflow-config/configs_ing.py")
}