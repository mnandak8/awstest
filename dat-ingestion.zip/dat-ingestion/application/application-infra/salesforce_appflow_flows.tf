data "aws_s3_bucket" "landing_bucket" {
  bucket = var.landing_bucket_name
}

resource "aws_appflow_flow" "salesforce_to_landing_account" {
  name        = "salesforce_to_landing_account"
  description = "flow for account object"
  kms_arn     = var.kms_key_arn

  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.account_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.account_path_prefix



        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }
    }
  }

  task {
    connector_operator { salesforce = "NO_OP" }
    source_fields   = [""]
    task_properties = {}
    task_type       = "Map_all"

  }

  dynamic "task" {
    for_each = var.env_mask == "test" ? var.account_masking_columns : []
    content {
      connector_operator { salesforce = var.env_mask == "test" ? "MASK_ALL" : "NO_OP" }
      source_fields     = [task.value]
      destination_field = task.value
      task_properties   = var.env_mask == "test" ? { MASK_VALUE = "*" } : {}
      task_type         = var.env_mask == "test" ? "Mask" : "Map"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }

}

resource "aws_appflow_flow" "salesforce_to_landing_contact" {
  name        = "salesforce_to_landing_contact"
  description = "flow for contact object"
  kms_arn     = var.kms_key_arn

  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.contact_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.contact_path_prefix


        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }
    }
  }

  task {
    connector_operator { salesforce = "NO_OP" }
    source_fields   = [""]
    task_properties = {}
    task_type       = "Map_all"

  }

  dynamic "task" {
    for_each = var.env_mask == "test" ? var.contact_masking_columns : []
    content {
      connector_operator { salesforce = var.env_mask == "test" ? "MASK_ALL" : "NO_OP" }
      source_fields     = [task.value]
      destination_field = task.value
      task_properties   = var.env_mask == "test" ? { MASK_VALUE = "*" } : {}
      task_type         = var.env_mask == "test" ? "Mask" : "Map"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }
}

resource "aws_appflow_flow" "salesforce_to_landing_llcBiLoanC" {
  name        = "salesforce_to_landing_llcBiLoanC"
  description = "flow for LLC_BI__Loan__c object"
  kms_arn     = var.kms_key_arn

  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.llc_bi_loan_c_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"

    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.llc_bi_loan_c_path_prefix


        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }

    }

  }

  task {
    connector_operator { salesforce = "NO_OP" }
    source_fields   = [""]
    task_properties = {}
    task_type       = "Map_all"

  }

  dynamic "task" {
    for_each = var.env_mask == "test" ? var.LLC_BI__Loan__c_masking_columns : []
    content {
      connector_operator { salesforce = var.env_mask == "test" ? "MASK_ALL" : "NO_OP" }
      source_fields     = [task.value]
      destination_field = task.value
      task_properties   = var.env_mask == "test" ? { MASK_VALUE = "*" } : {}
      task_type         = var.env_mask == "test" ? "Mask" : "Map"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }
}

resource "aws_appflow_flow" "salesforce_to_landing_accountContactRelation" {
  name        = "salesforce_to_landing_accountContactRelation"
  description = "flow for AccountContactRelation"
  kms_arn     = var.kms_key_arn

  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.account_contact_relation_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.account_contact_relation_path_prefix


        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }
    }
  }

  task {
    source_fields = [""]
    task_type     = "Map_all"

    connector_operator {
      salesforce = "NO_OP"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }
}

resource "aws_appflow_flow" "salesforce_to_landing_accountAddress" {
  name        = "salesforce_to_landing_accountAddress"
  description = "flow for AccountAddress"
  kms_arn     = var.kms_key_arn

  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.account_address_c_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.account_address_path_prefix


        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }
    }
  }

  task {
    source_fields = [""]
    task_type     = "Map_all"

    connector_operator {
      salesforce = "NO_OP"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }
}

resource "aws_appflow_flow" "salesforce_to_landing_recordtype" {
  name        = "salesforce_to_landing_recordtype"
  description = "flow for recordtype object"
  kms_arn     = var.kms_key_arn


  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = var.salesforce_connector_name
    source_connector_properties {
      salesforce {
        object = var.recordtype_salesforce_object_name
        enable_dynamic_field_update = true
      }
    }
  }

  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = data.aws_s3_bucket.landing_bucket.id
        bucket_prefix = var.recordtype_path_prefix


        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = "true"
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH_AND_FILENAME"
          }

        }
      }
    }
  }

  task {
    source_fields = [""]
    task_type     = "Map_all"

    connector_operator {
      salesforce = "NO_OP"
    }
  }

  trigger_config {
    trigger_type = "OnDemand"
  }
}

module "appflow_alerting" {
  source          = "git::https://github.com/cobank-acb/dat-terraform-modules.git//appflow_alerting?ref=v20240916.29"
  resource_suffix = "salesforce"
  environment     = var.environment
  email_address   = "mb_clouddataplatformsupport@cobank.com"
  flow_arns = [
    aws_appflow_flow.salesforce_to_landing_account.arn,
    aws_appflow_flow.salesforce_to_landing_contact.arn,
    aws_appflow_flow.salesforce_to_landing_llcBiLoanC.arn,
    aws_appflow_flow.salesforce_to_landing_accountContactRelation.arn,
    aws_appflow_flow.salesforce_to_landing_accountAddress.arn,
    aws_appflow_flow.salesforce_to_landing_recordtype.arn
  ]
}