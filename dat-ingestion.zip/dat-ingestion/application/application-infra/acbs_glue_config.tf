resource "aws_s3_object" "acbs-config-script" {
  bucket = var.tooling_bucket_name
  key    = "ingestion/glue-scripts/configs/acbs.config"
  source = join(var.environment, ["${path.module}/../src/main/acbs/configs/environments/", "/acbs.config"])
  etag   = filemd5(join(var.environment, ["${path.module}/../src/main/acbs/configs/environments/", "/acbs.config"]))
}