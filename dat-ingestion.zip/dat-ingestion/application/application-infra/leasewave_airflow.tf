# Upload acbs DAG script to lak account
resource "aws_s3_object" "rds_lw_mtvw_refresh-dag-scripts" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/leasewave/leasewave_mtvw_refresh_job_dag.py"
  source = "${path.module}/../src/main/leasewave/airflow/leasewave_mtvw_refresh_job_dag.py"
  etag   = filemd5("${path.module}/../src/main/leasewave/airflow/leasewave_mtvw_refresh_job_dag.py")
}

resource "aws_s3_object" "rds_lw_mtvw_inv_amt_refresh-dag-scripts" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/leasewave/leasewave_mtvw_rcvble_inv_amt_refresh_job_dag.py"
  source = "${path.module}/../src/main/leasewave/airflow/leasewave_mtvw_rcvble_inv_amt_refresh_job_dag.py"
  etag   = filemd5("${path.module}/../src/main/leasewave/airflow/leasewave_mtvw_rcvble_inv_amt_refresh_job_dag.py")
}

resource "aws_s3_object" "lease_eod_landing_to_raw-dag-scripts" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/leasewave/lease_eod_data_landing_to_raw.py"
  source = "${path.module}/../src/main/leasewave/airflow/lease_eod_data_landing_to_raw.py"
  etag   = filemd5("${path.module}/../src/main/leasewave/airflow/lease_eod_data_landing_to_raw.py")
}