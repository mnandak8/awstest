
# Upload Glue script file to tooling
resource "aws_s3_object" "lw-glue-script-rds" {
  bucket = var.tooling_bucket_name
  key    = "consumption/glue-scripts/leasewave_mtvw_refresh_job.py"
  source = "${path.module}/../src/main/leasewave/glue/leasewave_mtvw_refresh_job.py"
  etag   = filemd5("${path.module}/../src/main/leasewave/glue/leasewave_mtvw_refresh_job.py")
}

# Upload Glue config file to tooling
resource "aws_s3_object" "lw-glue-config_script-rds" {
  bucket = var.tooling_bucket_name
  key    = "consumption/glue-scripts/configs/rds_lw_mtvw_refresh.config"
  source = join(var.environment, ["${path.module}/../src/main/leasewave/configs/environments/", "/rds_lw_mtvw_refresh.config"])
  etag   = filemd5(join(var.environment, ["${path.module}/../src/main/leasewave/configs/environments/", "/rds_lw_mtvw_refresh.config"]))
}

data "aws_iam_role" "glue-role-rds" {
  name = "cobank-${var.environment}-glue-role"
}

resource "aws_glue_job" "leasewave_mtvw_refresh_job" {
  name        = "leasewave_mtvw_refresh_job"
  role_arn    = data.aws_iam_role.glue-role-rds.arn
  connections = [var.lw-consumption-jdbc-connector]
  execution_property {
    max_concurrent_runs = 1
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.lw-glue-script-rds.bucket}/${aws_s3_object.lw-glue-script-rds.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--continuous-log-cloudwatchGroupName" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--additional-python-modules" : "s3://${aws_s3_object.glue-utils-script-rds.bucket}/${aws_s3_object.glue-utils-script-rds.key},s3://${aws_s3_object.pylib-asn1crypto.bucket}/${aws_s3_object.pylib-asn1crypto.key},s3://${aws_s3_object.pylib-pg8000.bucket}/${aws_s3_object.pylib-pg8000.key},s3://${aws_s3_object.pylib-scramp.bucket}/${aws_s3_object.pylib-scramp.key}"
    "--configScript" : "rds_lw_mtvw_refresh.config"
    "--configBucket" : var.tooling_bucket_name
    "--mtvwName" : "mtvw_hh_lw_customer_contract_list"
  }

  glue_version      = "4.0"
  worker_type       = "G.1X"
  number_of_workers = "2"

  security_configuration = aws_glue_security_configuration.lw-security_configuration.name
}

resource "aws_glue_job" "leasewave_mtvw_rcvble_inv_amt_refresh_job" {
  name        = "leasewave_mtvw_rcvble_inv_amt_refresh_job"
  role_arn    = data.aws_iam_role.glue-role-rds.arn
  connections = [var.lw-consumption-jdbc-connector]
  execution_property {
    max_concurrent_runs = 1
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.lw-glue-script-rds.bucket}/${aws_s3_object.lw-glue-script-rds.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--continuous-log-cloudwatchGroupName" : aws_cloudwatch_log_group.log-group-rds-load.name
    "--additional-python-modules" : "s3://${aws_s3_object.glue-utils-script-rds.bucket}/${aws_s3_object.glue-utils-script-rds.key},s3://${aws_s3_object.pylib-asn1crypto.bucket}/${aws_s3_object.pylib-asn1crypto.key},s3://${aws_s3_object.pylib-pg8000.bucket}/${aws_s3_object.pylib-pg8000.key},s3://${aws_s3_object.pylib-scramp.bucket}/${aws_s3_object.pylib-scramp.key}"
    "--configScript" : "rds_lw_mtvw_refresh.config"
    "--configBucket" : var.tooling_bucket_name
    "--mtvwName" : "mtvw_hh_lw_receivable_invoice_amounts"
  }

  glue_version      = "4.0"
  worker_type       = "G.1X"
  number_of_workers = "2"

  security_configuration = aws_glue_security_configuration.lw-security_configuration.name
}

resource "aws_kms_key" "lw-KMS_Glue" {
  description         = "KMS key glue job"
  enable_key_rotation = true
  policy              = <<EOF
  {
    "Version" : "2012-10-17",
    "Id" : "key-default-1",
    "Statement" : [ {
        "Sid" : "Enable IAM User Permissions",
        "Effect" : "Allow",
        "Principal" : {
          "AWS" : "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        },
        "Action" : "kms:*",
        "Resource" : "*"
      },
      {
        "Effect": "Allow",
        "Principal": { "Service": "logs.${data.aws_region.current.name}.amazonaws.com" },
        "Action": [ 
          "kms:Encrypt*",
          "kms:Decrypt*",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:Describe*"
        ],
        "Resource": "*"
      }  
    ]
  }
  EOF
}


resource "aws_kms_alias" "lw-KMS_Glue" {
  name          = "alias/lw-key-glue-job"
  target_key_id = aws_kms_key.lw-KMS_Glue.key_id
}

resource "aws_glue_security_configuration" "lw-security_configuration" {
  depends_on = [aws_kms_alias.lw-KMS_Glue]
  name       = "lw-glue-security-configuration"

  encryption_configuration {
    cloudwatch_encryption {
      cloudwatch_encryption_mode = "SSE-KMS"
      kms_key_arn                = aws_kms_key.KMS_Glue.arn
    }
    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = "CSE-KMS"
      kms_key_arn                   = aws_kms_key.KMS_Glue.arn
    }
    s3_encryption {
      s3_encryption_mode = "SSE-KMS"
      kms_key_arn        = aws_kms_key.KMS_Glue.arn
    }
  }
}
