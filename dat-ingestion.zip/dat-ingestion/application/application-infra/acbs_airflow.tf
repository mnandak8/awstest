# Upload acbs DAG script to lak account
resource "aws_s3_object" "acbs-dag-scripts-j-cami" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_cami_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_cami_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_cami_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clte" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clte_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clte_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clte_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-cams" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_cams_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_cams_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_cams_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clas" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clas_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clas_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clas_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clhs" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clhs_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clhs_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clhs_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clli" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clli_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clli_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clli_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clmi" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clmi_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clmi_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clmi_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clms" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clms_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clms_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clms_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clpb" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clpb_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clpb_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clpb_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clrs" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clrs_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clrs_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clrs_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-clsb" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_clsb_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_clsb_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_clsb_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-cucr" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_cucr_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_cucr_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_cucr_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-cums" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_cums_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_cums_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_cums_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-sydc" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_sydc_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_sydc_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_sydc_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-j-cate" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_j_cate_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_j_cate_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_j_cate_etl_dag.py")
}
resource "aws_s3_object" "acbs-dag-scripts-z-hhps" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_z_hhps_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhps_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhps_etl_dag.py")
}
resource "aws_s3_object" "acbs-dag-scripts-z-hhbs" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_z_hhbs_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhbs_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhbs_etl_dag.py")
}

resource "aws_s3_object" "acbs-dag-scripts-z-hhtr" {
  bucket = var.airflow_dag_bucket_name
  key    = "dags/ingestion/acbs/acbs2landing_z_hhtr_etl_dag.py"
  source = "${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhtr_etl_dag.py"
  etag   = filemd5("${path.module}/../src/main/acbs/airflow/acbs2landing_z_hhtr_etl_dag.py")
}
