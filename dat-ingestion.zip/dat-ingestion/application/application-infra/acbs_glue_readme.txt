Steps to add new acbs table for ingestion and manually test the load -
1. Create separate airflow dag file for new acbs table similar to "dat-ingestion\application\src\main\acbs\airflow\acbs2landing_j_cami_etl_dag.sh"
2. Run the Glue job for new table using any of the following way -
    2.1 Run the command to trigger glue job from local for new table :
        aws glue start-job-run --region us-west-2 --job-name acbs_to_landing_extract --arguments='--tableName="<>"' --profile <>
    2.2 [OR] For dev manual testing, update table name for glue job parameter (--tableName) - "dat-ingestion-new\application\application-infra\acbs_glue_job.tf"
    2.3 [OR] For dev, go to console, update/verify all the details and run the job for testing. 
3. Monitar glue job progress from the console or through aws cli commands.
4. Validate data populated on S3 landing folder for the new table.
5. Check in the airflow scripts in feature branch.
5. Deploy the airflow dag using git actions on the branch and validate if airflow is created for the table or not.
6. Test the dag for the new table
