locals {
  leasewave_glue_role              = "cobank-${var.environment}-leasewave-glue-role"
}

resource "aws_iam_role" "create_role_leasewave_glue" {
  name               = local.leasewave_glue_role
  tags               = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

# adding the roles: S3 full Access
resource "aws_iam_role_policy_attachment" "role_policy_attachment_s3_role_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}
# adding the roles: KMS full access
resource "aws_iam_role_policy_attachment" "role-policy-attachment_kms_role_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_glue_service_role_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}
resource "aws_iam_role_policy_attachment" "role_policy_attachment_glue_console_role_to_leasewave_glue_role" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = "arn:aws:iam::aws:policy/AWSGlueConsoleFullAccess"
}

resource "aws_iam_policy" "role_policy_secret_read_for_leasewave_glue_role" {
  name        = "cobank-${var.environment}-leasewave-secret-read-policy"
  description = "Policy to enable read access on Secrets Manager"
  tags        = var.tags
  policy = jsonencode(
    {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "secretsmanager:DescribeSecret",
                "secretsmanager:GetSecretValue"
            ],
            "Resource": [
                  "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
            ],
            "Effect": "Allow"
        }
    ]
}
  )
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_secrets_role_leasewave" {
  role       = aws_iam_role.create_role_leasewave_glue.name
  policy_arn = aws_iam_policy.role_policy_secret_read_for_leasewave_glue_role.arn
}