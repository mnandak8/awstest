data "aws_secretsmanager_secret" "acbs-sercret" {
  name = var.rds_secret_name
}
data "aws_secretsmanager_secret_version" "current" {
  secret_id = data.aws_secretsmanager_secret.acbs-sercret.id
}
locals {
  sensitive_secret_hash = jsondecode(nonsensitive(data.aws_secretsmanager_secret_version.current.secret_string))
}
data "aws_rds_cluster" "postgresql" {
  cluster_identifier = local.sensitive_secret_hash.dbClusterIdentifier
}
data "aws_db_subnet_group" "subnet-group-rds" {
  name = data.aws_rds_cluster.postgresql.db_subnet_group_name
}

data "aws_subnet" "rds-subnet-any" {
  id = tolist(data.aws_db_subnet_group.subnet-group-rds.subnet_ids)[0]
}

# Selecting any subnet and any availability zone for the connector
resource "aws_glue_connection" "acbs-conn" {
  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:postgresql://${local.sensitive_secret_hash.host}:${local.sensitive_secret_hash.port}/${data.aws_rds_cluster.postgresql.database_name}"
    SECRET_ID           = data.aws_secretsmanager_secret.acbs-sercret.id
  }
  name = var.rds_connector_name

  physical_connection_requirements {
    availability_zone      = data.aws_subnet.rds-subnet-any.availability_zone
    security_group_id_list = data.aws_rds_cluster.postgresql.vpc_security_group_ids
    subnet_id              = data.aws_subnet.rds-subnet-any.id
  }
}

resource "aws_glue_connection" "sfdc-acbs-rds-conn" {
  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:postgresql://${local.sensitive_secret_hash.host}:${local.sensitive_secret_hash.port}/${data.aws_rds_cluster.postgresql.database_name}"
    SECRET_ID           = data.aws_secretsmanager_secret.acbs-sercret.id
  }
  name = var.sfdc_acbs_connector

  physical_connection_requirements {
    availability_zone      = data.aws_subnet.rds-subnet-any.availability_zone
    security_group_id_list = [aws_security_group.landing_rds.id]
    subnet_id              = data.aws_subnet.rds-subnet-any.id
  }
}

resource "aws_security_group" "landing_rds" {
  name        = "cobank-dl-landing-rds-security-${var.environment}"
  description = "Allow traffic for landing to rds"
  vpc_id      = data.aws_vpc.app_vpc.id

  tags = {
    Name = "landing_rds"
  }
}

resource "aws_vpc_security_group_ingress_rule" "landing_rds_ingress" {
  security_group_id = aws_security_group.landing_rds.id
  cidr_ipv4         = data.aws_vpc.app_vpc.cidr_block
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"
 }


resource "aws_vpc_security_group_egress_rule" "landing_rds_egress" {
  security_group_id = aws_security_group.landing_rds.id
  description       = "RDS egress"
  for_each          = var.rds_vpc_cidr_blocks_egress
  cidr_ipv4         = each.value
  ip_protocol       = "-1"
}
