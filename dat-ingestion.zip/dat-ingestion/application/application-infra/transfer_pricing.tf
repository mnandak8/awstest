# This data source will return the VPC ID for the application
data "aws_vpc" "app_vpc" {
  tags = {
    Name = "DA_${upper(var.environment)}-vpc"
  }
}

# This data source will return the application subnets of the VPC
data "aws_subnets" "app_subnets" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.app_vpc.id]
  }
  filter {
    name   = "tag:Name"
    values = ["*-application-subnet*"]
  }
}


module "transfer_pricing_lambda" {
  source          = "git::https://github.com/cobank-acb/dat-terraform-modules.git//lambda_docker?ref=main"
  environment     = var.environment
  resource_suffix = "transfer-pricing"
  email_address   = var.email_address
  image_command   = ["transfer_pricing.lambda_handler"]
  ecr_repo_name   = "transfer-pricing"
  subnet_ids      = data.aws_subnets.app_subnets.ids
  vpc_id          = data.aws_vpc.app_vpc.id
  environment_variables = {
    RAPPORT_DB_SECRET_NAME = var.rapport_db_secret_name
    TC_SECRET_NAME         = aws_secretsmanager_secret.transfer_pricing_api_secret.name
    REQUESTS_CA_BUNDLE     = "/etc/pki/tls/cert.pem"
    RAPPORT_SQL_QUERY      = var.rapport_sql_query
    SQS_URL                = data.aws_sqs_queue.transfer_pricing_queue.url
    DLQ_URL                = data.aws_sqs_queue.transfer_pricing_dlq.url
    MAX_RETRIES            = "3"
  }
}

##Uncomment the following code block to add security group egress rules if we are placing the transfer_pricing_lambda in a VPC.

resource "aws_vpc_security_group_egress_rule" "financial_pricing_https_outbound_rule" {
  security_group_id = module.transfer_pricing_lambda.security_group_id
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = 443
  ip_protocol       = "tcp"
  to_port           = 443
  description       = "Allow outbound HTTPS traffic to all"
}

resource "aws_vpc_security_group_egress_rule" "financial_pricing_mssql_outbound_rule" {
  security_group_id = module.transfer_pricing_lambda.security_group_id
  cidr_ipv4         = "0.0.0.0/0"
  from_port         = 26000
  ip_protocol       = "tcp"
  to_port           = 26000
  description       = "Allow outbound MSSQL traffic to all"
}


data "aws_iam_policy_document" "execution_policy" {
  statement {
    effect = "Allow"
    actions = [
      "kms:GenerateDataKey",
      "kms:Encrypt",
      "kms:Decrypt",
      "s3:GetObject"
    ]
    resources = [
      aws_secretsmanager_secret.transfer_pricing_api_secret.arn,
      data.aws_secretsmanager_secret.rapport_db_secret.arn,
      "${data.aws_s3_bucket.rapport_s3_bucket.arn}/*",
      data.aws_kms_alias.dms_kms_key_alias.target_key_arn
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:DescribeSecret",
      "secretsmanager:ListSecrets"
    ]
    resources = [
      aws_secretsmanager_secret.transfer_pricing_api_secret.arn,
      data.aws_secretsmanager_secret.rapport_db_secret.arn
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "sqs:SendMessage",
      "sqs:ReceiveMessage",
      "sqs:GetQueueAttributes",
      "sqs:GetQueueUrl",
      "sqs:DeleteMessage"
    ]
    resources = [
      data.aws_sqs_queue.transfer_pricing_queue.arn
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "sqs:SendMessage",
      "sqs:GetQueueAttributes",
      "sqs:GetQueueUrl"
    ]
    resources = [
      data.aws_sqs_queue.transfer_pricing_dlq.arn
    ]
  }

}

data "aws_kms_alias" "dms_kms_key_alias" {
  name = "alias/${var.dms_kms_key_alias}"
}

data "aws_s3_bucket" "rapport_s3_bucket" {
  bucket = var.rapport_s3_bucket_name
}

data "aws_sqs_queue" "transfer_pricing_queue" {
  name = var.rapport_sqs_name
}

data "aws_sqs_queue" "transfer_pricing_dlq" {
  name = var.rapport_dlq_name
}

data "aws_secretsmanager_secret" "rapport_db_secret" {
  name = var.rapport_db_secret_name
}

resource "aws_iam_policy" "transfer_pricing_lambda_execution_policy" {
  name   = "cobank-dl-${local.account_id}-lambda-authorizer-policy-${var.environment}"
  policy = data.aws_iam_policy_document.execution_policy.json
}

resource "aws_iam_role_policy_attachment" "execution_policy_attach" {
  role       = module.transfer_pricing_lambda.role_name
  policy_arn = aws_iam_policy.transfer_pricing_lambda_execution_policy.arn
}

resource "aws_secretsmanager_secret" "transfer_pricing_api_secret" {
  name        = "transfer_pricing_api_secret"
  description = "This secret is for holding the password that is used for accessing the Treasury Connect APIs."
}

resource "aws_secretsmanager_secret_version" "transfer_pricing_tc_api_secret_version" {
  secret_id = aws_secretsmanager_secret.transfer_pricing_api_secret.id
  secret_string = jsonencode({
    tc_url      = var.tc_api_url,
    api_key     = "",
    lw_url      = "https://leasewavedevapi.na.cobank2.corp/api/Entity/Party/",
    lw_username = "svcLWaveSLayerD",
    lw_password = ""
  })
}

 # Event source from SQS
resource "aws_lambda_event_source_mapping" "event_source_mapping" {
  event_source_arn = data.aws_sqs_queue.transfer_pricing_queue.arn
  enabled          = true
  function_name    = module.transfer_pricing_lambda.function_arn
  batch_size       = 1
}
