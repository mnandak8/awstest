/*data "aws_caller_identity" "current" {}
locals {
  account_id  = data.aws_caller_identity.current.account_id
}*/

# Define the IAM role for party data
resource "aws_iam_role" "glue_party_role" {
  name = "cobank-${var.environment}-glue-party-role"

  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::${var.lake_account_id}:role/cobank-${var.environment}-airflow-environment",
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

# Define the s3-party-policy
resource "aws_iam_policy" "s3_party_access" {
  name = "cobank-${var.environment}-s3-party-access"

  policy = jsonencode(
    {

      "Version" : "2012-10-17",
      "Statement" : [
        {
          "Effect" : "Allow",
          "Action" : "s3:*"
          "Resource" : [
            "arn:aws:s3:::${var.landing_bucket_name}/salesforce/*",
            "arn:aws:s3:::${var.tooling_bucket_name}/*"
          ]
        }
      ]
    }
  )
}

# Define the cross account rds policy
#   resource "aws_iam_policy" "cross_account_rds" {
#   name = "cobank-${var.environment}-cross-account-rds"

#    policy = jsonencode(
#     {

#     "Version": "2012-10-17",
#     "Statement": [
#         {
#             "Effect": "Allow",
#             "Action": "rds-data:*",
#             "Resource": "*"
#         },
#         {
#             "Sid": "RDSDataServiceAccess",
#             "Effect": "Allow",
#             "Action": [
#                 "rds-data:ExecuteSql",
#                 "rds-data:ExecuteStatement",
#                 "rds-data:BatchExecuteStatement",
#                 "rds-data:BeginTransaction",
#                 "rds-data:CommitTransaction",
#                 "rds-data:RollbackTransaction",
#                 "tag:GetResources"
#             ],
#             "Resource": "*"
#         }
#     ]
# }
#    )
#   }

resource "aws_iam_role_policy_attachment" "AmazonRDSDataFullAccess_policy_attach" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess"
}

resource "aws_iam_role_policy_attachment" "AmazonEC2ContainerRegistryReadOnly_policy_attach" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_role_policy_attachment" "glue_service_role_policy_attach" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}

resource "aws_iam_role_policy_attachment" "cross_account_lake_airflow_policy_attach" {
  role = aws_iam_role.glue_party_role.name
  # policy_arn = aws_iam_policy.cross_account_lake_airflow_policy.arn
  policy_arn = "arn:aws:iam::${local.account_id}:policy/cobank-${var.environment}-cross-account-lake-airflow-policy"
}

# resource "aws_iam_role_policy_attachment" "cross-account-rds" {
#   role       = aws_iam_role.glue_party_role.name
#   policy_arn = aws_iam_policy.cross_account_rds.arn
# }

resource "aws_iam_role_policy_attachment" "s3-party-policy" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = aws_iam_policy.s3_party_access.arn
}

resource "aws_iam_role_policy_attachment" "secret-read-glue" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/cobank-${var.environment}-secret-read-glue"
}

resource "aws_iam_role_policy_attachment" "kms_full_policy_attach" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}

resource "aws_iam_role_policy_attachment" "cloudwatchlogsaccess" {
  role       = aws_iam_role.glue_party_role.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
}

