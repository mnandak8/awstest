module "leasewave_asset_bucket" {
  source                     = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20250117.77"
  #lake_type                  = "dl"
  encryption_type            = "sse-s3"
  resource_suffix            = "leasewave-asset"
  environment                = var.environment
  terra_factory_aws_id       = var.terra_factory_aws_id
  expiration_days            = 2555
  ia_transition_days         = 365
  versioning                 = true
  #governance_account_id      = var.governance_account_id
  log_bucket_name            = "cobank-dl-${local.account_id}-${local.region_name}-logs-${var.environment}"
  outside_account_ids        = [var.lake_account_id]
}
