data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
locals {
  account_id                          = data.aws_caller_identity.current.account_id
  region_name                         = data.aws_region.current.name
  lw_dms_role                     = "cobank-${var.environment}-lw-dms-role"
  ods_consumption_secrets_manager_arn = "arn:aws:secretsmanager:${local.region_name}:${var.consumption_account_id}:secret:${var.ods_consumption_secrets_manager_arn_id}"
  ods_consumption_secrets_manager_kms_key_arn  = "arn:aws:kms:${local.region_name}:${var.consumption_account_id}:key/${var.ods_consumption_secrets_manager_arn_kms_key_id}"
}

resource "aws_iam_role" "create_role_lw_dms" {
  name               = local.lw_dms_role
  tags               = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "",
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.${local.region_name}.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Sid": "Airflow",
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.${local.region_name}.amazonaws.com",
                "AWS": "arn:aws:sts::${var.lake_account_id}:assumed-role/cobank-${var.environment}-airflow-environment/AmazonMWAA-airflow"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

# AWS mandates that this role name should exist in the account for cloudwatch logs to work
resource "aws_iam_role" "create-dms-cloudwatch-dms-log-role" {
  name               = "dms-cloudwatch-logs-role"
  tags               = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "",
            "Effect": "Allow",
            "Principal": {
                "Service": "dms.${local.region_name}.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

# adding the roles: S3 full Access
resource "aws_iam_role_policy_attachment" "role_policy_attachment_s3_role_lw_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}
# adding the roles: KMS full access
resource "aws_iam_role_policy_attachment" "role-policy-attachment_kms_role_lw_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::${local.account_id}:policy/KMSFullAccess"
}
# AmazonDMSCloudWatchLogsRole
resource "aws_iam_role_policy_attachment" "role_policy_attachment_cloudwatch_role_lw_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole"
}
resource "aws_iam_role_policy_attachment" "role_policy_attachment_dmsvpcmanagment_role_lw_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_dms_ec2_container_registry" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_dms_glue_service_role" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}
resource "aws_iam_role_policy_attachment" "role_policy_attachment_dms_glue_console" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/AWSGlueConsoleFullAccess"
}
resource "aws_iam_role_policy_attachment" "role_policy_attachment_sns_full_access" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSNSFullAccess"
}

# AmazonDMSCloudWatchLogsRole
resource "aws_iam_role_policy_attachment" "role_policy_attachment_aws_required_cloudwatch_role_lw_dms" {
  role       = aws_iam_role.create-dms-cloudwatch-dms-log-role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole"
}

##
resource "aws_iam_policy" "role_policy_attachment_dms_secret_read_role_lw_dms" {
  name        = "cobank-${var.environment}-dms-secret-read-policy"
  description = "Policy to enable read access on Secrets Manager for dms"
  tags        = var.tags
  policy = jsonencode(
    {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "secretsmanager:DescribeSecret",
                "secretsmanager:GetSecretValue"
            ],
            "Resource": [
                  "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
            ],
            "Effect": "Allow"
        },
		    {
            "Action": [
                "secretsmanager:DescribeSecret",
                "secretsmanager:GetSecretValue"
            ],
            "Resource": [
                "${local.ods_consumption_secrets_manager_arn}"
            ],
            "Effect": "Allow"
        },
	
	{
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey"
            ],
            "Resource": [
                "${local.ods_consumption_secrets_manager_kms_key_arn}"
            ],
            "Effect": "Allow"
        }
    ]
}
  )
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_secrets_role_lw_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = aws_iam_policy.role_policy_attachment_dms_secret_read_role_lw_dms.arn
}

############ DMS MWAA policy
resource "aws_iam_policy" "role_policy_attachment_dms_strat_stop_task" {
  name        = "cobank-${var.environment}-dms-start-stop-replicationTasks"
  description = "Policy MWAA to start and stop"
  tags        = var.tags
  policy = jsonencode(
{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Sid": "VisualEditor0",
			"Effect": "Allow",
			"Action": [
				"dms:StartReplicationTask",
				"dms:StopReplicationTask",
				"dms:StartReplication",
				"dms:StopReplication"
			],
			"Resource": "arn:aws:dms:*:${local.account_id}:task:*"
		}
	]
}

)
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_strat_stop_task_dms" {
  role       = aws_iam_role.create_role_lw_dms.name
  policy_arn = aws_iam_policy.role_policy_attachment_dms_strat_stop_task.arn
}

############################################################################

#creatres a role cobank-(env)-dat-ing-salesforce-events-role
resource "aws_iam_role" "create_role_sfdc_events" {
  name               = "cobank-${var.environment}-dat-ing-salesforce-events-role"
  tags               = var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "",
            "Effect": "Allow",
            "Principal": {
                "Service": "apidestinations.events.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        },
        {
            "Effect": "Allow",
            "Action": [
                "sts:AssumeRole"
            ],
            "Principal": {
                "Service": [
                    "lambda.amazonaws.com"
                ]
            }
        }
    ]
}
EOF
}




# adding the roles: S3 full Access
resource "aws_iam_role_policy_attachment" "role_policy_attachment_s3_role_sfdc_events" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
}
# adding the roles: KMS full access

resource "aws_iam_role_policy_attachment" "role_policy_attachment_cloudwatch_role_sfdc_events" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchEventsFullAccess"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_secerctread" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/SecretsManagerReadWrite"
}



resource "aws_iam_role_policy_attachment" "role_policy_attachment_dmsvpcmanagment_lambda_vpc_access" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_lambda_full" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/AWSLambda_FullAccess"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_sqs_execution_role" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaSQSQueueExecutionRole"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_EC2ContainerRegistryReadOnly" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_RDS" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonRDSFullAccess"
}
resource "aws_iam_role_policy_attachment" "role_policy_attachment_cloudwatchlogs" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
}

##
resource "aws_iam_policy" "role_policy_attachment_secret_sqs_sns_read_role_sfdc_events" {
  name        = "cobank-${var.environment}-sfdc_events-secret-read-kms-sqs-sns-policy"
  description = "Policy to enable read access on Secrets Manager for sfdc_events"
  tags        = var.tags
  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement" : [
        {
          "Action" : [
            "secretsmanager:DescribeSecret",
            "secretsmanager:GetSecretValue"
          ],
          "Resource" : [
            "arn:aws:secretsmanager:us-west-2:${local.account_id}:secret*"
          ],
          "Effect" : "Allow"
        },
        {
            "Action": [
			          "secretsmanager:DescribeSecret",
                "secretsmanager:GetSecretValue"
            ],
            "Resource": [
                "${local.ods_consumption_secrets_manager_arn}"
            ],
            "Effect": "Allow"
        },
        {
          "Action" : [
            "kms:Decrypt",
            "kms:DescribeKey"
          ],
          "Resource" : [
            "arn:aws:kms:us-west-2:${var.consumption_account_id}:key*"
          ],
          "Effect" : "Allow"
        },
		 
        {
          "Action" : [
            				"kms:Create*",
                "kms:Describe*",
                "kms:Enable*",
                "kms:List*",
                "kms:Put*",
                "kms:Update*",
                "kms:Revoke*",
                "kms:Disable*",
                "kms:Get*",
                "kms:Delete*",
                "kms:TagResource",
                "kms:UntagResource",
                "kms:ScheduleKeyDeletion",
                "kms:CancelKeyDeletion",
		"kms:Encrypt*",
		"kms:Decrypt*",
		"kms:ReEncrypt*",
		"kms:GenerateDataKey*",
		"kms:Describe*"
          ],
          "Resource" : "arn:aws:kms:us-west-2:${local.account_id}:*"
          "Effect" : "Allow"
        },
                {
          "Action" : [
            "sns:CreateTopic", "sns:ListTopics", "sns:SetTopicAttributes", "sns:DeleteTopic","sns:Publish","sns:Subscribe"
          ],
          "Resource" : "arn:aws:sns:us-west-2:${local.account_id}:*"
          "Effect" : "Allow"
        },

        {
            "Sid": "AWSXRayDaemonWriteAccess",
            "Effect": "Allow",
            "Action": [
                "xray:PutTraceSegments",
                "xray:PutTelemetryRecords",
                "xray:GetSamplingRules",
                "xray:GetSamplingTargets",
                "xray:GetSamplingStatisticSummaries"
            ],
            "Resource": [
                "*"
            ]
        }, 

        {
          "Action" : [
            "sqs:SendMessage","sqs:ReceiveMessage"
          ],
          "Resource" : "arn:aws:sqs:us-west-2:${local.account_id}:*"
          "Effect" : "Allow"
        }
      ]
    }
  )
}

resource "aws_iam_role_policy_attachment" "role_policy_attachment_secrets_role_salesforce_events" {
  role       = aws_iam_role.create_role_sfdc_events.name
  policy_arn = aws_iam_policy.role_policy_attachment_secret_sqs_sns_read_role_sfdc_events.arn
}
