# Upload Glue script file to tooling
resource "aws_s3_object" "glue-script" {
  bucket = var.tooling_bucket_name
  key    = "ingestion/glue-scripts/acbs_to_landing_extract.py"
  source = "${path.module}/../src/main/acbs/glue/acbs_to_landing_extract.py"
  etag   = filemd5("${path.module}/../src/main/acbs/glue/acbs_to_landing_extract.py")
}

# Upload utils lib to tooling
## TODO Move creation of wheel file to actions module main
resource "aws_s3_object" "glue-utils-script" {
  bucket = var.tooling_bucket_name
  key    = "ingestion/utils-0.1-py3-none-any.whl"
  source = "${path.module}/../src/main/libs/utils-0.1-py3-none-any.whl"
  etag   = filemd5("${path.module}/../src/main/libs/utils-0.1-py3-none-any.whl")
}

resource "aws_cloudwatch_log_group" "log-group-ingestion" {
  name              = "/aws-glue/jobs/ingestion-log-group"
  kms_key_id        = aws_kms_key.cloudwatch-kms-key.arn
  retention_in_days = 365
  tags              = { "Splunk" = var.splunk_tag }
  # tags = { "Splunk" = true }
}
resource "aws_kms_alias" "KMS_cloudwatch_acbs" {
  name          = "alias/key-cloudwatch-group_acbs"
  target_key_id = aws_kms_key.cloudwatch-kms-key.key_id
}
data "aws_iam_role" "glue-role" {
  name = var.glue_role_name
}

resource "aws_glue_job" "acbs_to_landing_extract" {
  name        = "acbs_to_landing_extract"
  role_arn    = data.aws_iam_role.glue-role.arn
  connections = [var.rds_connector_name]
  execution_property {
    max_concurrent_runs = 20
  }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.glue-script.bucket}/${aws_s3_object.glue-script.key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--enable-continuous-cloudwatch-log" : "false"
    "--continuous-log-logGroup" : aws_cloudwatch_log_group.log-group-ingestion.name
    "--continuous-log-cloudwatchGroupName" : aws_cloudwatch_log_group.log-group-ingestion.name
    "--additional-python-modules" : "s3://${aws_s3_object.glue-utils-script.bucket}/${aws_s3_object.glue-utils-script.key}"
    "--configScript" : "acbs.config"
    "--tableName" : "j_clms"
    "--configBucket" : var.tooling_bucket_name
    "--landingBucket" : var.landing_bucket_name
    "--enable-auto-scaling" = true
  }

  glue_version      = "4.0"
  worker_type       = "G.2X"
  number_of_workers = "10"
}
