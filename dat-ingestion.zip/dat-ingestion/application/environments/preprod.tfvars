landing_bucket_name                            = "cobank-dl-211125365237-us-west-2-landing-preprod"
tooling_bucket_name                            = "cobank-dl-211125365237-us-west-2-tooling-preprod"
kms_key_arn                                    = "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
salesforce_connector_name                      = "cobank-preprod-211125365237-sfdc-appflow-connector"
airflow_dag_bucket_name                        = "cobank-dl-654654411062-us-west-2-airflow-preprod"
glue_role_name                                 = "cobank-preprod-glue-role"
rds_secret_name                                = "RDSpreprodACBSDB-ETL"
env_mask                                       = "preprod"
audit_url                                      = "https://u3ihiwxaak.execute-api.us-west-2.amazonaws.com/preprod/audit"
consumption_rds_connector_name                 = "cobank-dl-rds-connection-party-preprod"
ods_consumption_secrets_manager_arn_id         = "cobank-dl-rds-user-secret-ods-svclwdms-preprod-JoJIKU"
ods_consumption_secrets_manager_arn_kms_key_id = "a26dc229-ca9f-47bd-b85a-66102dc5dd9b"
consumption_account_id                         = "905418043661"
lake_account_id                                = "654654411062"
governance_account_id			       = "975050018987"
email_address                                  = "mb_clouddataplatformsupport@cobank.com"
lambda_role_name                               = "cobank-preprod-lambda-role"
tags = {
  "cobank:cost-allocation:cost-center" = "8030"
  "cobank:operations:support-group"    = "Transformation Programs"
}
tc_api_url             = "https://SGNDMVTCONN001.na.cobank2.corp/api/TP/Lease/ProcessLeaseDetails"
rapport_db_secret_name = "dms-rapport-preprod-credentials-sqlserver-onprem"
rapport_sqs_name       = "cobank-preprod-rapport-sqs-s3-event-notification-queue"
rapport_dlq_name       = "cobank-preprod-rapport-sqs-dead-letter-queue"
rapport_s3_bucket_name = "preprod-acb-dl-dat-ing-rapport-asset"
dms_kms_key_alias      = "cobank-dl-211125365237-kms-key-rapport-preprod"

lw-consumption-jdbc-connector = "cobank-ods-rds-jdbc-connection-preprod"
rapport_sql_query      = <<EOF
select --top(10) 
SETUP_FKEY
,CTS_CONTRACT_NUMBER AS 'AccountNumber' -- TPP
,ENT_NAME AS 'CustomerName' --TPP 
,ENT_REFERENCE_NUM as 'CustomerNumber' -- TPP
,CAST(CO_BOOKING_DATE as DATE) as 'BookingDate'
,CO_VARIABLE_PYMT_CODE 
,CAST(CO_ACTIV_DATE as DATE) as 'CommencementDate'
,CO_FIRST_PYMT_DATE as 'FirstPrincipalPaymentDate'
,CO_FIRST_PYMT_DATE as 'FirstInterestPaymentDate'
,CO_TERM_DATE as 'NextRepriceDate'
,CO_TERM_DATE as 'MaturityDate'
,CO_TERM_DATE as 'AmortizationMaturityDate'
,CO_EQUIPMENT_COST as 'PricingAmount'--TPA
,CO_RESIDUAL AS 'LeaseResidualAmount' --TPA
, '00' as 'DayCountConvention' --TPA id of 4
,CO_UM_USER_AMT1 /100 as 'ExpectedRate' --TPA
,CO_PRETAX_YIELD
,CO_PRICING_TARGET_YIELD  /100 AS 'InterestRate'--TPA	
,3 AS 'LineOfBusiness'--TPA															
,CASE WHEN CO_UD_FCL_SHARE_PCT = 100 THEN 6 ELSE 1 END AS 'ParticipationTypeId' -- TPA GUESSING
,CO_UD_FCL_SHARE_PCT /100 as 'NetHoldPercentage'--TPA
,ROUND(CO_UD_FCL_SHARE_PCT / 100 * CO_EQUIPMENT_COST,2) as 'NetHoldAmount' -- TPA					TODO Validate
,CO_UD_FCL_SHARE_PCT
,CASE WHEN CO_UD_FCL_SHARE_PCT <> 100 then DLR_REFERENCE_NUM
	WHEN CO_UD_FCL_SHARE_PCT = 100 then null end as  'Dealer Reference Number'
,CASE WHEN CO_UD_FCL_SHARE_PCT <> 100 then  DLR_NAME 
	WHEN CO_UD_FCL_SHARE_PCT = 100 then null end as DLR_NAME
,CO_UD_PREPAYABLEDEBT
,EB_EARLY_BUYOUT_DATES
,CASE WHEN CO_UD_PREPAYABLEDEBT = 0 THEN 'Makewhole' 
	When CO_UD_PREPAYABLEDEBT = 1 and EB_EARLY_BUYOUT_DATES is not null then 'Lockout'
	ELSE 'Prepayable' END AS 'WholesalePrepaymentOption'
,CO_PRICING_PYMT_FREQUENCY_TBDESC AS 'PrincipalPaymentFrequency'
,CO_UD_AMR_SOFTCOST_STATUS_TBDESC
,CO_LEASE_TYPE_TBDESC
,CO_UD_APP_STATUS 
,CO_UD_APP_STATUS_TBDESC
,EB_EARLY_BUYOUT_DATES AS 'LockoutDate'
,CONTRACT_SETUP.CTS_DECISION_CODE_FKEY
FROM RPT_CO
inner join APPLICATION ON RPT_CO.APP_FKEY = APPLICATION.APP_KEY
inner join ENTITY ON APPLICATION.CUST_FKEY = ENTITY.ENT_KEY
inner join DEALER ON RPT_CO.CO_DEALER = DEALER.DLR_KEY
inner join CONTRACT_SETUP ON RPT_CO.SETUP_FKEY = CONTRACT_SETUP.CTS_CONTRACT_SETUP_KEY
LEFT JOIN RPT_EB ON RPT_CO.CO_KEY = RPT_EB.CO_FKEY
WHERE RPT_CO.Setup_FKey = ?
order by CO_BOOKING_DATE desc
EOF
leasewave_glue_role                            = "cobank-preprod-leasewave-glue-role"
leasewave_landing_bucket_name                  = "preprod-acb-dat-ing-leasewave-asset"
