aws_region         = "us-west-2"
cost_center        = "8030"
rds_connector_name = "AcbsDbConnection"
sfdc_acbs_connector = "SfdcAcbsDbConnection"
splunk_tag         = "true"
rds_vpc_cidr_blocks_ingress= ["10.70.4.0/25"]
rds_vpc_cidr_blocks_egress= ["10.70.4.0/25","10.70.8.0/22","10.70.0.0/23","10.64.0.7/32","10.64.0.105/32","10.64.0.121/32","10.64.0.19/32","172.30.110.0/24"]
