#############################################################
#---------------------- COMMON TFVARS ----------------------#
#############################################################
variable "cost_center" {
  type = string
}
variable "rds_connector_name" {
  type = string
}
variable "splunk_tag" {
  type = string
}
#############################################################
#---------------------- {ENV} TFVARS ----------------------#
#############################################################
variable "landing_bucket_name" {
  type = string
}
variable "tooling_bucket_name" {
  type = string
}
variable "kms_key_arn" {
  type = string
}
variable "salesforce_connector_name" {
  type = string
}
variable "airflow_dag_bucket_name" {
  type = string
}
variable "glue_role_name" {
  type = string
}
variable "rds_secret_name" {
  type = string
}
variable "env_mask" {
  type = string
}
variable "consumption_rds_connector_name" {
  type = string
}

variable "lake_account_id" { type = string }
variable "consumption_account_id" { type = string }
variable "ods_consumption_secrets_manager_arn_id" { type = string }
variable "ods_consumption_secrets_manager_arn_kms_key_id" { type = string }

variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "rapport_db_secret_name" {
  type = string
}

variable "rapport_sqs_name" {
  type = string
}

variable "rapport_dlq_name" {
  type = string
}

variable "rapport_s3_bucket_name" {
  type = string
}

variable "rapport_sql_query" {
  type = string
}

variable "tc_api_url" {
  type = string
}

variable "email_address" {
  type = string  
}

variable "dms_kms_key_alias" {
  type = string
}


variable "rds_vpc_cidr_blocks_ingress" { type = set(string)}
variable "rds_vpc_cidr_blocks_egress" { type = set(string)}
variable "governance_account_id" {
  type        = string
  description = "governance account id"
}


variable "lw-consumption-jdbc-connector" {
  description = "lw connector for glue job"
  type        = string
}

variable "leasewave_glue_role" {
  description = "leasewave_glue_role"
  type        = string
}

variable "leasewave_landing_bucket_name" {
  description = "landing bucket full name for leaewave"
  type        = string
}