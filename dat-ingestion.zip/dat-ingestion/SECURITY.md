# Security Policy

This is provided only for the processing of CoBank information.  

All data contained on this system or related systems, which includes but it not limited to, network servers, laptops, storage devices, storage media, routers, firewalls or other computer equipment, used in support of CoBank, is the property of CoBank.  
All activities and data on these systems may be monitored, intercepted, recorded, read, copied or otherwise captured by authorized personnel for various purposes which may lead to and include termination of employment or prosecution of criminal activity.  
Any user, authorized or unauthorized, who access this system expressly consents to this monitoring, releases CoBank from any liability that may result from his or her unauthorized use, and acknowledges responsibility for his or her access and use.  
By accessing and using this system, or related systems, you hereby acknowledge that you have read, understand, and will comply with the most recent version of [**CoBanks S1721-End-User Computing Guidelines**](https://intranet/InsideCoBank/enterprisesecurity/_layouts/15/DocIdRedir.aspx?ID=7DT2XM4RP2YR-488-32).  

This document and all other security policy documents are located on the [**Enterprise Security Intranet site**](https://intranet/InsideCoBank/enterprisesecurity/Pages/Enterprise%20Security%20Home.aspx).

# Static Code Analysis & Security Analysis

## Part of the Cyrus 16 Gates:

- Gate 4 - Static Code Analysis
- Gate 5 - Security Analysis

### Code Scanning (Static Code Analysis) workflow information can be found here:

- [cpe-code-scanning](https://github.com/cobank-acb/cpe-code-scanning/blob/main/README.md)
  
### The Architectural Decision Records (ADR) for gates 4 and 5 are available here:

- [0005-gate-four-static-code-analysis](https://github.com/cobank-acb/arc-adrs/blob/main/docs/decisions/devops-cloud/0005-gate-four-static-code-analysis.md)
- [0006-gate-five-security-analysis](https://github.com/cobank-acb/arc-adrs/blob/main/docs/decisions/devops-cloud/0006-gate-five-security-analysis.md)
