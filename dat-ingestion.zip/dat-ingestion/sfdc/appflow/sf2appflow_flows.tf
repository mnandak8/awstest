data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
   account_id            = data.aws_caller_identity.current.account_id
   region_name           = data.aws_region.current.name
    task_type            = "Map_all"
    trigger_type         = "OnDemand"
    bucket_prefix        = "salesforce/EOD"
    no_ops               = "NO_OP"
    mask_all             = "MASK_ALL" 
    flow_name            = "${var.sf_object}_sfdc_to_ing_EOD"
    flow_desc            = "Flow for ${var.sf_object} object"
    execution_id         = "EXECUTION_ID" 
    schema_version       = "SCHEMA_VERSION"
    dag_path             = "${path.root}/airflow/dags/sf2ing_dag.py"
    dag_s3_key           = "dags/sf2ing/sf2ing_dag.py"
    glue_role            = "arn:aws:iam::${local.account_id}:role/cobank-${var.env}-glue-role"
    target_bucket        = "${var.env}-acb-dat-ing-sfdc-asset" 
    sf_connector         = "cobank-${var.env}-${local.account_id}-sfdc-appflow-connector"
    preserve_data_typing = "true"
    mask                 = "Mask" 
    map                  = "Map"
    
}

resource "aws_appflow_flow" "sfdc_appflow_flows" {
  name        = local.flow_name
  description = local.flow_desc
  kms_arn     = var.appflow_centralized_kms_key_arn
  source_flow_config {
    connector_type         = "Salesforce"
    connector_profile_name = local.sf_connector
    source_connector_properties {
      salesforce {
        object = var.sf_object
      }
    }
  }
  destination_flow_config {
    connector_type = "S3"
    destination_connector_properties {
      s3 {
        bucket_name   = local.target_bucket
        bucket_prefix = local.bucket_prefix
        s3_output_format_config {
          file_type                   = "PARQUET"
          preserve_source_data_typing = local.preserve_data_typing
          prefix_config {
            prefix_format = "DAY"
            prefix_type   = "PATH"
            prefix_hierarchy = [local.execution_id]
          }
        }
      }
    }
  }
  task {
    connector_operator { salesforce = local.no_ops }
    source_fields   = []
    task_properties = {}
    task_type       = local.task_type
  }
  dynamic "task" {
    for_each = var.env == "test" ? var.columns2mask : []
    content {
      connector_operator { salesforce = var.env == "test" ? local.mask_all : local.no_ops }
      source_fields     = [task.value]
      destination_field = task.value
      task_properties   = var.env == "test" ? { MASK_VALUE = "*" } : {}
      task_type         = var.env == "test" ? local.mask : local.map
    }
  }
  trigger_config {
    trigger_type = local.trigger_type
  }
}
