variable "appflow_centralized_kms_key_arn" {type = string}
variable "sf_object" {type = string}
variable "env" {type = string}
variable "columns2mask" {type = list(string)}
#variable "create" {type = bool}


