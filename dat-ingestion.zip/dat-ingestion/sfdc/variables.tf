variable "email_address" { type = string }
variable "resource_prefix" { type = string }
variable "tags" { type = map(string) }
variable "lake_account_id" { type = string }
variable "consumption_account_id" { type = string }
variable "governance_account_id" { type = string }
variable "sfdc_partner_source_name" { type = string }

variable "visibility_timeout_seconds" { type = string }
variable "delay_seconds" { type = string }
variable "sqs_max_message_size" { type = string }
variable "sqs_message_retention_seconds" { type = string }
variable "sqs_receive_wait_time_seconds" { type = string }
variable "maximum_event_age_in_seconds" { type = string }
variable "maximum_retry_attempts" { type = string }
variable "vpc_name" { type = string }
variable "vpc_cidr_blocks_ingress" { type = list(any) }
variable "vpc_cidr_blocks_egress" { type = list(any) }
variable "pg_secret_arn" { type = string }
variable "events_kms_key_name" { type = string }
variable "sfdc_event_security_name" { type = string }
variable "lambda_invoke_congig_maximum_event_age_in_seconds" { type = string }
variable "lambda_invoke_congig_maximum_retry_attempts" { type = string }
variable "appflow_centralized_kms_key_arn" { type = string }

variable "objects" {
  type = map(object({
    columns2mask = optional(list(string))
  }))
}

