#######################################################################################
# The following code is utilized in Lambda, which is triggered by Salesforce CDC Events from the Event Bridge Bus via Rules.
#  If there is any Event sent to SQS as part of the DLQ settings for the Events Rule and Lambda 
#  this lambda is triggered and sends email  
####################################################################################################

import json
import boto3
import os
from datetime import datetime

snsarn: str = os.environ.get('snsarn')
environment: str = os.environ.get('environment')
inglandingbucket: str = os.environ.get('inglandingbucket')


def lambda_handler(event, context):
    event =json.dumps(event)
    my_bucket_name=inglandingbucket
    curr_date = datetime.today().strftime('%Y%m%d')
    curr_ts = datetime.today().strftime('%H%M%f')
    request_id = context.aws_request_id
    filename="SQS_"
    target_key=f"salesforce/failedevents_sqs/{curr_date}/{filename}_{curr_ts}_{request_id}"
    s3_client = boto3.client('s3')
    s3_client.put_object(Body=event, Bucket=my_bucket_name, Key=target_key)
    message=f" One of the SFDC Events made a way to SQS in {environment}   {snsarn} "
    sub=f" One of the SFDC Events made a way to SQS in {environment}  "
    client = boto3.client('sns')
    response = client.publish(
        TargetArn=snsarn,
        Message=message,
        Subject=sub
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('SNS Sent')
    }
