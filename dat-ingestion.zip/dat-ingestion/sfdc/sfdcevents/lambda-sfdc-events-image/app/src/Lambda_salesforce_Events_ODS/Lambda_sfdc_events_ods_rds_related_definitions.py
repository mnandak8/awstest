    
import os
import boto3
import psycopg2
import pandas as pd
import json
from botocore.exceptions import ClientError
from psycopg2 import OperationalError, errorcodes, errors
from psycopg2.errors import UniqueViolation  
from datetime import datetime
# Setup logging
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


from Lambda_sfdc_events_ods_def_copy_failedevents_s3 import Lambda_sfdc_events_ods_def_copy_failedevents_s3

def def_get_conn_details(pg_secret_name,pg_database,region_name): 
    session = boto3.Session()
    client = session.client(service_name='secretsmanager',region_name=region_name)
    try:
        get_secret_value_response = client.get_secret_value(SecretId=pg_secret_name)
        logger.info("Successfully obtained secret key for database")
        
    except ClientError as err:
        logger.critical('Error reading the Secrets')
        secrects_err_flag="Y"
    else:
        secret = get_secret_value_response['SecretString'] if 'SecretString' in get_secret_value_response else get_secret_value_response['SecretBinary']
        pg_secret=json.loads(secret)
        pg_details = {'host': pg_secret['host'],'port': pg_secret['port'],'user': pg_secret['username'],'password': pg_secret['password'],'database': pg_database}
    return(pg_details)


def def_get_column_metadata(pg_details,sfdc_table_name, event,inglandingbucket ):
    pg_query_meta= f" SELECT table_name as table_name , lower(column_name) as column_name , lower(data_type) as data_type FROM information_schema.columns WHERE table_schema = \'dbo\' AND table_name   = \'{sfdc_table_name}\' ; "
    try:    
        pg_conn_meta = psycopg2.connect(host=pg_details['host'], user=pg_details['user'], password=pg_details['password'], dbname=pg_details['database'], port=pg_details['port']);
        logger.info('@ Metadata Database connected successfully')
    except OperationalError as err:
        logger.error(f"@ Metadata Database connection failed --> {err} " )
        err=f"@ Metadata Database connection failed -->{err} "
        pg_conn_meta.commit()
        filename="RDS_conn"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)
        return {'statusCode': 404,'body':  json.dumps(err)}
        
    pg_cursor_meta = pg_conn_meta.cursor()
    try:
        pg_cursor_meta.execute(pg_query_meta)
        logger.info('@ Metadata query executed successfully')
    except Exception as err:
        logger.error( f"@ Meta query Failed --> {err} ")
        err=f"@ MetaData query execution failed -->{err} "
        pg_conn_meta.commit()
        pg_cursor_meta.close ()
        filename="meta_query"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)
        return {'statusCode': 404,'body':  json.dumps(err)}
    pg_results_meta = pg_cursor_meta.fetchall()
    pg_meta_df = pd.DataFrame(pg_results_meta, columns=['table_name', 'column_name','data_type'])
    pg_cursor_meta.close()
    pg_conn_meta.close()
    
    len_pg_meta_df=len(pg_meta_df)
    if len_pg_meta_df == 0:
        err=f"@ Meta query table {sfdc_table_name} does not exist in the Inforamtion Schema"
        filename="meta_dict"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)
        logger.error(err)
        return {'statusCode': 504,'body':  json.dumps(err)}    
    return(pg_meta_df)
    
def def_execute_sfdc_query_postgresql(pg_details,pg_query,sfdc_table,event,sfdc_change_type,inglandingbucket):
    
    try:    
        pg_conn =  psycopg2.connect(host=pg_details['host'], user=pg_details['user'], password=pg_details['password'], dbname=pg_details['database'], port=pg_details['port']);
        logger.info('@ sfdc query Database connected successfully ') 
        cursor = pg_conn.cursor()
    except OperationalError as err:
        logger.error(f"@ sfdc query Database connection failed--> {err} ")
        pg_conn.commit()
        cursor.close ()
        filename="RDS_conn"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)
        return {'statusCode': 404,'body':  json.dumps(err)}
    cursor = pg_conn.cursor()
    try:
        cursor.execute(pg_query)
        logger.info('@ sfdc  query executed successfully')
        pg_conn.commit()
        cursor.close ()
    except UniqueViolation as unique_dup:
        logger.info(unique_dup)
        pg_conn.commit()
        cursor.close ()
    except Exception as err:
        logger.error(f"@ sfdc query execution failed -->{err} ")
        pg_conn.commit()
        cursor.close ()
        filename=f"data_{sfdc_table}_{sfdc_change_type}"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)
        return {'statusCode': 404,'body':  json.dumps(err)}
        
    return('sfdc  query executed successfully')
