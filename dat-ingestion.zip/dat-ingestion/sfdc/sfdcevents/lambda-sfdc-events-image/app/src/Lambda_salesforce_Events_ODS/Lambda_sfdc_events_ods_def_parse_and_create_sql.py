import os
import boto3
import pandas as pd
import json
from botocore.exceptions import ClientError
from datetime import datetime
# Setup logging
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
##################################################
def sfdc_check_metadata(i_col_name,i_col_value,pg_meta_df):   
    match_found_meta_id = "no"
    for index, row in pg_meta_df.iterrows():
        i_meta_column_name = row['column_name']
        i_meta_data_type = row['data_type']
        i_column_data_type=""
        if i_col_name.lower() == i_meta_column_name:
            i_column_data_type = i_meta_data_type
            match_found_meta_id = 'yes'
            break
    return (i_column_data_type,i_col_name,i_col_value)    
################################################

def generate_create_sql(i_column_data_type,i_col_name,i_col_value,non_existance_columns,i_pg_query_2,i_pg_query_4):
    lit_null = "null"
    match i_column_data_type:
        case 'character' | 'character varying' | 'text' | 'date' | 'time with time zone' | 'time without time zone' | 'timestamp with time zone' | 'timestamp without time zone' :
            i_col_value = str(i_col_value).replace("'", "''")
            i_pg_query_2 = f" \"{i_col_name}\" "  + "," + i_pg_query_2
            if i_col_value == "literalnullvalue":
                i_pg_query_4 = f" {lit_null} "  +  ","  + i_pg_query_4
            else:
                i_pg_query_4 = f" \'{i_col_value}\' "  +  ","  + i_pg_query_4
            
        case 'double precision' | 'integer' | 'numeric' | 'smallint' | 'bigint' | 'boolean' :
            i_pg_query_2 = f" \"{i_col_name}\" "  + "," + i_pg_query_2
            if i_col_value == "literalnullvalue":
                i_pg_query_4 = f" {lit_null} "  +  ","  + i_pg_query_4
            else:
                i_pg_query_4 = f" {i_col_value} "  +  ","  + i_pg_query_4
    
        case _:
            non_existance_columns = f" {i_col_name}  "  + "," + non_existance_columns
    return(non_existance_columns,i_pg_query_2,i_pg_query_4)
######################################
###
def parse_create_dynamically_nested_json(non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value,pg_meta_df):
    if isinstance(i_col_value, dict):
        for i_col_name, i_col_value in i_col_value.items():
            non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value=parse_create_dynamically_nested_json(non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value,pg_meta_df)
    else:
        i_column_data_type,i_col_name,i_col_value =sfdc_check_metadata(i_col_name,i_col_value,pg_meta_df)  
        non_existance_columns,i_pg_query_2,i_pg_query_4=generate_create_sql(i_column_data_type,i_col_name,i_col_value,non_existance_columns,i_pg_query_2,i_pg_query_4)
    return(non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value)
################################################
################################################
def generate_update_sql(u_column_data_type,u_col_name,u_col_value,non_existance_columns,u_pg_query_2):
   
    lit_null = "null"
    match u_column_data_type:
        case 'character' | 'character varying' | 'text' | 'date' | 'time with time zone' | 'time without time zone' | 'timestamp with time zone' | 'timestamp without time zone':
            u_col_value = str(u_col_value).replace("'", "''")
            if u_col_value == "literalnullvalue":
                u_pg_query_2 =  f" \"{u_col_name}\" =  {lit_null} "   +   ","  + u_pg_query_2 
            else:
                u_pg_query_2 =  f" \"{u_col_name}\" =  \'{u_col_value}\' "   +   ","  + u_pg_query_2 
                
        case 'double precision' | 'integer' | 'numeric' | 'smallint' | 'bigint' | 'boolean' :
            if u_col_value == "literalnullvalue":
                u_pg_query_2 =  f" \"{u_col_name}\" =  {lit_null} " + ","  + u_pg_query_2 
            else:
                u_pg_query_2 =  f" \"{u_col_name}\" =  {u_col_value} "   +   ","  + u_pg_query_2 
        case _:
            non_existance_columns = f" {u_col_name}  "  + "," + non_existance_columns

    return(non_existance_columns,u_pg_query_2)
################################################
def parse_update_dynamically_nested_json(non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value,pg_meta_df):
    if isinstance(i_col_value, dict):
        for i_col_name, i_col_value in i_col_value.items():
            non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value=parse_update_dynamically_nested_json(non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value,pg_meta_df)
    else:
        i_column_data_type,i_col_name,i_col_value =sfdc_check_metadata(i_col_name,i_col_value,pg_meta_df)  
        non_existance_columns,u_pg_query_2=generate_update_sql(i_column_data_type,i_col_name,i_col_value,non_existance_columns,u_pg_query_2)
    return(non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value)
###############################################

def def_parse_sfdc_events(event,pg_meta_df):
    ######Get the Salesforce EVent Details
    sfdc_event_str = json.dumps(event)
    sfdc_event = json.loads(sfdc_event_str)
    sfdc_table = str(sfdc_event['detail']['payload']['ChangeEventHeader']['entityName'])
    changed_fields = sfdc_event['detail']['payload']['ChangeEventHeader']['changedFields']
    change_type = str(sfdc_event['detail']['payload']['ChangeEventHeader']['changeType'])
    
    logger.info( f" the table is --> {sfdc_table}  and the CHnage Type is -->  {change_type}" )
    

    pk = str(sfdc_event['detail']['payload']['ChangeEventHeader']['recordIds'][0])
    changed_columns_cnt=len(changed_fields)
    
    if change_type.lower() == "delete":
        d_pg_query_1 = f"delete from  dbo.{sfdc_table}  "
        d_pg_query_2 = f"where \"Id\" = \'{pk}\'  "
        pg_query= d_pg_query_1 + d_pg_query_2
        
    if change_type.lower() == "update":
        u_pg_query_1 = f"update dbo.{sfdc_table} set "
        u_pg_query_2 = ""
        #format not null ETL columns"
        u_pg_query_3= f"\"execution_user\" = 'svceventsrole' , update_timestamp = current_timestamp , \"load_operation\" = 'update'  "
        u_pg_query_4 = f"where \"Id\" = \'{pk}\'  "
        
        non_existance_columns =""
        sfdc_create_data = sfdc_event['detail']['payload']
        i_column_data_type=""
        non_existance_columns="" 
        for i_col_name, i_col_value in sfdc_create_data.items():
            if i_col_name != "ChangeEventHeader":
                if isinstance(i_col_value, dict):
                    non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value=parse_update_dynamically_nested_json(non_existance_columns,u_pg_query_2,i_column_data_type,i_col_name,i_col_value,pg_meta_df)
                else:
                    i_column_data_type,i_col_name,i_col_value =sfdc_check_metadata(i_col_name,i_col_value,pg_meta_df)  
                    non_existance_columns,u_pg_query_2=generate_update_sql(i_column_data_type,i_col_name,i_col_value,non_existance_columns,u_pg_query_2)
        pg_query=u_pg_query_1 + u_pg_query_2 + u_pg_query_3 + u_pg_query_4
    
    if change_type.lower() == "create":
        i_pg_query_1=f"Insert into dbo.{sfdc_table}  ( \"Id\", "
        i_pg_query_2 = ""
        i_pg_query_2_e = f" \"execution_user\" , \"load_timestamp\"  , \"update_timestamp\" ,  \"load_operation\" "
        i_pg_query_3 = f" ) values ( \'{pk}\' , "
        i_pg_query_4 = ""
        i_pg_query_4_e = f" 'svceventsrole' , current_timestamp , current_timestamp , 'insert' );"
        i_col_name_dq = ""
        non_existance_columns =""
        sfdc_create_data = sfdc_event['detail']['payload']
        
        
        # Parsing JSON data using recursion
        i_column_data_type=""
        non_existance_columns="" 
        for i_col_name, i_col_value in sfdc_create_data.items():
            if i_col_name != "ChangeEventHeader":
                if isinstance(i_col_value, dict):
                    non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value=parse_create_dynamically_nested_json(non_existance_columns,i_pg_query_2,i_pg_query_4,i_column_data_type,i_col_name,i_col_value,pg_meta_df)
                else:
                    i_column_data_type,i_col_name,i_col_value =sfdc_check_metadata(i_col_name,i_col_value,pg_meta_df)  
                    non_existance_columns,i_pg_query_2,i_pg_query_4=generate_create_sql(i_column_data_type,i_col_name,i_col_value,non_existance_columns,i_pg_query_2,i_pg_query_4)
        pg_query= i_pg_query_1 + i_pg_query_2 +i_pg_query_2_e + i_pg_query_3 + i_pg_query_4 + i_pg_query_4_e 
        if non_existance_columns != "":
            logger.info(f" Columns they dont exist in the table --> {non_existance_columns}" )
    return(pg_query,sfdc_table)


    
def def_replace_nulls(data, replacement_value):
    if isinstance(data, dict):
        return {key: def_replace_nulls(value, replacement_value) for key, value in data.items()}
    elif isinstance(data, list):
        return [def_replace_nulls(item, replacement_value) for item in data]
    elif data is None:
        return replacement_value
    return data
    