import os
import boto3
import psycopg2
import pandas as pd
import json
from botocore.exceptions import ClientError
from psycopg2 import OperationalError, errorcodes, errors
from psycopg2.errors import UniqueViolation  
from datetime import datetime
#from logger_setup import logger
# Setup logging
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket):
    event =json.dumps(event)
    logger.info( f"Move the Event to S3" )
    
    my_bucket_name=inglandingbucket
    curr_date = datetime.today().strftime('%Y%m%d')
    curr_ts = datetime.today().strftime('%H%M%f')
    target_key=f"salesforce/failedevents/{curr_date}/{filename}_{curr_ts}"
    s3_client = boto3.client('s3')
    s3_client.put_object(Body=event, Bucket=my_bucket_name, Key=target_key)
    return('null')
    