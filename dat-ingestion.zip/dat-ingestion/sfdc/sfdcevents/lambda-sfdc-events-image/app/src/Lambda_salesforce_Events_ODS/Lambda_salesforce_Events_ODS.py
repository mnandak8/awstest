#######################################################################################
# The following code is utilized in Lambda, which is triggered by Salesforce CDC Events from the Event Bridge Bus via Rules.
# This code is reusable and applicable to any Salesforce object. It retrieves the table name and change event type (delete, update, or insert) and dynamically generates the corresponding DML query.
# Purpose: Process the events and upsert the salesforce data in to ODS. 
# Parameters: 
#    secrets Manager ARN: Contains the credentials to connect to the ODS on consumption AWS account. 
#    Topic ARN : used to send email if Lambda fails to process the event
# Flow of the Code:
#  1.  Get the Credentials for the ODS 
#  2.  Read the Event (def lambda_handler) and replace the null values to handle the NULL's while creating the DML statementts 
#  3.  Connect to ODS, Get the columns names, data type from the informational schema for the given salesforce table 
#  4.  Parse the Event (parse_sfdc_events) and generate the DML statements.
#          a.  Check the change type (update, delete, insert)
#          b.  Depending on the Change Type format the DML statement. (generate_create_sql, generate_update_sql)
#          c.  Check if the column exist in the ODS table and include in the update and Delete statement.  (sfdc_check_metadata) 
#          d.  Check events if any json object has nested json or its a value, recursively call the Function till we find the value. (parse_update_dynamically_nested_json, parse_create_dynamically_nested_json)
#  5.  Execute the SQL (execute_sfdc_query_postgresql)
# Sep 19  2024
# Nov 11  2024 : Added more Datatypes to generate Dynmaic DML statement
####################################################################################################
import os
import boto3
import psycopg2
import pandas as pd
import json
from botocore.exceptions import ClientError
from psycopg2 import OperationalError, errorcodes, errors
from psycopg2.errors import UniqueViolation  
from datetime import datetime
##########################
# Setup logging
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)



from Lambda_sfdc_events_ods_def_copy_failedevents_s3 import Lambda_sfdc_events_ods_def_copy_failedevents_s3

from Lambda_sfdc_events_ods_rds_related_definitions import def_get_conn_details
from Lambda_sfdc_events_ods_rds_related_definitions import def_get_column_metadata
from Lambda_sfdc_events_ods_rds_related_definitions import def_execute_sfdc_query_postgresql

from Lambda_sfdc_events_ods_def_parse_and_create_sql import def_parse_sfdc_events
from Lambda_sfdc_events_ods_def_parse_and_create_sql import def_replace_nulls

pg_secret_arn: str = os.environ.get('pg_secret_arn')
environment: str = os.environ.get('environment')
inglandingbucket: str = os.environ.get('inglandingbucket')
pg_secret_name=pg_secret_arn
pg_database="Salesforce"
region_name = "us-west-2" 
filename=""
secrects_err_flag=""


def lambda_handler(event, context):
    
    replacement_value = "literalnullvalue"
    event = def_replace_nulls(event, replacement_value)
    sfdc_event_str = json.dumps(event)
    sfdc_event = json.loads(sfdc_event_str)
    sfdc_table_name = str(sfdc_event['detail']['payload']['ChangeEventHeader']['entityName'])
    sfdc_change_type=  str(sfdc_event['detail']['payload']['ChangeEventHeader']['changeType'])
    if secrects_err_flag == "Y":
        filename="secrets"
        Lambda_sfdc_events_ods_def_copy_failedevents_s3(event, filename,inglandingbucket)   
        return {'statusCode': 604,'body':  json.dumps(err)}
    pg_details=def_get_conn_details(pg_secret_name,pg_database,region_name)
    pg_meta_df=def_get_column_metadata(pg_details,sfdc_table_name.lower(), event,inglandingbucket)
    pg_query,sfdc_table=def_parse_sfdc_events(event, pg_meta_df)
    return_statement=def_execute_sfdc_query_postgresql(pg_details,pg_query,sfdc_table,event,sfdc_change_type,inglandingbucket)
    
    return {
        'statusCode': 200,
        'body': json.dumps(return_statement)
    }
