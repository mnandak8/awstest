import pytest
import json
import unittest
import sys
import os
import pandas as pd
import difflib

from testdata import input_acct_update_event_null_test
from testdata import result_acct_update_event
from testdata import acct_meta_data
from testdata import contact_meta_data

from testdata import result_pgquery_acct_update
from testdata import input_acct_update_event_test_case2

from testdata import result_pgquery_contact_create
from testdata import input_contact_create_event_test_case3

from testdata import input_contact_update_event_test_case4
from testdata import result_pgquery_contact_update

from testdata import result_pgquery_llb_delete
from testdata import input_llb_delete_event_test_case5

#pytest --cov=Lambda_salesforce_Events_ODS.Lambda_sfdc_events_ods_def_parse_and_create_sql --cov-report=htmlql --cov-report=html
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from Lambda_salesforce_Events_ODS.Lambda_sfdc_events_ods_def_parse_and_create_sql import def_replace_nulls
from Lambda_salesforce_Events_ODS.Lambda_sfdc_events_ods_def_parse_and_create_sql import def_parse_sfdc_events



class TestsfdcLambda2Ods(unittest.TestCase):
    def test_def_replace_nulls(self):
        event=input_acct_update_event_null_test
        event_dictionary = json.loads(event)
        rep="literalnullvalue"
        result = def_replace_nulls(event_dictionary, rep)
        expected = result_acct_update_event
        expected_event_dict = json.loads(expected)
        assert result == expected_event_dict
        
    def test_def_parse_sfdc_events_acct_update(self):
        event=input_acct_update_event_test_case2
        event_dict = json.loads(event)
        pg_meta_df = pd.DataFrame(acct_meta_data, columns=['table_name', 'column_name', 'data_type'])
        pg_query,sfdc_table=def_parse_sfdc_events(event_dict,pg_meta_df)
        assert result_pgquery_acct_update == pg_query

    def test_def_parse_sfdc_events_contact_create(self):
        event=input_contact_create_event_test_case3
        event_dict = json.loads(event)
        pg_meta_df = pd.DataFrame(contact_meta_data, columns=['table_name', 'column_name', 'data_type'])
        pg_query_c,sfdc_table=def_parse_sfdc_events(event_dict,pg_meta_df)
        assert result_pgquery_contact_create == pg_query_c

    def test_def_parse_sfdc_events_contact_update(self):
        event=input_contact_update_event_test_case4
        event_dict = json.loads(event)
        pg_meta_df = pd.DataFrame(contact_meta_data, columns=['table_name', 'column_name', 'data_type'])
        pg_query_c,sfdc_table=def_parse_sfdc_events(event_dict,pg_meta_df)
        print(pg_query_c)
        assert result_pgquery_contact_update == pg_query_c
    
    def test_def_parse_sfdc_events_llb_delete(self):
        event=input_llb_delete_event_test_case5
        event_dict = json.loads(event)
        pg_meta_df = pd.DataFrame(contact_meta_data, columns=['table_name', 'column_name', 'data_type'])
        pg_query_c,sfdc_table=def_parse_sfdc_events(event_dict,pg_meta_df)
        assert result_pgquery_llb_delete == pg_query_c
           
if __name__ == '__main__': 
    print('nanda')
    unittest.main()
	
