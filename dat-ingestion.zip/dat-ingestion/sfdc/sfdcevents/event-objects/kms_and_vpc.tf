## KMS Key
resource "aws_kms_key" "kms_key_sfdc_events" {
  description             = "kms key for SFDC Events"
  enable_key_rotation     = true
  deletion_window_in_days = 7
  key_usage               = "ENCRYPT_DECRYPT"
  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Id" : "key-consolepolicy-3",
      "Statement" : [
        {
          "Sid" : "EnableIAMUserPermissions",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:root"
          },
          "Action" : "kms:*",
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "events.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt",
            "kms:GenerateDataKey",
            "kms:Decrypt"
          ],
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "events.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt",
            "kms:GenerateDataKey",
            "kms:Decrypt"
          ],
          "Resource" : "*"
        },
        {
          "Sid" : "AllowAccessForKeyAdministrators",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:role/${local.sfdc-events-role}"
          },
          "Action" : [
            "kms:Create*",
            "kms:Describe*",
            "kms:Enable*",
            "kms:List*",
            "kms:Put*",
            "kms:Update*",
            "kms:Revoke*",
            "kms:Disable*",
            "kms:Get*",
            "kms:Delete*",
            "kms:TagResource",
            "kms:UntagResource",
            "kms:ScheduleKeyDeletion",
            "kms:CancelKeyDeletion"
          ],
          "Resource" : "*"
        },
        {
          "Effect" : "Allow",
          "Principal" : {
            "Service" : "logs.us-west-2.amazonaws.com"
          },
          "Action" : [
            "kms:Encrypt*",
            "kms:Decrypt*",
            "kms:ReEncrypt*",
            "kms:GenerateDataKey*",
            "kms:Describe*"
          ],
          "Resource" : "*",
          "Condition" : {
            "ArnLike" : {
              "kms:EncryptionContext:aws:logs:arn" : "arn:aws:logs:us-west-2:${local.account_id}:log-group*"
            }
          }
        }
      ]
    }
  )
}


resource "aws_kms_alias" "kms_key_sfdc_events_add_kms_key_alis" {
  #name          = "alias/cust-kms-key-sfdc-events-1"
  name          = var.events_kms_key_name
  target_key_id = aws_kms_key.kms_key_sfdc_events.key_id
}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

data "aws_vpc" "selected" {
  filter {
    name   = "tag:Name"
    values = [var.vpc_name]
  }
}

data "aws_subnets" "filtered" {
   filter {
    name   = "vpc-id"
    values = [data.aws_vpc.selected.id]
  }
  filter {
    name   = "tag:Name"
    values = ["*application-subnet*"]
  }
    
}

resource "aws_security_group" "sfdc_events_security_grp" {
  name        = var.sfdc_event_security_name
  vpc_id      = data.aws_vpc.selected.id
  description = "Security group for sfdc events "
  tags = var.tags
}
resource "aws_security_group_rule" "sfdc_events_security_grp_ingress" {
    type              = "ingress"
    security_group_id =aws_security_group.sfdc_events_security_grp.id
    description      = "sfdc events Ingress"
    from_port        = 4000
    to_port          = 65535
    protocol         = "All"
    cidr_blocks      = var.vpc_cidr_blocks_ingress
  }

resource "aws_security_group_rule" "sfdc_events_security_grp_egress" {
    type              = "egress"
    security_group_id =aws_security_group.sfdc_events_security_grp.id
    description      = "sfdc events  egress"
    from_port        = 4000
    to_port          = 65535
    protocol         = "All"
    cidr_blocks      =var.vpc_cidr_blocks_egress
  }
