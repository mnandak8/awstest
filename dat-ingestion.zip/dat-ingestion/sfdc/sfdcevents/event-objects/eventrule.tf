
## Create Event Partner Bus and Associate with the salesforce Event Partner Resource , this will be done once and used for all the CDC Salesforce EVents
resource "awscc_events_event_bus" "sfdc_events_partner_event_bus" {
  name               = var.sfdc_partner_source_name
  event_source_name  = var.sfdc_partner_source_name
  kms_key_identifier = aws_kms_key.kms_key_sfdc_events.arn
}
#####################################################
## create the Event Bus Rule for the Events on the object account with Lambda as a Target
resource "awscc_events_rule" "sfdc_events_partner_event_rules" {
  description    = "Routes to sfdc Change Events call a Lambda function to upserts in to ODS on cunsumption acct"  
  name           =  local.sfdc-events-rule-ph1
  event_bus_name = var.sfdc_partner_source_name
  #event_bus_name =  awscc_events_event_bus.sfdc_events_partner_event_bus_name
  event_pattern =  jsonencode(
    {"source" : [{"prefix" : "aws.partner/salesforce.com"}],
        "detail-type" : ["LLC_BI__Loan__ChangeEvent","ContactChangeEvent","AccountContactRelationChangeEvent","Account_Address__ChangeEvent","AccountChangeEvent"] } 
      )
  targets = [
    {
      arn                = aws_lambda_function.sfdc-events-lambda-function-ODS.arn
      id                 = "Lambda"
      dead_letter_config = { arn = aws_sqs_queue.sfdc_events_dlq_sqs.arn }
      retry_policy       = { maximum_event_age_in_seconds = var.maximum_event_age_in_seconds, maximum_retry_attempts = var.maximum_retry_attempts }
    }
  ]
}