locals {
  account_id                                  = data.aws_caller_identity.current.account_id
  region_name                                 = data.aws_region.current.name
  sfdc-events-role                            = "cobank-${var.environment}-dat-ing-salesforce-events-role"                                        
  sfdc-events-role-arn                        = "arn:aws:iam::${local.account_id}:role/cobank-${var.environment}-dat-ing-salesforce-events-role"
  sfdc-events-event-bus                       = "cobank-${var.environment}-sfdc-events-event-bus"
  sns-failure-topic-event-rule                = "cobank-${var.environment}-sfdc-events-event-sns_topic"
  sfdc-events-dlq-sqs                         = "cobank-${var.environment}-sqs-sfdc-events-dlq"
  sfdc-events-rule-ph1                        = "cobank-${var.environment}-sfdc-events-rule-ph1"
  sfdc-events-target-lambda-ph1               = "cobank-dat-ing-${var.environment}-lambda-sfdc-events-ods"
  sfdc-events-lambda-sfdc-events-invoke-sns   = "cobank-dat-ing-${var.environment}-lambda-sfdc-events-sns-alerts"
  ##ing landing bucket to write the failed events
  ing-landing-bucket                          = "cobank-dl-${local.account_id}-us-west-2-landing-${var.environment}"
  ecr_image_uri                               = "${local.account_id}.dkr.ecr.us-west-2.amazonaws.com/lambda-sfdc-events-image:latest"                                     
                                                                                                     
}

#1. Create EVent Bus and relate to sales force partner Bus
#2. Create SNS Topic and subcribe email address and cloudwatch log
#3. copy the Lambda Layer to S3
#4. Create Lambda Layer.
#5. ZIp the Python code w=its used in Lambda function. 




#######Create Cloudwatch log with splunk enabled
resource "aws_cloudwatch_log_group" "sfdc-events-lambda-function-ODS" {
  name = "/aws/lambda/${local.sfdc-events-target-lambda-ph1}"
  kms_key_id = aws_kms_key.kms_key_sfdc_events.arn
  tags = var.tags
}
resource "aws_cloudwatch_log_group" "sfdc-events-lambda-function-invoke-sns" {
  name = "/aws/lambda/${local.sfdc-events-lambda-sfdc-events-invoke-sns}"
  kms_key_id = aws_kms_key.kms_key_sfdc_events.arn
  tags = var.tags
}




resource "aws_lambda_function" "sfdc-events-lambda-function-ODS" {
  function_name                  = local.sfdc-events-target-lambda-ph1
  description                    = "Reads the sales from CDC-Events from Events Bridge and write the data to the ODS in consumption Layer "
  role                           =  local.sfdc-events-role-arn
  tags                           = var.tags
  image_uri                      = local.ecr_image_uri
  package_type                   = "Image"
  publish                        = "true"
  timeout                        = 600
  reserved_concurrent_executions = 50
  memory_size                    = 512
  ephemeral_storage            {  size = 1024 }
  kms_key_arn                    = aws_kms_key.kms_key_sfdc_events.arn
  image_config                     {command = [ "Lambda_salesforce_Events_ODS.lambda_handler"]}
  tracing_config                   {mode = "Active"}
  dead_letter_config               {target_arn= aws_sqs_queue.sfdc_events_dlq_sqs.arn}
  vpc_config                     { 
                                      subnet_ids         =  data.aws_subnets.filtered.ids 
                                      security_group_ids = [aws_security_group.sfdc_events_security_grp.id]
                                  }
  environment {
    variables = {
      pg_secret_arn= var.pg_secret_arn,
      environment = var.environment,
      inglandingbucket=local.ing-landing-bucket,
      log_group_name = aws_cloudwatch_log_group.sfdc-events-lambda-function-ODS.name
    }
  }
    depends_on = [
      aws_cloudwatch_log_group.sfdc-events-lambda-function-ODS
    ]
  source_code_hash = trimprefix(data.aws_ecr_image.lambda-sfdc-events-image.id, "sha256:")
}
########## get the latest Image 
data "aws_ecr_image" "lambda-sfdc-events-image" {
  repository_name = "lambda-sfdc-events-image"
  image_tag = "latest"
}



resource "aws_lambda_function_event_invoke_config" "sfdc-events-lambda-function-ODS-event-invoke-config" {
  function_name                = aws_lambda_function.sfdc-events-lambda-function-ODS.function_name
  qualifier                    = "$LATEST"
  maximum_event_age_in_seconds = var.lambda_invoke_congig_maximum_event_age_in_seconds
  maximum_retry_attempts       =  var.lambda_invoke_congig_maximum_retry_attempts

}


resource "aws_lambda_permission" "sfdc_events_partner_event_rule_permission" {
  statement_id = "AllowExecutionFromEventBridgneEVentRules"
  action = "lambda:InvokeFunction"
  function_name = aws_lambda_function.sfdc-events-lambda-function-ODS.arn
  principal = "events.amazonaws.com"
  source_arn =  awscc_events_rule.sfdc_events_partner_event_rules.arn
}


####
# Lambda 
resource "aws_lambda_function" "sfdc-events-lambda-function-invoke-sns" {
  function_name                  = local.sfdc-events-lambda-sfdc-events-invoke-sns
  description                    = "MOnitors SQS and sends email if there are any new events in the SFDC  DLQ-SQS"
  role                           =  local.sfdc-events-role-arn
  tags                           = var.tags
  image_uri                      = local.ecr_image_uri
  package_type                   = "Image"
  publish                        = "true"
  timeout                        = 600
  reserved_concurrent_executions = 50
  image_config                      {command = [ "Lambda_salesforce_Events_Invoke_SNS.lambda_handler" ]}
  tracing_config                    {mode = "Active"}
  memory_size                    = 128
  kms_key_arn                    = aws_kms_key.kms_key_sfdc_events.arn
  environment {
    variables = {
      snsarn = aws_sns_topic.sfdc_events_topic.arn,
      environment = var.environment,
      inglandingbucket=local.ing-landing-bucket,
      log_group_name = aws_cloudwatch_log_group.sfdc-events-lambda-function-invoke-sns.name
    }
  }

    depends_on = [
      aws_cloudwatch_log_group.sfdc-events-lambda-function-invoke-sns
    ]
   source_code_hash = trimprefix(data.aws_ecr_image.lambda-sfdc-events-image.id, "sha256:")
}

resource "aws_lambda_event_source_mapping" "sqs-trigger-lambda" {
  batch_size        = 1
  event_source_arn  = aws_sqs_queue.sfdc_events_dlq_sqs.arn
  enabled           = true
  function_name     = aws_lambda_function.sfdc-events-lambda-function-invoke-sns.arn
}

resource "aws_lambda_permission" "sfdc_events_sqs_trigger_sns_permission" {
  statement_id = "InvokeLambdaOnSQSMessage"
  action = "lambda:InvokeFunction"
  function_name = aws_lambda_function.sfdc-events-lambda-function-invoke-sns.arn
  principal = "sqs.amazonaws.com"
  source_arn =  aws_sqs_queue.sfdc_events_dlq_sqs.arn
}
