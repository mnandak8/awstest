
# trivy:ignore:AVD-AWS-0095: KMS key is added through the module, manually checked. checkov would need to be refactored to correctly see the kms encryption key
resource "aws_sns_topic" "sfdc_events_topic" {
  name              = local.sns-failure-topic-event-rule
  kms_master_key_id = aws_kms_key.kms_key_sfdc_events.arn
  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement" : [
        {
          "Sid" : "RootAccess",
          "Effect" : "Allow",
          "Principal" : {
            "AWS" : "arn:aws:iam::${local.account_id}:root"
          },
          "Action" : "SNS:Publish",
          "Resource" : "*"
        }
      ]
    }
  )
}
########################################
#######Add subcription to Create the SNS Topic for the SQS 
resource "aws_sns_topic_subscription" "sfdc_events_alerting_topic_email_subscription" {
  topic_arn = aws_sns_topic.sfdc_events_topic.arn
  protocol  = "email"
  endpoint  = var.email_address
}
# trivy:ignore:AVD-AWS-0096: KMS key is added through the module, manually checked. checkov would need to be refactored to correctly see the kms encryption key
########################################
resource "aws_sqs_queue" "sfdc_events_dlq_sqs" {
  name                       = local.sfdc-events-dlq-sqs
  visibility_timeout_seconds = 43200
  delay_seconds              = 0
  max_message_size           = var.sqs_max_message_size
  message_retention_seconds  = var.sqs_message_retention_seconds
  receive_wait_time_seconds  = var.sqs_receive_wait_time_seconds
  kms_master_key_id          = aws_kms_key.kms_key_sfdc_events.arn
  tags                       = var.tags
}
