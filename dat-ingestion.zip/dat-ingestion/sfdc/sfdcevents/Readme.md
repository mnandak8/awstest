# SFDC Events

Use Partner Event Bus/Event Bridge AWS services to fetch the real time CDC events from Sales Force and upsert the data into ODS.  


- [Partner-Event-Sources](#Partner-Event-Sources)
- [Partner-Event-Bus](#Partner-Event-Bus)
- [Partner-EventBridge-Rule](#Partner-EventBridge-Rule)
- [Partner-EventBridge-Rule-Target](#Partner-EventBridge-Rule-Target)
- [IAM](#IAM)
- [Secrets](#Secrets)
- [VPC-Security-Groups](#VPC-Security-Groups)
- [Error Handelling](#Error-Handelling)
- [Lambda-Docker-ECR-Image](#Lambda-Docker-ECR-Image)
- [Terraform-steps](#Terraform-steps)


![image](https://github.com/user-attachments/assets/12c2878b-81a6-4db9-80c4-7ec0128918e4)



# Partner Event Sources
![image](https://github.com/user-attachments/assets/da8254b4-3556-4d24-a16e-7ae7a712b0d5)
  -  Receive events from SFDC partner applications, partner event source is a resource created by partner (SFDC Team) points to a AWS account, that can be a
    an event source. 
        -  aws.partner/salesforce.com/00D02000000XXXXXXX/ChangeEvents
# Partner Event Bus
   -  Create a custom event bus and associate it to the partner event source. 
      -aws.partner/salesforce.com/00D02000000XXXXXXX/ChangeEvents
# Partner EventBridge Rule
  -  Event Pattern makes this a rule that is triggered when an event matching the pattern occurs.
  -  cobank-dev-sfdc-events-rule-ph1
      - Event Pattern:
          **{"detail-type": ["LLC_BI__Loan__ChangeEvent", "ContactChangeEvent", "AccountContactRelationChangeEvent", "Account_Address__ChangeEvent", "AccountChangeEvent"],
        "source": [{"prefix": "aws.partner/salesforce.com"}]}    **
# Partner EventBridge Rules Target
  Lambda_salesforce_Events_ODS --> Lambda to prase the incoming Events and upsert data in to ODS.

# IAM 
    cobank-dev-dat-ing-salesforce-events-role
# Secrets
    Credentials for the ODS.
    arn:aws:secretsmanager:us-west-2:<consumption-acct-number>:secret:cobank-dl-rds-user-secret-ods-svcsfdceventbridge-dev-<id>
# Error-Handelling
  -	Event Rule DLQ:cobank-dev-sqs-sfdc-events-dlq
  -	Lambda DLQ: cobank-dev-sqs-sfdc-events-dlq
  -	Failed events: Invoke SNS and write them to the S3 for further analysis.
  -	SNS Topic: Invoke topic for any Events in the DLQ using a Lambda: obank-dev-lambda-sfdc-events-invoke-sns
      arn:aws:sns:us-west-2:<ingestion_acct_number>:cobank-dev-sfdc-events-event-sns_topic 
  -	Failed Events : find them here s3://cobank-dl-<ingestion_acct_number>-us-west-2-landing-dev/salesforce/failedevents/
  
# VPC-Security-Groups
  -  Attach the VPC and Security Groups for the Lambda: Lambda_salesforce_Events_ODS
      -  VPC. 
      -  Security Group : cobank-sfdc-events-security
      -    InBound: VPC CIDR Block ING
      -    OutBound: VPC CIDR Block ING, VPC CIDR Block Con, VPC CIDR Block's for the Secrects for Cross Accounts.
        
# Lambda-Docker-ECR-Image
-  Docker File: https://github.com/cobank-acb/dat-ingestion/blob/main/sfdc/sfdcevents/lambda-sfdc-events-image/lambda-sfdc-events-image-dockerfile
-  requirements: https://github.com/cobank-acb/dat-ingestion/blob/main/sfdc/sfdcevents/lambda-sfdc-events-image/requirements.txt
-  ECR repository:lambda-sfdc-events-image
-  Image URI : <ing_acct_number>.dkr.ecr.us-west-2.amazonaws.com/lambda-sfdc-events-image:latest

# Terraform-steps
1. Create KMS Keys and Security Groups.
2. In the YML file:
   https://github.com/cobank-acb/dat-ingestion/blob/main/.github/workflows/terra-factory-invocation-sfdc.yml
     -  build-and-save-image : Use the Docker file and Build Image
     -  publish-image-to-ecr : Publish the Image. 
4. Create Event Bus and associate with Partner Source.
5. Create a SNS Topic
6. Subcription for the SNS topic.
7. Create SQS for DLQ 
8. Cretae Lambda Function to process the SFDC Events
9. Get Latest Image.
10. Attach the Latest Image to the Lambda
11. Create the Event Bus Rule
12. aws_lambda_permission: Trigger Lambda for the Event Rule.
13. Create Lambda Function to Invoke the SNS on failures.
14. aws_lambda_event_source_mapping : Trigger Lambda: step 13 for SQS
15. aws_lambda_permission: Trigger Lambda for SQS.
16. Add the Lambda Python Code to process the Events
17. Add the Lambda Python Code to invoke SNS on error. 
18. Add the requirements.txt for the Image
19. Add the docker file for the Image
      
