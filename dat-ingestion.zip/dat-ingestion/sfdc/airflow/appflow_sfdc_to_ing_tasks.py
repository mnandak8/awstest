from airflow import DAG
from  airflow.operators.trigger_dagrun import TriggerDagRunOperator 
from airflow.providers.amazon.aws.operators.appflow import (
AppflowRunOperator,
)
from airflow.utils.dates import days_ago
from airflow.operators.dummy_operator import DummyOperator
from datetime import datetime,timedelta
from cb_common.utils.common import SNSNotifier
from airflow.models import Variable
from cb_common.configs_ing import CONFIG

sns_notifier = SNSNotifier(region_name='us-west-2')
environment = Variable.get('env_vars',  deserialize_json=True)['environment']

acc_num =  CONFIG['ing'][environment]['acc_num']
sfdc_appflow_to_ing_schedule =CONFIG['ing'][environment]['sfdc_appflow_to_ing_schedule']
#The sfdc_appflow_to_ing_schedule is in the below file
#https://github.com/cobank-acb/dat-ingestion/blob/main/application/src/main/airflow-config/configs_ing.py



# Define default arguments for the DAG
default_args = {
    'owner': 'SMW',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_success': False ,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}
start_date = datetime.today() - timedelta(days=1)
# Define the DAG
dag = DAG(
    'SFDC_Appflow_Ingestion_load',
    description='SFDC_EOD_ING',
    default_args=default_args,
    tags=['SFDC'],
    schedule_interval=sfdc_appflow_to_ing_schedule,  
    catchup=False, 
    start_date=start_date,
    on_failure_callback=[sns_notifier.failure_notification] 
)

SFDC_Ing_Start_Task = DummyOperator(task_id='SFDC_Ing_Start_Task',dag=dag,on_success_callback=[sns_notifier.success_notification])
SFDC_Ing_End_Task = DummyOperator(task_id='SFDC_Ing_End_Task',dag=dag,on_success_callback=[sns_notifier.success_notification])

Account_contact_relation = AppflowRunOperator(task_id='AccountContactRelation',flow_name='AccountContactRelation_sfdc_to_ing_EOD',  dag=dag, aws_conn_id='ing_appflow')
Account = AppflowRunOperator(task_id='Account',flow_name='Account_sfdc_to_ing_EOD',  dag=dag, aws_conn_id='ing_appflow')
Contact = AppflowRunOperator(task_id='Contact',flow_name='Contact_sfdc_to_ing_EOD',  dag=dag, aws_conn_id='ing_appflow')
LLC_BI__Loan__c = AppflowRunOperator(task_id='LLC_BI__Loan__c',flow_name='LLC_BI__Loan__c_sfdc_to_ing_EOD', dag=dag, aws_conn_id='ing_appflow')
Account_Address__c = AppflowRunOperator(task_id='Account_Address__c',flow_name='Account_Address__c_sfdc_to_ing_EOD', dag=dag,aws_conn_id='ing_appflow')
RecordType = AppflowRunOperator(task_id='RecordType',flow_name='RecordType_sfdc_to_ing_EOD',dag=dag, aws_conn_id='ing_appflow')
LLC_BI__Loan__History = AppflowRunOperator(task_id='LLC_BI__Loan__History',flow_name='LLC_BI__Loan__History_sfdc_to_ing_EOD',dag=dag, aws_conn_id='ing_appflow')
LLC_BI__Product_Package__c = AppflowRunOperator(task_id='LLC_BI__Product_Package__c',flow_name='LLC_BI__Product_Package__c_sfdc_to_ing_EOD',dag=dag, aws_conn_id='ing_appflow')


SFDC_Ing_Trigger_Raw = TriggerDagRunOperator(
    task_id="SFDC_Ing_Trigger_Raw",
    trigger_dag_id="SFDC_EOD_Ingestion_2_raw",  # DAG to trigger
    wait_for_completion=False,  
    dag=dag
)



# Set the task dependencies
SFDC_Ing_Start_Task >> [Account_contact_relation, Account, Contact,LLC_BI__Loan__c,Account_Address__c,RecordType]  
[Account_contact_relation, Account, Contact,LLC_BI__Loan__c,Account_Address__c,RecordType,LLC_BI__Loan__History,LLC_BI__Product_Package__c ] >> SFDC_Ing_End_Task
SFDC_Ing_End_Task >> SFDC_Ing_Trigger_Raw

