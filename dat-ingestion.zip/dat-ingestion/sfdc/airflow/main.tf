variable "lake_account_id" {type = string}
variable "environment" {type = string}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}


locals {
   account_id            = data.aws_caller_identity.current.account_id
   region_name           = data.aws_region.current.name
}



resource "aws_s3_object" "sfdc_to_ingestions_dags" {
  bucket =  "cobank-dl-${var.lake_account_id}-${local.region_name}-airflow-${var.environment}"
  key    = "dags/ingestion/salesforce/appflow_sfdc_to_ing_tasks.py"
  source = "${path.module}/appflow_sfdc_to_ing_tasks.py"
  source_hash = filemd5("${path.module}/appflow_sfdc_to_ing_tasks.py")
}

