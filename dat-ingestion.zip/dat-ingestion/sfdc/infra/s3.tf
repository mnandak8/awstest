variable "governance_account_id" { type = string }
variable "environment" { type = string }
variable "lake_account_id" { type = string }
variable "account_id" { type = string }
variable "region_name" { type = string }
variable "consumption_account_id" { type = string }



module "sfdc_ingestion_bucket" {
  #source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=main"
  source                    = "git::https://github.com/cobank-acb/dat-terraform-modules.git//s3?ref=v20241009.45"
  expiration_days           = 30
  resource_suffix           = "sfdc-asset"
  environment               = var.environment
  terra_factory_aws_id      = "dat-ing"
  log_bucket_name           = "cobank-dl-${var.account_id}-us-west-2-logs-${var.environment}"
  access_service_user_names = [    "appflow"]  
  outside_account_ids        = [var.lake_account_id,var.consumption_account_id,var.governance_account_id]
}





