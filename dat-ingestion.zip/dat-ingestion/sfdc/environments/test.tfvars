
vpc_name = "DA_TEST-vpc"
vpc_cidr_blocks_ingress= ["10.70.40.0/22"]
vpc_cidr_blocks_egress= ["10.70.40.0/22","10.70.32.0/22","10.70.38.0/23","10.64.0.7/32","10.64.0.105/32","10.72.0.32/32","10.72.0.113/32","10.64.0.121/32","10.64.0.19/32"]

sfdc_partner_source_name="aws.partner/salesforce.com/00D8M0000004edwUAA/ChangeEvents"

pg_secret_arn = "arn:aws:secretsmanager:us-west-2:905418335811:secret:cobank-dl-rds-user-secret-ods-svcsfdceventbridge-test-LjOck8" 

consumption_account_id="905418335811"
lake_account_id="767398005888"

email_address="mb_clouddataplatformsupport@cobank.com"
events_kms_key_name="alias/cust-kms-key-sfdc-events"
sfdc_event_security_name= "cobank-sfdc-events-security"

####DLQ SQS settings
visibility_timeout_seconds  = 1
delay_seconds               = 0
sqs_max_message_size            = 262144
##### 14 days = 1209600 seconds 
sqs_message_retention_seconds   = 1209600
sqs_receive_wait_time_seconds   = 20

##########################################################################################################################
# Events Retry POlicy                                                                                                    #
##The maximum number of hours to keep unprocessed events for. The default value is 24 hours.                             #
##The maximum number of times to retry sending an event to a target after an error occurs. The default value is 185 times#
##########################################################################################################################
maximum_event_age_in_seconds=300
maximum_retry_attempts =5
####################
lambda_invoke_congig_maximum_event_age_in_seconds = 60
lambda_invoke_congig_maximum_retry_attempts = 1

governance_account_id="590183999398"

