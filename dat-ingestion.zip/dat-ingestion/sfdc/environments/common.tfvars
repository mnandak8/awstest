
tags = {
        "cobank:cost-allocation:cost-center" = "8103"
        "cobank:operations:support-group" = "Transformation Programs"
        Splunk = true
}
resource_prefix = "cobank"
appflow_centralized_kms_key_arn                                    = "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"

objects = {
    "Account" = {}
    "Contact" = {}
    "LLC_BI__Loan__c" = {}
    "AccountContactRelation" = {}
    "Account_Address__c" = {}
    "RecordType" = {}
    "LLC_BI__Loan__History" = {}
    "LLC_BI__Product_Package__c"  = {}
}

