data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
}

module "sfdc-events" {
  source                                         = "./sfdcevents/event-objects"
  tags                                           = var.tags
  environment                                    = var.environment
  account_id                                     = local.account_id
  region_name                                    = local.region_name
  consumption_account_id                         = var.consumption_account_id
  lake_account_id                                = var.lake_account_id
  sfdc_partner_source_name                       = var.sfdc_partner_source_name
  visibility_timeout_seconds                     = var.visibility_timeout_seconds
  delay_seconds                                  = var.delay_seconds
  sqs_max_message_size                           = var.sqs_max_message_size
  sqs_message_retention_seconds                  = var.sqs_message_retention_seconds
  sqs_receive_wait_time_seconds                  = var.sqs_receive_wait_time_seconds
  maximum_event_age_in_seconds                   = var.maximum_event_age_in_seconds
  maximum_retry_attempts                         = var.maximum_retry_attempts
  email_address                                  = var.email_address
  vpc_name                                       = var.vpc_name
  vpc_cidr_blocks_ingress                        = var.vpc_cidr_blocks_ingress
  vpc_cidr_blocks_egress                         = var.vpc_cidr_blocks_egress
  pg_secret_arn                                  = var.pg_secret_arn
  events_kms_key_name                            = var.events_kms_key_name 
  sfdc_event_security_name                       = var.sfdc_event_security_name
  lambda_invoke_congig_maximum_event_age_in_seconds = var.lambda_invoke_congig_maximum_event_age_in_seconds
  lambda_invoke_congig_maximum_retry_attempts       =  var.lambda_invoke_congig_maximum_retry_attempts

}

module "sfdc-infra" {
  source                                         = "./infra"
  environment                                    = var.environment
  account_id                                     = local.account_id
  lake_account_id                                = var.lake_account_id
  consumption_account_id                         = var.consumption_account_id
  governance_account_id                          = var.governance_account_id
  region_name                                    = local.region_name
}

module "sfdc-appflows" {
  depends_on = [ module.sfdc-infra ]
  source        = "./appflow"
  appflow_centralized_kms_key_arn   = var.appflow_centralized_kms_key_arn
  env           = var.environment
  for_each      = var.objects
  sf_object     = each.key
  #create        = coalesce(each.value.create, false)
  columns2mask  = coalesce(each.value.columns2mask, [])
}

module "sfdc-airflow-dags" {
  depends_on = [ module.sfdc-appflows ]
  source        = "./airflow"
  environment           = var.environment
  lake_account_id                                = var.lake_account_id
}


