# Account specific values
resource_prefix = "cobank"
environment = "dev"


