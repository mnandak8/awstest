variable "tags" {type        = map(string)}
variable "dynamodb-consumption-full-access-policy" {type        = string}
variable "consumption_acct_id" {type        = string}
variable "glue_role_name" {type        = string}