resource "aws_iam_policy" "dynamodb-consumption-full-access" {
  name        = var.dynamodb-consumption-full-access-policy
  path        = "/"
  description = "Policy to access the dynamodb on Consummption"
  tags        = var.tags
  policy = jsonencode(
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Statement1",
            "Effect": "Allow",
            "Action": [
                "sts:AssumeRole"
            ],
            "Resource": [
                "arn:aws:iam::${var.consumption_acct_id}:role/cobank-crossacct-lake-dynamodbfullaccess"
            ]
        }
    ]
}
  )

}

resource "aws_iam_role_policy_attachment" "role-policy-attachment-dynamodb-consumption-full-access" {
  role       = var.glue_role_name
  policy_arn = aws_iam_policy.dynamodb-consumption-full-access.arn
}

