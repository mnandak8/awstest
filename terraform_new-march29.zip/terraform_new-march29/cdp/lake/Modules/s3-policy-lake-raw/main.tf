
resource "aws_s3_bucket_policy" "allow_access_from_another_account" {
  bucket = "cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}"
  policy = data.aws_iam_policy_document.allow_access_from_another_account.json
}

data "aws_iam_policy_document" "allow_access_from_another_account" {
  statement {
    sid    = "AllowAppFlowSourceActions"
    effect = "Allow"

    resources = [
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}",
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}/*"
    ]

    actions = ["s3:*"]

    principals {
      type        = "Service"
      identifiers = ["appflow.amazonaws.com"]
    }
  }
    statement {
    sid    = "LambdaSourceActions"
    effect = "Allow"

    resources = [
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}",
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}/*"
    ]

    actions = ["s3:*"]

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
  statement {
    sid    = "glueSourceActions"
    effect = "Allow"

    resources = [
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}",
      "arn:aws:s3:::cobank-dl-${var.account_id}-${var.region_name}-raw-${var.environment}/*"
    ]

    actions = ["s3:*"]

    principals {
      type        = "Service"
      identifiers = ["glue.amazonaws.com"]
    }
  }
}

  
