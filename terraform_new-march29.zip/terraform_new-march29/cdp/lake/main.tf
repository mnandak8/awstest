data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
}

module "mwaa" {
  source                 = "../../modules/mwaa"
  environment            = var.environment
  mwaa_domain            = var.mwaa_domain
  resource_prefix        = var.resource_prefix
  tags                   = var.tags
  account_id             = local.account_id
  region_name            = local.region_name
  mwaa_buckets           = var.mwaa_buckets
  vpc_id                 = var.vpc_id
  mwaa_role_name         = var.mwaa_role_name
  mwaa_env_name          = var.mwaa_env_name
  mwaa-data-app-subnets  = var.mwaa-data-app-subnets
  mwaa_airflow_version   = var.mwaa_airflow_version
  mwaa_environment_class = var.mwaa_environment_class
  mwaa_min_workers       = var.mwaa_min_workers
  mwaa_max_workers       = var.mwaa_max_workers
  mwaa_schedulers        = var.mwaa_schedulers
}


module "s3" {
  source      = "../../modules/s3"
  environment = var.environment
  domain      = var.domain
  #kms_key_arn_s3     = var.kms_key_arn_s3 
  resource_prefix = var.resource_prefix
  tags            = var.tags
  buckets         = var.buckets
  account_id      = local.account_id
  region_name     = local.region_name
}

module "glueroles" {
  source                      = "../../modules/glueroles"
  iam_policy_arn_glue_rds     = var.iam_policy_arn_glue_rds
  glue_role_name              = var.glue_role_name
  secrets_manager_read_policy = var.secrets_manager_read_policy
  tags                        = var.tags
}

module "crossacct-lake-dynamodbfullaccess-policy" {
  source                                  = "./modules/crossacct-lake-dynamodbfullaccess-policy"
  tags                                    = var.tags
  dynamodb-consumption-full-access-policy = var.dynamodb-consumption-full-access-policy
  consumption_acct_id                     = var.consumption_acct_id
   glue_role_name              = var.glue_role_name
}

module "s3-policy-lake-raw" {
  source             = "./modules/s3-policy-lake-raw"
  environment        = var.environment
  account_id         = local.account_id
  region_name        = local.region_name
}
module "s3-policy-lake-curated" {
  source             = "./modules/s3-policy-lake-curated"
  environment        = var.environment
  account_id         = local.account_id
  region_name        = local.region_name
}
module "s3-policy-lake-transformed" {
  source             = "./modules/s3-policy-lake-transformed"
  environment        = var.environment
  account_id         = local.account_id
  region_name        = local.region_name
}