# Account specific values
resource_prefix = "cobank"
environment = "dev"
tags = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Data Innovation" 
     } 

vpc_id="vpc-0aec90854aa575ce4"


#mwaa#
mwaa_domain     = "airflow"
mwaa-data-app-subnets = [ "subnet-02b21afc073915f0f","subnet-05c749df7b7f13083" ]                
mwaa_buckets = {
    "dags" = {
        versioning = true
        expiration = 2555
        transition = 365
        storage_class = "STANDARD_IA"
    }}
mwaa_role_name="mnk-delete-airflow-test-dontuse"
mwaa_env_name="mnk-delete-airflow-env-dontuse"
mwaa_airflow_version   = "2.8.1"
mwaa_environment_class = "mw1.medium"
mwaa_min_workers        = 10
mwaa_max_workers        = 20
mwaa_schedulers         = 5

#s3
#kms_key_arn_s3 ="arn:aws:kms:us-west-2:832576047628:key/127e0d23-fa10-497d-8c40-d074e2f808dc"
domain = "dl"
buckets = {
    "raw" = {
        versioning = true
        expiration = 2555
        transition = 365
        storage_class = "STANDARD_IA"
    }
     "transformed" = {
        versioning = true
        expiration = 2555
        transition = 365
        storage_class = "STANDARD_IA"
    }
     "curated" = {
        versioning = true
        expiration = 2555
        transition = 365
        storage_class = "STANDARD_IA"
    }
}

#glueroles
iam_policy_arn_glue_rds=["arn:aws:iam::654654598303:policy/KMSFullAccess","arn:aws:iam::aws:policy/AmazonRDSDataFullAccess","arn:aws:iam::aws:policy/AmazonS3FullAccess","arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole","arn:aws:iam::aws:policy/AWSKeyManagementServicePowerUser"]
glue_role_name="cobank-dev-glue-role"
secrets_manager_read_policy="cobank-dev-read-secrets-manager"

dynamodb-consumption-full-access-policy="cobank-dynamodb-consumption-full-access-policy"
consumption_acct_id="590184072445"
