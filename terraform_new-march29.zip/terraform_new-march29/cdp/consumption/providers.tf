variable "workspace_iam_roles" {
  default = {
    dev = "arn:aws:iam::590184072445:role/DataConsumptionDeploymentRole",
    test = "<role_arn>"
  }
}
provider "aws" {
  region = "us-west-2"
  assume_role {
    role_arn = var.workspace_iam_roles[terraform.workspace]
  }
  default_tags {
    tags = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Transformation Programs" 
     }
  } 
}