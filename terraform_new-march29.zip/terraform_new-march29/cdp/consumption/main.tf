data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
    account_id = data.aws_caller_identity.current.account_id
    region_name = data.aws_region.current.name
}

module "crossacct-dynamodb-fullaccess-role" {
  source                                           = "./modules/crossacct-dynamodb-fullaccess-role"
  environment        = var.environment
  account_id         = local.account_id
  crossacct_lake_dynamodbfullaccess_role_name      = var.crossacct_lake_dynamodbfullaccess_role_name
  iam_policy_arn_crossacct_lake_dynamodbfullaccess = var.iam_policy_arn_crossacct_lake_dynamodbfullaccess
  lake_account_id                                  = var.lake_account_id
  tags                                             = var.tags
}
