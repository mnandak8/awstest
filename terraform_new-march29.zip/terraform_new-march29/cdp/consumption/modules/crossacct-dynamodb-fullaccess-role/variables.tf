variable "account_id" {type        = string}
variable "environment" {type        = string}
variable "tags" {type        = map(string)}
variable "crossacct_lake_dynamodbfullaccess_role_name" {type        = string}
variable "iam_policy_arn_crossacct_lake_dynamodbfullaccess" { type = list(string) }
variable "lake_account_id" {type        = string}
