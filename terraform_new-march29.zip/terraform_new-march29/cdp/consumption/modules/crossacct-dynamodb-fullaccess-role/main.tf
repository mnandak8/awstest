
resource "aws_iam_role" "crossacct-lake-dynamodbfullaccess" {
  name = var.crossacct_lake_dynamodbfullaccess_role_name
  tags=var.tags
  assume_role_policy = <<EOF
{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Effect": "Allow",
			"Principal": {
				"AWS": "arn:aws:iam::${var.lake_account_id}:root"
			},
			"Action": "sts:AssumeRole",
			"Condition": {}
		}
	]
}
EOF
}

resource "aws_iam_role_policy_attachment" "role-policy-attachment_crossacct-lake-dynamodbfullaccess" {
  role       = aws_iam_role.crossacct-lake-dynamodbfullaccess.name
  count      = length(var.iam_policy_arn_crossacct_lake_dynamodbfullaccess)
  policy_arn = var.iam_policy_arn_crossacct_lake_dynamodbfullaccess[count.index]
}

