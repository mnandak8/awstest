# Account specific values
resource_prefix = "cobank"
environment = "dev"
tags = {
    "cobank:cost-allocation:cost-center"        = "8030",
    "cobank:operations:support-group"           = "Transformation Programs" 
     } 
  crossacct_lake_dynamodbfullaccess_role_name      = "cobank-crossacct-lake-dynamodbfullaccess"
  iam_policy_arn_crossacct_lake_dynamodbfullaccess = ["arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess"]
  lake_account_id                                  = "654654598303"