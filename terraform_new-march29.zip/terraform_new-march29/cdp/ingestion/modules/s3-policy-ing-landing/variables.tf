variable "environment" {type        = string}
variable "account_id" {type        = string}
variable "region_name" {type        = string}
variable "dat-lake-acct-id" {type        = string}
variable "dat-lake-glue-role" {type        = string}

