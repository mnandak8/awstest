
--RITM0307306 and RITM0307312 for service account approvals


CREATE ROLE svcacbsrepawsdbd WITH
 CREATEROLE
 CREATEDB
 INHERIT 
 LOGIN
 PASSWORD '56qddZ>u9J!^ab?WyqEHc<l39#yt'
 VALID UNTIL 'infinity' ;

CREATE ROLE svcglueacbsdbd WITH
 LOGIN
 PASSWORD '57qddZ>u9J!^ab?WyqEHc<l39#yt'
 VALID UNTIL 'infinity' ;
 grant pg_read_all_data to svcglueacbsdbd;
 
  


in the new ACBS DB
CREATE ROLE svcacbsrepawsdbd WITH
 CREATEROLE
 CREATEDB
 INHERIT 
 LOGIN
 PASSWORD '56qddZ>u9J!^ab?WyqEHc<l39#yt'
 VALID UNTIL 'infinity' ;
 
 GRANT rds_superuser TO svcacbsrepawsdbd;
 
 CREATE ROLE svclwrepawsdbd WITH
 INHERIT 
 LOGIN
 PASSWORD '56qddZ>u9J!^ab?WyqEHc<l39#yt'
 VALID UNTIL 'infinity' ;
 
 GRANT rds_superuser TO svcacbsrepawsdbd;