variable "resource_prefix" {
  type        = string
  description = "Prefix to be added for all resources"
}

variable "environment" {
  type        = string
}

variable "domain" {
  type        = string
}

variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "buckets" {
  type = map(object({
    versioning = bool
    expiration = number
    transition = number
    storage_class = string
  }))
}

variable "bucket_name_label" {
  type    = string
  default = "%s-%s-%s-%s-%s-%s" #resourceprefix-domain-awsaccountid-awsregion-bucketname-environment
}
/*
variable "kms_key_arn_s3" {
  type        = string
  description = "KMS key ARN for S3 SSE KMS"
}
*/
variable "bucket_key_enabled" {
  type        = string
  default     = "true"
  description = "Reduce calls to KMS by enabling bucket key"
}

variable "bucket_encryption" {
  type = map(string)
  default = {
    algorithm : "aws:kms"
    kms_id : ""
  }
}

variable "aurora_engine" {
    default = "aurora-postgresql"
}

variable "aurora_engine_version" {
    default = ""
}

variable "instance_class" {
    default = ""
}

variable "database_name" {
    default = ""
}

variable "master_username" {
    default = ""
}

variable "identifier" {
  default = "" 
}

variable "vpc_id" {
    type = string
    default = ""
}

variable "vpc_security_group_ids" {
    type = list
    default = []
}

variable "subnets" {
    type = list
    default = []
}

variable "db_subnet_group_name" {
  type = string
  default = ""
}

variable final_snapshot_identifier {
  type = string
  default = ""
}

variable "db_cluster_parameter_group_name" {
  type = string
  default = ""
}

variable "db_parameter_group_name" {
  type = string
  default = ""
}

variable "kms_key_id" {
  description = "The ARN for the KMS encryption key. When specifying `kms_key_id`, `storage_encrypted` needs to be set to `true`"
  type        = string
  default     = null
}

variable "vpc_cidr_blocks" {type =list}

variable "iam_policy_arn_glue_rds" { type = list(string) }
variable "glue_role_name" { type = string }
variable "secrets_manager_read_policy" { type = string }
variable "iam_policy_arn_lambda_rds" { type = list(string) }
variable "lambda_role_name" { type = string }
variable "iam_policy_arn_appflow_rds" { type = list(string) }
variable "appflow_role_name" { type = string }


#variable "sfdc_applflow_name" {type = string}
#variable "sfdc_applflow_kms_arn_name" {type = string}
variable "salesforce-client-credentials_sec_manager" {type = string}

##cross acct
variable "dat-lake-acct-id" {type        = string}
variable "dat-lake-glue-role" {type        = string}
variable "sfdc_instance_url" {type = string}

