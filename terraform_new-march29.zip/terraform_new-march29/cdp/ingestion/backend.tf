terraform {
  required_version = ">= 1.0.0"
  
  backend "s3" {
    bucket         = "cobank-tooling-891377330445-us-west-2-terraformstate"
    key            = "data-ingestion-accounts/terraform.tfstate"
    region         = "us-west-2"
    dynamodb_table = "cobank-tooling-891377330445-us-west-2-terraformlock"
  }
}