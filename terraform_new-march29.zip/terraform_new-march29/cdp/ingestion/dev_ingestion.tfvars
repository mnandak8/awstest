# Account specific values
resource_prefix = "cobank"
environment     = "dev"
tags = {
  "cobank:cost-allocation:cost-center" = "8030"
  "cobank:operations:support-group"    = "Transformation Programs"
}
# RDS specific values
aurora_engine                   = "aurora-postgresql"
aurora_engine_version           = "15.5"
instance_class                  = "db.r5.large"
database_name                   = "acbsdb"
master_username                 = "mstrrdsauadbd"
identifier                      = "acbs-db"
vpc_id                          = "vpc-067fafb824460e415"
subnets                         = ["subnet-044ada5821b98a75b", "subnet-0d557d556afa47606"]
db_subnet_group_name            = "acbs-subnet-group"
final_snapshot_identifier       = "acbs-final-snapshot"
db_cluster_parameter_group_name = "acbs-cluster-parameter-group"
db_parameter_group_name         = "acbs-instance-parameter-group"
kms_key_id                      = "arn:aws:kms:us-west-2:832576047628:key/d80ddc81-162a-488c-b9e1-b401d8ee35f7"
#vpc_cidr_blocks                = ["10.70.4.0/22","172.26.0.0/16","172.30.74.0/23","172.30.76.0/24","172.30.160.0/20","172.30.0.0/18","172.30.224.0/20","172.30.140.0/22","172.30.208.0/20"]
vpc_cidr_blocks                = ["10.70.4.0/22","0.0.0.0/0"]


# S3 specific values
domain = "dl"
buckets = {
  "landing" = {
    versioning    = true
    expiration    = 2555
    transition    = 365
    storage_class = "STANDARD_IA"
  }
}
#kms_key_arn_s3 = "arn:aws:kms:us-west-2:832576047628:key/127e0d23-fa10-497d-8c40-d074e2f808dc"
#glueroles
iam_policy_arn_glue_rds     = ["arn:aws:iam::471112929721:policy/KMSFullAccess", "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess", "arn:aws:iam::aws:policy/AmazonS3FullAccess", "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"]
glue_role_name              = "cobank-dev-glue-role"
secrets_manager_read_policy = "cobank-dev-read-secrets-manager"
iam_policy_arn_lambda_rds   = ["arn:aws:iam::471112929721:policy/cobank-dev-read-secrets-manager", "arn:aws:iam::471112929721:policy/KMSFullAccess", "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess", "arn:aws:iam::aws:policy/AmazonS3FullAccess", "arn:aws:iam::aws:policy/AWSLambda_FullAccess"]
lambda_role_name            = "cobank-dev-lambda-role"
iam_policy_arn_appflow_rds  = ["arn:aws:iam::471112929721:policy/cobank-dev-read-secrets-manager", "arn:aws:iam::471112929721:policy/KMSFullAccess", "arn:aws:iam::aws:policy/AmazonRDSDataFullAccess", "arn:aws:iam::aws:policy/AmazonS3FullAccess", "arn:aws:iam::aws:policy/AmazonAppFlowFullAccess"]
appflow_role_name           = "cobank-dev-appflow-role"

#appflow
#sfdc_applflow_kms_arn_name                = "arn:aws:kms:us-west-2:832576047628:key/9a1ed2df-9798-463f-a886-2ecee60bec2e"
sfdc_applflow_kms_arn_name                = "arn:aws:kms:us-west-2:471112929721:key/83e51210-8777-4f91-b079-a9030c59d817" 
#nanda's key" 
sfdc_applflow_name                        = "cobank-471112929721-sfdc-dev-connector"
salesforce-client-credentials_sec_manager = "salesforce-client-credentials-cdmintdev_test4"

#cross actt Glue
dat-lake-acct-id   = "654654598303"
dat-lake-glue-role = "cobank-dev-glue-role"
sfdc_instance_url = "https://cobank--cdmintdev.sandbox.my.salesforce.com"
