data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  account_id  = data.aws_caller_identity.current.account_id
  region_name = data.aws_region.current.name
}




module "s3" {
  source          = "../../modules/s3"
  environment     = var.environment
  domain          = var.domain
  #kms_key_arn_s3  = var.kms_key_arn_s3
  resource_prefix = var.resource_prefix
  tags            = var.tags
  buckets         = var.buckets
  account_id      = local.account_id
  region_name     = local.region_name
}

module "aurora_postgres_db" {
  source = "../../modules/rds"


  name           = format("%s-%s-%s", var.resource_prefix, var.environment, var.identifier)
  engine         = var.aurora_engine
  engine_version = var.aurora_engine_version
  instance_class = var.instance_class
  instances = {
    1 = {}
    2 = {
      instance_class = var.instance_class
    }
  }

  database_name   = var.database_name
  master_username = var.master_username
  port            = "5432"
  tags=var.tags
  iam_database_authentication_enabled = true

  publicly_accessible   = false
  create_security_group = true
  #security_group_rules = { ingress_postgressql_traffic =  var.ingress_postgressql_traffic
  vpc_cidr_blocks =var.vpc_cidr_blocks
  manage_master_user_password = true
  cluster_tags = var.tags
  # DB subnet group
  vpc_id                    = var.vpc_id
  create_db_subnet_group    = true
  db_subnet_group_name      = format("%s-%s-%s", var.resource_prefix, var.environment,  var.db_subnet_group_name)
  subnets                   = var.subnets
  final_snapshot_identifier = format("%s-%s-%s", var.resource_prefix, var.environment,  var.final_snapshot_identifier)

  # DB cluster parameter group
  create_db_cluster_parameter_group      = true
  db_cluster_parameter_group_family      = "aurora-postgresql15"
  db_cluster_parameter_group_description = "This is a cluster parameter group managed by terraform"
  db_cluster_parameter_group_name        = format("%s-%s-%s", var.resource_prefix, var.environment, var.db_cluster_parameter_group_name)

  # DB instance parameter group
  create_db_parameter_group      = true
  db_parameter_group_description = "This instance parameter group is managed by terraform and has query logging enabled"
  db_parameter_group_family      = "aurora-postgresql15"
  db_parameter_group_name        = format("%s-%s-%s", var.resource_prefix, var.environment, var.db_parameter_group_name)
  db_parameter_group_parameters = [{
    name  = "log_statement"
    value = "all"
    },
    {
      name  = "log_min_duration_statement"
      value = "1"
  }]


  enabled_cloudwatch_logs_exports        = ["postgresql"]
  cloudwatch_log_group_retention_in_days = 365

  monitoring_interval     = 5
  deletion_protection     = true
  backup_retention_period = 30
  storage_encrypted       = true
  kms_key_id              = var.kms_key_id
}

module "glueroles" {
  source                      = "../../modules/glueroles"
  iam_policy_arn_glue_rds     = var.iam_policy_arn_glue_rds
  glue_role_name              = var.glue_role_name
  secrets_manager_read_policy = var.secrets_manager_read_policy
  tags                        = var.tags
}

module "lambdaroles" {
  source                      = "../../modules/lambdaroles"
  iam_policy_arn_lambda_rds   = var.iam_policy_arn_lambda_rds
  lambda_role_name            = var.lambda_role_name
  secrets_manager_read_policy = var.secrets_manager_read_policy
  tags                        = var.tags
}

/*
module "appflowroles" {
  source                      = "../../modules/appflowroles"
  iam_policy_arn_appflow_rds  = var.iam_policy_arn_appflow_rds
  appflow_role_name           = var.appflow_role_name
  secrets_manager_read_policy = var.secrets_manager_read_policy
  tags                        = var.tags
}


module "sfdcappflow" {
  source                                    = "../../modules/sfdcappflow"
  environment                               = var.environment
  sfdc_applflow_name                        = var.sfdc_applflow_name
  tags                                      = var.tags
  salesforce-client-credentials_sec_manager = var.salesforce-client-credentials_sec_manager
  sfdc_instance_url =var.sfdc_instance_url
  sfdc_applflow_kms_arn_name=var.sfdc_applflow_kms_arn_name
} 
*/

module "s3-policy-ing-landing" {
  source             = "./modules/s3-policy-ing-landing"
  environment        = var.environment
  account_id         = local.account_id
  region_name        = local.region_name
  dat-lake-acct-id   = var.dat-lake-acct-id
  dat-lake-glue-role = var.dat-lake-glue-role
}


