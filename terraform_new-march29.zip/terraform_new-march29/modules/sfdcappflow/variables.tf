variable "tags" {type        = map(string)}
variable "environment" {type        = string}
variable "sfdc_applflow_name" {type = string}
variable "sfdc_applflow_kms_arn_name" {type = string}
variable "salesforce-client-credentials_sec_manager" {type        = string}
variable "sfdc_instance_url" {type = string}



