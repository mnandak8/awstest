
resource "aws_secretsmanager_secret" "salesforce_credentials" {
              name = var.salesforce-client-credentials_sec_manager
              tags = var.tags
              kms_key_id =  var.sfdc_applflow_kms_arn_name

}
resource "aws_secretsmanager_secret_version" "salesforce_credentials_version" {
              secret_id = aws_secretsmanager_secret.salesforce_credentials.id
              secret_string = jsonencode({ key1 = "33", key2 = "44" }) 
}


resource "aws_secretsmanager_secret_policy" "salesforce_credentials_policy" {
  secret_arn = aws_secretsmanager_secret.salesforce_credentials.arn
  policy     = jsonencode(
  {
  "Version" : "2012-10-17",
  "Statement" : [ {
    "Effect" : "Allow",
    "Principal" : {
      "Service" : "appflow.amazonaws.com"
    },
    "Action" : [ "secretsmanager:GetSecretValue", "secretsmanager:PutSecretValue", "secretsmanager:DeleteSecret", "secretsmanager:DescribeSecret", "secretsmanager:UpdateSecret" ],
    "Resource" : "*"
  },
  {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::471112929721:role/DataIngestionDeploymentRole"
      },
      "Action": "secretsmanager:GetSecretValue",
      "Resource": "*"
    },
      {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::471112929721:role/cobank-dev-appflow-role"
      },
      "Action": "secretsmanager:GetSecretValue",
      "Resource": "*"
    }
   ]
} 
  )
}

resource "aws_appflow_connector_profile" "sfdc_appflow" {
name = var.sfdc_applflow_name
connector_type = "Salesforce"
kms_arn=var.sfdc_applflow_kms_arn_name
connection_mode       = "Public" 
connector_profile_config {

    connector_profile_credentials {
       salesforce {
        client_credentials_arn=aws_secretsmanager_secret.salesforce_credentials.arn
        #client_credentials_arn="arn:aws:secretsmanager:us-west-2:471112929721:secret:salesforce-client-credential-cdmintdev-wWF0h0"
        #client_credentials_arn="arn:aws:secretsmanager:us-west-2:471112929721:secret:RDSdevACBSDB-ETL-xCf4XY"
        oauth2_grant_type="CLIENT_CREDENTIALS"    
      }
    }
    connector_profile_properties {
      salesforce {
        is_sandbox_environment=true
       # instance_url = "https://cobank--cdmintdev.sandbox.my.salesforce.com"
        instance_url = var.sfdc_instance_url
  
      }
    }
  }
}
