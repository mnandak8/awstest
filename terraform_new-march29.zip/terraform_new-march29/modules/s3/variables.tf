variable "resource_prefix" {
  type        = string
  description = "Prefix to be added for S3 buckets"
}

variable "environment" {
  type        = string
}

variable "domain" {
  type        = string
}

variable "tags" {
  description = "Mandatory normalized tags to tag the resources accordingly."
  type        = map(string)
}

variable "buckets" {
  type = map(object({
    versioning = bool
    expiration = number
    transition = number
    storage_class = string
  }))
}

variable "bucket_name_label" {
  type    = string
  default = "%s-%s-%s-%s-%s-%s" #resourceprefix-domain-awsaccountid-awsregion-bucketname-environment
}

variable "region_name" {
  type        = string
  description = "AWS Region name"
}

/*variable "kms_key_arn_s3" {
  type        = string
  description = "KMS key ARN for S3 SSE KMS"
} */

variable "account_id" {
  type        = string
  description = "AWS account id."
}

variable "bucket_key_enabled" {
  type        = string
  default     = "true"
  description = "Reduce calls to KMS by enabling bucket key"
}

variable "bucket_encryption" {
  type = map(string)
  default = {
    #algorithm : "aws:kms" 
    algorithm : "AES256"
    kms_id : ""
  }
}