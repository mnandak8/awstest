output "buckets" {
  value = aws_s3_bucket.datalake_buckets
}


output "bucket_access_logs" {
  value = {
    bucket = aws_s3_bucket.datalake_access_log_bucket.bucket
    arn    = aws_s3_bucket.datalake_access_log_bucket.arn
  }
}