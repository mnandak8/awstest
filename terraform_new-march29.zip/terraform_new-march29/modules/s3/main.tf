resource "aws_s3_bucket" "datalake_access_log_bucket" {
  bucket = format(var.bucket_name_label, var.resource_prefix, var.domain , var.account_id, var.region_name, "logs", var.environment)
  tags = var.tags
}

resource "aws_s3_bucket_public_access_block" "datalake_access_log_bucket" {

  bucket = aws_s3_bucket.datalake_access_log_bucket.bucket

  block_public_acls       = true
  block_public_policy     = true
  restrict_public_buckets = true
  ignore_public_acls      = true
}

resource "aws_s3_bucket_versioning" "datalake_access_log_bucket" {
  bucket = aws_s3_bucket.datalake_access_log_bucket.bucket

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "datalake_access_log_bucket" {
  bucket = aws_s3_bucket.datalake_access_log_bucket.bucket

  rule {
    bucket_key_enabled = var.bucket_key_enabled
    apply_server_side_encryption_by_default {
      sse_algorithm     = var.bucket_encryption["algorithm"]
      #kms_master_key_id = var.kms_key_arn_s3
    }
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "datalake_access_log_bucket" {
  bucket = aws_s3_bucket.datalake_access_log_bucket.bucket

  rule {

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
      }

    id = "datalake-logs-expiration"

    expiration {
      days = 7
    }

    status = "Enabled"
  }
}

## Data Lake Landing Layer
resource "aws_s3_bucket" "datalake_buckets" {
  for_each = var.buckets
  bucket = format(var.bucket_name_label, var.resource_prefix, var.domain, var.account_id, var.region_name, each.key, var.environment)
  tags = var.tags
}

resource "aws_s3_bucket_public_access_block" "datalake_buckets" {
  for_each = aws_s3_bucket.datalake_buckets

  bucket = each.value.bucket

  block_public_acls       = true
  block_public_policy     = true
  restrict_public_buckets = true
  ignore_public_acls      = true
}

resource "aws_s3_bucket_versioning" "datalake_buckets" {
  for_each = aws_s3_bucket.datalake_buckets

  bucket = each.value.bucket

  versioning_configuration {
    status = var.buckets[each.key].versioning == true ? "Enabled" : "Disabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "datalake_buckets" {
  for_each = aws_s3_bucket.datalake_buckets

  bucket = each.value.bucket

  rule {
    bucket_key_enabled = var.bucket_key_enabled
    apply_server_side_encryption_by_default {
      sse_algorithm     = var.bucket_encryption["algorithm"]
     #kms_master_key_id = var.kms_key_arn_s3
    }
  }
}

resource "aws_s3_bucket_logging" "datalake_buckets" {
  for_each = aws_s3_bucket.datalake_buckets

  bucket        = each.value.bucket
  target_bucket = aws_s3_bucket.datalake_access_log_bucket.id
  target_prefix = format("%s/%s", "log", "${each.key}")
}

resource "aws_s3_bucket_lifecycle_configuration" "datalake_landing_buckets" {
  for_each = aws_s3_bucket.datalake_buckets

  bucket = aws_s3_bucket.datalake_buckets[each.key].id

  rule {

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
      }

    id = format("%s-%s-%s", var.resource_prefix,each.key,"bucket-lifecycle-rule")

    transition {
      days          = var.buckets[each.key].transition
      storage_class = "STANDARD_IA"
    }

    expiration {
      days = var.buckets[each.key].expiration
    }

    status = "Enabled"
  }
}