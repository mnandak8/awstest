resource "aws_s3_bucket" "mwaa_s3_bucket" {
  bucket = format(var.bucket_name_label,var.resource_prefix, var.mwaa_domain, var.account_id, var.region_name, var.environment)
    tags = var.tags
}

resource "aws_s3_bucket_public_access_block" "mwaa_s3_bucket" {

  bucket = aws_s3_bucket.mwaa_s3_bucket.bucket

  block_public_acls       = true
  block_public_policy     = true
  restrict_public_buckets = true
  ignore_public_acls      = true
}

resource "aws_s3_bucket_versioning" "mwaa_s3_bucket" {
  bucket = aws_s3_bucket.mwaa_s3_bucket.bucket
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "mwaa_s3_bucket" {
  bucket  = aws_s3_bucket.mwaa_s3_bucket.bucket
  rule {
    bucket_key_enabled = var.bucket_key_enabled
    apply_server_side_encryption_by_default {
      sse_algorithm     = "AES256"
      #kms_master_key_id = var.mwaa_kms_key_arn
    }
  }
}

/*
resource "aws_security_group" "mwaa_security_grp" {
  name        = "cobank-airflow-allow-traffic"
  description = "Allow Traffic for the airflow"
  vpc_id      = var.vpc_id
   tags =  var.tags
}

resource "aws_security_group_rule" "mwaa_security_grp_inr1" {
    type              = "ingress"
    security_group_id =  aws_security_group.mwaa_security_grp.id
    from_port        = 0
    to_port          = 65535
    protocol         = "All"
    cidr_blocks      = ["0.0.0.0/0"]
  }

resource "aws_security_group_rule" "mwaa_security_grp_egr1" {
    type              = "egress"
    security_group_id =  aws_security_group.mwaa_security_grp.id
    from_port        = 0
    to_port          = 65535
    protocol         = "All"
    cidr_blocks      = ["0.0.0.0/0"]
  }
*/
  resource "aws_mwaa_environment" "mwaa_env" {
  
  name              = var.mwaa_env_name
  airflow_version   = var.mwaa_airflow_version
  environment_class = var.mwaa_environment_class
  min_workers        =var.mwaa_min_workers
  max_workers        =var.mwaa_max_workers
  schedulers         =var.mwaa_schedulers
  webserver_access_mode = "PUBLIC_ONLY"
  source_bucket_arn = aws_s3_bucket.mwaa_s3_bucket.arn
  dag_s3_path        = "dags/"
  execution_role_arn = aws_iam_role.mwaa_create_role.arn
  weekly_maintenance_window_start = "SUN:23:30"


  network_configuration {
    security_group_ids = ["sg-01074154434553ff6"]
    subnet_ids         = var.mwaa-data-app-subnets
  }

   logging_configuration {
    dag_processing_logs {
      enabled   = true 
      log_level = "DEBUG" 
      }
    scheduler_logs {
      enabled   = true
      log_level = "INFO"
    }
    task_logs {
      enabled   = true
      log_level = "WARNING" 
    }
    webserver_logs {
      enabled   = true
      log_level = "ERROR"
    }
    worker_logs {
      enabled   = true
      log_level = "CRITICAL"
    }
  }
}

resource "aws_iam_role" "mwaa_create_role" {
  name = var.mwaa_role_name
  assume_role_policy    = data.aws_iam_policy_document.mwaa_assume.json
}

resource "aws_iam_role_policy" "mwaa_role-policy" {
  name = "cobank-mwaa-execution-policy"
  role   = aws_iam_role.mwaa_create_role.id
  policy = data.aws_iam_policy_document.execution_role_policy.json
}



data "aws_iam_policy_document" "execution_role_policy" {
  version = "2012-10-17"
  statement {
    effect = "Allow"
    actions = [
      "airflow:PublishMetrics"
    ]
    resources = [
      "arn:aws:airflow:${var.region_name}:${var.account_id}:environment/${var.mwaa_env_name}*"
      
    ]
  }
  statement {
    effect  = "Deny"
    actions = ["s3:ListAllMyBuckets"]
    resources = [
       "arn:aws:s3:::${var.resource_prefix}-${var.mwaa_domain}-${var.account_id}-${var.region_name}-${var.environment}",
       "arn:aws:s3:::${var.resource_prefix}-${var.mwaa_domain}-${var.account_id}-${var.region_name}-${var.environment}/*"
      
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject*",
      "s3:GetBucket*",
      "s3:List*"
    ]
    resources = [
      "arn:aws:s3:::${var.resource_prefix}-${var.mwaa_domain}-${var.account_id}-${var.region_name}-${var.environment}",
      "arn:aws:s3:::${var.resource_prefix}-${var.mwaa_domain}-${var.account_id}-${var.region_name}-${var.environment}/*"
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "s3:GetAccountPublicAccessBlock"
    ]
    resources = ["*"]
  }
  statement {
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:CreateLogGroup",
      "logs:PutLogEvents",
      "logs:GetLogEvents",
      "logs:GetLogRecord",
      "logs:GetLogGroupFields",
      "logs:GetQueryResults"
    ]
    resources = [
      "arn:aws:logs:${var.region_name}:${var.account_id}:log-group:airflow-${var.mwaa_env_name}-*"
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "logs:DescribeLogGroups"
    ]
    resources = [
      "*"
    ]
  }
  statement {

    effect = "Allow"
    actions = [
      "cloudwatch:PutMetricData"
    ]
    resources = [
      "*"
    ]
  }
  statement {
    effect = "Allow"
    actions = [
      "sqs:ChangeMessageVisibility",
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes",
      "sqs:GetQueueUrl",
      "sqs:ReceiveMessage",
      "sqs:SendMessage"
    ]
    resources = [
      "arn:aws:sqs:${var.region_name}:*:airflow-celery-*"
    ]
  }
statement {
    sid       = ""
    effect    = "Allow"
    resources =  ["arn:aws:kms:${var.region_name}:${var.account_id}:key/*"]
    actions = [
      "kms:Decrypt",
      "kms:DescribeKey",
      "kms:GenerateDataKey*",
      "kms:Encrypt",
    ]
  
    condition {
      test     = "StringLike"
      variable = "kms:ViaService"

      values = [
        "sqs.us-west-2.amazonaws.com",
        "s3.us-west-2.amazonaws.com",
      ]
    }
  }
}


data "aws_iam_policy_document" "mwaa_assume" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["airflow.amazonaws.com"]
    }

    principals {
      type        = "Service"
      identifiers = ["airflow-env.amazonaws.com"]
    }

    principals {
      type        = "Service"
      identifiers = ["batch.amazonaws.com"]
    }

    principals {
      type        = "Service"
      identifiers = ["ssm.amazonaws.com"]
    }
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }
  }
}