variable "environment" { type        = string}
variable "resource_prefix" {  type        = string}
variable "mwaa_domain" {  type        = string}
variable "account_id" {type        = string}
variable "region_name" {type        = string}
variable "tags" { type        = map(string)}
variable "bucket_key_enabled" {
  type        = string
  default     = "true"
  description = "Reduce calls to KMS by enabling bucket key"
}
variable "mwaa_buckets" {
  type = map(object({
    versioning = bool
    expiration = number
    transition = number
    storage_class = string
  }))
}
variable "bucket_name_label" {
  type    = string
  default = "%s-%s-%s-%s-%s" #resourceprefix-domain-awsaccountid-awsregion-bucketname-environment
}
variable "vpc_id" {type        = string}
variable "mwaa_role_name" {type        = string}
variable "mwaa_env_name" {type        = string}
variable "mwaa-data-app-subnets" {type        = list}
variable "mwaa_airflow_version" {type        = string}
variable "mwaa_environment_class" {type    = string}
variable "mwaa_min_workers" { type        = number}
variable "mwaa_max_workers" { type        = number}
variable "mwaa_schedulers" { type        = number}