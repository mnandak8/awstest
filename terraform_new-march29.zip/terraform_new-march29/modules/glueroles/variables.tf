
variable "iam_policy_arn_glue_rds" { type = list(string) }
variable "glue_role_name" { type = string }
variable "secrets_manager_read_policy" { type = string }
variable "tags" {type        = map(string)}
