resource "aws_iam_policy" "secrets_manager_read_policy" {
  name        = var.secrets_manager_read_policy
  path        = "/"
  description = "Access The Secrets Manager "
  tags= var.tags
  policy = jsonencode(
  {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetResourcePolicy",
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
                "secretsmanager:ListSecretVersionIds",
                "secretsmanager:ListSecrets"
            ],
            "Resource": [
                "*"
            ]
        }
    ]
}
  )
}
resource "aws_iam_role" "create_role_glue_rds" {
  name = var.glue_role_name
  tags=var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "glue.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

resource "aws_iam_role_policy_attachment" "role-policy-attachment_glue_rds" {
  role       = aws_iam_role.create_role_glue_rds.name
  count      = length(var.iam_policy_arn_glue_rds)
  policy_arn = var.iam_policy_arn_glue_rds[count.index]
}
resource "aws_iam_role_policy_attachment" "role-policy-attachment_glue_rds_secret" {
  role       = aws_iam_role.create_role_glue_rds.name
  policy_arn = aws_iam_policy.secrets_manager_read_policy.arn
}

