
variable "secrets_manager_read_policy" { type = string }
variable "tags" {type        = map(string)}
variable "iam_policy_arn_lambda_rds" { type = list(string) }
variable "lambda_role_name" { type = string }


