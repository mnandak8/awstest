
resource "aws_iam_role" "create_role_lambda_rds" {
  name = var.lambda_role_name
  tags=var.tags
  assume_role_policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "lambda.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
}

resource "aws_iam_role_policy_attachment" "role-policy-attachment_lambda_rds" {
  role       = aws_iam_role.create_role_lambda_rds.name
  count      = length(var.iam_policy_arn_lambda_rds)
  policy_arn = var.iam_policy_arn_lambda_rds[count.index]
}


