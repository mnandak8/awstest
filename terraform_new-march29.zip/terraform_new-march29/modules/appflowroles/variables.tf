
variable "iam_policy_arn_appflow_rds" { type = list(string) }
variable "appflow_role_name" { type = string }
variable "secrets_manager_read_policy" { type = string }
variable "tags" {type        = map(string)}


